class AutoWorldRegister(type):
    world_types = {}
