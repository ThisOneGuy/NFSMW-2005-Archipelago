from .AutoWorld import AutoWorldRegister
network_data_package = {"games": {"Need for Speed: Most Wanted": {
    "item_name_to_id": {}, "location_name_to_id": {}, "checksum": ""}}}
