from __future__ import annotations
from collections import deque
import csv
import logging
from pathlib import Path
import re
import time

BUILD='1.0.1'
HINT_STATUS={0:'Unspecified',10:'No priority',20:'Avoid',30:'Priority',40:'Found'}
ROUTINE_NFSMW={'<module>','__init__','_load_state','configure_isolated_ap_session',
    'ensure_game_launched','wait_for_game_bridge','sync_slot_save','refresh_setup_state',
    'scout_shop_locations','accept_location_preview','process_location_info','replay_seed_config',
    'configure_deathlink','main'}


def field(row,name,default=''):
    return row.get(name,default) if isinstance(row,dict) else getattr(row,name,default)


def number(value,default=0):
    try:return int(value)
    except (TypeError,ValueError):return default


def hint_items(ctx):
    game=getattr(getattr(ctx,'slot_info',{}).get(getattr(ctx,'slot',None)),'game',None) or getattr(ctx,'game','')
    try:
        names={str(name) for item,name in ctx.item_names[game].items() if number(item)!=1950006}
    except (KeyError,TypeError,AttributeError):names=set()
    if not names:
        names={str(field(meta,'name')) for meta in getattr(ctx,'item_manifest',{}).values() if field(meta,'name')}
    return sorted(name for name in names if name and len(name)<=500 and not any(ord(c)<32 for c in name))


def blank_snapshot(assets):
    assets=Path(assets)
    with (assets/'NFSMW_ShopLocations.csv').open(encoding='utf-8-sig',newline='') as stream:
        shops=[{'location_id':int(r['id']),'location_type':r['type'],'location_name':r['name'],
                'car':r['car'],'category':r['category'],'tier':r['tier'],'price':None,
                'item_name':'Not scouted yet','recipient_name':'','checked':False,'hinted':False,
                'received':False,'status':'Waiting for game data','flags':0} for r in csv.DictReader(stream)]
    with (assets/'NFSMW_ItemManifest.csv').open(encoding='utf-8-sig',newline='') as stream:
        cars=sorted({r['car'] for r in csv.DictReader(stream) if r['type']=='car'})
    return {'schema':1,'build':BUILD,'session_id':'','available':False,'connected':False,
            'server':'','slot':'','slot_id':None,'seed':'','team':None,'goal':False,'checks':0,'total_checks':0,
            'received_count':0,'hint_points':0,'hint_cost':0,'form_open':False,'cars':[{'name':c,'received':False} for c in cars],
            'shops':shops,'hints':[],'hint_items':[],'text':[]}


class ViewLog(logging.Handler):
    def __init__(self):
        super().__init__(logging.INFO)
        self.records=deque(maxlen=400);self.sequence=0
    def emit(self,record):
        try:
            message=re.sub(r'\x1b\[[0-9;]*m','',record.getMessage())[:4096]
            if record.levelno<logging.WARNING:
                if record.name=='NFSMW':
                    if record.funcName in ROUTINE_NFSMW:return
                    if record.funcName=='on_package' and not message.startswith('Received item'):return
                    if record.funcName=='server_auth' and message.startswith('RoomInfo received'):return
                    if record.funcName=='handle_game_connection' and not message.startswith(
                            ('Game confirmed delivery','Game race result','NFSMW ASI disconnected')):return
                if record.name=='Client' and (record.funcName in (
                        'consume_network_data_package','update_permissions','process_server_cmd','run_cli') or
                        record.funcName=='server_loop' and message.startswith(
                            ('Please connect to','Connecting to','Connected'))):return
            self.sequence+=1
            self.records.append({'id':self.sequence,'time':time.strftime('%H:%M:%S',time.localtime(record.created)),
                                 'channel':record.name,'level':record.levelname,'text':message})
        except Exception:pass
    def install(self):
        for name in ('Client','NFSMW','StreamLog'):logging.getLogger(name).addHandler(self)
    def uninstall(self):
        for name in ('Client','NFSMW','StreamLog'):logging.getLogger(name).removeHandler(self)


def hint_rows(ctx):
    rows=[]
    values={}
    prefix=f'_read_hints_{ctx.team}_'
    for key,entries in getattr(ctx,'stored_data',{}).items():
        if key.startswith(prefix) and isinstance(entries,(list,tuple,set)):
            for hint in entries:
                identity=tuple(number(field(hint,k)) for k in ('finding_player','location','receiving_player','item'))
                previous=values.get(identity)
                if previous is None or field(hint,'found',False) or number(field(hint,'status'))==40:
                    values[identity]=hint
    for hint in values.values():
        receiving=number(field(hint,'receiving_player'));finding=number(field(hint,'finding_player'))
        location=number(field(hint,'location'));item=number(field(hint,'item'))
        found=bool(field(hint,'found',False)) or number(field(hint,'status'))==40;status=40 if found else number(field(hint,'status'))
        try:item_name=ctx.item_names.lookup_in_slot(item,receiving)
        except (KeyError,AssertionError,AttributeError):item_name=f'Item {item}'
        try:location_name=ctx.location_names.lookup_in_slot(location,finding)
        except (KeyError,AssertionError,AttributeError):location_name=f'Location {location}'
        rows.append({'receiving_player':receiving,'finding_player':finding,'location':location,'item':item,
                     'item_name':item_name,'location_name':location_name,
                     'recipient_name':ctx.player_names.get(receiving,f'Player {receiving}'),
                     'finder_name':ctx.player_names.get(finding,f'Player {finding}'),
                     'entrance':str(field(hint,'entrance')),'found':found,'status':status,
                     'status_name':HINT_STATUS.get(status,'Unspecified'),
                     'can_update':False})
    return sorted(rows,key=lambda r:(r['found'],r['recipient_name'].casefold(),r['item_name'].casefold(),r['location']))


def blacklist_rows(ctx):
    names=('Sonny','Taz','Vic','Izzy','Big Lou','Baron','Earl','Jewels','Kaze','Ming','Webster','JV','Ronnie','Bull','Razor')
    received={number(field(item,'item')) for item in ctx.items_received}
    defeated=getattr(ctx,'_verified_defeated_ranks',lambda:set())()
    return [{'rank':rank,'name':names[15-rank],'unlocked':1300000+rank in received,'defeated':rank in defeated}
            for rank in range(15,0,-1)]


def snapshot(ctx,log,session_id):
    connected=bool(ctx.ap_connected())
    hints=hint_rows(ctx)
    hinted={r['location'] for r in hints if r['finding_player']==ctx.slot}
    received=set();received_cars=set();cars=set()
    received_ids=set();receipts=set()
    for meta in ctx.item_manifest.values():
        if meta.item_type=='car':cars.add(meta.car)
    for item in ctx.items_received:
        item_id=number(field(item,'item'));received_ids.add(item_id)
        receipts.add((item_id,number(field(item,'location')),number(field(item,'player'))))
        meta=ctx.item_manifest.get(item_id)
        if meta:
            received.add((meta.item_type,meta.car,meta.category,meta.tier))
            if meta.item_type=='car':received_cars.add(meta.car)
    checked=set(ctx.checked_locations)|set(getattr(ctx,'won_race_locations',set()))
    queued=set(getattr(ctx,'queued_location_checks',set()))|set(getattr(ctx,'pending_checks',set()))
    server_locations=set(ctx.server_locations)
    shops=[]
    for location_id,meta in sorted(ctx.shop_locations.items()):
        entry=ctx.shop_catalog.get(location_id,{})


        bought=location_id in checked
        in_seed=not server_locations or location_id in server_locations
        kind='car' if meta.location_type=='dealership' else 'performance_part'
        owned=(kind,meta.car,meta.category,meta.tier) in received
        reward_id=number(entry.get('item_id'));recipient=number(entry.get('recipient_player'))
        reward_meta=ctx.item_manifest.get(reward_id)
        own_reward=recipient==ctx.slot
        reward_received=own_reward and ((reward_id,location_id,ctx.slot) in receipts or
            reward_id in received_ids and reward_meta is not None and reward_meta.item_type in ('car','performance_part'))
        reward_status=('Unrevealed' if not reward_id else 'Received' if reward_received else
            'Sent' if not own_reward and bought else 'Other player' if not own_reward else
            'Awaiting delivery' if bought else 'Not received')
        item_name=str(entry.get('item_name','Not scouted yet'))
        if entry.get('item_id') and entry.get('recipient_player') in ctx.slot_info:
            try:item_name=ctx.item_names.lookup_in_slot(entry['item_id'],entry['recipient_player'])
            except (KeyError,AssertionError,AttributeError):pass
        status=('Not in seed' if not in_seed else 'Checked' if bought else 'Syncing check' if location_id in queued
                else 'Unchecked' if entry else 'Waiting for game data')
        shops.append({'location_id':location_id,'location_type':meta.location_type,'location_name':meta.location_name,
                      'car':meta.car,'category':meta.category,'tier':meta.tier,'price':entry.get('price'),
                      'item_name':item_name,'recipient_name':str(entry.get('recipient_name','')),
                      'recipient_game':str(entry.get('recipient_game','')),'item_id':entry.get('item_id'),
                      'checked':bought,'hinted':location_id in hinted,'received':owned,
                      'reward_received':reward_received,'reward_status':reward_status,'unlock_received':owned,
                      'status':status,'flags':number(entry.get('flags'))})
    return {'schema':1,'build':BUILD,'session_id':session_id,'available':True,'connected':connected,
            'capabilities':['website_links','read_only_hint_status','shared_hints','hint_requests'],
            'connection_phase':str(getattr(ctx,'connection_message',{}).get('phase','input')),
            'connection_message':str(getattr(ctx,'connection_message',{}).get('message','')),
            'session_bound':bool(getattr(ctx,'session_key','') or getattr(ctx,'game_ready_pids',set())),
            'server':str(getattr(ctx,'requested_server','')),'slot':str(ctx.slot_name),'slot_id':ctx.slot,
            'seed':str(getattr(ctx,'session_seed_name','') or getattr(ctx,'server_seed_name','') or ''),
            'team':ctx.team,'goal':bool(ctx.finished_game),'checks':len(ctx.checked_locations),
            'form_open':bool(getattr(ctx,'connection_screen',None) is not None
                             and not ctx.connection_screen.closed and not getattr(ctx.connection_screen,'hidden_for_game',False)),
            'total_checks':len(server_locations),'received_count':len(ctx.items_received),
            'hint_points':number(getattr(ctx,'hint_points',0)),'hint_cost':number(getattr(ctx,'hint_cost',0)),
            'cars':[{'name':c,'received':c in received_cars} for c in sorted(cars)],
            'blacklist_randomized':bool(getattr(ctx,'slot_data',{}).get('randomize_blacklist_unlocks',False)),
            'blacklist_current':getattr(ctx,'current_blacklist_rank',None),'blacklist':blacklist_rows(ctx),
            'shops':shops,'hints':hints,'hint_items':hint_items(ctx),'text':list(log.records)}


async def perform_action(ctx,request):
    if not ctx.ap_connected():return {'ok':False,'error':'Disconnected from your Archipelago session.'}
    action=request.get('action')
    if action=='hint_request':
        name=request.get('item')
        if not isinstance(name,str) or name not in hint_items(ctx):
            return {'ok':False,'operation':action,'error':'Select an exact item from the matching items list.'}
        message='!hint '+name
        try:
            await ctx.send_msgs([{'cmd':'Say','text':message}])
            if not ctx.ap_connected():raise ConnectionError('Disconnected during hint request')
        except (OSError,RuntimeError):
            return {'ok':False,'operation':action,'error':'Could not send the hint request. Check your connection and retry.'}
        logging.getLogger('Client').info('You: %s',message)
        return {'ok':True,'operation':action,'item':name,
                'message':'Hint requested. Server replies also appear in Archipelago.'}
    if action=='command':
        value=request.get('text')
        if not isinstance(value,str) or not value.strip() or len(value)>512 or any(ord(c)<32 for c in value):
            return {'ok':False,'error':'Enter one message of 1–512 characters.'}
        if value.split()[0].casefold() in ('/connect','/disconnect','/exit','/quit'):
            return {'ok':False,'error':'The connection is managed by the game-folder client.'}
        logging.getLogger('Client').info('You: %s',value)
        ctx.command_processor(ctx)(value)
        return {'ok':True}
    if action=='reveal':
        location=number(request.get('location'))
        if location not in ctx.shop_locations or location not in ctx.server_locations:
            return {'ok':False,'error':'Choose a location in this game.'}
        revealed=ctx.__dict__.setdefault('revealed_hint_locations',set())
        manual=ctx.__dict__.setdefault('manual_hint_locations',set())
        seen=ctx.__dict__.setdefault('seen_locations',set())
        old=location in revealed;old_seen=location in seen;old_manual=location in manual
        revealed.add(location);seen.add(location);manual.add(location)
        if not getattr(ctx,'_save_state',lambda:True)():
            if not old:revealed.discard(location)
            if not old_seen:seen.discard(location)
            if not old_manual:manual.discard(location)
            return {'ok':False,'error':'Could not save this reveal. Try again.'}
        await ctx.flush_seen_hints()
        return {'ok':True,'operation':'reveal','message':'Hint reveal queued.'}
    if action=='hint_status':
        return {'ok':False,'error':'Hint status is read-only in NFSMW Client.'}
    return {'ok':False,'error':'Unsupported view action.'}
