


#if !defined(_MSC_VER) || !defined(_M_IX86)
#error This independent check requires the Microsoft x86 ABI.
#endif
#if defined(__clang__)
#define SMS_MEMBER_OFFSET(type,field) __builtin_offsetof(type,field)
#else
#include <cstddef>
#define SMS_MEMBER_OFFSET(type,field) offsetof(type,field)
#endif
namespace SMSWindowsABI {
using U32=unsigned int;
struct Vector2 {float x,y;};
template<class T> struct Node {T* next;T* prev;};
template<class T> struct List {T* head;T* tail;};
struct ScrollBar {
    bool vertical,resize,grabbed,arrows,visible;
    Vector2 grabbedPos,currentPos,grabOffset,backingPos,backingSize,minimum;
    float segment;U32 timer;void *backing,*handle,*arrow1,*arrow2,*end1,*end2;
};
struct Constructor {const char* name;void* package;int argument;};
struct Menu {
    virtual ~Menu()=default;
    bool play;U32 direction;bool messenger;const char* name;Constructor constructor;
    bool garage;void* input;unsigned char capture;
};
struct TextScroller {
    Menu* owner;void* font;ScrollBar* scrollbar;char name[32];
    int width,visible,count;short** lines;char* raw;U32 size,position;
    int top;U32 down,up;
};
struct MessageScreen:Menu {TextScroller text;ScrollBar bar;void* message;};
struct ArrayDatum:Node<ArrayDatum> {
    virtual ~ArrayDatum()=default;
    U32 hash,description;bool enabled,greyed,locked,checked;
};
struct SmsDatum:ArrayDatum {void* message;};
struct ArraySlot:Node<ArraySlot> {
    virtual ~ArraySlot()=default;
    void* object;void* scripts;
};
struct SmsSlot:ArraySlot {void* icon;void* text;};
struct Scripts {virtual ~Scripts()=default;U32 grey,normal,highlight,unhighlight;};
struct Scroller {
    virtual ~Scroller()=default;
    bool play;List<ArraySlot> slots;List<ArrayDatum> data;ArrayDatum* current;
    int start,width,height;U32 description;const char* name;void* package;
    ScrollBar bar;void* region;bool selectable;Scripts scripts;U32 mouse;bool click;
};
struct ScrollerMenu:Menu,Scroller {};
struct Inbox:ScrollerMenu {
    unsigned char last[2];int button;bool voice,automatic,waiting,complete;
};
static_assert(sizeof(void*)==4 && sizeof(bool)==1);
static_assert(sizeof(ScrollBar)==0x58 && sizeof(Menu)==0x2C);
static_assert(SMS_MEMBER_OFFSET(Menu,constructor)==0x14);
static_assert(SMS_MEMBER_OFFSET(MessageScreen,text)==0x2C);
static_assert(sizeof(TextScroller)==0x54 && sizeof(MessageScreen)==0xDC);
static_assert(SMS_MEMBER_OFFSET(MessageScreen,message)==0xD8);
static_assert(sizeof(ArrayDatum)==0x18 && SMS_MEMBER_OFFSET(SmsDatum,message)==0x18);
static_assert(SMS_MEMBER_OFFSET(SmsSlot,text)==0x18);
static_assert(sizeof(Scroller)==0xB0 && sizeof(ScrollerMenu)==0xDC);
static_assert(SMS_MEMBER_OFFSET(Inbox,voice)==0xE4 && sizeof(Inbox)==0xE8);

}
#undef SMS_MEMBER_OFFSET
