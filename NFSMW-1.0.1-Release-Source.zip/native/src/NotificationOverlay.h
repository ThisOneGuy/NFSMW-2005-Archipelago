#pragma once

#include <Windows.h>

#include <string>

namespace NFSMWAP
{
    void ConfigureNotifications(bool enabled);
    void SetMultiworldStatus(bool connected,int queuedChecks=0);

    enum class StorePresentationMode
    {
        Generic = 0,
        CarLot3DLogo = 1,
        Parts2DIcons = 2
    };

    struct StoreOverlayInfo
    {
        bool visible = false;
        bool checked = false;
        bool recipientIsLocal = false;
        bool carItem = false;
        StorePresentationMode presentationMode = StorePresentationMode::Generic;
        int slotIndex = 0;
        int slotCount = 0;
        std::string storeName;
        std::string locationName;
        std::string itemName;
        std::string itemType;
        std::string itemDetail;
        std::string priceText;
        std::string careerCashText;
        std::string recipientName;
        std::string recipientGame;
        std::string controls;
    };

    void SetStoreOverlay(const StoreOverlayInfo& info);
    void ClearStoreOverlay();

    void QueueNotification(
        const std::string& title,
        const std::string& line1,
        const std::string& line2,
        unsigned int durationMs = 5000);
    DWORD WINAPI NotificationOverlayThread(LPVOID);
}
