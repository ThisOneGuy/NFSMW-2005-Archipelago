#pragma once

#include <Windows.h>

namespace NFSMWAP
{
    bool InstallEventDiscoveryHook();
    DWORD WINAPI EventDiscoveryThread(LPVOID);
}
