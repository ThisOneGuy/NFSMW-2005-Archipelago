#include "BountyEarnings.h"
#include "BountyRequirements.h"
#include "CareerContext.h"
#include "Logger.h"
#include <Windows.h>
#include <cstdint>

namespace {
using Word=std::uint32_t;
using AddBounty=void(__thiscall*)(void*,int);
constexpr unsigned EntryCount=24,DestructionEntry=14,NormalEntry=15;
Word copiedTable[EntryCount+1]={},originalTable=0,hookedPerp=0;
AddBounty originalNormal=nullptr,originalDestruction=nullptr;
unsigned normalRemainder=0,destructionRemainder=0,previousPercent=100;
thread_local unsigned forwarding=0;
bool logged=false;

void ForwardBounty(void* perp,int amount,AddBounty original,unsigned& remainder) {
    if(!original)return;
    const auto percent=NFSMWAP::EarnedBountyPercent();
    if(!forwarding && NFSMWAP::IsLiveCareerMode() && reinterpret_cast<std::uintptr_t>(perp)==hookedPerp) {
        if(percent!=previousPercent){normalRemainder=destructionRemainder=0;previousPercent=percent;}
        amount=NFSMWAP::ScaleEarnedBounty(amount,percent,remainder);
    }
    ++forwarding;original(perp,amount);--forwarding;
}
void __fastcall NormalBounty(void* perp,void*,int amount){ForwardBounty(perp,amount,originalNormal,normalRemainder);}
void __fastcall DestructionBounty(void* perp,void*,int amount){ForwardBounty(perp,amount,originalDestruction,destructionRemainder);}
bool ReadPlayerPerp(Word& perp) {
    perp=0;
    __try {
        if(*reinterpret_cast<int*>(0x925E90u)!=6 || !NFSMWAP::IsLiveCareerMode())return false;
        const Word manager=*reinterpret_cast<Word*>(0x91E00Cu);
        if(manager<0x10000u || (manager&3u))return false;
        Word pursuit=0;
        reinterpret_cast<void(__thiscall*)(void*,Word&,Word&)>(0x5EB9E0u)(reinterpret_cast<void*>(manager),pursuit,perp);
        return perp>=0x10000u && !(perp&3u);
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool Executable(Word address) {
    MEMORY_BASIC_INFORMATION region{};
    if(!address || !VirtualQuery(reinterpret_cast<const void*>(address),&region,sizeof(region)) || region.State!=MEM_COMMIT ||
       (region.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return false;
    return (region.Protect&(PAGE_EXECUTE|PAGE_EXECUTE_READ|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY))!=0;
}
void ReleasePerp() {
    __try {
        if(hookedPerp && *reinterpret_cast<Word*>(hookedPerp)==static_cast<Word>(reinterpret_cast<std::uintptr_t>(copiedTable+1)))
            *reinterpret_cast<Word*>(hookedPerp)=originalTable;
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
    hookedPerp=originalTable=0;normalRemainder=destructionRemainder=0;previousPercent=100;
}
bool InstallPerp(Word perp) {
    __try {
        const Word table=*reinterpret_cast<Word*>(perp);
        if(table<0x10004u || (table&3u))return false;
        const auto* entries=reinterpret_cast<const Word*>(table);
        for(unsigned index=0;index<EntryCount;++index)if(!Executable(entries[index]))return false;
        copiedTable[0]=entries[-1];
        for(unsigned index=0;index<EntryCount;++index)copiedTable[index+1]=entries[index];
        originalNormal=reinterpret_cast<AddBounty>(entries[NormalEntry]);originalDestruction=reinterpret_cast<AddBounty>(entries[DestructionEntry]);
        copiedTable[NormalEntry+1]=static_cast<Word>(reinterpret_cast<std::uintptr_t>(&NormalBounty));
        copiedTable[DestructionEntry+1]=static_cast<Word>(reinterpret_cast<std::uintptr_t>(&DestructionBounty));
        originalTable=table;hookedPerp=perp;
        *reinterpret_cast<Word*>(perp)=static_cast<Word>(reinterpret_cast<std::uintptr_t>(copiedTable+1));return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {hookedPerp=originalTable=0;return false;}
}
}
namespace NFSMWAP {
void BountyEarningsMainThreadTick() {
    const auto percent=EarnedBountyPercent();Word perp=0;
    if(percent==100u || !ReadPlayerPerp(perp)){if(hookedPerp)ReleasePerp();return;}
    __try {
        if(perp==hookedPerp && *reinterpret_cast<Word*>(perp)==static_cast<Word>(reinterpret_cast<std::uintptr_t>(copiedTable+1)))return;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return;}
    ReleasePerp();
    if(InstallPerp(perp) && !logged){logged=true;Log("NFSMW_AP_BOUNTY_EARNINGS_V1: player bounty earnings multiplied; normal rival requirements retained.");}
}
}
