#include "NativeRewardUI.h"
#include "SeedConfig.h"
#include "NativeRaceIdentity.h"
#include "JsonLite.h"
#include "Logger.h"
#include "PhotoTrapLogic.h"
#include "GameEventJournal.h"
#include "StoreRuntime.h"
#include <Windows.h>
#include <algorithm>
#include <cmath>
#include <cctype>
#include <cstring>
#include <map>
#include <mutex>
#include <vector>

namespace {
    using Word=std::uint32_t;
    using Refresh=void(__thiscall*)(Word*);
    struct Reward {int location=0,rank=0;std::string type,event,category,item,recipient,locationName,status;double threshold=0;bool checked=false;};
    std::mutex rewardMutex;
    std::map<int,Reward> rewards;
    std::map<std::string,int> rewardAliases;
    struct ActiveSheet {Word* screen=nullptr;Word table=0;bool milestone=false;std::string package;};
    ActiveSheet activeSheet;
    bool hooksReady=false;
    Word racePrimary=0x89D7ACu,milestonePrimary=0x89EEDCu;
    Word* CompleteSheet(Word* incoming,bool milestone) {
        __try {
            const Word expected=milestone ? milestonePrimary : racePrimary;
            if (incoming && *incoming==expected) return incoming;
            if (incoming && *(incoming-11)==expected) return incoming-11;
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
        return nullptr;
    }
    struct Selection {const char* package=nullptr;char event[128]={},activity[96]={};Word key=0,camera=0;int rank=0;float required=0;NFSMWAP::NativeRaceIdentity identity{};};
    Selection observedRace,observedMilestone;
    bool haveObservedRace=false,haveObservedMilestone=false;
    bool CareerRewardsAllowed() {
        __try {const Word db=*reinterpret_cast<Word*>(0x91CF90u);
            if (!db) return false;const Word flags=*reinterpret_cast<Word*>(db+0x12Cu);
            return (flags&1u)!=0 && !(flags&0xEu);
        } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }
    bool CaptureRaceName(void* parameters,char* out,unsigned capacity) {
        __try {
            if (!parameters || !capacity) return false;
            const Word db=*reinterpret_cast<Word*>(0x91CF90u);if (!db) return false;
            const int type=reinterpret_cast<int(__thiscall*)(void*)>(0x5FAA20u)(parameters);
            const Word hash=reinterpret_cast<Word(__thiscall*)(void*,int)>(0x56E010u)(reinterpret_cast<void*>(db),type);
            const char* name=reinterpret_cast<const char*(__cdecl*)(Word)>(0x56BC10u)(hash);
            if (!name) return false;
            for (unsigned n=0;n<capacity;++n) {out[n]=name[n];if (!name[n]) return n>0;}
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
        out[0]=0;return false;
    }
    bool CaptureObjective(void* objective,bool photo,Selection& selected) {
        __try {
            if (!objective) return false;
            const auto address=reinterpret_cast<std::uintptr_t>(objective);
            if (photo) {
                selected.rank=*reinterpret_cast<unsigned short*>(address+0x2u);
                selected.camera=reinterpret_cast<Word(__thiscall*)(void*)>(0x5E5810u)(objective);
            } else {
                selected.key=*reinterpret_cast<Word*>(address);
                selected.rank=*reinterpret_cast<unsigned short*>(address+0xAu);
                selected.required=*reinterpret_cast<float*>(address+0xCu);
            }
            return selected.rank>=1 && selected.rank<=15;
        } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }
    float __fastcall MilestoneBounty(void* objective,void*) {
        observedMilestone={};haveObservedMilestone=CaptureObjective(objective,false,observedMilestone);
        return reinterpret_cast<float(__thiscall*)(void*)>(0x5E54F0u)(objective);
    }
    float __fastcall PhotoBounty(void* objective,void*) {
        observedMilestone={};haveObservedMilestone=CaptureObjective(objective,true,observedMilestone);
        return reinterpret_cast<float(__thiscall*)(void*)>(0x5E56C0u)(objective);
    }
    const char* MilestoneCategory(Word key) {
        switch(key) {
        case 0x850A64BCu:return "Trade Paint";
        case 0x2377E50Du:return "Bounty";
        case 0x5392E4FDu:return "Pursuit Evasion";
        case 0x033FA23Au:return "Pursuit Time";
        case 0xDCFC0710u:case 0xFD989A3Au:return "Cost to State";
        case 0xEB45F99Du:return "Roadblock";
        case 0xA61CAC24u:return "Infractions";
        case 0xCDF36FC2u:return "Spike Strip";
        default:return "";
        }
    }
    bool ReadSelection(Word* screen,bool milestone,Selection& result) {
        __try {
            const auto db=*reinterpret_cast<Word*>(0x91CF90u);
            if (!db) return false;
            const auto flags=*reinterpret_cast<Word*>(db+0x12Cu);
            if (!(flags&1u) || (flags&0xEu)) return false;
            result.package=reinterpret_cast<const char*>(screen[4]);
            Word* datum=reinterpret_cast<Word*(__thiscall*)(void*)>(0x5106C0u)(reinterpret_cast<char*>(screen)+0x2Cu);
            if (!datum || !result.package) return false;
            if (!milestone) {
                const auto params=reinterpret_cast<void*>(datum[0x18u/4u]);if (!params) return false;
                CaptureRaceName(params,result.activity,sizeof(result.activity));
                const int view=*reinterpret_cast<const int*>(0x91CA3Cu);
                if(NFSMWAP::ReadNativeRaceIdentity(params,view,result.identity,true))result.rank=result.identity.rank;
                const char* event=reinterpret_cast<const char*(__thiscall*)(void*)>(0x5FBA70u)(params);
                if (!event) return false;
                for (unsigned n=0;n<sizeof(result.event);++n) {result.event[n]=event[n];if (!event[n]) return n>0;}
                return false;
            }
            const auto objective=datum[0x18u/4u];
            if (objective) {
                result.key=*reinterpret_cast<Word*>(objective);
                result.rank=*reinterpret_cast<unsigned short*>(objective+0xAu);
                result.required=*reinterpret_cast<float*>(objective+0xCu);
            } else {
                const auto trap=reinterpret_cast<void*>(datum[0x1Cu/4u]);if (!trap) return false;
                result.rank=*reinterpret_cast<unsigned short*>(reinterpret_cast<std::uintptr_t>(trap)+0x2u);
                result.camera=reinterpret_cast<Word(__thiscall*)(void*)>(0x5E5810u)(trap);
            }
            return result.rank>=1 && result.rank<=15;
        } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }
    int ReadPhotoRoster(int rank,NFSMWAP::PhotoCamera* cameras) {
        int count=0;
        __try {
            const auto manager=reinterpret_cast<void*>(*reinterpret_cast<Word*>(0x91E00Cu));if (!manager) return 0;
            auto trap=reinterpret_cast<void*(__thiscall*)(void*,bool,unsigned)>(0x5E9D40u)(manager,false,rank);
            while (trap && count<64) {
                const auto key=reinterpret_cast<Word(__thiscall*)(void*)>(0x5E5810u)(trap);
                for (int n=0;n<count;++n) if (cameras[n].key==key) return 0;
                const auto mph=reinterpret_cast<float(__thiscall*)(void*)>(0x5118B0u)(trap)*2.2369362920544;
                cameras[count++]={key,mph,true};
                trap=reinterpret_cast<void*(__thiscall*)(void*,void*,bool,unsigned)>(0x5E4770u)(manager,trap,false,rank);
            }
            if (trap) return 0;
        } __except(EXCEPTION_EXECUTE_HANDLER) {return 0;}
        return count;
    }
    int PhotoLocation(int rank,Word selected) {
        NFSMWAP::PhotoCamera cameras[64]={};const int count=ReadPhotoRoster(rank,cameras);

        for (const auto& match:NFSMWAP::MatchPhotoCameras(rank,std::vector<NFSMWAP::PhotoCamera>(cameras,cameras+count)))
            if (match.camera.key==selected) return match.location;
        return 0;
    }
    std::string NormalizedActivity(const std::string& activity) {
        std::string result;
        for (unsigned char ch:activity) if(ch!=' '&&ch!='\t'&&ch!='-'&&ch!='_')
            result.push_back(static_cast<char>(std::tolower(ch)));
        return result;
    }
    bool MatchesRewardActivity(const Reward& value,const Selection& selected) {
        if(selected.activity[0]==0)return true;
        const auto requested=NormalizedActivity(selected.activity);
        if(requested.empty()||requested=="race")return true;
        for(const auto& marker:{std::string(" - Race - "),std::string(" - Rival Race - ")}) {
            const auto at=value.locationName.find(marker);
            if(at==std::string::npos)continue;
            const auto first=at+marker.size(),last=value.locationName.find(" - ",first);
            return NormalizedActivity(value.locationName.substr(first,last==std::string::npos?last:last-first))==requested;
        }
        return false;
    }
    void PaintReward(const Selection& selected,bool milestone,Word* screen=nullptr) {
        const int photo=selected.camera ? PhotoLocation(selected.rank,selected.camera) : 0;
        Reward reward;bool found=false;
        {
            std::lock_guard<std::mutex> lock(rewardMutex);
            const std::string observed=selected.event;
            const auto alias=rewardAliases.find(observed+"|"+NormalizedActivity(selected.activity)+"|"+std::to_string(selected.rank)+"|"+NormalizedActivity(selected.identity.track)+"|"+std::to_string(selected.identity.index));
            if(!milestone&&alias!=rewardAliases.end()) {
                const auto row=rewards.find(alias->second);
                if(row!=rewards.end()){reward=row->second;found=true;}
            }
            for (const auto& row:rewards) {
                if(found && !milestone && alias!=rewardAliases.end())break;
                const auto& value=row.second;
                const bool match=milestone ? value.type=="milestone" && value.rank==selected.rank &&
                    (selected.camera ? value.location==photo : value.category==MilestoneCategory(selected.key) &&
                        std::isfinite(selected.required) && std::abs(value.threshold-selected.required)<0.01) :
                    value.type=="race" && MatchesRewardActivity(value,selected) &&
                    (!selected.rank || value.rank==selected.rank) &&
                    (!selected.identity.rank || (selected.identity.boss ? value.locationName.find(" - Rival Race - ")!=std::string::npos : value.locationName.find(" - Race - ")!=std::string::npos)) &&
                    (!selected.identity.track[0] || (value.locationName.rfind(" - ")!=std::string::npos && NormalizedActivity(value.locationName.substr(value.locationName.rfind(" - ")+3))==NormalizedActivity(selected.identity.track))) &&
                    value.event==observed;
                if (match) {if (found) {found=false;break;}reward=value;found=true;}
            }
        }
        std::string activity=milestone ? (selected.camera ? "Photo Ticket" : MilestoneCategory(selected.key)) : selected.activity;
        if (activity.empty() && found && !milestone) {


            for (const auto& marker:{std::string(" - Race - "),std::string(" - Rival Race - ")}) {
                const auto at=reward.locationName.find(marker);
                if (at==std::string::npos) continue;
                const auto start=at+marker.size(),end=reward.locationName.find(" - ",start);
                activity=reward.locationName.substr(start,end==std::string::npos ? end : end-start);break;
            }
        }
        if (activity.empty()) activity=milestone ? "Milestone" : "Race";
        std::string item=found ? reward.item : "awaiting scout";


        const auto separator=item.find(" - ");
        if (separator!=std::string::npos) item.replace(separator,3,"\n");
        const auto checked=reward.status=="won"?" [Won]":reward.status=="released"?" [Released]":" [AP checked]";
        const auto label=activity+": "+item+(found && reward.checked ? checked : "");


        const bool written=NFSMWAP::WriteNativeRewardText(selected.package,milestone ? 0xB5117FDEu : 0x9BA78BA2u,label);
        if(written) {
            const auto category=std::string(selected.camera?"Photo Ticket":MilestoneCategory(selected.key));
            const auto identity=milestone ? "milestone:"+std::to_string(selected.rank)+":"+category+":"+
                std::to_string(selected.required)+":"+std::to_string(selected.camera) : "race:"+std::string(selected.event)+":"+NormalizedActivity(selected.activity)+":"+std::to_string(selected.rank)+":"+std::to_string(selected.identity.index);
            const auto location=found?reward.location:photo;
            NFSMWAP::RecordGameEvent("view:v4:"+identity,
                "{\"type\":\"location_preview\",\"location_id\":"+std::to_string(location)+
                ",\"event_id\":\""+NFSMWAP::JsonLite::Escape(selected.event)+"\""+
                (selected.identity.rank ? NFSMWAP::NativeRaceIdentityJson(selected.identity) :
                    ",\"activity\":\""+NFSMWAP::JsonLite::Escape(selected.activity)+"\",\"blacklist_rank\":"+std::to_string(selected.rank))+
                ",\"category\":\""+category+"\",\"threshold\":\""+std::to_string(selected.required)+"\"}");
        }
        static std::map<Word*,int> lastLabel;
        if (found && lastLabel[screen]!=reward.location) {
            lastLabel[screen]=reward.location;
            NFSMWAP::Log("AP NATIVE REWARD LABEL: location="+std::to_string(reward.location)+" item='"+reward.item+
                "' recipient='"+reward.recipient+"' native_text="+(written ? "yes" : "NO"));
        }
        if (!written) {
            static bool warned=false;if (!warned) {warned=true;NFSMWAP::Log("AP REWARD UI: native description FEString unavailable.");}
        }
    }
    void ShowReward(Word* screen,bool milestone) {
        if(!NFSMWAP::RevealEventRewards())return;
        Selection selected;
        if (!screen) return;
        if (!ReadSelection(screen,milestone,selected)) {
            static std::map<Word*,bool> warned;
            if (!warned[screen]) {warned[screen]=true;NFSMWAP::Log("AP REWARD UI: selection not ready; sheet="+std::to_string(reinterpret_cast<std::uintptr_t>(screen))+" kind="+(milestone ? "milestone" : "race"));}
            return;
        }
        activeSheet={screen,*screen,milestone,selected.package};


        if (milestone) {observedMilestone=selected;haveObservedMilestone=true;}
        else {observedRace=selected;haveObservedRace=true;}
        PaintReward(selected,milestone,screen);
    }
    void __fastcall RaceRefresh(Word* scroller,void*) {
        reinterpret_cast<Refresh>(0x547730u)(scroller);ShowReward(CompleteSheet(scroller,false),false);
    }
    void __fastcall MilestoneRefresh(Word* scroller,void*) {
        reinterpret_cast<Refresh>(0x52FB70u)(scroller);ShowReward(CompleteSheet(scroller,true),true);
    }
    void __fastcall RaceSetup(Word* screen,void*) {
        reinterpret_cast<Refresh>(0x547E30u)(screen);ShowReward(screen,false);
    }
    void __fastcall MilestoneSetup(Word* screen,void*) {
        reinterpret_cast<Refresh>(0x552440u)(screen);ShowReward(screen,true);
    }
    bool SheetIdentity(Word* screen,Word& table,char* package,unsigned capacity) {
        __try {
            if (!screen || !capacity) return false;table=*screen;
            const auto name=reinterpret_cast<const char*>(screen[4]);if (!name) return false;
            for (unsigned n=0;n<capacity;++n) {package[n]=name[n];if (!name[n]) return n>0;}
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
        return false;
    }
    bool SameSheet(Word* screen,Word table) {
        __try {return screen && *screen==table;}
        __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }
    void AfterNotify(Word* screen,Word table,const char* package,bool milestone) {
        std::string active;
        if (SameSheet(screen,table) && NFSMWAP::GetNativeStorePackage(active) && active==package)
            ShowReward(screen,milestone);
    }
    using Notify=void(__thiscall*)(Word*,Word,Word*,Word,Word);
    void __fastcall RaceNotify(Word* screen,void*,Word message,Word* object,Word a,Word b) {
        Word table=0;char package[128]={};const bool live=SheetIdentity(screen,table,package,sizeof(package));
        if (message==0x911AB364u) {if (activeSheet.screen==screen) activeSheet={};haveObservedRace=false;}
        reinterpret_cast<Notify>(0x551530u)(screen,message,object,a,b);
        if (live && message!=0x911AB364u) AfterNotify(screen,table,package,false);
    }
    void __fastcall MilestoneNotify(Word* screen,void*,Word message,Word* object,Word a,Word b) {
        Word table=0;char package[128]={};const bool live=SheetIdentity(screen,table,package,sizeof(package));
        if (message==0x911AB364u) {if (activeSheet.screen==screen) activeSheet={};haveObservedMilestone=false;}
        reinterpret_cast<Notify>(0x551F80u)(screen,message,object,a,b);
        if (live && message!=0x911AB364u) AfterNotify(screen,table,package,true);
    }
    struct Patch {std::uintptr_t address;Word original,value;};
    bool WritePatch(const Patch& patch) {
        DWORD old=0,unused=0;
        if (*reinterpret_cast<Word*>(patch.address)!=patch.original ||
            !VirtualProtect(reinterpret_cast<void*>(patch.address),4,PAGE_EXECUTE_READWRITE,&old)) return false;
        *reinterpret_cast<Word*>(patch.address)=patch.value;
        VirtualProtect(reinterpret_cast<void*>(patch.address),4,old,&unused);
        FlushInstructionCache(GetCurrentProcess(),reinterpret_cast<void*>(patch.address),4);return true;
    }
    void CollectCalls(std::vector<Patch>& patches,std::uintptr_t start,std::uintptr_t end,Word target,const void* hook) {
        for (auto address=start;address+5<=end;++address) {
            if (*reinterpret_cast<unsigned char*>(address)!=0xE8u) continue;
            const auto displacement=*reinterpret_cast<std::int32_t*>(address+1);
            if (address+5+displacement!=target) continue;
            const auto value=static_cast<Word>(reinterpret_cast<std::uintptr_t>(hook)-address-5);
            patches.push_back({address+1,static_cast<Word>(displacement),value});address+=4;
        }
    }
    std::uintptr_t ResolveTable(std::uintptr_t preferred,Word notify,Word sound) {


        if (*reinterpret_cast<Word*>(preferred+4u)==notify && *reinterpret_cast<Word*>(preferred+8u)==sound) return preferred;
        std::uintptr_t result=0;
        for (auto address=std::uintptr_t(0x890000u);address+16u<0x8C0000u;address+=4u) {
            if (*reinterpret_cast<Word*>(address+4u)!=notify || *reinterpret_cast<Word*>(address+8u)!=sound) continue;
            if (result) return 0;result=address;
        }
        return result;
    }
}
namespace NFSMWAP {
    void ObserveNativeRaceReward(const char* eventID,void* parameters) {
        haveObservedRace=false;observedRace={};
        CaptureRaceName(parameters,observedRace.activity,sizeof(observedRace.activity));
        const int view=*reinterpret_cast<const int*>(0x91CA3Cu);
        if(ReadNativeRaceIdentity(parameters,view,observedRace.identity,true))observedRace.rank=observedRace.identity.rank;
        if (!eventID) return;
        for (unsigned n=0;n<sizeof(observedRace.event);++n) {
            observedRace.event[n]=eventID[n];
            if (!eventID[n]) {haveObservedRace=n>0;break;}
        }
    }
    void RegisterNativeReward(const std::string& packet) {
        char expected[512]={};const auto size=GetEnvironmentVariableA("NFSMW_AP_SESSION_KEY",expected,sizeof(expected));
        std::string session;if (!size || size>=sizeof(expected) || !JsonLite::GetString(packet,"session_key",session) || session!=expected) return;
        Reward row;std::string threshold;
        JsonLite::GetInt(packet,"location_id",row.location);JsonLite::GetInt(packet,"blacklist_rank",row.rank);
        JsonLite::GetString(packet,"location_type",row.type);JsonLite::GetString(packet,"event_id",row.event);
        JsonLite::GetString(packet,"category",row.category);JsonLite::GetString(packet,"threshold",threshold);
        JsonLite::GetString(packet,"location_name",row.locationName);
        JsonLite::GetString(packet,"item_name",row.item);JsonLite::GetString(packet,"recipient_name",row.recipient);
        JsonLite::GetBool(packet,"checked",row.checked);
        JsonLite::GetString(packet,"check_status",row.status);
        if (row.location<=0 || row.rank<1 || row.rank>15 || row.item.empty() || row.item.size()>1024 || row.recipient.size()>200) return;
        if (row.type=="milestone") {
            try {std::size_t n=0;row.threshold=std::stod(threshold,&n);if (n!=threshold.size() || !std::isfinite(row.threshold)) return;}
            catch (...) {return;}
        } else if (row.type!="race" || row.event.empty() || row.event.size()>=128) return;
        std::lock_guard<std::mutex> lock(rewardMutex);
        const bool firstType=std::none_of(rewards.begin(),rewards.end(),[&row](const std::pair<const int,Reward>& value){return value.second.type==row.type;});
        rewards[row.location]=row;
        std::string observed,activity,track;int rank=0,index=0;
        if(JsonLite::GetString(packet,"observed_event_id",observed)&&!observed.empty()&&observed.size()<128) {
            JsonLite::GetString(packet,"observed_activity",activity);
            JsonLite::GetString(packet,"observed_track",track);JsonLite::GetInt(packet,"observed_rank",rank);JsonLite::GetInt(packet,"observed_index",index);
            rewardAliases[observed+"|"+NormalizedActivity(activity)+"|"+std::to_string(rank)+"|"+NormalizedActivity(track)+"|"+std::to_string(index)]=row.location;
        }
        if (firstType) Log("AP REWARD CATALOG: received "+row.type+" scouts for this session.");
    }
    bool InstallNativeRewardHooks() {
        std::vector<Patch> patches;

        const auto raceTable=ResolveTable(0x89D7ACu,0x551530u,0x5116F0u);
        const auto milestoneTable=ResolveTable(0x89EEDCu,0x551F80u,0x511900u);
        if (!raceTable || !milestoneTable) {
            Log("AP REWARD UI: table validation race="+std::to_string(raceTable)+" milestone="+std::to_string(milestoneTable));return false;
        }
        racePrimary=static_cast<Word>(raceTable);milestonePrimary=static_cast<Word>(milestoneTable);


        if (*reinterpret_cast<Word*>(raceTable-4u)!=0x547730u ||
            *reinterpret_cast<Word*>(milestoneTable-4u)!=0x52FB70u) return false;
        patches.push_back({raceTable-4u,0x547730u,static_cast<Word>(reinterpret_cast<std::uintptr_t>(&RaceRefresh))});
        patches.push_back({milestoneTable-4u,0x52FB70u,static_cast<Word>(reinterpret_cast<std::uintptr_t>(&MilestoneRefresh))});
        patches.push_back({raceTable+4u,0x551530u,static_cast<Word>(reinterpret_cast<std::uintptr_t>(&RaceNotify))});
        patches.push_back({milestoneTable+4u,0x551F80u,static_cast<Word>(reinterpret_cast<std::uintptr_t>(&MilestoneNotify))});
        for (const auto& range:std::vector<std::pair<Word,Word>>{{0x551530,0x55178B},{0x547E30,0x547FE4},{0x55A760,0x55A99E}})
            CollectCalls(patches,range.first,range.second,0x547730u,reinterpret_cast<void*>(&RaceRefresh));
        for (const auto& range:std::vector<std::pair<Word,Word>>{{0x551F80,0x55243F},{0x552440,0x552568},{0x55A9A0,0x55ABEE}})
            CollectCalls(patches,range.first,range.second,0x52FB70u,reinterpret_cast<void*>(&MilestoneRefresh));
        CollectCalls(patches,0x55A760u,0x55A99Eu,0x547E30u,reinterpret_cast<void*>(&RaceSetup));
        CollectCalls(patches,0x55A9A0u,0x55ABEEu,0x552440u,reinterpret_cast<void*>(&MilestoneSetup));
        CollectCalls(patches,0x551530u,0x55178Bu,0x547E30u,reinterpret_cast<void*>(&RaceSetup));


        const auto captureStart=patches.size();
        CollectCalls(patches,0x52FB70u,0x52FFB3u,0x5E54F0u,reinterpret_cast<void*>(&MilestoneBounty));
        const bool milestoneCapture=patches.size()>captureStart;
        const auto photoStart=patches.size();
        CollectCalls(patches,0x52FB70u,0x52FFB3u,0x5E56C0u,reinterpret_cast<void*>(&PhotoBounty));
        if (!milestoneCapture || patches.size()==photoStart) {
            Log("AP REWARD UI: native objective capture callsites missing; no reward UI patches applied.");return false;
        }
        std::size_t applied=0;
        for (;applied<patches.size();++applied) if (!WritePatch(patches[applied])) break;
        if (applied!=patches.size()) {
            while (applied) {auto p=patches[--applied];WritePatch({p.address,p.value,p.original});}return false;
        }
        hooksReady=true;
        Log("NFSMW_AP_NATIVE_REWARDS_V11: exact race identities, verified completion statuses and durable viewed-location hints installed.");return true;
    }
    bool SheetAlive(Word* screen,Word table) {
        return SameSheet(screen,table);
    }
    void NativeRewardMainThreadTick() {
        if (!hooksReady || !CareerRewardsAllowed()) return;
        std::string package;
        if (!GetNativeStorePackage(package)) return;
        const bool racePackage=package=="SafeHouseRaceSheet.fng" || package=="InGameRaceSheet.fng";
        const bool milestonePackage=package=="SafeHouseMilestones.fng" || package=="InGameMilestones.fng";
        if (activeSheet.screen && package==activeSheet.package && SheetAlive(activeSheet.screen,activeSheet.table)) {
            ShowReward(activeSheet.screen,activeSheet.milestone);return;
        }
        if (racePackage && haveObservedRace) {
            auto selected=observedRace;selected.package=package.c_str();PaintReward(selected,false);return;
        }
        if (milestonePackage && haveObservedMilestone) {
            auto selected=observedMilestone;selected.package=package.c_str();PaintReward(selected,true);return;
        }
    }
    void ReportViewedShopLocation(int location) {
        if(location>0)RecordGameEvent("view:location:"+std::to_string(location),
            "{\"type\":\"location_preview\",\"location_id\":"+std::to_string(location)+"}");
    }
}
