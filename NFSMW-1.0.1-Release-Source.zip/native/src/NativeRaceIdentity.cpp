#include "NativeRaceIdentity.h"
#include "JsonLite.h"
#include "Logger.h"
#include <Windows.h>
#include <cstdint>
#include <map>
#include <mutex>
namespace {
using Word=std::uint32_t;
struct Record {NFSMWAP::NativeRaceIdentity identity;unsigned ranks=0;int stages[16]{},counts[16]{};};
bool Key(void* parameters,Word& hash,bool& boss,Word& database) {
    __try {
        if(!parameters)return false;
        database=*reinterpret_cast<Word*>(0x91E004u);
        if(!database)return false;
        hash=reinterpret_cast<Word(__thiscall*)(void*)>(0x5FAB40u)(parameters);
        boss=reinterpret_cast<bool(__thiscall*)(void*)>(0x5FBD90u)(parameters);
        return hash!=0;
    } __except(EXCEPTION_EXECUTE_HANDLER){return false;}
}
bool CopyName(const char* source,char* dest,unsigned capacity) {
    if(!source)return false;
    for(unsigned i=0;i<capacity;++i){dest[i]=source[i];if(!dest[i])return i>0;}
    dest[0]=0;return false;
}
bool Capture(void* parameters,Word hash,bool boss,Word database,Record& record) {
    __try {
        record.identity.boss=boss;
        const Word frontend=*reinterpret_cast<Word*>(0x91CF90u);
        if(!frontend)return false;
        const int type=reinterpret_cast<int(__thiscall*)(void*)>(0x5FAA20u)(parameters);
        const Word typeHash=reinterpret_cast<Word(__thiscall*)(void*,int)>(0x56E010u)(reinterpret_cast<void*>(frontend),type);
        const Word trackHash=reinterpret_cast<Word(__cdecl*)(const char*,void*)>(0x56E560u)("TRACKNAME_",parameters);
        const auto localize=reinterpret_cast<const char*(__cdecl*)(Word)>(0x56BC10u);
        if(!CopyName(localize(typeHash),record.identity.activity,sizeof(record.identity.activity))||
           !CopyName(localize(trackHash),record.identity.track,sizeof(record.identity.track)))return false;
        for(int rank=1;rank<=15;++rank) {
            void* bin=reinterpret_cast<void*(__thiscall*)(void*,int)>(0x5E3980u)(reinterpret_cast<void*>(database),rank);
            if(!bin)return false;
            const Word count=reinterpret_cast<Word(__thiscall*)(void*)>(boss?0x5DCF60u:0x5DCF70u)(bin);
            if(count>256)return false;
            Word hashes[256]{};bool contains=false;
            for(Word n=0;n<count;++n) {
                hashes[n]=reinterpret_cast<Word(__thiscall*)(void*,Word)>(boss?0x601020u:0x601060u)(bin,n);
                contains|=hashes[n]==hash;
            }
            if(!contains)continue;
            int visible=0,matched=0;
            for(Word n=0;n<count;++n) {
                const Word candidate=hashes[n];
                void* race=reinterpret_cast<void*(__thiscall*)(void*,Word)>(0x5FB710u)(reinterpret_cast<void*>(database),candidate);
                if(!race)return false;
                const int category=reinterpret_cast<int(__thiscall*)(void*)>(0x5FAA20u)(race);

                if(!boss&&(category==9||category==10))continue;
                ++visible;
                if(candidate==hash){if(matched)return false;matched=visible;}
            }
            if(matched) {
                record.ranks|=1u<<rank;
                record.stages[rank]=matched;record.counts[rank]=visible;
            }
        }
        return record.ranks!=0;
    } __except(EXCEPTION_EXECUTE_HANDLER){return false;}
}
}
namespace NFSMWAP {
bool ReadNativeRaceIdentity(void* parameters,int preferredRank,NativeRaceIdentity& identity,bool careerSheet) {
    identity={};Word hash=0,database=0;bool boss=false;
    if(!Key(parameters,hash,boss,database))return false;
    if(careerSheet)boss=false;
    static std::mutex mutex;static std::map<std::pair<Word,bool>,Record> records;static Word owner=0;
    std::lock_guard<std::mutex> lock(mutex);
    if(owner!=database){owner=database;records.clear();}
    const auto key=std::make_pair(hash,boss);auto found=records.find(key);
    if(found==records.end()) {
        Record record;
        if(!Capture(parameters,hash,boss,database,record))return false;
        found=records.emplace(key,record).first;
    }
    const auto& record=found->second;identity=record.identity;
    int rank=0;
    if(preferredRank>=1&&preferredRank<=15&&(record.ranks&(1u<<preferredRank)))rank=preferredRank;
    else for(int n=1;n<=15;++n)if(record.ranks&(1u<<n)){if(rank)return false;rank=n;}
    static bool reported=false;
    if(!reported){reported=true;Log("NFSMW_AP_NATIVE_RACE_IDENTITY_V1: native bin membership, track names and rival stages available.");}
    identity.rank=rank;identity.index=record.stages[rank];identity.count=record.counts[rank];
    if(boss){identity.stage=record.stages[rank];identity.stages=record.counts[rank];}
    return rank!=0;
}
std::string NativeRaceIdentityJson(const NativeRaceIdentity& identity) {
    if(!identity.rank)return "";
    return ",\"activity\":\""+JsonLite::Escape(identity.activity)+"\",\"track_name\":\""+
        JsonLite::Escape(identity.track)+"\",\"blacklist_rank\":"+std::to_string(identity.rank)+
        ",\"race_kind\":\""+(identity.boss?"rival":"career")+"\",\"rival_stage\":"+
        std::to_string(identity.stage)+",\"rival_stages\":"+std::to_string(identity.stages)+
        ",\"native_index\":"+std::to_string(identity.index)+",\"native_count\":"+std::to_string(identity.count);
}
}
