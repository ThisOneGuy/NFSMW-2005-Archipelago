#pragma once

#include <string>

namespace NFSMWAP
{


    bool PrimeSaveIsolationEarly();


    bool InitializeSaveIsolation();

    bool IsSaveIsolationActive();
    bool WasSaveIsolationPrimedEarly();
    int GetSaveIsolationHookCount();
    unsigned GetSaveIsolationRedirectCount();
    unsigned GetSaveIsolationProfileOpenCount();
    unsigned GetSaveIsolationProfileRedirectCount();
    std::string GetSaveIsolationLastProfileOpenPath();
    std::string GetIsolatedDocumentsRoot();
}
