#pragma once
#include <string>
#include <cstdlib>
namespace NFSMWAP {
    inline int LatchRivalChallenge(const std::string& event,bool boss,int previous) {
        if (!boss) return 0;
        if (event.size()>2 && event.substr(event.size()-2)==".r") return previous;
        const auto dot=event.find('.');if (dot==std::string::npos) return 0;
        const auto text=event.substr(0,dot);char* end=nullptr;
        const auto rank=std::strtol(text.c_str(),&end,10);
        return end && *end=='\0' && rank>=1 && rank<=15 ? static_cast<int>(rank) : 0;
    }
}
