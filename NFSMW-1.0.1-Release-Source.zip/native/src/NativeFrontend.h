#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <string>
#include "ShopCatalog.h"

namespace NFSMWAP
{
    inline bool SquareLogoSize(float& width,float& height) {
        if(!std::isfinite(width)||!std::isfinite(height)||width==0||height==0)return false;
        const float side=std::min(std::abs(width),std::abs(height));
        if(std::abs(std::abs(width)-side)<0.001f && std::abs(std::abs(height)-side)<0.001f)return false;
        width=std::copysign(side,width);height=std::copysign(side,height);return true;
    }
    inline std::string NativeShopCashLabel(int amount)
    {
        if (amount<0) amount=0;
        std::string value=std::to_string(amount);
        for (int n=static_cast<int>(value.size())-3;n>0;n-=3) value.insert(static_cast<std::size_t>(n),",");
        return "$"+value;
    }

    inline std::string NativeShopPriceLabel(int amount)
    {return amount<=0 ? "FREE" : NativeShopCashLabel(amount);}

    inline bool NativeCareerDeliveryMode(std::uint32_t flags)
    {

        return (flags&1u)!=0 && (flags&0xEu)==0;
    }

    template<class ReadWord,class WriteWord>
    bool PrepareNativeOwnedCareerSelection(std::uintptr_t screen,std::uint32_t ownedHandle,
                                          ReadWord read,WriteWord write)
    {
        std::uint32_t player=0,datum=0,filter=0,previousHandle=0,previousLock=0,previousTimer=0;
        if (!screen || ownedHandle>=200u || !read(screen+106u*4u,player) || player!=0 ||
            !read(screen+13u*4u,datum) || datum<0x10000u || (datum&3u) ||
            !read(screen+107u*4u,filter) || !(filter&1u) || !read(datum+8u,previousHandle) ||
            !read(datum+12u,previousLock) || !read(screen+14u*4u,previousTimer)) return false;


        if (!write(datum+8u,ownedHandle)) return false;


        if (!write(datum+12u,previousLock&0xFFFFFF00u)) {write(datum+8u,previousHandle);return false;}
        if (!write(screen+14u*4u,0u)) {write(datum+12u,previousLock);write(datum+8u,previousHandle);return false;}
        if (write(screen+107u*4u,(filter&0xFFFF0000u)|2u)) return true;
        write(screen+14u*4u,previousTimer);write(datum+12u,previousLock);
        write(datum+8u,previousHandle);
        return false;
    }

    inline bool NativeStoreMode(std::uint32_t flags, bool dealership)
    {

        return dealership ? (flags&0x8000u)!=0 : (flags&1u)!=0 && (flags&0x8000u)==0;
    }

    struct NativeDealerSelection { std::uintptr_t stable = 0; unsigned int handle = 0; };
    template<class ReadWord>
    bool ResolveNativeDealerSelection(std::uintptr_t screen, std::uintptr_t database,
                                     ReadWord read, NativeDealerSelection& selected)
    {
        selected={};
        std::uint32_t player=0, datum=0, profile=0, handle=0;
        if (!screen || !database || !read(screen+106u*4u,player) || player>1 ||
            !read(screen+13u*4u,datum) || datum<0x10000u || (datum&3u) ||
            !read(database+(4u+player)*4u,profile) || profile<0x10000u || (profile&3u) ||
            !read(datum+8u,handle) || (handle&0xFFu)==0xFFu) return false;
        selected={profile+0x414u,handle&0xFFu};
        return true;
    }


    struct NativeFEObjectPrefix
    {
        std::uint32_t vtable, next, prev;
        std::uint32_t guid, nameHash, namePointer;
        std::uint32_t type, flags;
    };
    static_assert(offsetof(NativeFEObjectPrefix,type)==0x18u);
    static_assert(offsetof(NativeFEObjectPrefix,namePointer)==0x14u);


    constexpr std::size_t FEStringBufferOffset=0x64u;
    constexpr std::size_t FEStringFormatOffset=0x6Cu;
    constexpr std::size_t FEStringMaxWidthOffset=0x74u;
    constexpr std::uint32_t FEStringWordWrap=0x10u;
    constexpr std::uint32_t FEStringHorizontalMask=0x3u;
    constexpr std::uint32_t FEStringHorizontalCenter=0x1u;
    constexpr std::uint32_t FEStringLiteral=0x2u|0x20u;


    constexpr std::uint32_t FERewardLiteral=0x2u|0x800u;

    inline std::u16string NativeShopWideText(const std::string& value)
    {
        std::u16string result;
        for (std::size_t n=0;n<value.size();)
        {
            const auto first=static_cast<unsigned char>(value[n++]);
            std::uint32_t code=first;int extra=0;
            if (first>=0xC2u && first<=0xDFu) {code=first&0x1Fu;extra=1;}
            else if (first>=0xE0u && first<=0xEFu) {code=first&0x0Fu;extra=2;}
            else if (first>=0xF0u && first<=0xF4u) {code=first&0x7u;extra=3;}
            else if (first>=0x80u) code=0xFFFDu;
            const int length=extra;
            bool valid=true;
            while (extra--)
            {
                if (n>=value.size() || (static_cast<unsigned char>(value[n])&0xC0u)!=0x80u) {valid=false;break;}
                code=(code<<6u)|(static_cast<unsigned char>(value[n++])&0x3Fu);
            }
            if (!valid || (length==1 && code<0x80u) || (length==2 && code<0x800u) ||
                (length==3 && code<0x10000u) || code>0x10FFFFu || (code>=0xD800u && code<=0xDFFFu)) code=0xFFFDu;
            if (code<=0xFFFFu) result+=static_cast<char16_t>(code);
            else {code-=0x10000u;result+=static_cast<char16_t>(0xD800u+(code>>10u));result+=static_cast<char16_t>(0xDC00u+(code&0x3FFu));}
        }
        return result;
    }

    inline std::string WrapNativeShopLabel(const std::string& value, std::size_t columns)
    {
        if (!columns) return value;
        std::string result;
        std::size_t start=0;
        while (value.size()-start>columns)
        {
            auto end=value.rfind(' ',start+columns);
            if (end==std::string::npos || end<=start) end=start+columns;
            if (!result.empty()) result+='\n';
            result+=value.substr(start,end-start);
            start=end;
            if (value[start]==' ') ++start;
        }
        if (!result.empty()) result+='\n';
        return result+value.substr(start);
    }

    inline bool NativeFEObjectIsString(const void* object)
    {
        if (!object) return false;
        std::uint32_t type=0;
        std::memcpy(&type,static_cast<const unsigned char*>(object)+offsetof(NativeFEObjectPrefix,type),sizeof(type));
        return type==2u;
    }

    inline std::string NativeShopItemLabel(const ShopEntry& entry)
    {


        const auto suffix=entry.itemName.rfind(" Cash");
        if (entry.itemName.size()>5u && entry.itemName.front()=='$' && suffix==entry.itemName.size()-5u)
        {
            const auto amount=entry.itemName.substr(1,suffix-1);
            if (!amount.empty() && amount.find_first_not_of("0123456789,")==std::string::npos)
                return "Cash reward: "+amount;
        }
        if (entry.itemName.empty() && entry.itemType=="cash")
        {
            switch (entry.itemId)
            {
            case 1900001: return "Cash reward: 5,000";
            case 1900002: return "Cash reward: 10,000";
            case 1900003: return "Cash reward: 25,000";
            default: return "Cash reward (amount awaiting scout)";
            }
        }

        return entry.itemName.empty() ? "Waiting for AP item scout" : entry.itemName;
    }
}
