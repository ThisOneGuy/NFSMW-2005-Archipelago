#pragma once

#include <cstdint>
#include <string>

namespace NFSMWAP
{
    struct GameVersionInfo
    {
        std::string exePath;
        std::uint64_t fileSize = 0;
        bool supported = false;
    };

    std::string GetGameDirectory();
    GameVersionInfo DetectGameVersion();

    constexpr std::uint64_t SupportedSpeedExeSize = 6029312ULL;
}
