#include "ShopCatalog.h"
#include "CarIdentity.h"

#include <algorithm>
#include <cctype>
#include <mutex>
#include <sstream>
#include <unordered_map>

#include "BridgeClient.h"
#include "Logger.h"

namespace
{
    std::mutex g_shopMutex;
    std::unordered_map<int, NFSMWAP::ShopEntry> g_shopEntries;
    std::size_t g_lastLoggedHundred = 0;

    std::string NormalizeCarLookupKey(const std::string& value)
    {
        return NFSMWAP::CarIdentityKey(value);
    }

}

namespace NFSMWAP
{
    void UpdateShopEntry(const ShopEntry& entry)
    {
        if (entry.locationId <= 0)
            return;

        std::size_t count = 0;
        {
            std::lock_guard<std::mutex> lock(g_shopMutex);
            g_shopEntries[entry.locationId] = entry;
            count = g_shopEntries.size();
        }

        const std::size_t hundred = count / 100;
        if (count == 1 || (hundred > g_lastLoggedHundred && count % 100 == 0))
        {
            g_lastLoggedHundred = hundred;
            std::ostringstream line;
            line << "AP shop catalog received: " << count << " entries.";
            Log(line.str());
        }
    }

    bool GetShopEntry(int locationId, ShopEntry& entry)
    {
        std::lock_guard<std::mutex> lock(g_shopMutex);
        auto it = g_shopEntries.find(locationId);
        if (it == g_shopEntries.end())
            return false;
        entry = it->second;
        return true;
    }

    bool GetShopEntryForCar(const std::string& locationType, const std::string& car, ShopEntry& entry)
    {
        const std::string wantedCar = NormalizeCarLookupKey(car);
        std::lock_guard<std::mutex> lock(g_shopMutex);
        for (const auto& pair : g_shopEntries)
        {
            const ShopEntry& candidate = pair.second;
            if (candidate.locationType == locationType && NormalizeCarLookupKey(candidate.car) == wantedCar)
            {
                entry = candidate;
                return true;
            }
        }
        return false;
    }

    std::vector<ShopEntry> GetShopEntriesForCar(const std::string& locationType, const std::string& car)
    {
        std::vector<ShopEntry> result;
        const std::string wantedCar = NormalizeCarLookupKey(car);
        std::lock_guard<std::mutex> lock(g_shopMutex);
        for (const auto& pair : g_shopEntries)
        {
            const ShopEntry& candidate = pair.second;
            if (candidate.locationType == locationType && NormalizeCarLookupKey(candidate.car) == wantedCar)
                result.push_back(candidate);
        }
        std::sort(result.begin(), result.end(), [](const ShopEntry& a, const ShopEntry& b)
        {
            return a.locationId < b.locationId;
        });
        return result;
    }

    void SetShopEntryChecked(int locationId, bool checked)
    {
        std::lock_guard<std::mutex> lock(g_shopMutex);
        auto it = g_shopEntries.find(locationId);
        if (it != g_shopEntries.end())
            it->second.checked = checked;
    }

    std::size_t GetShopEntryCount()
    {
        std::lock_guard<std::mutex> lock(g_shopMutex);
        return g_shopEntries.size();
    }

    bool RequestShopPurchase(int locationId)
    {
        ShopEntry entry;
        if (!GetShopEntry(locationId, entry) || entry.checked)
            return false;

        std::ostringstream message;
        message << "{\"type\":\"shop_purchase\",\"location_id\":"
                << locationId
                << "}";
        return SendBridgeLine(message.str());
    }
}
