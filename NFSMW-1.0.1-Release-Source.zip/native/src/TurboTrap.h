#pragma once
#include <cstdint>
#include <string>

namespace NFSMWAP {
    constexpr int TurboTrapItemId=1950001;
    constexpr int BrakeTrapItemId=1950002;
    constexpr int FlashBangTrapItemId=1950003;
    constexpr int TruckTrapItemId=1950004;
    constexpr int SpeedbreakerTrapItemId=1950005;
    constexpr std::uint64_t BrakeTrapDurationMs=3000;
    constexpr std::uint64_t TurboLeadMs=2000,TurboEndMs=17000;

    constexpr std::uint64_t FlashBangLeadMs=1000,FlashBangEndMs=6316,FlashBangFadeMs=500;


    constexpr std::uint64_t TruckTrapCueMs=5000,TruckTrapEndMs=6316;
    constexpr float TurboSpeedMps=156.464f;
    bool InitializeTurboTraps();
    void SetDrivingTrapsEnabled(bool enabled);

    bool QueueTurboTrap(int index,int item,const std::string& session,bool trigger);
    void TurboTrapMainThreadTick();
    bool DrivingTrapsPending();

    unsigned char FlashBangOpacity();
}
