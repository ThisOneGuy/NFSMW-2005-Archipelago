#pragma once

#include <string>

namespace NFSMWAP
{


    void ObserveCareerEventID(const std::string& eventId);
    int GetLastCareerRank();
    bool IsLiveCareerMode();
    void CareerContextMainThreadTick();
    int GetActiveRivalRank();
    void ClearActiveRivalRank();
}
