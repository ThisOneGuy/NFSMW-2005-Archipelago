#pragma once
#include "ItemInventory.h"
#include "CarIdentity.h"
#include "NativeShopLogic.h"
#include <algorithm>

namespace NFSMWAP
{
    inline int EquipmentPhysicsType(unsigned int menu)
    {
        switch (menu) {
        case 0x201:return 4;case 0x202:return 3;case 0x203:return 2;
        case 0x204:return 6;case 0x205:return 0;case 0x206:return 1;case 0x207:return 5;
        default:return -1;
        }
    }
    inline int EquipmentLevel(const std::string& tier,int type,int packages)
    {
        if (tier=="Stock") return 0;
        if (tier=="Unique") return type>=0 && type<7 && packages>0 ? 7 : -1;
        const bool four=type==1 || type==3 || type==4;
        const int maximum=four ? 4 : 3;
        int level=tier=="Ultimate" ? maximum : tier=="Super Pro" ? maximum-1 :
            tier=="Pro" ? maximum-2 : tier=="Race" && four ? 1 : -1;
        if (level<1 || packages<1 || packages>maximum) return -1;


        return std::max(1,level-(maximum-packages));
    }
    inline bool EquipmentCategoryAllowed(unsigned int category)
    {

        return category==0x802u || EquipmentPhysicsType(category)>=0;
    }
    inline bool BackroomVisualRoot(unsigned int category)
    {return (category&0xFFFFu)==0x801u || (category&0xFFFFu)==0x803u;}

    struct EquipmentText
    {
        std::string title,car,description,status;
    };

    inline EquipmentText EquipmentLabels(const ShopEntry& entry)
    {
        const bool unique=entry.itemType=="native_unique";
        const bool stock=entry.tier=="Stock";
        EquipmentText text;
        text.title=entry.category+" - "+(unique ? "Unique (Junkman)" : entry.tier);
        text.car=CarDisplayName(entry.car);
        text.description=stock ? "Factory equipment" : unique ? "Earned Unique performance part" : "Received Archipelago upgrade";
        text.status=entry.checked ? "Equipped" : unique ? "Equip | Cost: 1 Unique marker" : "Equip | Cost: FREE";
        return text;
    }
    inline std::vector<ShopEntry> EquipmentCatalog(const std::vector<ReceivedItem>& inventory,
                                                  const std::string& car,unsigned int menu,int packages,bool unique=false)
    {
        const int type=EquipmentPhysicsType(menu);
        if (type<0 || packages<1) return {};
        const std::string category=NativePerformanceCategory(type);
        ShopEntry stock;stock.locationId=-1;stock.car=car;stock.category=category;stock.tier="Stock";
        stock.itemName=car+" - "+category+" Stock";stock.itemType="equipment";
        std::vector<ShopEntry> rows{stock};
        for (const auto& item:inventory) {
            if (item.itemId<=0 || item.itemType!="performance_part" || CarIdentityKey(item.car)!=CarIdentityKey(car) || CanonicalPerformanceCategory(item.category)!=category ||
                EquipmentLevel(item.tier,type,packages)<1) continue;
            if (std::any_of(rows.begin(),rows.end(),[&item](const ShopEntry& r){return r.itemId==item.itemId;})) continue;
            ShopEntry row;row.locationId=-item.itemId;row.itemId=item.itemId;row.car=car;
            row.category=category;row.tier=item.tier;row.itemType="equipment";
            row.itemName=item.itemName.empty() || item.category=="Tyres"
                ? car+" - "+category+" "+item.tier+" Unlock" : item.itemName;
            rows.push_back(row);
        }
        std::sort(rows.begin()+1,rows.end(),[type,packages](const ShopEntry& a,const ShopEntry& b) {
            const int x=EquipmentLevel(a.tier,type,packages),y=EquipmentLevel(b.tier,type,packages);
            return x==y ? a.itemId<b.itemId : x<y;
        });
        if (unique) {
            ShopEntry row;row.locationId=-2;row.car=car;row.category=category;row.tier="Unique";
            row.itemType="native_unique";row.itemName=car+" - "+category+" Unique (Junkman)";rows.push_back(row);
        }
        return rows;
    }
}
