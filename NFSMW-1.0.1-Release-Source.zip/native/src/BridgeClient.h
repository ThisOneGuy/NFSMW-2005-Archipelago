#pragma once


#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <WinSock2.h>
#include <WS2tcpip.h>
#include <Windows.h>

#include <string>

namespace NFSMWAP
{
    void ConfigureBridge(const std::string& host, int port);
    DWORD WINAPI BridgeClientThread(LPVOID);
    bool SendBridgeLine(const std::string& line);
    bool IsBridgeConnected();
}
