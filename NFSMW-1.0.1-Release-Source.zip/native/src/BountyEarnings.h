#pragma once
#include <cstdint>
#include <limits>
namespace NFSMWAP {
inline std::int32_t ScaleEarnedBounty(std::int32_t amount,unsigned percent,unsigned& remainder) {
    if(amount<=0 || percent==100u || percent<1u || percent>10000u)return amount;
    const auto value=static_cast<std::uint64_t>(amount)*percent+remainder;
    remainder=static_cast<unsigned>(value%100u);
    const auto scaled=value/100u;
    return scaled>static_cast<std::uint64_t>(std::numeric_limits<std::int32_t>::max()) ?
        std::numeric_limits<std::int32_t>::max() : static_cast<std::int32_t>(scaled);
}
void BountyEarningsMainThreadTick();
}
