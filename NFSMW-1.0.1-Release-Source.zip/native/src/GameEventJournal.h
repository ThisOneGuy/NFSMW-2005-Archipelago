#pragma once
#include <string>
namespace NFSMWAP {
    bool RecordGameEvent(const std::string& key,const std::string& payload);
    void ReplayGameEvents();
    void AcknowledgeGameEvent(const std::string& key,const std::string& session);
}
