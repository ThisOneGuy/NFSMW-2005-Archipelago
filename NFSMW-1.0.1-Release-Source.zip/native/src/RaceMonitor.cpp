#include "RaceMonitor.h"
#include "NativeRaceIdentity.h"
#include <cstring>
#include "GameEventJournal.h"
#include "RaceFinishGate.h"

#include <Windows.h>
#include <cstdint>
#include <iomanip>
#include <sstream>
#include <string>

#include "Logger.h"
#include "BridgeClient.h"
#include "CareerContext.h"
#include "RivalRaceIdentity.h"
#include "NotificationOverlay.h"

namespace
{
    constexpr std::uintptr_t GameFlowManagerAddress = 0x00925E90u;
    constexpr std::uintptr_t GRaceStatusPointerAddress = 0x0091E000u;
    constexpr std::size_t GRaceParametersIndex = 1626;
    constexpr std::uintptr_t GRaceParametersGetEventIDAddress = 0x005FBA70u;
    constexpr std::uintptr_t GRaceStatusGetRacerInfoAddress = 0x005DBED0u;


    constexpr std::size_t GRacerInfoRankingOffset = 0x10u;
    constexpr std::size_t GRacerInfoPctRaceCompleteOffset = 0x18u;
    constexpr std::size_t GRacerInfoFinishedRacingOffset = 0x21u;

    using GetEventIDFn = char* (__thiscall*)(void*);
    using GetRacerInfoFn = DWORD* (__thiscall*)(DWORD*, int);

    std::string Hex(std::uintptr_t value)
    {
        std::ostringstream out;
        out << "0x"
            << std::uppercase
            << std::hex
            << std::setw(8)
            << std::setfill('0')
            << value;
        return out.str();
    }

    bool IsReadableAddress(const void* ptr, std::size_t bytes)
    {
        if (!ptr || bytes == 0)
            return false;

        MEMORY_BASIC_INFORMATION mbi{};
        if (VirtualQuery(ptr, &mbi, sizeof(mbi)) == 0)
            return false;

        if (mbi.State != MEM_COMMIT)
            return false;

        if ((mbi.Protect & PAGE_GUARD) || (mbi.Protect & PAGE_NOACCESS))
            return false;

        const DWORD readable =
            PAGE_READONLY | PAGE_READWRITE | PAGE_WRITECOPY |
            PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE |
            PAGE_EXECUTE_WRITECOPY;

        if ((mbi.Protect & readable) == 0)
            return false;

        const auto start = reinterpret_cast<std::uintptr_t>(ptr);
        const auto end = start + bytes;
        const auto regionEnd =
            reinterpret_cast<std::uintptr_t>(mbi.BaseAddress) + mbi.RegionSize;

        return end <= regionEnd;
    }

    DWORD ReadGameFlowState()
    {
        const auto ptr =
            reinterpret_cast<const DWORD*>(GameFlowManagerAddress);

        if (!IsReadableAddress(ptr, sizeof(DWORD)))
            return 0xFFFFFFFFu;

        return *ptr;
    }

    DWORD* ReadRaceStatus()
    {
        const auto slot =
            reinterpret_cast<DWORD* const*>(GRaceStatusPointerAddress);

        if (!IsReadableAddress(slot, sizeof(DWORD*)))
            return nullptr;

        return *slot;
    }

    DWORD* ReadRaceParameters(DWORD* raceStatus)
    {
        if (!raceStatus)
            return nullptr;

        const auto paramsSlot =
            reinterpret_cast<DWORD* const*>(
                reinterpret_cast<std::uintptr_t>(raceStatus) + 0x1968u);

        if (!IsReadableAddress(paramsSlot, sizeof(DWORD*)))
            return nullptr;

        return *paramsSlot;
    }

    char* SafeCallGetEventID(DWORD* raceParameters) noexcept
    {
        if (!raceParameters)
            return nullptr;

        const auto fn =
            reinterpret_cast<GetEventIDFn>(
                GRaceParametersGetEventIDAddress);

        __try
        {
            return fn(raceParameters);
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return nullptr;
        }
    }

    DWORD* SafeGetRacerInfo(DWORD* raceStatus, int racerIndex) noexcept
    {
        if (!raceStatus)
            return nullptr;

        const auto fn =
            reinterpret_cast<GetRacerInfoFn>(
                GRaceStatusGetRacerInfoAddress);

        __try
        {
            return fn(raceStatus, racerIndex);
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return nullptr;
        }
    }

    bool IsActiveNativeRace(DWORD* raceStatus) noexcept
    {
        if(!raceStatus)return false;
        __try {


            return reinterpret_cast<int(__thiscall*)(void*)>(0x404A70u)(raceStatus)!=-1;
        } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }

    std::string CallGetEventID(DWORD* raceParameters)
    {
        char* eventID = SafeCallGetEventID(raceParameters);

        if (!eventID)
            return {};

        constexpr std::size_t maxLen = 128;
        std::size_t len = 0;

        while (len < maxLen)
        {
            if (!IsReadableAddress(eventID + len, 1))
                return {};

            if (eventID[len] == '\0')
                break;

            ++len;
        }

        if (len == 0 || len == maxLen)
            return {};

        return std::string(eventID, len);
    }

    bool ReadLocalRacerState(
        DWORD* raceStatus,
        int& ranking,
        float& pctComplete,
        bool& finished, bool& failed)
    {
        DWORD* racer = SafeGetRacerInfo(raceStatus, 0);
        if (!racer)
            return false;

        const auto base =
            reinterpret_cast<std::uintptr_t>(racer);

        const auto rankingPtr =
            reinterpret_cast<const std::int32_t*>(
                base + GRacerInfoRankingOffset);

        const auto pctPtr =
            reinterpret_cast<const float*>(
                base + GRacerInfoPctRaceCompleteOffset);

        const auto finishedPtr =
            reinterpret_cast<const BYTE*>(
                base + GRacerInfoFinishedRacingOffset);

        if (!IsReadableAddress(rankingPtr, sizeof(*rankingPtr)) ||
            !IsReadableAddress(pctPtr, sizeof(*pctPtr)) ||
            !IsReadableAddress(finishedPtr, sizeof(*finishedPtr)))
        {
            return false;
        }

        const auto bytes=reinterpret_cast<const BYTE*>(racer);
        if(!IsReadableAddress(bytes,0x191u))return false;
        failed=bytes[0x1Cu] || bytes[0x1Du] || bytes[0x1Eu] || bytes[0x1Fu] || bytes[0x190u];
        ranking = *rankingPtr;
        pctComplete = *pctPtr;
        finished = (*finishedPtr != 0);
        return true;
    }

    bool TimedRaceExpired(DWORD* raceStatus) noexcept {
        const auto flag=reinterpret_cast<const BYTE*>(raceStatus)+0x1989u;
        return !IsReadableAddress(flag,1u) || *flag!=0;
    }
    bool IsTimedRace(void* parameters) noexcept
    {
        __try {return parameters && reinterpret_cast<int(__thiscall*)(void*)>(0x5FAA20u)(parameters)==4;}
        __except(EXCEPTION_EXECUTE_HANDLER) {return true;}
    }
    bool IsNativeBossRace(void* parameters)
    {
        __try {return parameters && reinterpret_cast<bool(__thiscall*)(void*)>(0x5FBD90u)(parameters);}
        __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }
}

namespace NFSMWAP
{
    DWORD WINAPI RaceMonitorThread(LPVOID)
    {
        Log("Race monitor 1.0.1 started.");
        Log("Read-only local-player finish/ranking detector enabled.");
        Log("Local Career player: racer index 0.");
        Log("GRacerInfo mRanking offset: +0x10.");
        Log("GRacerInfo mPctRaceComplete offset: +0x18.");
        Log("GRacerInfo mFinishedRacing offset: +0x21.");

        Sleep(3000);

        DWORD lastGameFlow = 0xFFFFFFFFu;
        DWORD* lastRaceStatus =
            reinterpret_cast<DWORD*>(~std::uintptr_t{0});

        std::string currentEvent;
        std::string lastLoggedEvent;


        RaceFinishGate finishGate;
        bool lastFinished = false;
        int challengeRank = 0;
        NativeRaceIdentity raceIdentity{};
        int lastRanking = -999;
        int lastPctBucket = -1;

        while (true)
        {
            const DWORD gameFlow = ReadGameFlowState();
            DWORD* raceStatus = ReadRaceStatus();
            DWORD* raceParameters = ReadRaceParameters(raceStatus);

            if (gameFlow != lastGameFlow)
            {
                std::ostringstream line;
                line << "GAME FLOW STATE: " << gameFlow;
                if (gameFlow == 6)
                    line << " (Gameplay)";
                Log(line.str());

                if (lastGameFlow == 6 && gameFlow != 6)
                {
                    Log("Gameplay exited. Last active event: " +
                        (currentEvent.empty()
                            ? std::string("<unknown>")
                            : currentEvent));

                    ClearActiveRivalRank();
                    challengeRank = 0;
                    lastLoggedEvent.clear();
                    currentEvent.clear();

                    finishGate.Reset();
                    lastFinished = false;
                    lastRanking = -999;
                    lastPctBucket = -1;
                }

                lastGameFlow = gameFlow;
            }

            if (raceStatus != lastRaceStatus)
            {
                Log("GRaceStatus pointer: " +
                    Hex(reinterpret_cast<std::uintptr_t>(raceStatus)));

                lastRaceStatus = raceStatus;

                finishGate.Reset();
                lastFinished = false;
                lastRanking = -999;
                lastPctBucket = -1;
            }

            currentEvent.clear();

            if (gameFlow == 6 && raceStatus && raceParameters)
                currentEvent = CallGetEventID(raceParameters);

            if (!currentEvent.empty() &&
                currentEvent != lastLoggedEvent)
            {
                Log("ACTIVE RACE EVENT ID: " + currentEvent);
                ObserveCareerEventID(currentEvent);


                challengeRank=LatchRivalChallenge(currentEvent,IsNativeBossRace(raceParameters),challengeRank);
                raceIdentity={};
                if(ReadNativeRaceIdentity(raceParameters,challengeRank?challengeRank:GetLastCareerRank(),raceIdentity)&&raceIdentity.boss)
                    challengeRank=raceIdentity.rank;
                lastLoggedEvent = currentEvent;



                finishGate.Reset();
                lastFinished = false;
                lastRanking = -999;
                lastPctBucket = -1;
            }

            if(gameFlow==6&&raceParameters&&!currentEvent.empty()) {
                NativeRaceIdentity observed{};
                if(ReadNativeRaceIdentity(raceParameters,challengeRank?challengeRank:GetLastCareerRank(),observed)) {
                    if(observed.rank!=raceIdentity.rank||observed.stage!=raceIdentity.stage||observed.index!=raceIdentity.index||
                       std::strcmp(observed.track,raceIdentity.track)!=0) {
                        raceIdentity=observed;finishGate.Reset();lastFinished=false;
                    }
                    if(observed.boss) {
                        challengeRank=observed.rank;
                        std::ostringstream unlocked;
                        unlocked<<"{\"type\":\"blacklist_unlocked\",\"race_kind\":\"rival\",\"blacklist_rank\":"<<observed.rank
                                <<",\"rival_rank\":"<<observed.rank<<"}";
                        RecordGameEvent("blacklist:unlocked:"+std::to_string(observed.rank),unlocked.str());
                    }
                }
            }
            if (gameFlow == 6 && raceStatus && !currentEvent.empty())
            {
                int ranking = 0;
                float pctComplete = 0.0f;
                bool finished = false, failed = false;

                if (ReadLocalRacerState(
                        raceStatus,
                        ranking,
                        pctComplete,
                        finished,failed))
                {


                    if (ranking != lastRanking)
                    {
                        std::ostringstream line;
                        line << "LOCAL RACER RANKING: "
                             << ranking
                             << ", event="
                             << currentEvent;
                        Log(line.str());
                        lastRanking = ranking;
                    }


                    int pctBucket =
                        static_cast<int>(pctComplete / 25.0f);

                    if (pctBucket != lastPctBucket)
                    {
                        std::ostringstream line;
                        line << "LOCAL RACER PROGRESS: "
                             << std::fixed
                             << std::setprecision(1)
                             << pctComplete
                             << "%, event="
                             << currentEvent;
                        Log(line.str());
                        lastPctBucket = pctBucket;
                    }


                    const bool earnedFinish=finishGate.Observe(IsLiveCareerMode()&&(finished||IsActiveNativeRace(raceStatus)),finished,ranking,pctComplete);
                    if (finished && !lastFinished && earnedFinish)
                    {
                        std::ostringstream line;
                        line << "LOCAL PLAYER FINISHED: event="
                             << currentEvent
                             << ", final ranking="
                             << ranking;
                        Log(line.str());

                        {
                            if (WinningRaceResult(ranking,pctComplete,IsTimedRace(raceParameters),failed,TimedRaceExpired(raceStatus)))
                            {
                                Log(
                                    "PLAYER WIN DETECTED: event=" +
                                    currentEvent);


                                QueueNotification(
                                    "RACE WON",
                                    std::string("EVENT: ") + currentEvent,
                                    "CHECKING ARCHIPELAGO...",
                                    2500);

                                std::ostringstream bridge;
                                bridge
                                    << "{\"type\":\"race_result\","
                                    << "\"event_id\":\"" << currentEvent << "\","
                                    << "\"ranking\":" << ranking << ","
                                    << "\"rival_rank\":" << challengeRank << ","
                                    << "\"won\":true" << NativeRaceIdentityJson(raceIdentity) << "}";
                                if (!RecordGameEvent("race:v3:"+currentEvent+":"+std::to_string(raceIdentity.rank)+":"+std::to_string(challengeRank)+":"+std::to_string(raceIdentity.stage)+":"+std::to_string(raceIdentity.index),bridge.str())) {
                                    Log("Race win journal could not be saved; retrying this result.");
                                    Sleep(250);continue;
                                }
                            }
                            else if (ranking >= 1)
                            {
                                std::ostringstream loss;
                                loss << "PLAYER LOSS DETECTED: event="
                                     << currentEvent
                                     << ", final ranking="
                                     << ranking;
                                Log(loss.str());

                                std::ostringstream bridge;
                                bridge
                                    << "{\"type\":\"race_result\","
                                    << "\"event_id\":\"" << currentEvent << "\","
                                    << "\"ranking\":" << ranking << ","
                                    << "\"won\":false}";
                                if (!SendBridgeLine(bridge.str()))
                                    Log("Bridge not connected; loss event was not forwarded.");
                            }
                            else
                            {
                                Log(
                                    "RACE RESULT UNKNOWN: invalid final ranking.");
                            }


                        }
                    }

                    lastFinished = finished;
                }
            }

            Sleep(100);
        }
    }
}
