#pragma once

#include <string>

namespace NFSMWAP::JsonLite
{
    bool GetString(const std::string& json, const char* key, std::string& value);
    bool GetInt(const std::string& json, const char* key, int& value);
    bool GetBool(const std::string& json, const char* key, bool& value);
    std::string Escape(const std::string& value);
}
