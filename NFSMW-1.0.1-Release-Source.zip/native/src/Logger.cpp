#include "Logger.h"

#include <Windows.h>
#include <fstream>
#include <mutex>
#include <sstream>
#include <iomanip>

namespace
{
    std::string g_logPath;
    std::mutex g_logMutex;

    std::string Timestamp()
    {
        SYSTEMTIME st{};
        GetLocalTime(&st);

        std::ostringstream out;
        out << std::setfill('0')
            << std::setw(4) << st.wYear << "-"
            << std::setw(2) << st.wMonth << "-"
            << std::setw(2) << st.wDay << " "
            << std::setw(2) << st.wHour << ":"
            << std::setw(2) << st.wMinute << ":"
            << std::setw(2) << st.wSecond;
        return out.str();
    }
}

namespace NFSMWAP
{
    void InitializeLogger(const std::string& gameDirectory)
    {
        g_logPath = gameDirectory + "\\NFSMWArchipelago.log";

        std::lock_guard<std::mutex> lock(g_logMutex);
        std::ofstream file(g_logPath, std::ios::out | std::ios::trunc);
        if (file)
        {
            file << "NFSMW Archipelago log started: " << Timestamp() << "\n";
        }
    }

    void Log(const std::string& message)
    {
        std::lock_guard<std::mutex> lock(g_logMutex);
        if (g_logPath.empty())
            return;

        std::ofstream file(g_logPath, std::ios::out | std::ios::app);
        if (file)
        {
            file << "[" << Timestamp() << "] " << message << "\n";
        }

        std::string debuggerLine = "[NFSMWAP] " + message + "\n";
        OutputDebugStringA(debuggerLine.c_str());
    }

    std::string GetLogPath()
    {
        return g_logPath;
    }
}
