#include "JsonLite.h"

#include <cctype>
#include <cstdlib>
#include <sstream>

namespace
{
    bool FindValueStart(
        const std::string& json,
        const char* key,
        std::size_t& position)
    {
        const std::string needle = std::string("\"") + key + "\"";
        std::size_t found = json.find(needle);
        if (found == std::string::npos)
            return false;

        found = json.find(':', found + needle.size());
        if (found == std::string::npos)
            return false;

        ++found;
        while (found < json.size() &&
               std::isspace(static_cast<unsigned char>(json[found])))
        {
            ++found;
        }

        if (found >= json.size())
            return false;

        position = found;
        return true;
    }

    char TransliterateUnicode(unsigned int value)
    {
        switch (value)
        {
        case 0x00C0: case 0x00C1: case 0x00C2: case 0x00C3:
        case 0x00C4: case 0x00C5: case 0x00E0: case 0x00E1:
        case 0x00E2: case 0x00E3: case 0x00E4: case 0x00E5:
            return 'A';
        case 0x00C7: case 0x00E7:
            return 'C';
        case 0x00C8: case 0x00C9: case 0x00CA: case 0x00CB:
        case 0x00E8: case 0x00E9: case 0x00EA: case 0x00EB:
            return 'E';
        case 0x00CC: case 0x00CD: case 0x00CE: case 0x00CF:
        case 0x00EC: case 0x00ED: case 0x00EE: case 0x00EF:
            return 'I';
        case 0x00D1: case 0x00F1:
            return 'N';
        case 0x00D2: case 0x00D3: case 0x00D4: case 0x00D5:
        case 0x00D6: case 0x00F2: case 0x00F3: case 0x00F4:
        case 0x00F5: case 0x00F6:
            return 'O';
        case 0x00D9: case 0x00DA: case 0x00DB: case 0x00DC:
        case 0x00F9: case 0x00FA: case 0x00FB: case 0x00FC:
            return 'U';
        case 0x00DD: case 0x00FD: case 0x00FF:
            return 'Y';
        default:
            if (value <= 0x7F)
                return static_cast<char>(value);
            return '?';
        }
    }

    int HexDigit(char c)
    {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return 10 + c - 'a';
        if (c >= 'A' && c <= 'F') return 10 + c - 'A';
        return -1;
    }
}

namespace NFSMWAP::JsonLite
{
    bool GetString(
        const std::string& json,
        const char* key,
        std::string& value)
    {
        std::size_t p = 0;
        if (!FindValueStart(json, key, p) || json[p] != '"')
            return false;

        ++p;
        std::string out;
        while (p < json.size())
        {
            char c = json[p++];
            if (c == '"')
            {
                value = out;
                return true;
            }

            if (c != '\\')
            {
                out.push_back(c);
                continue;
            }

            if (p >= json.size())
                return false;

            char escaped = json[p++];
            switch (escaped)
            {
            case '"': out.push_back('"'); break;
            case '\\': out.push_back('\\'); break;
            case '/': out.push_back('/'); break;
            case 'b': out.push_back('\b'); break;
            case 'f': out.push_back('\f'); break;
            case 'n': out.push_back('\n'); break;
            case 'r': out.push_back('\r'); break;
            case 't': out.push_back('\t'); break;
            case 'u':
                if (p + 4 > json.size())
                    return false;
                {
                    unsigned int code = 0;
                    for (int i = 0; i < 4; ++i)
                    {
                        int digit = HexDigit(json[p + i]);
                        if (digit < 0)
                            return false;
                        code = (code << 4) | static_cast<unsigned int>(digit);
                    }
                    p += 4;
                    out.push_back(TransliterateUnicode(code));
                }
                break;
            default:
                out.push_back(escaped);
                break;
            }
        }
        return false;
    }

    bool GetInt(
        const std::string& json,
        const char* key,
        int& value)
    {
        std::size_t p = 0;
        if (!FindValueStart(json, key, p))
            return false;

        char* end = nullptr;
        long parsed = std::strtol(json.c_str() + p, &end, 10);
        if (end == json.c_str() + p)
            return false;

        value = static_cast<int>(parsed);
        return true;
    }

    bool GetBool(
        const std::string& json,
        const char* key,
        bool& value)
    {
        std::size_t p = 0;
        if (!FindValueStart(json, key, p))
            return false;

        if (json.compare(p, 4, "true") == 0)
        {
            value = true;
            return true;
        }
        if (json.compare(p, 5, "false") == 0)
        {
            value = false;
            return true;
        }
        return false;
    }

    std::string Escape(const std::string& value)
    {
        std::ostringstream out;
        for (unsigned char c : value)
        {
            switch (c)
            {
            case '\\': out << "\\\\"; break;
            case '"': out << "\\\""; break;
            case '\n': out << "\\n"; break;
            case '\r': out << "\\r"; break;
            case '\t': out << "\\t"; break;
            default:
                if (c >= 0x20 && c < 0x7F)
                    out << static_cast<char>(c);
                else
                    out << '?';
                break;
            }
        }
        return out.str();
    }
}
