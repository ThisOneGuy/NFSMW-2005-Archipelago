#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>
namespace NFSMWAP {
struct CareerBootBranch {std::uint32_t offset=0,original=0;};
struct CareerBootBranches {CareerBootBranch slots[2]{};unsigned count=0;};
inline bool FindCareerBootBranches(const unsigned char* code,std::size_t size,std::uint32_t address,std::uint32_t target,CareerBootBranches& result) {
    result={};
    if(!code||size<5u||size>0x1000u||address>0xFFFFFFFFu-size)return false;
    for(std::size_t offset=0;offset+5u<=size;++offset) {
        if(code[offset]!=0xE8u&&code[offset]!=0xE9u)continue;
        std::uint32_t displacement=0;std::memcpy(&displacement,code+offset+1u,4);
        if(address+static_cast<std::uint32_t>(offset)+5u+displacement!=target)continue;
        if(result.count==2u){result={};return false;}
        result.slots[result.count++]={static_cast<std::uint32_t>(offset+1u),displacement};offset+=4u;
    }
    return result.count!=0;
}
inline bool IsCareerStartupAliasPrompt(bool managed,bool starting,int flow,std::uint32_t language,std::uint32_t prompt,std::uint32_t operation) {
    const auto command=operation&0xF0u;
    return managed&&starting&&flow==3&&language==0xBE97590Fu&&prompt==0x01000000u&&
        !(operation&0x0FFF8000u)&&(command==0x20u||command==0x40u||command==0x60u||command==0xB0u||command==0xF0u);
}
struct BootProfileEntries {std::uint32_t* slots[32]{};unsigned count=0;};
inline bool FindBootProfileEntries(unsigned char* image,std::size_t size,BootProfileEntries& result) {
    result={};
    if(!image||size<0x1000u||size>0x4000000u||reinterpret_cast<std::uintptr_t>(image)>0xFFFFFFFFu)return false;
    const auto read16=[&](std::size_t offset){std::uint16_t value=0;if(offset<=size-2u)std::memcpy(&value,image+offset,2);return value;};
    const auto read32=[&](std::size_t offset){std::uint32_t value=0;if(offset<=size-4u)std::memcpy(&value,image+offset,4);return value;};
    const auto pe=read32(0x3Cu);
    if(read16(0)!=0x5A4Du||pe<64u||pe>size-0x100u||read32(pe)!=0x4550u||read16(pe+4u)!=0x14Cu||read16(pe+24u)!=0x10Bu)return false;
    const auto count=read16(pe+6u),optional=read16(pe+20u);const std::size_t sections=pe+24u+optional;
    if(!count||count>96u||optional<0x60u||sections>size-count*40u||read32(pe+80u)!=size)return false;
    const auto readable=[&](std::size_t section){return (read32(section+36u)&0x62000000u)==0x40000000u;};
    const auto text=[&](std::uint32_t address)->const char* {
        const auto base=reinterpret_cast<std::uintptr_t>(image);if(address<base||address-base>=size)return nullptr;
        const std::size_t offset=address-base;
        for(unsigned index=0;index<count;++index) {
            const auto section=sections+index*40u;const auto begin=read32(section+12u),length=read32(section+8u);
            if(!readable(section)||!length||begin>=size||length>size-begin||offset<begin||offset-begin>=length)continue;
            const auto available=begin+length-offset,limit=available<64u?available:64u;
            return std::memchr(image+offset,0,limit)?reinterpret_cast<const char*>(image+offset):nullptr;
        }
        return nullptr;
    };
    const auto profileStep=[](const char* name){
        return !std::strncmp(name,"MC_Main",7)||!std::strncmp(name,"MC_Bootup",9);
    };
    const auto bootStep=[&](const char* name){
        const auto length=std::strlen(name);
        return length>=4u&&!std::strcmp(name+length-4u,".fng")&&
            (profileStep(name)||!std::strncmp(name,"LS_",3)||!std::strncmp(name,"MW_LS_",6)||
             !std::strncmp(name,"WS_LS_",6)||!std::strcmp(name,"DiscErrorPC.fng"));
    };
    for(unsigned index=0;index<count;++index) {
        const auto section=sections+index*40u;const auto begin=read32(section+12u),length=read32(section+8u);
        if(!readable(section)||length<12u||begin>=size||length>size-begin)continue;
        for(std::size_t offset=(begin+3u)&~std::size_t(3u);offset+4u<=begin+length;offset+=4u) {
            const auto menu=text(read32(offset));if(!menu||std::strcmp(menu,"MainMenu.fng"))continue;
            std::uint32_t* found[12]{};unsigned used=0;bool splash=false;
            for(unsigned step=1;step<=12u&&offset>=begin+step*4u;++step) {
                const auto position=offset-step*4u;const auto name=text(read32(position));
                if(!name||!bootStep(name))break;
                if(std::strstr(name,"Splash"))splash=true;
                if(profileStep(name))found[used++]=reinterpret_cast<std::uint32_t*>(image+position);
            }
            if(!splash||!used)continue;
            for(unsigned n=0;n<used;++n) {
                bool duplicate=false;
                for(unsigned prior=0;prior<result.count;++prior)duplicate|=result.slots[prior]==found[n];
                if(duplicate)continue;
                if(result.count>=32u){result={};return false;}
                result.slots[result.count++]=found[n];
            }
        }
    }
    return result.count!=0;
}
bool PrimeCareerBootFlowEarly();
unsigned CareerBootProfileStepsSkipped();
}
