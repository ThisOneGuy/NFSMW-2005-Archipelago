#include "CareerBootstrap.h"
#include "NativeCareerMemory.h"
#include "CarIdentity.h"
#include "NativeFrontend.h"
#include "StoreRuntime.h"
#include "TurboTrap.h"

#include <Windows.h>
#include <algorithm>
#include <array>
#include <cctype>
#include <cstdint>
#include <cstddef>
#include <deque>
#include <mutex>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

#include "BridgeClient.h"
#include "CareerContext.h"
#include "Logger.h"
#include "NotificationOverlay.h"
#include "NativeShop.h"
#include "SeedConfig.h"
#include "BlacklistAppearance.h"
#include "ConnectionSetup.h"
#include "ShopCatalog.h"

namespace
{
    constexpr std::uintptr_t GameFlowStateAddress = 0x00925E90u;
    constexpr std::uintptr_t CurrentFECarRecordAddress = 0x009B9EC4u;
    constexpr std::uintptr_t FECarRecordGetTypeAddress = 0x005816B0u;
    constexpr std::uintptr_t GetCarTypeNameAddress = 0x00668370u;
    constexpr std::uintptr_t FEDatabaseAddress = 0x0091CF90u;
    constexpr std::size_t FECarTableCount = 200u;
    constexpr std::uintptr_t FEPlayerCarDBOffset = 0x414u;
    constexpr std::uintptr_t CFEngInstanceAddress = 0x0091CADCu;
    constexpr std::uintptr_t CFEngFindPackageWithControlAddress = 0x00516A90u;
    constexpr std::uintptr_t FEPlayerCarDBGetCarRecordByHandleAddress = 0x0056ECC0u;
    constexpr std::uintptr_t FEPlayerCarDBGetCustomizationRecordByHandleAddress = 0x0056F100u;
    constexpr std::uintptr_t FEPlayerCarDBBuildRideForPlayerAddress = 0x005910E0u;
    constexpr std::uintptr_t FEPlayerCarDBCreateCareerCarCall = 0x00599D45u;
    constexpr std::uintptr_t FEPlayerCarDBCreateNewCareerRecordAddress = 0x00580D60u;


    constexpr std::uintptr_t PVehicleConstructAddress = 0x00689820u;
    constexpr std::uintptr_t TextScanStartAddress = 0x00401000u;
    constexpr std::uintptr_t TextScanEndAddress = 0x00890000u;

    bool g_enabled = true;
    int g_purchaseHotkey = VK_F7;
    bool g_carLotScanDumped = false;
    std::size_t g_lastCarLotRecognizedCount = static_cast<std::size_t>(-1);
    std::string g_lastFrontendPackage;

    using FECarRecordGetTypeFn = int(__thiscall*)(void*);
    using CFEngFindPackageWithControlFn = void*(__thiscall*)(void*);

#pragma pack(push, 1)
    struct FECarRecordNative
    {
        std::uint32_t handle;
        std::uint32_t feKey;
        std::uint32_t vehicleKey;
        std::uint32_t filterBits;
        std::uint8_t customization;
        std::uint8_t careerHandle;
        std::uint16_t padding;
    };
#pragma pack(pop)

    static_assert(sizeof(FECarRecordNative) == 0x14, "NFSMW 1.3 FECarRecord size mismatch");


    struct VehicleParamsNative
    {
        std::uint32_t type;
        std::uint32_t name;
        std::uint32_t data;
        std::uint32_t pad;
        std::uint32_t driverClass;
        std::uint32_t vehicleKey;
        std::uint32_t direction;
        std::uint32_t position;
        std::uint32_t customization;
        std::uint32_t vehicleCache;
        std::uint32_t performanceMatch;
        std::uint32_t flags;
    };

#if defined(_M_IX86) || defined(__i386__)
    static_assert(sizeof(VehicleParamsNative) == 0x30, "MW05 VehicleParams size mismatch");
    static_assert(offsetof(VehicleParamsNative, driverClass) == 0x10, "MW05 VehicleParams::driverClass offset mismatch");
    static_assert(offsetof(VehicleParamsNative, vehicleKey) == 0x14, "MW05 VehicleParams::vehicleKey offset mismatch");
    static_assert(offsetof(VehicleParamsNative, customization) == 0x20, "MW05 VehicleParams::customization offset mismatch");
#endif

    constexpr std::uint32_t DriverClassHuman = 0u;
    constexpr std::uint32_t DriverClassRacer = 3u;
    constexpr std::uint32_t VehicleParamsNameKey = 0xA6B47FACu;

    volatile LONG g_carSelectLookupProxyActive = 0;
    volatile LONG g_carSelectLookupMapReady = 0;
    FECarRecordNative* g_lookupProxySources[32] = {};
    FECarRecordNative* g_lookupProxyTargets[32] = {};
    volatile LONG g_lookupHookLogBudget = 64;
    volatile LONG g_lookupCallCount = 0;
    volatile LONG g_lookupMappedCount = 0;
    volatile LONG g_lookupProxyInFlight = 0;
    volatile LONG g_customizationLookupCallCount = 0;
    volatile LONG g_customizationLookupMappedCount = 0;
    std::uint8_t g_lookupProxySourceCustomization[32] = {};
    std::uint8_t g_lookupProxyTargetCustomization[32] = {};
    std::vector<std::uintptr_t> g_patchedLookupCallsites;
    std::vector<std::uintptr_t> g_patchedCustomizationLookupCallsites;
    std::vector<std::uintptr_t> g_patchedBuildRideCallsites;
    bool g_callsiteProxiesEnabled = false;
    volatile LONG g_buildRideCallCount = 0;
    volatile LONG g_buildRideMappedCount = 0;
    volatile LONG g_buildRideProxyInFlight = 0;


    volatile LONG g_lastMappedBuildRideSourceHandle = 0;
    volatile LONG g_lastMappedBuildRideTargetHandle = 0;


    PVOID g_pvehicleVehHandle = nullptr;
    unsigned char g_pvehicleConstructOriginalByte = 0;
    DWORD g_pvehicleConstructOriginalProtect = 0;
    volatile LONG g_pvehicleBreakpointInstalled = 0;
    volatile LONG g_pvehicleBreakpointStepThreadId = 0;
    volatile LONG g_vehicleSpawnProxyCallCount = 0;
    volatile LONG g_vehicleSpawnHumanCount = 0;
    volatile LONG g_vehicleSpawnRacerCount = 0;
    volatile LONG g_vehicleSpawnAbiInlineCount = 0;
    volatile LONG g_vehicleSpawnAbiIndirectCount = 0;
    volatile LONG g_vehicleSpawnAbiScanCount = 0;
    volatile LONG g_vehicleSpawnUnresolvedCount = 0;
    volatile LONG g_vehicleSpawnUnresolvedCaptured = 0;
    std::uint32_t g_vehicleSpawnUnresolvedStack[16] = {};
    std::uint32_t g_vehicleSpawnUnresolvedIndirect[16] = {};
    volatile LONG g_vehicleSpawnUnresolvedIndirectReadable = 0;
    volatile LONG g_starterSpawnReady = 0;
    volatile LONG g_starterSpawnSourceVehicleKey = 0;
    volatile LONG g_starterSpawnTargetVehicleKey = 0;
    volatile LONG g_starterSpawnTargetCustomization = 0;
    volatile LONG g_starterSpawnMappedCount = 0;
    volatile LONG g_lastHumanEffectiveVehicleKey = 0;
    volatile LONG g_purchaseSpawnOverrideReady = 0;
    volatile LONG g_purchaseSpawnSourceVehicleKey = 0;
    volatile LONG g_purchaseSpawnTargetVehicleKey = 0;
    volatile LONG g_purchaseSpawnMappedCount = 0;
    volatile LONG g_bossSpawnReady = 0;
    volatile LONG g_bossSpawnActive = 0;
    volatile LONG g_bossSpawnRank = 0;
    volatile LONG g_bossSpawnSourceVehicleKey = 0;
    volatile LONG g_bossSpawnTargetVehicleKey = 0;
    volatile LONG g_bossSpawnTargetCustomization = 0;
    volatile LONG g_bossSpawnMappedCount = 0;
    volatile LONG g_bossSpawnLastMappedRank = 0;
    volatile LONG g_bossSpawnTableReady = 0;
    volatile LONG g_bossSpawnTableCount = 0;
    volatile LONG g_bossSpawnSourceKeys[16] = {};
    volatile LONG g_bossSpawnTargetKeys[16] = {};
    volatile LONG g_bossSpawnTargetCustomizations[16] = {};
    volatile LONG g_bossAppearanceVehicleKeys[16] = {};


    volatile LONG g_starterRideProxyReady = 0;
    volatile LONG g_starterRideSourceHandle = 0;
    volatile LONG g_starterRideTargetHandle = 0;
    volatile LONG g_starterRideMappedCount = 0;


    constexpr int BlacklistProxyMaxSources = 64;
    volatile LONG g_blacklistProxyActive = 0;
    volatile LONG g_blacklistProxyReady = 0;
    volatile LONG g_blacklistProxyRank = 0;
    FECarRecordNative* g_blacklistProxySources[BlacklistProxyMaxSources] = {};
    FECarRecordNative* g_blacklistProxyTarget = nullptr;
    std::uint8_t g_blacklistProxySourceCustomization[BlacklistProxyMaxSources] = {};
    std::uint8_t g_blacklistProxyTargetCustomization = 0xFFu;
    volatile LONG g_blacklistProxySourceCount = 0;
    volatile LONG g_blacklistLookupMappedCount = 0;
    volatile LONG g_blacklistBuildRideMappedCount = 0;
    volatile LONG g_blacklistCustomizationMappedCount = 0;

    std::mutex g_purchaseMutex;
    int g_nextPurchaseRequestId = 1;
    int g_pendingPurchaseLocationId = 0;
    int g_pendingPurchaseRequestId = 0;
    DWORD g_pendingPurchaseStartedTick = 0;
    bool g_pendingPurchaseAckReady = false;
    bool g_pendingPurchaseAccepted = false;
    std::string g_pendingPurchaseReason;
    int g_pendingPurchaseReservedCash = 0;
    bool g_pendingPurchaseCashDebited = false;
    std::uintptr_t g_pendingPurchaseCashAddress = 0;
    bool g_pendingPurchaseTimeoutShown = false;
    volatile LONG g_careerCashLogged = 0;

    struct PendingCarDelivery
    {
        int index = -1;
        int itemId = 0;
        std::string car;
    };

    std::mutex g_receivedCarMutex;
    std::deque<PendingCarDelivery> g_pendingCarDeliveries;

    struct StockRecordSnapshot
    {
        FECarRecordNative* record = nullptr;
        std::uint32_t feKey = 0;
        std::uint32_t vehicleKey = 0;
        std::string rawName;
        std::string friendlyName;
    };

    struct FrontendProxySlot
    {
        FECarRecordNative* source = nullptr;
        FECarRecordNative* target = nullptr;
        std::uint32_t originalFeKey = 0;
        std::uint32_t originalVehicleKey = 0;
        std::string sourceName;
        std::string targetName;
    };

    struct VehicleIdentitySnapshot
    {
        std::uint32_t feKey = 0;
        std::uint32_t vehicleKey = 0;
        std::uint8_t customization = 0;
        bool valid = false;
    };

    struct OwnedCarRowSnapshot
    {
        std::uint32_t handle = 0;
        std::uint32_t feKey = 0;
        std::uint32_t vehicleKey = 0;
        std::uint32_t filterBits = 0;
        std::uint8_t customization = 0;
        std::uint8_t careerHandle = 0;
        std::uint16_t padding = 0;
    };

    struct OwnedCarTableSnapshot
    {
        OwnedCarRowSnapshot rows[FECarTableCount] = {};
        bool valid = false;
    };

    using GetCarTypeNameFn = char*(__cdecl*)(int);

    void PublishLookupProxyMap(const std::vector<FrontendProxySlot>& slots)
    {
        InterlockedExchange(&g_carSelectLookupMapReady, 0);
        for (int i = 0; i < 32; ++i)
        {
            g_lookupProxySources[i] = nullptr;
            g_lookupProxyTargets[i] = nullptr;
            g_lookupProxySourceCustomization[i] = 0xFFu;
            g_lookupProxyTargetCustomization[i] = 0xFFu;
        }
        const std::size_t count = (std::min)(slots.size(), static_cast<std::size_t>(32));
        for (std::size_t i = 0; i < count; ++i)
        {
            g_lookupProxySources[i] = slots[i].source;
            g_lookupProxyTargets[i] = slots[i].target;
            g_lookupProxySourceCustomization[i] = slots[i].source ? slots[i].source->customization : 0xFFu;
            g_lookupProxyTargetCustomization[i] = slots[i].target ? slots[i].target->customization : 0xFFu;
        }
        if (count == 32u)
            InterlockedExchange(&g_carSelectLookupMapReady, 1);
    }


    using FEPlayerCarDBGetCarRecordByHandleFn = FECarRecordNative*(__thiscall*)(void*, unsigned int);

    FECarRecordNative* __fastcall FEPlayerCarDBLookupProxy(void* db, void*, unsigned int handle)
    {
        InterlockedIncrement(&g_lookupProxyInFlight);

        FEPlayerCarDBGetCarRecordByHandleFn original =
            reinterpret_cast<FEPlayerCarDBGetCarRecordByHandleFn>(FEPlayerCarDBGetCarRecordByHandleAddress);
        FECarRecordNative* result = original(db, handle);
        InterlockedIncrement(&g_lookupCallCount);

        FECarRecordNative* mappedResult = result;
        if (result &&
            InterlockedCompareExchange(&g_carSelectLookupProxyActive, 0, 0) != 0 &&
            InterlockedCompareExchange(&g_carSelectLookupMapReady, 0, 0) != 0)
        {
            for (int i = 0; i < 32; ++i)
            {
                if (g_lookupProxySources[i] == result && g_lookupProxyTargets[i])
                {
                    InterlockedIncrement(&g_lookupMappedCount);
                    mappedResult = g_lookupProxyTargets[i];
                    break;
                }
            }
        }

        if (mappedResult == result && result &&
            InterlockedCompareExchange(&g_blacklistProxyActive, 0, 0) != 0 &&
            InterlockedCompareExchange(&g_blacklistProxyReady, 0, 0) != 0 &&
            g_blacklistProxyTarget)
        {
            const LONG count = InterlockedCompareExchange(&g_blacklistProxySourceCount, 0, 0);
            for (LONG i = 0; i < count && i < BlacklistProxyMaxSources; ++i)
            {
                if (g_blacklistProxySources[i] == result)
                {
                    InterlockedIncrement(&g_blacklistLookupMappedCount);
                    mappedResult = g_blacklistProxyTarget;
                    break;
                }
            }
        }

        InterlockedDecrement(&g_lookupProxyInFlight);
        return mappedResult;
    }

    using FEPlayerCarDBBuildRideForPlayerFn = void(__thiscall*)(void*, unsigned int, int, void*);

    void __fastcall FEPlayerCarDBBuildRideForPlayerProxy(void* db, void*, unsigned int handle, int mode, void* ride)
    {
        InterlockedIncrement(&g_buildRideProxyInFlight);

        FEPlayerCarDBBuildRideForPlayerFn original =
            reinterpret_cast<FEPlayerCarDBBuildRideForPlayerFn>(FEPlayerCarDBBuildRideForPlayerAddress);

        InterlockedIncrement(&g_buildRideCallCount);
        unsigned int effectiveHandle = handle;


        if (InterlockedCompareExchange(&g_carSelectLookupProxyActive, 0, 0) != 0 &&
            InterlockedCompareExchange(&g_carSelectLookupMapReady, 0, 0) != 0)
        {
            for (int i = 0; i < 32; ++i)
            {
                if (g_lookupProxySources[i] && g_lookupProxyTargets[i] &&
                    g_lookupProxySources[i]->handle == handle)
                {
                    effectiveHandle = g_lookupProxyTargets[i]->handle;


                    InterlockedExchange(&g_lastMappedBuildRideSourceHandle, static_cast<LONG>(handle));
                    InterlockedExchange(&g_lastMappedBuildRideTargetHandle, static_cast<LONG>(effectiveHandle));
                    if (effectiveHandle != handle)
                        InterlockedIncrement(&g_buildRideMappedCount);
                    break;
                }
            }
        }

        if (InterlockedCompareExchange(&g_blacklistProxyActive, 0, 0) != 0 &&
            InterlockedCompareExchange(&g_blacklistProxyReady, 0, 0) != 0 &&
            g_blacklistProxyTarget)
        {
            const LONG count = InterlockedCompareExchange(&g_blacklistProxySourceCount, 0, 0);
            for (LONG i = 0; i < count && i < BlacklistProxyMaxSources; ++i)
            {
                FECarRecordNative* source = g_blacklistProxySources[i];
                if (source && source->handle == effectiveHandle)
                {
                    const unsigned int mapped = g_blacklistProxyTarget->handle;
                    if (mapped != effectiveHandle)
                        InterlockedIncrement(&g_blacklistBuildRideMappedCount);
                    effectiveHandle = mapped;
                    break;
                }
            }
        }

        original(db, effectiveHandle, mode, ride);
        InterlockedDecrement(&g_buildRideProxyInFlight);
    }

    bool ValidateVehicleParamsNative(VehicleParamsNative* params)
    {
        if (reinterpret_cast<std::uintptr_t>(params)<0x10000u || (reinterpret_cast<std::uintptr_t>(params)&3u))
            return false;
        __try
        {
            return params->name == VehicleParamsNameKey &&
                   params->driverClass <= 6u &&
                   params->vehicleKey != 0u;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return false;
        }
    }

    VehicleParamsNative* ResolveVehicleParamsFromEntryStack(CONTEXT* context, LONG* abiMode)
    {
#if defined(_M_IX86)
        if (abiMode)
            *abiMode = 0;
        if (!context)
            return nullptr;

        const std::uintptr_t stack = static_cast<std::uintptr_t>(context->Esp);


        VehicleParamsNative* inlineParams =
            reinterpret_cast<VehicleParamsNative*>(stack + sizeof(std::uint32_t));
        if (ValidateVehicleParamsNative(inlineParams))
        {
            if (abiMode)
                *abiMode = 1;
            return inlineParams;
        }


        VehicleParamsNative* indirect = nullptr;
        __try
        {
            indirect = *reinterpret_cast<VehicleParamsNative**>(stack + sizeof(std::uint32_t));
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            indirect = nullptr;
        }
        if (ValidateVehicleParamsNative(indirect))
        {
            if (abiMode)
                *abiMode = 2;
            return indirect;
        }


        for (std::uintptr_t off = sizeof(std::uint32_t); off <= 0x80u; off += 4u)
        {
            VehicleParamsNative* candidate = reinterpret_cast<VehicleParamsNative*>(stack + off);
            if (ValidateVehicleParamsNative(candidate))
            {
                if (abiMode)
                    *abiMode = 3;
                return candidate;
            }

            VehicleParamsNative* pointed = nullptr;
            __try
            {
                pointed = *reinterpret_cast<VehicleParamsNative**>(stack + off);
            }
            __except (EXCEPTION_EXECUTE_HANDLER)
            {
                pointed = nullptr;
            }
            if (ValidateVehicleParamsNative(pointed))
            {
                if (abiMode)
                    *abiMode = 3;
                return pointed;
            }
        }
#endif
        return nullptr;
    }

    void CaptureUnresolvedVehicleParamsStack(CONTEXT* context)
    {
#if defined(_M_IX86)
        if (!context || InterlockedCompareExchange(&g_vehicleSpawnUnresolvedCaptured, 1, 0) != 0)
            return;

        const std::uintptr_t stack = static_cast<std::uintptr_t>(context->Esp);
        __try
        {
            for (int i = 0; i < 16; ++i)
                g_vehicleSpawnUnresolvedStack[i] = *reinterpret_cast<const std::uint32_t*>(stack + 4u + static_cast<std::uintptr_t>(i * 4));
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
        }

        VehicleParamsNative* pointed = nullptr;
        __try
        {
            pointed = *reinterpret_cast<VehicleParamsNative**>(stack + 4u);
            if (pointed)
            {
                for (int i = 0; i < 16; ++i)
                    g_vehicleSpawnUnresolvedIndirect[i] = reinterpret_cast<const std::uint32_t*>(pointed)[i];
                InterlockedExchange(&g_vehicleSpawnUnresolvedIndirectReadable, 1);
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            InterlockedExchange(&g_vehicleSpawnUnresolvedIndirectReadable, 0);
        }
#else
        (void)context;
#endif
    }

    void ApplyVehicleSpawnMapping(VehicleParamsNative* params)
    {
        InterlockedIncrement(&g_vehicleSpawnProxyCallCount);
        if (!params)
        {
            InterlockedIncrement(&g_vehicleSpawnUnresolvedCount);
            return;
        }

        if (params->driverClass == DriverClassHuman)
        {
            InterlockedIncrement(&g_vehicleSpawnHumanCount);


            bool purchaseMapped = false;
            if (InterlockedCompareExchange(&g_purchaseSpawnOverrideReady, 0, 0) != 0)
            {
                const std::uint32_t purchaseSource = static_cast<std::uint32_t>(
                    InterlockedCompareExchange(&g_purchaseSpawnSourceVehicleKey, 0, 0));
                const std::uint32_t purchaseTarget = static_cast<std::uint32_t>(
                    InterlockedCompareExchange(&g_purchaseSpawnTargetVehicleKey, 0, 0));
                if (purchaseSource != 0u && purchaseTarget != 0u &&
                    params->vehicleKey == purchaseSource)
                {
                    params->vehicleKey = purchaseTarget;
                    params->customization = 0u;
                    InterlockedIncrement(&g_purchaseSpawnMappedCount);
                    InterlockedExchange(&g_purchaseSpawnOverrideReady, 0);
                    purchaseMapped = true;
                }
            }

            if (!purchaseMapped && InterlockedCompareExchange(&g_starterSpawnReady, 0, 0) != 0)
            {
                const std::uint32_t sourceKey = static_cast<std::uint32_t>(
                    InterlockedCompareExchange(&g_starterSpawnSourceVehicleKey, 0, 0));
                const std::uint32_t targetKey = static_cast<std::uint32_t>(
                    InterlockedCompareExchange(&g_starterSpawnTargetVehicleKey, 0, 0));
                if (sourceKey != 0u && targetKey != 0u && params->vehicleKey == sourceKey)
                {
                    params->vehicleKey = targetKey;
                    params->customization = 0u;
                    InterlockedIncrement(&g_starterSpawnMappedCount);
                }
            }

            InterlockedExchange(&g_lastHumanEffectiveVehicleKey, static_cast<LONG>(params->vehicleKey));
        }
        else if (params->driverClass == DriverClassRacer)
        {
            InterlockedIncrement(&g_vehicleSpawnRacerCount);


            if (InterlockedCompareExchange(&g_bossSpawnTableReady, 0, 0) != 0)
            {
                for (int rank = 1; rank <= 15; ++rank)
                {
                    const std::uint32_t sourceKey = static_cast<std::uint32_t>(
                        InterlockedCompareExchange(&g_bossSpawnSourceKeys[rank], 0, 0));
                    const std::uint32_t targetKey = static_cast<std::uint32_t>(
                        InterlockedCompareExchange(&g_bossSpawnTargetKeys[rank], 0, 0));
                    if (sourceKey != 0u && targetKey != 0u && params->vehicleKey == sourceKey)
                    {
                        params->vehicleKey = targetKey;
                        const auto appearanceKey=static_cast<std::uint32_t>(
                            InterlockedCompareExchange(&g_bossAppearanceVehicleKeys[rank],0,0));
                        params->customization = appearanceKey==targetKey ? static_cast<std::uint32_t>(
                            InterlockedCompareExchange(&g_bossSpawnTargetCustomizations[rank],0,0)) : 0u;
                        InterlockedExchange(&g_bossSpawnLastMappedRank, rank);
                        InterlockedIncrement(&g_bossSpawnMappedCount);
                        break;
                    }
                }
            }
        }
    }

    bool WritePVehicleBreakpointByte(unsigned char value)
    {
        __try
        {
            *reinterpret_cast<volatile unsigned char*>(PVehicleConstructAddress) = value;
            FlushInstructionCache(
                GetCurrentProcess(),
                reinterpret_cast<const void*>(PVehicleConstructAddress),
                1u);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return false;
        }
    }

    LONG CALLBACK PVehicleConstructVehHandler(EXCEPTION_POINTERS* exceptionInfo)
    {
#if defined(_M_IX86)
        if (!exceptionInfo || !exceptionInfo->ExceptionRecord || !exceptionInfo->ContextRecord)
            return EXCEPTION_CONTINUE_SEARCH;

        EXCEPTION_RECORD* record = exceptionInfo->ExceptionRecord;
        CONTEXT* context = exceptionInfo->ContextRecord;
        const DWORD threadId = GetCurrentThreadId();

        if (record->ExceptionCode == EXCEPTION_BREAKPOINT &&
            reinterpret_cast<std::uintptr_t>(record->ExceptionAddress) == PVehicleConstructAddress &&
            InterlockedCompareExchange(&g_pvehicleBreakpointInstalled, 0, 0) != 0)
        {
            LONG abiMode = 0;
            VehicleParamsNative* params = ResolveVehicleParamsFromEntryStack(context, &abiMode);
            if (abiMode == 1)
                InterlockedIncrement(&g_vehicleSpawnAbiInlineCount);
            else if (abiMode == 2)
                InterlockedIncrement(&g_vehicleSpawnAbiIndirectCount);
            else if (abiMode == 3)
                InterlockedIncrement(&g_vehicleSpawnAbiScanCount);
            if (!params)
                CaptureUnresolvedVehicleParamsStack(context);
            ApplyVehicleSpawnMapping(params);


            if (!WritePVehicleBreakpointByte(g_pvehicleConstructOriginalByte))
                return EXCEPTION_CONTINUE_SEARCH;

            InterlockedExchange(
                &g_pvehicleBreakpointStepThreadId,
                static_cast<LONG>(threadId));
            context->Eip = static_cast<DWORD>(PVehicleConstructAddress);
            context->EFlags |= 0x100u;
            return EXCEPTION_CONTINUE_EXECUTION;
        }

        if (record->ExceptionCode == EXCEPTION_SINGLE_STEP &&
            InterlockedCompareExchange(
                &g_pvehicleBreakpointStepThreadId,
                0,
                0) == static_cast<LONG>(threadId))
        {


            WritePVehicleBreakpointByte(0xCCu);
            InterlockedExchange(&g_pvehicleBreakpointStepThreadId, 0);
            context->EFlags &= ~0x100u;
            return EXCEPTION_CONTINUE_EXECUTION;
        }
#else
        (void)exceptionInfo;
#endif
        return EXCEPTION_CONTINUE_SEARCH;
    }

    bool InstallPVehicleConstructEntryBreakpoint()
    {
#if !defined(_M_IX86)
        return false;
#else
        if (InterlockedCompareExchange(&g_pvehicleBreakpointInstalled, 0, 0) != 0)
            return true;

        unsigned char original = 0;
        __try
        {
            original = *reinterpret_cast<const unsigned char*>(PVehicleConstructAddress);
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return false;
        }

        if (original == 0xCCu)
            return false;


        DWORD oldProtect = 0;
        if (!VirtualProtect(
                reinterpret_cast<void*>(PVehicleConstructAddress),
                1u,
                PAGE_EXECUTE_READWRITE,
                &oldProtect))
        {
            return false;
        }

        PVOID veh = AddVectoredExceptionHandler(1u, &PVehicleConstructVehHandler);
        if (!veh)
        {
            DWORD ignored = 0;
            VirtualProtect(
                reinterpret_cast<void*>(PVehicleConstructAddress),
                1u,
                oldProtect,
                &ignored);
            return false;
        }

        g_pvehicleConstructOriginalByte = original;
        g_pvehicleConstructOriginalProtect = oldProtect;
        g_pvehicleVehHandle = veh;
        InterlockedExchange(&g_pvehicleBreakpointInstalled, 1);

        if (!WritePVehicleBreakpointByte(0xCCu))
        {
            InterlockedExchange(&g_pvehicleBreakpointInstalled, 0);
            RemoveVectoredExceptionHandler(veh);
            g_pvehicleVehHandle = nullptr;
            DWORD ignored = 0;
            VirtualProtect(
                reinterpret_cast<void*>(PVehicleConstructAddress),
                1u,
                oldProtect,
                &ignored);
            return false;
        }

        return true;
#endif
    }

    using FEPlayerCarDBGetCustomizationRecordByHandleFn = void*(__thiscall*)(void*, unsigned char);

    void* __fastcall FEPlayerCarDBCustomizationLookupProxy(void* db, void*, unsigned char handle)
    {
        FEPlayerCarDBGetCustomizationRecordByHandleFn original =
            reinterpret_cast<FEPlayerCarDBGetCustomizationRecordByHandleFn>(FEPlayerCarDBGetCustomizationRecordByHandleAddress);

        InterlockedIncrement(&g_customizationLookupCallCount);
        unsigned char effectiveHandle = handle;

        if (InterlockedCompareExchange(&g_carSelectLookupProxyActive, 0, 0) != 0 &&
            InterlockedCompareExchange(&g_carSelectLookupMapReady, 0, 0) != 0)
        {
            for (int i = 0; i < 32; ++i)
            {
                if (g_lookupProxySources[i] && g_lookupProxyTargets[i] &&
                    g_lookupProxySourceCustomization[i] == handle)
                {
                    effectiveHandle = g_lookupProxyTargetCustomization[i];
                    if (effectiveHandle != handle)
                        InterlockedIncrement(&g_customizationLookupMappedCount);
                    break;
                }
            }
        }

        if (InterlockedCompareExchange(&g_blacklistProxyActive, 0, 0) != 0 &&
            InterlockedCompareExchange(&g_blacklistProxyReady, 0, 0) != 0)
        {
            const LONG count = InterlockedCompareExchange(&g_blacklistProxySourceCount, 0, 0);
            for (LONG i = 0; i < count && i < BlacklistProxyMaxSources; ++i)
            {
                if (g_blacklistProxySourceCustomization[i] == effectiveHandle)
                {
                    if (g_blacklistProxyTargetCustomization != effectiveHandle)
                        InterlockedIncrement(&g_blacklistCustomizationMappedCount);
                    effectiveHandle = g_blacklistProxyTargetCustomization;
                    break;
                }
            }
        }

        return original(db, effectiveHandle);
    }

    bool PatchRelativeCallToAddress(std::uintptr_t callsite, std::uintptr_t target)
    {
        if (*reinterpret_cast<unsigned char*>(callsite) != 0xE8u)
            return false;

        DWORD oldProtect = 0;
        if (!VirtualProtect(reinterpret_cast<void*>(callsite), 5u, PAGE_EXECUTE_READWRITE, &oldProtect))
            return false;

        const std::intptr_t rel = static_cast<std::intptr_t>(target) -
            static_cast<std::intptr_t>(callsite + 5u);
        *reinterpret_cast<unsigned char*>(callsite) = 0xE8u;
        *reinterpret_cast<std::int32_t*>(callsite + 1u) = static_cast<std::int32_t>(rel);
        FlushInstructionCache(GetCurrentProcess(), reinterpret_cast<void*>(callsite), 5u);

        DWORD ignored = 0;
        VirtualProtect(reinterpret_cast<void*>(callsite), 5u, oldProtect, &ignored);
        return true;
    }

    bool PatchRelativeCall(std::uintptr_t callsite, void* replacement)
    {
        return PatchRelativeCallToAddress(callsite, reinterpret_cast<std::uintptr_t>(replacement));
    }

    std::vector<std::uintptr_t> FindDirectCallsitesFast(std::uintptr_t target)
    {
        std::vector<std::uintptr_t> matches;
        std::uintptr_t cursor = TextScanStartAddress;
        while (cursor + 5u <= TextScanEndAddress)
        {
            MEMORY_BASIC_INFORMATION mbi{};
            if (VirtualQuery(reinterpret_cast<void*>(cursor), &mbi, sizeof(mbi)) != sizeof(mbi))
                break;

            const std::uintptr_t regionBase =
                reinterpret_cast<std::uintptr_t>(mbi.BaseAddress);
            const std::uintptr_t regionStart =
                (cursor > regionBase) ? cursor : regionBase;
            const std::uintptr_t regionLimit =
                regionBase + static_cast<std::uintptr_t>(mbi.RegionSize);
            const std::uintptr_t regionEnd =
                (regionLimit < TextScanEndAddress) ? regionLimit : TextScanEndAddress;

            if (mbi.State == MEM_COMMIT && !(mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)))
            {
                for (std::uintptr_t p = regionStart; p + 5u <= regionEnd; ++p)
                {
                    if (*reinterpret_cast<unsigned char*>(p) != 0xE8u)
                        continue;
                    const std::int32_t rel = *reinterpret_cast<std::int32_t*>(p + 1u);
                    const std::uintptr_t resolved = static_cast<std::uintptr_t>(
                        static_cast<std::intptr_t>(p + 5u) + static_cast<std::intptr_t>(rel));
                    if (resolved == target)
                        matches.push_back(p);
                }
            }

            if (regionEnd <= cursor)
                break;
            cursor = regionEnd;
        }
        return matches;
    }

    bool InstallPVehicleConstructCallProxy()
    {


        return InstallPVehicleConstructEntryBreakpoint();
    }

    bool InstallFEPlayerCarDBLookupCallProxy()
    {
        if (!g_patchedLookupCallsites.empty())
            return true;


        g_patchedLookupCallsites = FindDirectCallsitesFast(FEPlayerCarDBGetCarRecordByHandleAddress);
        return !g_patchedLookupCallsites.empty();
    }

    bool InstallFEPlayerCarDBBuildRideCallProxy()
    {
        if (!g_patchedBuildRideCallsites.empty())
            return true;


        g_patchedBuildRideCallsites = FindDirectCallsitesFast(FEPlayerCarDBBuildRideForPlayerAddress);
        return !g_patchedBuildRideCallsites.empty();
    }

    bool InstallFEPlayerCarDBCustomizationLookupCallProxy()
    {


        g_patchedCustomizationLookupCallsites.clear();
        return false;
    }

    bool SetCarSelectCallsiteProxiesEnabled(bool enabled)
    {
        if (g_callsiteProxiesEnabled == enabled)
            return true;

        bool ok = true;


        const std::uintptr_t lookupTarget = FEPlayerCarDBGetCarRecordByHandleAddress;
        const std::uintptr_t buildRideTarget = enabled
            ? reinterpret_cast<std::uintptr_t>(&FEPlayerCarDBBuildRideForPlayerProxy)
            : FEPlayerCarDBBuildRideForPlayerAddress;
        const std::uintptr_t customizationTarget = enabled
            ? reinterpret_cast<std::uintptr_t>(&FEPlayerCarDBCustomizationLookupProxy)
            : FEPlayerCarDBGetCustomizationRecordByHandleAddress;


        (void)lookupTarget;
        for (std::uintptr_t callsite : g_patchedBuildRideCallsites)
            ok = PatchRelativeCallToAddress(callsite, buildRideTarget) && ok;
        for (std::uintptr_t callsite : g_patchedCustomizationLookupCallsites)
            ok = PatchRelativeCallToAddress(callsite, customizationTarget) && ok;

        if (ok)
            g_callsiteProxiesEnabled = enabled;

        return ok;
    }


    bool WaitForCarSelectProxyCallsToDrain(DWORD timeoutMs)
    {
        const DWORD start = GetTickCount();
        for (;;)
        {
            const LONG lookupInFlight = InterlockedCompareExchange(&g_lookupProxyInFlight, 0, 0);
            const LONG buildRideInFlight = InterlockedCompareExchange(&g_buildRideProxyInFlight, 0, 0);
            if (lookupInFlight == 0 && buildRideInFlight == 0)
                return true;

            if (GetTickCount() - start >= timeoutMs)
                return false;

            Sleep(1);
        }
    }

    std::string UpperAlnum(std::string value)
    {
        std::string out;
        out.reserve(value.size());
        for (unsigned char c : value)
        {
            if (std::isalnum(c))
                out.push_back(static_cast<char>(std::toupper(c)));
        }
        return out;
    }

    std::string FriendlyCarNameFromType(const std::string& raw)
    {
        static const std::unordered_map<std::string, std::string> map = {
            {"DB9", "Aston Martin DB9"},
            {"M3GTR", "BMW M3 GTR"},
            {"BMWM3GTR", "BMW M3 GTR"},
            {"BMWM3GTRE46", "BMW M3 GTR (E46)"},
            {"M3GTRE46", "BMW M3 GTR (E46)"},
            {"M3GTRCAREERSTART", "BMW M3 GTR"},
            {"A3", "Audi A3 3.2 quattro"},
            {"A320T", "Audi A3 3.2 quattro"},
            {"A4", "Audi A4 3.2 FSI quattro"},
            {"A432", "Audi A4 3.2 FSI quattro"},
            {"TT", "Audi TT 3.2 quattro"},
            {"CTS", "Cadillac CTS"},
            {"COBALTSS", "Chevrolet Cobalt SS"},
            {"CORVETTEC6", "Chevrolet Corvette C6"},
            {"CORVETTE", "Chevrolet Corvette C6"},
            {"CORVETTECAR", "Chevrolet Corvette C6"},
            {"VIPER", "Dodge Viper SRT-10"},
            {"PUNTO", "Fiat Punto"},
            {"FORDGT", "Ford GT"},
            {"MUSTANGGT", "Ford Mustang GT"},
            {"GALLARDO", "Lamborghini Gallardo"},
            {"MURCIELAGO", u8"Lamborghini Murci\u00E9lago"},
            {"IS300", "Lexus IS 300"},
            {"LOTUSELISE", "Lotus Elise"},
            {"ELISE", "Lotus Elise"},
            {"RX7", "Mazda RX-7"},
            {"RX8", "Mazda RX-8"},
            {"CLK500", "Mercedes-Benz CLK 500"},
            {"SL500", "Mercedes-Benz SL 500"},
            {"SLR", "Mercedes-Benz SLR McLaren"},
            {"ECLIPSEGT", "Mitsubishi Eclipse GT"},
            {"EVO8", "Mitsubishi Lancer Evolution VIII"},
            {"LANCEREVO8", "Mitsubishi Lancer Evolution VIII"},
            {"GTO", "Pontiac GTO"},
            {"997S", "Porsche 911 Carrera S"},
            {"PORSCHE997S", "Porsche 911 Carrera S"},
            {"997TT", "Porsche 911 Turbo S"},
            {"911TURBO", "Porsche 911 Turbo S"},
            {"PORSCHE911TURBO", "Porsche 911 Turbo S"},
            {"CARRERAGT", "Porsche Carrera GT"},
            {"PORSCHECARRERAGT", "Porsche Carrera GT"},
            {"CAYMANS", "Porsche Cayman S"},
            {"CLIOV6", "Renault Clio V6"},
            {"CLIO", "Renault Clio V6"},
            {"IMPREZAWRX", "Subaru Impreza WRX STi"},
            {"IMPREZZAWRX", "Subaru Impreza WRX STi"},
            {"SUPRA", "Toyota Supra"},
            {"MONARO", "Vauxhall Monaro VXR"},
            {"GTI", "Volkswagen Golf GTI"},
        };

        const std::string key = UpperAlnum(raw);
        const auto it = map.find(key);
        return it == map.end() ? raw : it->second;
    }

    bool ReadGameFlow(int& flow)
    {
        __try
        {
            flow = *reinterpret_cast<int*>(GameFlowStateAddress);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            flow = -1;
            return false;
        }
    }

    bool ReadControlledPackageNative(char* packageName, std::size_t packageNameSize)
    {
        if (!packageName || packageNameSize == 0)
            return false;
        packageName[0] = '\0';

        __try
        {
            void* feng = *reinterpret_cast<void**>(CFEngInstanceAddress);
            if (!feng)
                return false;

            CFEngFindPackageWithControlFn findPackage =
                reinterpret_cast<CFEngFindPackageWithControlFn>(CFEngFindPackageWithControlAddress);
            void* package = findPackage(feng);
            if (!package)
                return false;

            const char* name = *reinterpret_cast<const char**>(reinterpret_cast<std::uintptr_t>(package) + 0xCu);
            if (!name || !*name)
                return false;

            std::size_t i = 0;
            while (i + 1 < packageNameSize && name[i] != '\0')
            {
                packageName[i] = name[i];
                ++i;
            }
            packageName[i] = '\0';
            return i != 0;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            packageName[0] = '\0';
            return false;
        }
    }

    bool ReadControlledPackage(std::string& packageName)
    {
        packageName.clear();
        char nativeName[128] = {};
        if (!ReadControlledPackageNative(nativeName, sizeof(nativeName)))
            return false;
        packageName.assign(nativeName);
        return !packageName.empty();
    }

    bool IsCarLotPackage(const std::string& packageName)
    {
        const std::string key = UpperAlnum(packageName);
        return key.find("CARLOT") != std::string::npos || key.find("CARSELECT") != std::string::npos;
    }

    bool IsPurchaseDialogPackage(const std::string& packageName)
    {
        const std::string key = UpperAlnum(packageName);
        return key == "DIALOGFNG" || key == "DIALOG" || key.find("DIALOG") != std::string::npos;
    }

    bool IsPartsStorePackage(const std::string& packageName)
    {
        const std::string key = UpperAlnum(packageName);
        if (key.empty())
            return false;


        return key.find("CUSTOMIZEPERFORMANCE") != std::string::npos ||
               key.find("CUSTOMIZEPARTS") != std::string::npos ||
               key.find("SPOILER") != std::string::npos ||
               key.find("BODYKIT") != std::string::npos ||
               key.find("HOOD") != std::string::npos ||
               key.find("RIM") != std::string::npos ||
               key.find("VINYL") != std::string::npos ||
               key.find("PAINT") != std::string::npos ||
               key.find("WINDOWTINT") != std::string::npos ||
               key.find("DECAL") != std::string::npos;
    }


    bool ReadSelectedCarNative(int* typeId, std::uintptr_t* recordAddress, char* rawName, std::size_t rawNameSize)
    {
        if (!typeId || !recordAddress || !rawName || rawNameSize == 0)
            return false;

        *typeId = -1;
        *recordAddress = 0;
        rawName[0] = '\0';

        __try
        {
            void* record = *reinterpret_cast<void**>(CurrentFECarRecordAddress);
            if (!record)
                return false;

            FECarRecordGetTypeFn getType = reinterpret_cast<FECarRecordGetTypeFn>(FECarRecordGetTypeAddress);
            GetCarTypeNameFn getName = reinterpret_cast<GetCarTypeNameFn>(GetCarTypeNameAddress);

            const int nativeTypeId = getType(record);
            char* name = getName(nativeTypeId);
            if (!name || !*name)
                return false;

            std::size_t i = 0;
            while (i + 1 < rawNameSize && name[i] != '\0')
            {
                rawName[i] = name[i];
                ++i;
            }
            rawName[i] = '\0';

            *typeId = nativeTypeId;
            *recordAddress = reinterpret_cast<std::uintptr_t>(record);
            return i != 0;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            *typeId = -1;
            *recordAddress = 0;
            rawName[0] = '\0';
            return false;
        }
    }

    bool ReadNativeCashWord(std::uintptr_t address, std::uint32_t& value);

    bool ReadDealerCarNative(const void* screenAddress, char* rawName, std::size_t rawNameSize)
    {
        if (!screenAddress || !rawName || !rawNameSize) return false;
        rawName[0]='\0';
        __try
        {
            const std::uintptr_t database=*reinterpret_cast<std::uint32_t*>(FEDatabaseAddress);
            NFSMWAP::NativeDealerSelection selection;
            if (!NFSMWAP::ResolveNativeDealerSelection(reinterpret_cast<std::uintptr_t>(screenAddress),
                database,ReadNativeCashWord,selection)) return false;
            using RecordFn=void*(__thiscall*)(void*,unsigned int);
            void* record=reinterpret_cast<RecordFn>(FEPlayerCarDBGetCarRecordByHandleAddress)(
                reinterpret_cast<void*>(selection.stable),selection.handle);
            if (!record) return false;
            const int type=reinterpret_cast<FECarRecordGetTypeFn>(FECarRecordGetTypeAddress)(record);
            const char* name=reinterpret_cast<char*(__cdecl*)(int)>(GetCarTypeNameAddress)(type);
            if (!name || !*name) return false;
            std::size_t i=0;
            while (i+1<rawNameSize && name[i]) { rawName[i]=name[i];++i; }
            rawName[i]='\0';
            return i!=0;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { rawName[0]='\0';return false; }
    }

    bool GetCareerStockTableNative(FECarRecordNative** table)
    {
        if (!table)
            return false;
        *table = nullptr;

        __try
        {
            const std::uintptr_t feDatabase = *reinterpret_cast<std::uintptr_t*>(FEDatabaseAddress);
            if (!feDatabase)
                return false;

            const std::uintptr_t playerProfile = reinterpret_cast<std::uintptr_t*>(feDatabase)[4];
            if (!playerProfile)
                return false;

            *table = reinterpret_cast<FECarRecordNative*>(playerProfile + FEPlayerCarDBOffset);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            *table = nullptr;
            return false;
        }
    }

    bool ReadRecordNative(FECarRecordNative* record, int* typeId, char* rawName, std::size_t rawNameSize)
    {
        if (!record || !typeId || !rawName || rawNameSize == 0)
            return false;

        *typeId = -1;
        rawName[0] = '\0';

        __try
        {
            FECarRecordGetTypeFn getType = reinterpret_cast<FECarRecordGetTypeFn>(FECarRecordGetTypeAddress);
            GetCarTypeNameFn getName = reinterpret_cast<GetCarTypeNameFn>(GetCarTypeNameAddress);
            const int nativeTypeId = getType(record);
            char* name = getName(nativeTypeId);
            if (!name || !*name)
                return false;

            std::size_t i = 0;
            while (i + 1 < rawNameSize && name[i] != '\0')
            {
                rawName[i] = name[i];
                ++i;
            }
            rawName[i] = '\0';
            *typeId = nativeTypeId;
            return i != 0;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            *typeId = -1;
            rawName[0] = '\0';
            return false;
        }
    }

    bool ReadFECarRecordFieldsNative(
        FECarRecordNative* record,
        std::uint32_t* handle,
        std::uint32_t* feKey,
        std::uint32_t* vehicleKey,
        std::uint32_t* filterBits,
        std::uint8_t* customization,
        std::uint8_t* careerHandle)
    {
        if (!record || !handle || !feKey || !vehicleKey || !filterBits ||
            !customization || !careerHandle)
            return false;

        __try
        {
            *handle = record->handle;
            *feKey = record->feKey;
            *vehicleKey = record->vehicleKey;
            *filterBits = record->filterBits;
            *customization = record->customization;
            *careerHandle = record->careerHandle;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            *handle = *feKey = *vehicleKey = *filterBits = 0u;
            *customization = *careerHandle = 0u;
            return false;
        }
    }

    bool IsStockRecordNative(FECarRecordNative* record)
    {
        if (!record)
            return false;
        __try
        {
            return (record->filterBits & 1u) != 0u;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return false;
        }
    }

    bool WriteVehicleIdentityNative(FECarRecordNative* record, std::uint32_t feKey, std::uint32_t vehicleKey)
    {
        if (!record)
            return false;
        __try
        {
            record->feKey = feKey;
            record->vehicleKey = vehicleKey;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return false;
        }
    }

    bool WriteCurrentFECarRecordNative(FECarRecordNative* record)
    {
        __try
        {
            *reinterpret_cast<FECarRecordNative**>(CurrentFECarRecordAddress) = record;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return false;
        }
    }

    struct PurchaseMaterializationSnapshot
    {
        FECarRecordNative* source = nullptr;
        std::uint32_t feKey = 0;
        std::uint32_t vehicleKey = 0;
        std::uint8_t customization = 0;
        bool active = false;
    };

    bool MaterializePurchaseTargetNative(FECarRecordNative* source,
                                         FECarRecordNative* target,
                                         PurchaseMaterializationSnapshot* snapshot)
    {
        if (!source || !target || !snapshot)
            return false;

        __try
        {
            snapshot->source = source;
            snapshot->feKey = source->feKey;
            snapshot->vehicleKey = source->vehicleKey;
            snapshot->customization = source->customization;
            snapshot->active = false;


            source->feKey = target->feKey;
            source->vehicleKey = target->vehicleKey;
            source->customization = target->customization;
            snapshot->active = true;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            snapshot->active = false;
            return false;
        }
    }

    bool RestorePurchaseSourceNative(PurchaseMaterializationSnapshot* snapshot)
    {
        if (!snapshot || !snapshot->active || !snapshot->source)
            return true;

        __try
        {
            snapshot->source->feKey = snapshot->feKey;
            snapshot->source->vehicleKey = snapshot->vehicleKey;
            snapshot->source->customization = snapshot->customization;
            snapshot->active = false;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return false;
        }
    }


    FECarRecordNative* ReadCurrentFECarRecordNative()
    {
        __try
        {
            return *reinterpret_cast<FECarRecordNative**>(CurrentFECarRecordAddress);
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return nullptr;
        }
    }

    bool IsDealershipCarName(const std::string& friendly)
    {


        const std::string key = NFSMWAP::CarIdentityKey(friendly);
        if (key == "LAMBORGHINIMURCILAGO" || key == "LAMBORGHINIMURCIELAGO")
            return true;

        NFSMWAP::ShopEntry ignored;
        return NFSMWAP::GetShopEntryForCar("dealership", friendly, ignored);
    }

    std::uint32_t NextSeed(std::uint32_t& state)
    {
        state = state * 1664525u + 1013904223u;
        return state;
    }

    bool BuildFrontendDealershipProxy(FECarRecordNative* firstSelected,
                                      std::vector<FrontendProxySlot>& proxySlots)
    {
        proxySlots.clear();

        FECarRecordNative* table = nullptr;
        if (!GetCareerStockTableNative(&table) || !table)
            return false;

        std::vector<StockRecordSnapshot> stock;
        stock.reserve(32);
        for (std::size_t i = 0; i < FECarTableCount; ++i)
        {
            FECarRecordNative* record = &table[i];
            if ((record->filterBits & 1u) == 0u || record->feKey == 0u || record->vehicleKey == 0u)
                continue;

            int typeId = -1;
            char rawName[128] = {};
            if (!ReadRecordNative(record, &typeId, rawName, sizeof(rawName)))
                continue;

            const std::string raw(rawName);
            const std::string friendly = FriendlyCarNameFromType(raw);
            if (!IsDealershipCarName(friendly))
                continue;

            const auto duplicate = std::find_if(stock.begin(), stock.end(), [&](const StockRecordSnapshot& x)
            {
                return UpperAlnum(x.friendlyName) == UpperAlnum(friendly);
            });
            if (duplicate != stock.end())
                continue;

            stock.push_back({record, record->feKey, record->vehicleKey, raw, friendly});
        }

        if (stock.size() != 32u)
        {
            std::ostringstream out;
            out << "AP FRONTEND CAR LOT PROXY: expected 32 stock records, found " << stock.size() << ".";
            NFSMWAP::Log(out.str());
            return false;
        }

        std::sort(stock.begin(), stock.end(), [](const StockRecordSnapshot& a, const StockRecordSnapshot& b)
        {
            if (a.record->handle != b.record->handle)
                return a.record->handle < b.record->handle;
            return a.record < b.record;
        });

        std::vector<StockRecordSnapshot> targets = stock;
        std::sort(targets.begin(), targets.end(), [](const StockRecordSnapshot& a, const StockRecordSnapshot& b)
        {
            return UpperAlnum(a.friendlyName) < UpperAlnum(b.friendlyName);
        });

        const std::string starter = NFSMWAP::GetSeedStartingCar();
        auto starterIt = std::find_if(targets.begin(), targets.end(), [&](const StockRecordSnapshot& x)
        {
            return UpperAlnum(x.friendlyName) == UpperAlnum(starter);
        });
        if (starterIt == targets.end())
        {
            NFSMWAP::Log("AP FRONTEND CAR LOT PROXY: starter car was not found in stock target pool.");
            return false;
        }
        const std::size_t starterTarget = static_cast<std::size_t>(std::distance(targets.begin(), starterIt));

        std::size_t firstSlot = 0u;
        if (firstSelected)
        {
            auto it = std::find_if(stock.begin(), stock.end(), [&](const StockRecordSnapshot& x)
            {
                return x.record == firstSelected;
            });
            if (it != stock.end())
                firstSlot = static_cast<std::size_t>(std::distance(stock.begin(), it));
        }

        std::vector<std::size_t> remaining;
        remaining.reserve(31);
        for (std::size_t i = 0; i < targets.size(); ++i)
            if (i != starterTarget)
                remaining.push_back(i);

        std::uint32_t rng = static_cast<std::uint32_t>(NFSMWAP::GetSeedOpponentCarSeed());
        if (rng == 0u)
        {
            rng = 2166136261u;
            for (unsigned char c : starter)
            {
                rng ^= c;
                rng *= 16777619u;
            }
        }
        for (std::size_t i = remaining.size(); i > 1u; --i)
        {
            const std::size_t j = static_cast<std::size_t>(NextSeed(rng) % static_cast<std::uint32_t>(i));
            std::swap(remaining[i - 1u], remaining[j]);
        }

        std::vector<std::size_t> targetForSlot(stock.size(), 0u);
        targetForSlot[firstSlot] = starterTarget;
        std::size_t next = 0u;
        for (std::size_t slot = 0; slot < stock.size(); ++slot)
        {
            if (slot == firstSlot)
                continue;
            targetForSlot[slot] = remaining[next++];
        }

        proxySlots.reserve(32);
        for (std::size_t slot = 0; slot < stock.size(); ++slot)
        {
            const StockRecordSnapshot& source = stock[slot];
            const StockRecordSnapshot& target = targets[targetForSlot[slot]];
            FrontendProxySlot proxy;
            proxy.source = source.record;
            proxy.target = target.record;
            proxy.originalFeKey = source.feKey;
            proxy.originalVehicleKey = source.vehicleKey;
            proxy.sourceName = source.friendlyName;
            proxy.targetName = target.friendlyName;
            proxySlots.push_back(proxy);
        }

        std::ostringstream summary;
        summary << "AP FRONTEND CAR LOT PROXY READY: package-selected slot " << (firstSlot + 1u)
                << " -> starter '" << starter << "'; 32 runtime selection mappings built.";
        NFSMWAP::Log(summary.str());
        return true;
    }

    FrontendProxySlot* FindFrontendProxySlot(std::vector<FrontendProxySlot>& proxySlots,
                                             FECarRecordNative* source)
    {
        for (FrontendProxySlot& slot : proxySlots)
            if (slot.source == source)
                return &slot;
        return nullptr;
    }

    bool ApplyNativeDealershipPermutation(FECarRecordNative* selectedRecord)
    {
        FECarRecordNative* table = nullptr;
        if (!GetCareerStockTableNative(&table) || !table)
        {
            NFSMWAP::Log("AP NATIVE CAR LOT: FEPlayerCarDB is not ready yet.");
            return false;
        }

        std::vector<StockRecordSnapshot> stock;
        std::vector<std::string> rejectedStockNames;
        stock.reserve(32);
        rejectedStockNames.reserve(32);
        for (std::size_t i = 0; i < FECarTableCount; ++i)
        {
            FECarRecordNative* record = &table[i];
            if ((record->filterBits & 1u) == 0u || record->feKey == 0u || record->vehicleKey == 0u)
                continue;

            int typeId = -1;
            char rawName[128] = {};
            if (!ReadRecordNative(record, &typeId, rawName, sizeof(rawName)))
                continue;

            const std::string raw(rawName);
            const std::string friendly = FriendlyCarNameFromType(raw);
            if (!IsDealershipCarName(friendly))
            {
                if (std::find(rejectedStockNames.begin(), rejectedStockNames.end(), raw) == rejectedStockNames.end())
                    rejectedStockNames.push_back(raw);
                continue;
            }

            const auto duplicate = std::find_if(stock.begin(), stock.end(), [&](const StockRecordSnapshot& x)
            {
                return UpperAlnum(x.friendlyName) == UpperAlnum(friendly);
            });
            if (duplicate != stock.end())
                continue;

            stock.push_back({record, record->feKey, record->vehicleKey, raw, friendly});
        }

        if (stock.size() != 32u)
        {
            if (!g_carLotScanDumped || g_lastCarLotRecognizedCount != stock.size())
            {
                g_carLotScanDumped = true;
                g_lastCarLotRecognizedCount = stock.size();
                std::ostringstream out;
                out << "AP NATIVE CAR LOT: expected 32 unique stock dealership records, found " << stock.size()
                    << ". No writes performed.";
                NFSMWAP::Log(out.str());
                for (const StockRecordSnapshot& x : stock)
                    NFSMWAP::Log("  RECOGNIZED STOCK: raw='" + x.rawName + "' -> '" + x.friendlyName + "'");
                for (const std::string& rawRejected : rejectedStockNames)
                    NFSMWAP::Log("  UNMATCHED STOCK TYPE: raw='" + rawRejected + "' normalized='" + UpperAlnum(rawRejected) + "'");
            }
            return false;
        }


        std::sort(stock.begin(), stock.end(), [](const StockRecordSnapshot& a, const StockRecordSnapshot& b)
        {
            if (a.record->handle != b.record->handle)
                return a.record->handle < b.record->handle;
            return a.record < b.record;
        });


        std::size_t selectedIndex = 0u;
        if (selectedRecord)
        {
            auto selectedIt = std::find_if(stock.begin(), stock.end(), [&](const StockRecordSnapshot& x)
            {
                return x.record == selectedRecord;
            });
            if (selectedIt != stock.end())
                selectedIndex = static_cast<std::size_t>(std::distance(stock.begin(), selectedIt));
        }

        const std::string starter = NFSMWAP::GetSeedStartingCar();


        std::vector<StockRecordSnapshot> identities = stock;
        std::sort(identities.begin(), identities.end(), [](const StockRecordSnapshot& a, const StockRecordSnapshot& b)
        {
            return UpperAlnum(a.friendlyName) < UpperAlnum(b.friendlyName);
        });

        auto starterIt = std::find_if(identities.begin(), identities.end(), [&](const StockRecordSnapshot& x)
        {
            return UpperAlnum(x.friendlyName) == UpperAlnum(starter);
        });
        if (starterIt == identities.end())
        {
            NFSMWAP::Log("AP NATIVE CAR LOT: seed starter '" + starter + "' is not one of the 32 stock dealership cars. No writes performed.");
            return false;
        }
        const std::size_t starterIndex = static_cast<std::size_t>(std::distance(identities.begin(), starterIt));


        std::vector<std::size_t> remainingTargets;
        remainingTargets.reserve(identities.size() - 1u);
        for (std::size_t i = 0; i < identities.size(); ++i)
            if (i != starterIndex)
                remainingTargets.push_back(i);

        std::uint32_t rng = static_cast<std::uint32_t>(NFSMWAP::GetSeedOpponentCarSeed());
        if (rng == 0u)
        {
            rng = 2166136261u;
            for (unsigned char c : starter)
            {
                rng ^= c;
                rng *= 16777619u;
            }
        }
        for (std::size_t i = remainingTargets.size(); i > 1u; --i)
        {
            const std::size_t j = static_cast<std::size_t>(NextSeed(rng) % static_cast<std::uint32_t>(i));
            std::swap(remainingTargets[i - 1u], remainingTargets[j]);
        }

        std::vector<std::size_t> targetForSlot(stock.size(), 0u);
        targetForSlot[selectedIndex] = starterIndex;
        std::size_t next = 0u;
        for (std::size_t slot = 0; slot < stock.size(); ++slot)
        {
            if (slot == selectedIndex)
                continue;
            targetForSlot[slot] = remainingTargets[next++];
        }

        for (std::size_t slot = 0; slot < stock.size(); ++slot)
        {
            const StockRecordSnapshot& target = identities[targetForSlot[slot]];
            if (!WriteVehicleIdentityNative(stock[slot].record, target.feKey, target.vehicleKey))
            {
                NFSMWAP::Log("AP NATIVE CAR LOT: write fault while applying permutation. Stopping further writes.");
                return false;
            }
        }

        NFSMWAP::Log("AP NATIVE CAR LOT RANDOMIZED: 32 stock FECarRecords FORCE-WRITTEN with canonical seed permutation; first selected stock slot -> '" + starter + "'.");
        for (std::size_t slot = 0; slot < stock.size(); ++slot)
        {
            std::ostringstream line;
            line << "  CAR LOT SLOT " << (slot + 1u) << ": " << stock[slot].friendlyName
                 << " -> " << identities[targetForSlot[slot]].friendlyName;
            NFSMWAP::Log(line.str());
        }
        return true;
    }

    bool ReadSelectedCar(std::string& friendly, std::string& raw, int& typeId, std::uintptr_t& recordAddress)
    {
        friendly.clear();
        raw.clear();
        typeId = -1;
        recordAddress = 0;

        char rawName[128] = {};
        if (!ReadSelectedCarNative(&typeId, &recordAddress, rawName, sizeof(rawName)))
            return false;

        raw.assign(rawName);
        friendly = FriendlyCarNameFromType(raw);
        return !friendly.empty();
    }


    bool ReadNativeCashWord(std::uintptr_t address, std::uint32_t& value)
    {
        __try { value=*reinterpret_cast<std::uint32_t*>(address); return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { value=0; return false; }
    }

    bool GetCareerCashAddressNative(std::uintptr_t* address)
    {
        if (!address) return false;
        *address=0;
        std::uint32_t database=0;
        return ReadNativeCashWord(FEDatabaseAddress,database) &&
            NFSMWAP::ResolveCareerCashAddress(database,ReadNativeCashWord,*address);
    }

    bool ReadCareerCashNative(int* cash)
    {
        if (!cash)
            return false;
        *cash = 0;

        std::uintptr_t cashAddress = 0;
        if (!GetCareerCashAddressNative(&cashAddress))
            return false;

        __try
        {
            const int value = *reinterpret_cast<int*>(cashAddress);


            if (value < 0 || value > 999999999)
                return false;
            *cash = value;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            *cash = 0;
            return false;
        }
    }

    bool WriteCareerCashNative(int newCash)
    {
        if (newCash < 0 || newCash > 999999999)
            return false;

        std::uintptr_t cashAddress = 0;
        if (!GetCareerCashAddressNative(&cashAddress))
            return false;

        __try
        {
            int* cash = reinterpret_cast<int*>(cashAddress);
            const int before = *cash;
            if (before < 0 || before > 999999999)
                return false;
            *cash = newCash;
            return *cash == newCash;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return false;
        }
    }

    bool ReserveCareerCashNative(int amount, int* beforeCash, int* afterCash)
    {
        if (beforeCash) *beforeCash = 0;
        if (afterCash) *afterCash = 0;
        if (amount < 0)
            return false;

        int current = 0;
        if (!ReadCareerCashNative(&current))
            return false;
        if (beforeCash) *beforeCash = current;
        if (current < amount)
        {
            if (afterCash) *afterCash = current;
            return false;
        }

        const int updated = current - amount;
        if (!WriteCareerCashNative(updated))
            return false;
        if (afterCash) *afterCash = updated;
        return true;
    }

    bool RefundCareerCashNative(int amount, int* resultingCash)
    {
        if (resultingCash) *resultingCash = 0;
        if (amount <= 0)
            return true;

        int current = 0;
        if (!ReadCareerCashNative(&current))
            return false;
        if (current > 999999999 - amount)
            return false;
        const int updated = current + amount;
        if (!WriteCareerCashNative(updated))
            return false;
        if (resultingCash) *resultingCash = updated;
        return true;
    }

    std::string JsonEscape(const std::string& value)
    {
        std::string out;
        out.reserve(value.size() + 8u);
        for (unsigned char c : value)
        {
            switch (c)
            {
            case '\\': out += "\\\\"; break;
            case '"': out += "\\\""; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c >= 0x20u)
                    out.push_back(static_cast<char>(c));
                break;
            }
        }
        return out;
    }

    std::string MoneyText(int amount);

    bool BeginTransactionalShopPurchase(
        const NFSMWAP::ShopEntry& entry,
        const std::string& selectedCar,
        bool chargeCareerCash = false)
    {
        if (entry.locationId <= 0 || entry.checked)
            return false;

        std::lock_guard<std::mutex> lock(g_purchaseMutex);
        if (g_pendingPurchaseLocationId != 0)
            return false;

        int cashBefore = 0;
        int cashAfter = 0;
        bool cashDebited = false;
        const int requestedPrice = std::max(0, entry.price);

        if (chargeCareerCash && requestedPrice > 0)
        {
            if (!ReadCareerCashNative(&cashBefore))
            {
                NFSMWAP::Log("AP CAREER CASH 1.0.1: could not resolve embedded CurrentCash at UserProfile+0xB4; paid AP purchase blocked.");
                NFSMWAP::QueueNotification("ARCHIPELAGO SHOP", "CAREER CASH NOT READY", "PURCHASE NOT SENT", 4000);
                return false;
            }

            if (cashBefore < requestedPrice)
            {
                NFSMWAP::Log("AP CAREER CASH 1.0.1: insufficient funds; have=" +
                    std::to_string(cashBefore) + " need=" + std::to_string(requestedPrice) + ".");
                NFSMWAP::QueueNotification(
                    "ARCHIPELAGO SHOP",
                    "NOT ENOUGH CAREER CASH",
                    "HAVE " + MoneyText(cashBefore) + " / NEED " + MoneyText(requestedPrice),
                    4000);
                return false;
            }

            if (!ReserveCareerCashNative(requestedPrice, &cashBefore, &cashAfter))
            {
                NFSMWAP::Log("AP CAREER CASH 1.0.1: debit verification failed; AP purchase blocked.");
                NFSMWAP::QueueNotification("ARCHIPELAGO SHOP", "CASH DEBIT FAILED", "PURCHASE NOT SENT", 4000);
                return false;
            }
            cashDebited = true;

            if (InterlockedCompareExchange(&g_careerCashLogged, 1, 0) == 0)
            {
                NFSMWAP::Log("AP CAREER CASH 1.0.1 VALIDATED: embedded UserProfile+0xB4 debit " +
                    MoneyText(cashBefore) + " -> " + MoneyText(cashAfter) + ".");
            }
        }

        const int requestId = g_nextPurchaseRequestId++;
        std::ostringstream message;
        message << "{\"type\":\"shop_purchase\",\"location_id\":" << entry.locationId
                << ",\"request_id\":" << requestId
                << ",\"expected_price\":" << entry.price
                << ",\"expected_car\":\"" << JsonEscape(selectedCar) << "\"}";

        if (!NFSMWAP::SendBridgeLine(message.str()))
        {
            if (cashDebited)
            {
                int refundCash = 0;
                const bool refunded = RefundCareerCashNative(requestedPrice, &refundCash);
                NFSMWAP::Log(std::string("AP CAREER CASH 1.0.1: bridge send failed; immediate refund=") +
                    (refunded ? "yes" : "NO") +
                    (refunded ? " resulting_cash=" + std::to_string(refundCash) : std::string()));
            }
            NFSMWAP::QueueNotification("ARCHIPELAGO SHOP", "AP CLIENT NOT CONNECTED", "PURCHASE NOT SENT", 4000);
            return false;
        }

        g_pendingPurchaseLocationId = entry.locationId;
        g_pendingPurchaseRequestId = requestId;
        g_pendingPurchaseStartedTick = GetTickCount();
        g_pendingPurchaseAckReady = false;
        g_pendingPurchaseAccepted = false;
        g_pendingPurchaseReason.clear();
        g_pendingPurchaseReservedCash = cashDebited ? requestedPrice : 0;
        g_pendingPurchaseCashDebited = cashDebited;
        g_pendingPurchaseCashAddress = 0;
        if (cashDebited) GetCareerCashAddressNative(&g_pendingPurchaseCashAddress);
        g_pendingPurchaseTimeoutShown = false;

        std::ostringstream log;
        log << "AP SHOP TRANSACTION SENT 1.0.1: request_id=" << requestId
            << " location=" << entry.locationId
            << " expected_price=" << entry.price
            << " expected_car='" << selectedCar << "'";
        if (cashDebited)
            log << " career_cash=" << cashBefore << "->" << cashAfter << " debited=yes";
        else
            log << " career_cash=native_or_not_charged";
        NFSMWAP::Log(log.str());
        return true;
    }

    void ProcessPendingPurchaseTransaction()
    {
        int locationId = 0;
        int requestId = 0;
        bool ackReady = false;
        bool accepted = false;
        bool timedOut = false;
        bool cashDebited = false;
        bool refunded = false;
        int reservedCash = 0;
        int refundCash = 0;
        std::string reason;

        {
            std::lock_guard<std::mutex> lock(g_purchaseMutex);
            if (g_pendingPurchaseLocationId == 0)
                return;

            locationId = g_pendingPurchaseLocationId;
            requestId = g_pendingPurchaseRequestId;
            ackReady = g_pendingPurchaseAckReady;
            accepted = g_pendingPurchaseAccepted;
            reason = g_pendingPurchaseReason;
            cashDebited = g_pendingPurchaseCashDebited;
            reservedCash = g_pendingPurchaseReservedCash;
            timedOut = !ackReady && (GetTickCount() - g_pendingPurchaseStartedTick > 10000u);

            if (!ackReady && !timedOut)
                return;

            if (timedOut && cashDebited)
            {


                std::ostringstream status;
                status << "{\"type\":\"shop_purchase_status\",\"location_id\":" << locationId
                       << ",\"request_id\":" << requestId << "}";
                NFSMWAP::SendBridgeLine(status.str());
                g_pendingPurchaseStartedTick = GetTickCount();
                if (!g_pendingPurchaseTimeoutShown)
                {
                    g_pendingPurchaseTimeoutShown = true;
                    NFSMWAP::QueueNotification("ARCHIPELAGO SHOP", "WAITING FOR PURCHASE STATUS",
                        "RECONNECT AP CLIENT TO RESOLVE", 4000);
                }
                return;
            }

            if (cashDebited && ackReady && !accepted)
            {
                std::uintptr_t currentCashAddress = 0;


                if (!GetCareerCashAddressNative(&currentCashAddress) || currentCashAddress != g_pendingPurchaseCashAddress)
                    return;


                refunded = RefundCareerCashNative(reservedCash, &refundCash);
                if (!refunded)
                    return;
            }

            g_pendingPurchaseLocationId = 0;
            g_pendingPurchaseRequestId = 0;
            g_pendingPurchaseStartedTick = 0;
            g_pendingPurchaseAckReady = false;
            g_pendingPurchaseAccepted = false;
            g_pendingPurchaseReason.clear();
            g_pendingPurchaseReservedCash = 0;
            g_pendingPurchaseCashDebited = false;
            g_pendingPurchaseCashAddress = 0;
        }

        std::ostringstream log;
        log << "AP SHOP TRANSACTION " << (timedOut ? "TIMEOUT" : (accepted ? "CONFIRMED" : "REJECTED"))
            << " 1.0.1: request_id=" << requestId << " location=" << locationId;
        if (!reason.empty()) log << " reason='" << reason << "'";
        if (cashDebited)
        {
            if (accepted)
                log << " career_cash_committed=" << reservedCash;
            else
                log << " career_cash_refund=" << (refunded ? "yes" : "NO")
                    << (refunded ? " resulting_cash=" + std::to_string(refundCash) : std::string());
        }
        NFSMWAP::Log(log.str());

        if (timedOut)
        {
            NFSMWAP::QueueNotification(
                "ARCHIPELAGO SHOP",
                "PURCHASE TIMED OUT",
                cashDebited ? (refunded ? "CAREER CASH REFUNDED" : "REFUND FAILED - CHECK LOG") : "NO LOCATION WAS LOST",
                4000);
        }
        else if (!accepted)
        {
            NFSMWAP::QueueNotification(
                "ARCHIPELAGO SHOP",
                "PURCHASE REJECTED",
                cashDebited ? (refunded ? "CAREER CASH REFUNDED" : "REFUND FAILED - CHECK LOG") : reason,
                4000);
        }
        else if (cashDebited)
        {
            NFSMWAP::QueueNotification("ARCHIPELAGO SHOP", "PURCHASE CONFIRMED", MoneyText(reservedCash) + " PAID", 3000);
        }
    }

    void* GetCareerCarDBNative()
    {
        __try
        {
            const std::uintptr_t feDatabase = *reinterpret_cast<std::uintptr_t*>(FEDatabaseAddress);
            if (!feDatabase)
                return nullptr;
            const std::uintptr_t playerProfile = reinterpret_cast<std::uintptr_t*>(feDatabase)[4];
            if (!playerProfile)
                return nullptr;
            return reinterpret_cast<void*>(playerProfile + FEPlayerCarDBOffset);
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return nullptr;
        }
    }

    FECarRecordNative* CreateCareerOwnedCarNative(void* db, FECarRecordNative* source)
    {
        if (!db || !source)
            return nullptr;
        __try
        {


            if (*reinterpret_cast<const unsigned char*>(FEPlayerCarDBCreateCareerCarCall)!=0xE8u) return nullptr;
            const auto relative=*reinterpret_cast<const std::int32_t*>(FEPlayerCarDBCreateCareerCarCall+1u);
            const auto target=FEPlayerCarDBCreateCareerCarCall+5u+relative;
            if (target<0x401000u || target>=0x890000u) return nullptr;
            using CreateFn = FECarRecordNative*(__thiscall*)(void*,unsigned int,int);
            FECarRecordNative* created = reinterpret_cast<CreateFn>(target)(db,source->handle,2);
            if (!created || created==source)
                return nullptr;
            using CareerFn=unsigned char*(__thiscall*)(void*);
            unsigned char* career=reinterpret_cast<CareerFn>(FEPlayerCarDBCreateNewCareerRecordAddress)(db);
            if (!career || *career>=25u || created->handle>=200u || created->customization>=75u)
            {

                if (career) *career=0xFFu;
                using CustomFn=unsigned char*(__thiscall*)(void*,unsigned char);
                if (created->customization<75u)
                {
                    auto custom=reinterpret_cast<CustomFn>(FEPlayerCarDBGetCustomizationRecordByHandleAddress)(db,created->customization);
                    if (custom) custom[0x194u]=0xFFu;
                }
                created->handle=0xFFFFFFFFu;created->filterBits=0;
                return nullptr;
            }
            created->careerHandle=*career;
            return created;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return nullptr;
        }
    }

    bool FindStockRecordForCar(const std::string& car, FECarRecordNative** outRecord)
    {
        if (!outRecord)
            return false;
        *outRecord = nullptr;
        FECarRecordNative* table = nullptr;
        if (!GetCareerStockTableNative(&table) || !table)
            return false;

        const std::string wanted = NFSMWAP::CarIdentityKey(car);
        for (std::size_t i = 0; i < FECarTableCount; ++i)
        {
            FECarRecordNative* record = &table[i];
            if ((record->filterBits & 1u) == 0u || record->feKey == 0u || record->vehicleKey == 0u)
                continue;
            int typeId = -1;
            char rawName[128] = {};
            if (!ReadRecordNative(record, &typeId, rawName, sizeof(rawName)))
                continue;
            if (NFSMWAP::CarIdentityKey(FriendlyCarNameFromType(rawName)) == wanted)
            {
                *outRecord = record;
                return true;
            }
        }
        return false;
    }

    bool FindBossSourceRecordForCar(const std::string& car,FECarRecordNative** result)
    {
        if (FindStockRecordForCar(car,result)) return true;
        FECarRecordNative* table=nullptr;
        if (!GetCareerStockTableNative(&table) || !table) return false;
        const auto wanted=NFSMWAP::CarIdentityKey(car);
        for (std::size_t i=0;i<FECarTableCount;++i)
        {
            int type=-1;char name[128]={};
            std::uint32_t handle=0,fe=0,key=0,filter=0;
            std::uint8_t custom=0,career=0;
            if (!ReadFECarRecordFieldsNative(&table[i],&handle,&fe,&key,&filter,&custom,&career) || !fe || !key) continue;


            if (ReadRecordNative(&table[i],&type,name,sizeof(name)) && NFSMWAP::CarIdentityKey(FriendlyCarNameFromType(name))==wanted)
            { *result=&table[i];return true; }
        }
        return false;
    }

    bool FindDeliverySourceForCar(const std::string& car,FECarRecordNative** result)
    {
        if (!result) return false;
        if (FindStockRecordForCar(car,result)) return true;


        if (NFSMWAP::CarIdentityKey(car)!="BMWM3GTR") return false;
        FECarRecordNative* table=nullptr;
        if (!GetCareerStockTableNative(&table) || !table) return false;
        for (std::size_t i=0;i<FECarTableCount;++i) {
            std::uint32_t handle=0,fe=0,key=0,filter=0;
            std::uint8_t customization=0,career=0;int type=-1;char name[128]={};
            if (!ReadFECarRecordFieldsNative(&table[i],&handle,&fe,&key,&filter,&customization,&career) ||
                handle>=FECarTableCount || !fe || !key || !filter) continue;
            if (ReadRecordNative(&table[i],&type,name,sizeof name) &&
                NFSMWAP::CarIdentityKey(FriendlyCarNameFromType(name))=="BMWM3GTR") {
                *result=&table[i];return true;
            }
        }
        return false;
    }

    const char* VanillaBlacklistCarForRank(int rank);
    void PrepareBlacklistAppearancesMainThread()
    {
        if (NFSMWAP::IsConnectionSetupOnly() || !NFSMWAP::IsSeedConfigReady()) return;
        if (!NFSMWAP::GetSeedRandomizeBlacklistAppearance())
        {
            for (auto& pointer:g_bossSpawnTargetCustomizations) InterlockedExchange(&pointer,0);
            return;
        }


        static int sourceCursor=15;
        const int activeRank=NFSMWAP::GetActiveRivalRank();
        const bool activeValid=activeRank>=1 && activeRank<=15;
        const int missing=(activeValid && !InterlockedCompareExchange(&g_bossSpawnSourceKeys[activeRank],0,0))
            ? activeRank : sourceCursor;
        sourceCursor=sourceCursor==1 ? 15 : sourceCursor-1;
        if (!InterlockedCompareExchange(&g_bossSpawnSourceKeys[missing],0,0))
        {
            FECarRecordNative* source=nullptr;FECarRecordNative* replacement=nullptr;
            const auto replacementCar=NFSMWAP::GetSeedBlacklistCar(missing);
            if (!replacementCar.empty() && FindStockRecordForCar(replacementCar,&replacement) && replacement &&
                FindBossSourceRecordForCar(VanillaBlacklistCarForRank(missing),&source) && source)
            {
                InterlockedExchange(&g_bossSpawnSourceKeys[missing],static_cast<LONG>(source->vehicleKey));
                InterlockedExchange(&g_bossSpawnTargetKeys[missing],static_cast<LONG>(replacement->vehicleKey));
                NFSMWAP::Log("AP BLACKLIST SOURCE RECOVERED: rank="+std::to_string(missing)+" preset identity available.");
            }
        }
        static int cursor=15;
        const int rank=(activeValid && !InterlockedCompareExchange(&g_bossSpawnTargetCustomizations[activeRank],0,0))
            ? activeRank : cursor;
        cursor=cursor==1 ? 15 : cursor-1;
        const auto car=NFSMWAP::GetSeedBlacklistCar(rank);
        FECarRecordNative* target=nullptr;
        int type=-1;char name[128]={};
        if (car.empty() || !FindStockRecordForCar(car,&target) || !target ||
            !ReadRecordNative(target,&type,name,sizeof(name))) return;
        const auto appearance=NFSMWAP::PrepareBlacklistAppearance(rank,type,target->vehicleKey,
            NFSMWAP::GetSeedBlacklistAppearanceSeed());
        InterlockedExchange(&g_bossSpawnTargetCustomizations[rank],static_cast<LONG>(appearance));
        InterlockedExchange(&g_bossAppearanceVehicleKeys[rank],appearance ? static_cast<LONG>(target->vehicleKey) : 0);
    }

    void* GetCustomizationRecordNative(void* db, std::uint8_t handle)
    {
        if (!db)
            return nullptr;
        __try
        {
            using Fn = void*(__thiscall*)(void*, unsigned char);
            Fn fn = reinterpret_cast<Fn>(FEPlayerCarDBGetCustomizationRecordByHandleAddress);
            return fn(db, static_cast<unsigned char>(handle));
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return nullptr;
        }
    }

    const char* VanillaBlacklistCarForRank(int rank);
    bool IsVanillaCareerStarter(const std::string& friendly);

    bool PrepareStarterVehicleSpawnProxy()
    {
        InterlockedExchange(&g_starterSpawnReady, 0);
        if (!NFSMWAP::IsSeedConfigReady())
            return false;

        const std::string targetCar = NFSMWAP::GetSeedStartingCar();
        if (targetCar.empty())
            return false;

        FECarRecordNative* target = nullptr;
        if (!FindStockRecordForCar(targetCar, &target) || !target)
            return false;

        FECarRecordNative* table = nullptr;
        if (!GetCareerStockTableNative(&table) || !table)
            return false;

        FECarRecordNative* source = nullptr;
        std::string sourceName;
        unsigned int bestCareerHandle = 0xFFu;
        for (std::size_t i = 0; i < FECarTableCount; ++i)
        {
            FECarRecordNative* record = &table[i];
            std::uint32_t handle = 0, feKey = 0, vehicleKey = 0, filterBits = 0;
            std::uint8_t customization = 0, careerHandle = 0;
            if (!ReadFECarRecordFieldsNative(record, &handle, &feKey, &vehicleKey,
                                             &filterBits, &customization, &careerHandle))
                return false;
            if ((filterBits & 0x2u) == 0u || handle == 0u || vehicleKey == 0u)
                continue;

            int typeId = -1;
            char rawName[128] = {};
            if (!ReadRecordNative(record, &typeId, rawName, sizeof(rawName)))
                continue;
            const std::string friendly = FriendlyCarNameFromType(rawName);
            if (!IsVanillaCareerStarter(friendly))
                continue;

            if (!source || static_cast<unsigned int>(careerHandle) < bestCareerHandle)
            {
                source = record;
                sourceName = friendly;
                bestCareerHandle = static_cast<unsigned int>(careerHandle);
            }
        }

        if (!source || source->vehicleKey == 0u || target->vehicleKey == 0u)
            return false;


        void* targetCustomization = nullptr;
        InterlockedExchange(&g_starterSpawnSourceVehicleKey, static_cast<LONG>(source->vehicleKey));
        InterlockedExchange(&g_starterSpawnTargetVehicleKey, static_cast<LONG>(target->vehicleKey));
        InterlockedExchange(&g_starterSpawnTargetCustomization, 0);
        InterlockedExchange(&g_starterSpawnReady, 1);

        std::ostringstream line;
        line << "AP STARTER SPAWN PROXY READY 1.0.1: source='" << sourceName
             << "' source_vehicle_key=0x" << std::hex << std::uppercase << source->vehicleKey
             << " target='" << targetCar << "' target_vehicle_key=0x" << target->vehicleKey
             << " target_customization=" << reinterpret_cast<std::uintptr_t>(targetCustomization)
             << std::dec << " fe_record_mutation=no constructor_params_only=yes.";
        NFSMWAP::Log(line.str());
        return true;
    }

    bool PrepareBossVehicleSpawnProxy(int rank)
    {
        InterlockedExchange(&g_bossSpawnReady, 0);
        InterlockedExchange(&g_bossSpawnActive, 0);
        if (rank < 1 || rank > 15)
            return false;

        const std::string sourceCar = VanillaBlacklistCarForRank(rank);
        const std::string targetCar = NFSMWAP::GetSeedBlacklistCar(rank);
        if (sourceCar.empty() || targetCar.empty())
            return false;

        FECarRecordNative* source = nullptr;
        FECarRecordNative* target = nullptr;
        if (!FindBossSourceRecordForCar(sourceCar, &source) || !source ||
            !FindStockRecordForCar(targetCar, &target) || !target)
            return false;


        void* targetCustomization = nullptr;
        InterlockedExchange(&g_bossSpawnRank, rank);
        InterlockedExchange(&g_bossSpawnSourceVehicleKey, static_cast<LONG>(source->vehicleKey));
        InterlockedExchange(&g_bossSpawnTargetVehicleKey, static_cast<LONG>(target->vehicleKey));
        InterlockedExchange(&g_bossSpawnTargetCustomization, 0);
        InterlockedExchange(&g_bossSpawnReady, 1);
        InterlockedExchange(&g_bossSpawnActive, 1);

        std::ostringstream line;
        line << "AP BLACKLIST SPAWN PROXY READY 1.0.1: rank #" << rank
             << " source='" << sourceCar << "' source_vehicle_key=0x"
             << std::hex << std::uppercase << source->vehicleKey
             << " target='" << targetCar << "' target_vehicle_key=0x" << target->vehicleKey
             << " target_customization=" << reinterpret_cast<std::uintptr_t>(targetCustomization)
             << std::dec << " constructor_params_only=yes.";
        NFSMWAP::Log(line.str());
        NFSMWAP::QueueNotification("ARCHIPELAGO BLACKLIST",
                                   "RANK #" + std::to_string(rank) + " -> " + targetCar,
                                   "RACE VEHICLE ARMED", 3500);
        return true;
    }

    bool PrepareAllBossVehicleSpawnMappings()
    {
        InterlockedExchange(&g_bossSpawnTableReady, 0);
        InterlockedExchange(&g_bossSpawnTableCount, 0);
        for (int rank = 1; rank <= 15; ++rank)
        {


            InterlockedExchange(&g_bossSpawnTargetKeys[rank], 0);
        }

        if (!NFSMWAP::IsSeedConfigReady())
            return false;

        int resolved = 0;
        for (int rank = 1; rank <= 15; ++rank)
        {
            const std::string sourceCar = VanillaBlacklistCarForRank(rank);
            const std::string targetCar = NFSMWAP::GetSeedBlacklistCar(rank);
            if (sourceCar.empty() || targetCar.empty())
                continue;

            FECarRecordNative* source = nullptr;
            FECarRecordNative* target = nullptr;
            if (!FindStockRecordForCar(targetCar, &target) || !target || !target->vehicleKey) continue;
            std::uint32_t sourceKey=static_cast<std::uint32_t>(InterlockedCompareExchange(&g_bossSpawnSourceKeys[rank],0,0));
            if (FindBossSourceRecordForCar(sourceCar,&source) && source) sourceKey=source->vehicleKey;
            if (!sourceKey) continue;
            InterlockedExchange(&g_bossSpawnSourceKeys[rank], static_cast<LONG>(sourceKey));
            InterlockedExchange(&g_bossSpawnTargetKeys[rank], static_cast<LONG>(target->vehicleKey));
            ++resolved;
        }

        InterlockedExchange(&g_bossSpawnTableCount, resolved);
        if (resolved == 0)
            return false;

        InterlockedExchange(&g_bossSpawnTableReady, 1);
        NFSMWAP::Log("AP BLACKLIST SPAWN TABLE READY 1.0.1: resolved " +
                     std::to_string(resolved) +
                     "/15 vanilla boss vehicle keys to seed targets; mapping is source-key driven and does not wait for rival frontend timing.");
        return true;
    }

    bool CareerAlreadyOwnsVehicle(std::uint32_t vehicleKey)
    {
        FECarRecordNative* table = nullptr;
        if (!GetCareerStockTableNative(&table) || !table)
            return false;
        for (std::size_t i = 0; i < FECarTableCount; ++i)
        {
            FECarRecordNative* record = &table[i];
            __try
            {
                if ((record->filterBits & 0x2u) != 0u && record->vehicleKey == vehicleKey &&
                    record->handle<200u && record->careerHandle<25u && record->customization<75u)
                    return true;
            }
            __except (EXCEPTION_EXECUTE_HANDLER)
            {
                return false;
            }
        }
        return false;
    }

    bool CaptureVehicleIdentityNative(FECarRecordNative* record, VehicleIdentitySnapshot* snapshot)
    {
        if (!record || !snapshot)
            return false;
        __try
        {
            snapshot->feKey = record->feKey;
            snapshot->vehicleKey = record->vehicleKey;
            snapshot->customization = record->customization;
            snapshot->valid = snapshot->feKey != 0u && snapshot->vehicleKey != 0u;
            return snapshot->valid;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            snapshot->valid = false;
            return false;
        }
    }

    bool CaptureOwnedCarTableSnapshotNative(OwnedCarTableSnapshot* snapshot)
    {
        if (!snapshot)
            return false;
        snapshot->valid = false;

        FECarRecordNative* table = nullptr;
        if (!GetCareerStockTableNative(&table) || !table)
            return false;

        __try
        {
            for (std::size_t i = 0; i < FECarTableCount; ++i)
            {
                snapshot->rows[i].handle = table[i].handle;
                snapshot->rows[i].feKey = table[i].feKey;
                snapshot->rows[i].vehicleKey = table[i].vehicleKey;
                snapshot->rows[i].filterBits = table[i].filterBits;
                snapshot->rows[i].customization = table[i].customization;
                snapshot->rows[i].careerHandle = table[i].careerHandle;
                snapshot->rows[i].padding = table[i].padding;
            }
            snapshot->valid = true;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            snapshot->valid = false;
            return false;
        }
    }

    FECarRecordNative* FindNewOwnedCarAfterPurchaseNative(const OwnedCarTableSnapshot* before,
                                                          std::uint32_t sourceVehicleKey,
                                                          std::size_t* changedOwnedCount)
    {
        if (changedOwnedCount)
            *changedOwnedCount = 0u;
        if (!before || !before->valid)
            return nullptr;

        FECarRecordNative* table = nullptr;
        if (!GetCareerStockTableNative(&table) || !table)
            return nullptr;

        FECarRecordNative* exact = nullptr;
        FECarRecordNative* onlyChanged = nullptr;
        std::size_t changed = 0u;

        __try
        {
            for (std::size_t i = 0; i < FECarTableCount; ++i)
            {
                FECarRecordNative* current = &table[i];
                if ((current->filterBits & 0x2u) == 0u || current->handle == 0u ||
                    current->feKey == 0u || current->vehicleKey == 0u)
                    continue;

                const OwnedCarRowSnapshot& old = before->rows[i];
                const bool wasOwned = (old.filterBits & 0x2u) != 0u;
                const bool changedRow = !wasOwned ||
                    old.handle != current->handle ||
                    old.feKey != current->feKey ||
                    old.vehicleKey != current->vehicleKey ||
                    old.customization != current->customization ||
                    old.careerHandle != current->careerHandle;
                if (!changedRow)
                    continue;

                ++changed;
                onlyChanged = current;
                if (sourceVehicleKey != 0u && current->vehicleKey == sourceVehicleKey)
                {
                    exact = current;
                    break;
                }
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return nullptr;
        }

        if (changedOwnedCount)
            *changedOwnedCount = changed;
        if (exact)
            return exact;
        return changed == 1u ? onlyChanged : nullptr;
    }

    bool ConvertOwnedCarToTargetNative(FECarRecordNative* owned, const VehicleIdentitySnapshot* target)
    {
        if (!owned || !target || !target->valid)
            return false;
        __try
        {


            owned->feKey = target->feKey;
            owned->vehicleKey = target->vehicleKey;
            owned->customization = target->customization;
            return owned->feKey == target->feKey &&
                   owned->vehicleKey == target->vehicleKey &&
                   owned->customization == target->customization;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return false;
        }
    }

    bool RestorePurchasedOwnedRowFromSnapshotNative(
        FECarRecordNative* owned,
        const OwnedCarTableSnapshot* before)
    {
        if (!owned || !before || !before->valid)
            return false;

        FECarRecordNative* table = nullptr;
        if (!GetCareerStockTableNative(&table) || !table)
            return false;

        __try
        {
            const std::ptrdiff_t index = owned - table;
            if (index < 0 || index >= static_cast<std::ptrdiff_t>(FECarTableCount))
                return false;
            const OwnedCarRowSnapshot& old = before->rows[static_cast<std::size_t>(index)];
            owned->handle = old.handle;
            owned->feKey = old.feKey;
            owned->vehicleKey = old.vehicleKey;
            owned->filterBits = old.filterBits;
            owned->customization = old.customization;
            owned->careerHandle = old.careerHandle;
            owned->padding = old.padding;
            return owned->handle == old.handle &&
                   owned->feKey == old.feKey &&
                   owned->vehicleKey == old.vehicleKey &&
                   owned->filterBits == old.filterBits &&
                   owned->customization == old.customization &&
                   owned->careerHandle == old.careerHandle;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return false;
        }
    }


    std::string ShopItemDetail(const NFSMWAP::ShopEntry& entry)
    {
        const std::string type = UpperAlnum(entry.itemType);
        if (type == "CAR")
            return entry.itemCar.empty() ? std::string("CAR") : entry.itemCar;
        if (type == "PERFORMANCEPART")
        {
            std::string out = entry.itemCar;
            if (!entry.itemCategory.empty())
                out += (out.empty() ? std::string() : std::string(" / ")) + entry.itemCategory;
            if (!entry.itemTier.empty())
                out += (out.empty() ? std::string() : std::string(" ")) + entry.itemTier;
            return out;
        }
        if (type == "REMOTE")
            return "ITEM FROM " + (entry.recipientGame.empty() ? std::string("ANOTHER GAME") : entry.recipientGame);
        return entry.itemType;
    }

    void ShowShopOverlay(const NFSMWAP::ShopEntry& entry,
                         const std::string& storeName,
                         int slotIndex,
                         int slotCount,
                         const std::string& controls)
    {
        NFSMWAP::StoreOverlayInfo info;
        info.visible = true;
        info.checked = entry.checked;
        info.recipientIsLocal = entry.recipientIsLocal;
        info.carItem = UpperAlnum(entry.itemType) == "CAR";
        info.slotIndex = slotIndex;
        info.slotCount = slotCount;
        info.storeName = storeName;
        info.locationName = entry.locationName;
        info.itemName = entry.itemName.empty() ? entry.locationName : entry.itemName;
        info.itemType = entry.itemType.empty() ? std::string("UNKNOWN") : entry.itemType;
        info.itemDetail = ShopItemDetail(entry);
        info.priceText = MoneyText(entry.price);
        info.recipientName = entry.recipientName;
        info.recipientGame = entry.recipientGame;
        info.controls = controls;
        if (UpperAlnum(storeName) == "CARLOT")
            info.presentationMode = NFSMWAP::StorePresentationMode::CarLot3DLogo;
        else if (UpperAlnum(storeName) == "PARTSSTORE")
            info.presentationMode = NFSMWAP::StorePresentationMode::Parts2DIcons;

        int careerCash = 0;
        if (ReadCareerCashNative(&careerCash))
            info.careerCashText = MoneyText(careerCash);
        NFSMWAP::SetStoreOverlay(info);
    }

    const char* VanillaBlacklistCarForRank(int rank)
    {
        switch (rank)
        {
        case 15: return "Volkswagen Golf GTI";
        case 14: return "Lexus IS 300";
        case 13: return "Toyota Supra";
        case 12: return "Mazda RX-8";
        case 11: return "Mitsubishi Eclipse GT";
        case 10: return "Porsche Cayman S";
        case 9:  return "Mitsubishi Lancer Evolution VIII";
        case 8:  return "Ford Mustang GT";
        case 7:  return "Mercedes-Benz CLK 500";
        case 6:  return "Lamborghini Gallardo";
        case 5:  return "Chevrolet Corvette C6";
        case 4:  return "Dodge Viper SRT-10";
        case 3:  return "Aston Martin DB9";
        case 2:  return "Mercedes-Benz SLR McLaren";
        case 1:  return "BMW M3 GTR";
        default: return "";
        }
    }

    bool IsVanillaCareerStarter(const std::string& friendly)
    {
        const std::string key = NFSMWAP::CarIdentityKey(friendly);
        return key == UpperAlnum("Chevrolet Cobalt SS") ||
               key == UpperAlnum("Fiat Punto") ||
               key == UpperAlnum("Lexus IS 300") ||
               key == UpperAlnum("Volkswagen Golf GTI");
    }

    bool TryPrepareSeedStarterRideProxyNative()
    {
        if (!NFSMWAP::IsSeedConfigReady())
            return false;

        const std::string targetCar = NFSMWAP::GetSeedStartingCar();
        if (targetCar.empty())
            return false;

        FECarRecordNative* targetStock = nullptr;
        if (!FindStockRecordForCar(targetCar, &targetStock) || !targetStock)
            return false;

        FECarRecordNative* table = nullptr;
        if (!GetCareerStockTableNative(&table) || !table)
            return false;

        FECarRecordNative* starter = nullptr;
        std::string starterName;
        unsigned int bestCareerHandle = 0x100u;

        for (std::size_t i = 0; i < FECarTableCount; ++i)
        {
            FECarRecordNative* record = &table[i];
            std::uint32_t handle = 0, feKey = 0, vehicleKey = 0, filterBits = 0;
            std::uint8_t customization = 0, careerHandle = 0;
            if (!ReadFECarRecordFieldsNative(record, &handle, &feKey, &vehicleKey,
                                             &filterBits, &customization, &careerHandle))
                return false;
            if ((filterBits & 0x2u) == 0u || handle == 0u || vehicleKey == 0u)
                continue;

            int typeId = -1;
            char rawName[128] = {};
            if (!ReadRecordNative(record, &typeId, rawName, sizeof(rawName)))
                continue;

            const std::string friendly = FriendlyCarNameFromType(rawName);
            if (!IsVanillaCareerStarter(friendly))
                continue;

            if (!starter || static_cast<unsigned int>(careerHandle) < bestCareerHandle)
            {
                starter = record;
                starterName = friendly;
                bestCareerHandle = static_cast<unsigned int>(careerHandle);
            }
        }

        if (!starter || starter->handle == 0u || targetStock->handle == 0u)
            return false;

        InterlockedExchange(&g_starterRideProxyReady, 0);
        InterlockedExchange(&g_starterRideSourceHandle, static_cast<LONG>(starter->handle));
        InterlockedExchange(&g_starterRideTargetHandle, static_cast<LONG>(targetStock->handle));
        InterlockedExchange(&g_starterRideMappedCount, 0);
        InterlockedExchange(&g_starterRideProxyReady, 1);

        std::ostringstream line;
        line << "AP STARTER RIDE PROXY READY 1.0.1: source='" << starterName
             << "' source_handle=0x" << std::hex << std::uppercase << starter->handle
             << " target='" << targetCar << "' target_handle=0x" << targetStock->handle
             << std::dec << " fe_record_mutation=no live_ride_virtualization=yes.";
        NFSMWAP::Log(line.str());
        NFSMWAP::QueueNotification("ARCHIPELAGO STARTER", targetCar,
                                   "LIVE RIDE PROXY READY", 4000);
        return true;
    }

    bool PrepareBlacklistRideProxy(int rank)
    {
        InterlockedExchange(&g_blacklistProxyActive, 0);
        InterlockedExchange(&g_blacklistProxyReady, 0);
        InterlockedExchange(&g_blacklistProxySourceCount, 0);
        g_blacklistProxyTarget = nullptr;
        g_blacklistProxyTargetCustomization = 0xFFu;
        for (int i = 0; i < BlacklistProxyMaxSources; ++i)
        {
            g_blacklistProxySources[i] = nullptr;
            g_blacklistProxySourceCustomization[i] = 0xFFu;
        }

        if (rank < 1 || rank > 15)
            return false;

        const std::string targetCar = NFSMWAP::GetSeedBlacklistCar(rank);
        const std::string vanillaCar = VanillaBlacklistCarForRank(rank);
        if (targetCar.empty() || vanillaCar.empty())
            return false;

        FECarRecordNative* target = nullptr;
        if (!FindStockRecordForCar(targetCar, &target) || !target)
        {
            NFSMWAP::Log("AP BLACKLIST RIDE PROXY 1.0.1: target stock record not found for rank #" +
                         std::to_string(rank) + " car='" + targetCar + "'.");
            return false;
        }

        FECarRecordNative* table = nullptr;
        if (!GetCareerStockTableNative(&table) || !table)
            return false;

        const std::string wanted = NFSMWAP::CarIdentityKey(vanillaCar);
        LONG count = 0;
        for (std::size_t i = 0; i < FECarTableCount && count < BlacklistProxyMaxSources; ++i)
        {
            FECarRecordNative* record = &table[i];
            std::uint32_t handle = 0, feKey = 0, vehicleKey = 0, filterBits = 0;
            std::uint8_t customization = 0, careerHandle = 0;
            if (!ReadFECarRecordFieldsNative(record, &handle, &feKey, &vehicleKey,
                                             &filterBits, &customization, &careerHandle))
                return false;

            if ((filterBits & 0x2u) != 0u || handle == 0u || feKey == 0u || vehicleKey == 0u)
                continue;

            int typeId = -1;
            char rawName[128] = {};
            if (!ReadRecordNative(record, &typeId, rawName, sizeof(rawName)))
                continue;
            if (NFSMWAP::CarIdentityKey(FriendlyCarNameFromType(rawName)) != wanted)
                continue;

            bool duplicate = false;
            for (LONG j = 0; j < count; ++j)
            {
                if (g_blacklistProxySources[j] == record)
                {
                    duplicate = true;
                    break;
                }
            }
            if (duplicate)
                continue;

            g_blacklistProxySources[count] = record;
            g_blacklistProxySourceCustomization[count] = customization;
            ++count;
        }

        if (count == 0)
        {
            NFSMWAP::Log("AP BLACKLIST RIDE PROXY 1.0.1: no FE source records found for rank #" +
                         std::to_string(rank) + " vanilla='" + vanillaCar + "'.");
            return false;
        }

        g_blacklistProxyTarget = target;
        g_blacklistProxyTargetCustomization = target->customization;
        InterlockedExchange(&g_blacklistProxyRank, rank);
        InterlockedExchange(&g_blacklistProxySourceCount, count);
        InterlockedExchange(&g_blacklistProxyReady, 1);

        std::ostringstream line;
        line << "AP BLACKLIST RIDE PROXY READY 1.0.1: rank #" << rank
             << " vanilla='" << vanillaCar << "' target='" << targetCar
             << "' source_handles=" << count << " target_handle=0x"
             << std::hex << std::uppercase << target->handle << std::dec << ".";
        NFSMWAP::Log(line.str());
        return true;
    }

    bool IsRivalChallengePackage(const std::string& packageName)
    {
        const std::string key = UpperAlnum(packageName);
        return key.find("INGAMERIVALCHALLENGE") != std::string::npos ||
               key.find("RIVALCHALLENGE") != std::string::npos;
    }

    bool IsSafeStarterConversionPackage(const std::string& packageName)
    {
        const std::string key = UpperAlnum(packageName);


        return key.find("SAFEHOUSE") != std::string::npos ||
               key.find("CARSELECT") != std::string::npos ||
               key.find("REPUTATIONOVERVIEW") != std::string::npos;
    }

    FECarRecordNative* SingleOwnedCurrentCarNative()
    {
        __try
        {
            const std::uint32_t database=*reinterpret_cast<std::uint32_t*>(FEDatabaseAddress);
            if (!database) return nullptr;
            const std::uint32_t profile=*reinterpret_cast<std::uint32_t*>(database+0x10u);
            if (!profile) return nullptr;
            const std::uint32_t current=*reinterpret_cast<std::uint32_t*>(profile+0xA8u);
            FECarRecordNative* table=nullptr;
            if (!GetCareerStockTableNative(&table) || !table) return nullptr;
            FECarRecordNative* only=nullptr;
            for (std::size_t i=0;i<FECarTableCount;++i)
            {


                if ((table[i].filterBits&2u)==0u || table[i].handle>=200u ||
                    table[i].careerHandle>=25u || table[i].customization>=75u) continue;
                if (only) return nullptr;
                only=&table[i];
            }
            return only && only->handle==current ? only : nullptr;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    bool ReplaceInitialCarrierNative(FECarRecordNative* carrier,FECarRecordNative* source)
    {
        if (!carrier || !source) return false;
        __try
        {
            if (!source->feKey || !source->vehicleKey || !(carrier->filterBits&2u) ||
                carrier->handle>=200u || carrier->careerHandle>=25u || carrier->customization>=75u) return false;
            void* db=GetCareerCarDBNative();
            if (!db || *reinterpret_cast<const unsigned char*>(FEPlayerCarDBCreateCareerCarCall)!=0xE8u) return false;
            const auto target=FEPlayerCarDBCreateCareerCarCall+5u+
                *reinterpret_cast<const std::int32_t*>(FEPlayerCarDBCreateCareerCarCall+1u);
            if (target<0x401000u || target>=0x890000u) return false;
            using CustomFn=unsigned char*(__thiscall*)(void*,unsigned char);
            auto oldCustom=reinterpret_cast<CustomFn>(FEPlayerCarDBGetCustomizationRecordByHandleAddress)(db,carrier->customization);
            if (!oldCustom) return false;
            using CreateFn=FECarRecordNative*(__thiscall*)(void*,unsigned int,int);
            FECarRecordNative* temporary=reinterpret_cast<CreateFn>(target)(db,source->handle,2);
            if (!temporary || temporary==source || temporary==carrier) return false;
            if (temporary->customization>=75u || temporary->customization==carrier->customization || temporary->handle>=200u)
            { temporary->handle=0xFFFFFFFFu;temporary->filterBits=0;return false; }


            carrier->feKey=temporary->feKey;
            carrier->vehicleKey=temporary->vehicleKey;
            carrier->customization=temporary->customization;
            oldCustom[0x194u]=0xFFu;
            temporary->handle=0xFFFFFFFFu;temporary->filterBits=0;
            temporary->customization=0xFFu;temporary->careerHandle=0xFFu;
            return carrier->vehicleKey==source->vehicleKey;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    bool g_firstReceivedCarDelivered=false;
    std::string g_firstReceivedCar;
    bool g_receivedCareerStartPending=false;
    bool g_receivedCareerStartDispatched=false;
    std::uint32_t g_receivedCareerStartHandle=0xFFFFFFFFu;

    int CountOwnedCareerCarsNative()
    {
        __try
        {
            FECarRecordNative* table=nullptr;
            if (!GetCareerStockTableNative(&table) || !table) return -1;
            int count=0;
            for (std::size_t i=0;i<FECarTableCount;++i)
                if ((table[i].filterBits&2u) && table[i].handle<200u) ++count;
            return count;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -1; }
    }

    bool SelectInitialReceivedCarNative(FECarRecordNative* car)
    {
        __try
        {
            if (!car || car->handle>=200u || car->careerHandle>=25u || !(car->filterBits&2u)) return false;
            const auto db=*reinterpret_cast<std::uint32_t*>(FEDatabaseAddress);
            if (!db || !NFSMWAP::NativeCareerDeliveryMode(*reinterpret_cast<std::uint32_t*>(db+0x12Cu))) return false;
            const auto profile=*reinterpret_cast<std::uint32_t*>(db+0x10u);
            if (profile<0x10000u || (profile&3u)) return false;
            *reinterpret_cast<std::uint32_t*>(profile+0xA8u)=car->handle;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    bool DeliverOnePendingCarToCareerGarage()
    {
        PendingCarDelivery pending;
        {
            std::lock_guard<std::mutex> lock(g_receivedCarMutex);
            if (g_pendingCarDeliveries.empty())
                return false;
            pending = g_pendingCarDeliveries.front();
        }

        FECarRecordNative* source = nullptr;
        if (!FindDeliverySourceForCar(pending.car, &source) || !source) {
            static DWORD lastMissingSource=0;
            const DWORD now=GetTickCount();
            if (!lastMissingSource || now-lastMissingSource>=5000u) {
                lastMissingSource=now;
                NFSMWAP::Log("AP CAR SOURCE WAITING: car='"+pending.car+"' identity="+NFSMWAP::CarIdentityKey(pending.car));
            }
            return false;
        }

        bool delivered = CareerAlreadyOwnsVehicle(source->vehicleKey);
        FECarRecordNative* created = nullptr;
        if (NFSMWAP::InitialDealershipSelectionPending() && !g_firstReceivedCarDelivered && !delivered)
        {
            const int owned=CountOwnedCareerCarsNative();
            if (owned<0) return false;
            if (owned==0)
            {
                created=CreateCareerOwnedCarNative(GetCareerCarDBNative(),source);
                delivered=created && SelectInitialReceivedCarNative(created);
                if (delivered)
                {
                    std::string package;
                    std::uint32_t database=0,mode=0;
                    g_receivedCareerStartPending=ReadControlledPackage(package) &&
                        UpperAlnum(package).find("CARSELECT")!=std::string::npos &&
                        ReadNativeCashWord(FEDatabaseAddress,database) &&
                        ReadNativeCashWord(database+0x12Cu,mode) && (mode&0x8000u);
                    g_receivedCareerStartHandle=created->handle;
                    NFSMWAP::Log("AP FIRST CAR: received car initialized with native customization and Career records; completing Career selection.");
                }
            }
            FECarRecordNative* carrier=SingleOwnedCurrentCarNative();
            int type=-1;char raw[128]={};
            if (!delivered && carrier && ReadRecordNative(carrier,&type,raw,sizeof(raw)) &&
                IsVanillaCareerStarter(FriendlyCarNameFromType(raw)) && ReplaceInitialCarrierNative(carrier,source))
            {
                delivered=true;
                NFSMWAP::Log("AP FIRST CAR: initial Career carrier replaced by received car '"+pending.car+"'; no free seed car.");
            }
            if (!delivered)
            {
                static DWORD lastWaitingLog=0;
                const DWORD now=GetTickCount();
                if (!lastWaitingLog || now-lastWaitingLog>5000u)
                {
                    lastWaitingLog=now;
                    NFSMWAP::Log("AP FIRST CAR WAITING: owned_count="+std::to_string(owned)+
                        " current_carrier='"+std::string(raw)+"'; native allocation/initial carrier is not ready.");
                }
                return false;
            }
        }
        if (!delivered)
        {
            void* db = GetCareerCarDBNative();
            created = CreateCareerOwnedCarNative(db, source);
            delivered = created != nullptr;
        }
        if (!delivered)
            return false;
        if (NFSMWAP::InitialDealershipSelectionPending() && !g_firstReceivedCarDelivered)
        {


            FECarRecordNative* initial=SingleOwnedCurrentCarNative();
            std::string package;
            std::uint32_t database=0,mode=0;
            if (initial && initial->vehicleKey==source->vehicleKey &&
                ReadControlledPackage(package) && UpperAlnum(package).find("CARSELECT")!=std::string::npos &&
                ReadNativeCashWord(FEDatabaseAddress,database) && database &&
                ReadNativeCashWord(database+0x12Cu,mode) && (mode&0x8000u))
            {
                g_receivedCareerStartHandle=initial->handle;
                g_receivedCareerStartPending=true;
                NFSMWAP::Log("AP FIRST CAR: validated received owned car ready for native Career selection.");
            }
        }
        g_firstReceivedCarDelivered=true;
        if (g_firstReceivedCar.empty()) g_firstReceivedCar=pending.car;
        if (g_receivedCareerStartPending) return false;

        std::ostringstream ack;
        ack << "{\"type\":\"received_item_ack\",\"index\":" << pending.index << "}";
        if (!NFSMWAP::SendBridgeLine(ack.str()))
            return false;

        {
            std::lock_guard<std::mutex> lock(g_receivedCarMutex);
            if (!g_pendingCarDeliveries.empty() && g_pendingCarDeliveries.front().index == pending.index)
                g_pendingCarDeliveries.pop_front();
        }

        std::ostringstream log;
        log << "AP CAR DELIVERY CONFIRMED: index=" << pending.index << " item_id=" << pending.itemId
            << " car='" << pending.car << "'";
        if (created)
            log << " new_record_handle=" << created->handle << " career_filter=0x2";
        else
            log << " already_owned=yes";
        NFSMWAP::Log(log.str());

        return true;
    }

    void DeliverPendingCarsToCareerGarage()
    {
        std::size_t attempts=0;
        {std::lock_guard<std::mutex> lock(g_receivedCarMutex);attempts=(std::min)(g_pendingCarDeliveries.size(),std::size_t(32));}
        for(std::size_t i=0;i<attempts;++i) {
            int index=-1;
            {std::lock_guard<std::mutex> lock(g_receivedCarMutex);if(g_pendingCarDeliveries.empty())break;index=g_pendingCarDeliveries.front().index;}
            const bool delivered=DeliverOnePendingCarToCareerGarage();
            if(g_receivedCareerStartPending || NFSMWAP::InitialDealershipSelectionPending())break;
            if(!delivered) {
                std::lock_guard<std::mutex> lock(g_receivedCarMutex);
                if(!g_pendingCarDeliveries.empty()&&g_pendingCarDeliveries.front().index==index) {
                    g_pendingCarDeliveries.push_back(g_pendingCarDeliveries.front());g_pendingCarDeliveries.pop_front();
                }
            }
        }
    }

    std::string MoneyText(int amount)
    {
        std::ostringstream out;
        out << '$' << amount;
        return out.str();
    }
}

namespace NFSMWAP
{
    void ConfigureStoreRuntime(bool enabled, int purchaseHotkey)
    {
        g_enabled = enabled;
        if (purchaseHotkey > 0 && purchaseHotkey <= 0xFF)
            g_purchaseHotkey = purchaseHotkey;
    }

    bool NativeShopRequested() { return g_enabled; }

    bool GetNativeShopCar(std::string& car)
    {
        std::string raw;
        int typeId = -1;
        std::uintptr_t address = 0;
        return ReadSelectedCar(car, raw, typeId, address);
    }

    bool GetNativeDealerCar(const void* screen, std::string& car)
    {
        car.clear();
        char raw[128]={};
        if (!ReadDealerCarNative(screen,raw,sizeof(raw))) return false;
        car=FriendlyCarNameFromType(raw);
        return !car.empty();
    }

    bool GetNativeStorePackage(std::string& package) { return ReadControlledPackage(package); }

    bool PurchaseNativeShopEntry(int locationId, const std::string& car)
    {
        ShopEntry entry;
        if (!GetShopEntry(locationId, entry)) return false;
        if (entry.checked)
        {
            QueueNotification("ARCHIPELAGO SHOP", "ALREADY PURCHASED", entry.itemName, 3000);
            return false;
        }
        return BeginTransactionalShopPurchase(entry, car, true);
    }

    bool GetNativeCareerCash(int& cash)
    {
        cash=0;return IsCareerProfileReady() && ReadCareerCashNative(&cash);
    }

    void StorePurchaseMainThreadTick()
    {
        if (!IsCareerProfileReady()) return;
        ProcessPendingPurchaseTransaction();
        if (!g_enabled) return;
        int appearanceFlow=-1;
        std::string appearancePackage;
        const DWORD now=GetTickCount();
        static DWORD lastAppearancePass=0;
        static int lastPriorityRank=0;
        if (ReadGameFlow(appearanceFlow) && appearanceFlow==3 && ReadControlledPackage(appearancePackage) &&
            (IsSafeStarterConversionPackage(appearancePackage) || IsPartsStorePackage(appearancePackage) ||
             appearancePackage=="SafeHouseRivalChallenge.fng" || appearancePackage=="InGameRivalChallenge.fng"))
        {
            const int selectedRank=GetActiveRivalRank();
            const bool newRival=selectedRank>=1 && selectedRank<=15 && selectedRank!=lastPriorityRank;
            if (!lastAppearancePass || static_cast<DWORD>(now-lastAppearancePass)>=100u || newRival)
            {
                lastAppearancePass=now;
                lastPriorityRank=selectedRank;
                PrepareBlacklistAppearancesMainThread();
            }
        }
        static DWORD lastDelivery=0;
        if (now-lastDelivery<1000u) return;
        lastDelivery=now;
        int flow=-1;
        if (!ReadGameFlow(flow)) return;
        if (g_receivedCareerStartPending && g_receivedCareerStartDispatched)
        {
            std::string package;
            const bool hasPackage=ReadControlledPackage(package);
            if (flow>=4 || (flow==3 && hasPackage && UpperAlnum(package).find("CARSELECT")==std::string::npos))
            {
                g_receivedCareerStartPending=false;
                Log("AP FIRST CAR: native Career selection completed; receipt acknowledgement released.");
            }
        }
        if (flow!=3) return;
        std::string package;
        if (!ReadControlledPackage(package) ||
            !(package=="MainMenu_Sub.fng" || IsSafeStarterConversionPackage(package) || IsPartsStorePackage(package))) return;
        std::uint32_t database=0,mode=0;
        if (!ReadNativeCashWord(FEDatabaseAddress,database) || !database ||
            !ReadNativeCashWord(database+0x12Cu,mode) || !NativeCareerDeliveryMode(mode)) return;


        const bool firstCarChoice=InitialDealershipSelectionPending() && (mode&0x8000u) &&
            UpperAlnum(package).find("CARSELECT")!=std::string::npos &&
            (!g_firstReceivedCarDelivered || g_receivedCareerStartPending);
        const bool receivedCareerOpened=IsDealershipFirstStart() &&
            g_receivedCareerStartDispatched && !g_receivedCareerStartPending;
        if (!IsLiveCareerMode() && !firstCarChoice && !receivedCareerOpened) return;
        DeliverPendingCarsToCareerGarage();


        if (InitialDealershipSelectionPending() && !g_firstReceivedCar.empty())
        {
            FECarRecordNative* source=nullptr;
            if (FindStockRecordForCar(g_firstReceivedCar,&source) && source && !CareerAlreadyOwnsVehicle(source->vehicleKey))
            {
                FECarRecordNative* carrier=SingleOwnedCurrentCarNative();
                int type=-1;char raw[128]={};
                if (carrier && ReadRecordNative(carrier,&type,raw,sizeof(raw)) && IsVanillaCareerStarter(FriendlyCarNameFromType(raw)))
                    ReplaceInitialCarrierNative(carrier,source);
            }
        }
    }

    bool GetReceivedCareerStartChoice(unsigned int& handle)
    {
        handle=0;
        if (!InitialDealershipSelectionPending() || !g_receivedCareerStartPending || g_receivedCareerStartDispatched) return false;
        auto current=SingleOwnedCurrentCarNative();
        if (!current || current->handle!=g_receivedCareerStartHandle || current->careerHandle>=25u)
        {
            static DWORD lastWaiting=0;
            const DWORD now=GetTickCount();
            if (!lastWaiting || now-lastWaiting>=5000u)
            {
                lastWaiting=now;
                Log("AP FIRST CAR SELECTOR WAITING: received_handle="+std::to_string(g_receivedCareerStartHandle)+
                    " valid_current_handle="+(current ? std::to_string(current->handle) : std::string("none"))+
                    " owned_count="+std::to_string(CountOwnedCareerCarsNative()));
            }
            return false;
        }
        handle=current->handle;
        return true;
    }

    void NotifyReceivedCareerStartChoice() { g_receivedCareerStartDispatched=true; }

    void NotifyShopPurchaseAck(int locationId, int requestId, bool accepted, const std::string& reason)
    {
        std::lock_guard<std::mutex> lock(g_purchaseMutex);
        if (g_pendingPurchaseLocationId == 0 || g_pendingPurchaseLocationId != locationId)
            return;
        if (requestId > 0 && g_pendingPurchaseRequestId != requestId)
            return;
        g_pendingPurchaseAccepted = accepted;
        g_pendingPurchaseReason = reason;
        g_pendingPurchaseAckReady = true;
    }

    void NotifyReceivedCarItem(int index, int itemId, const std::string& car)
    {
        if (index < 0 || car.empty())
            return;
        std::lock_guard<std::mutex> lock(g_receivedCarMutex);
        for (const PendingCarDelivery& pending : g_pendingCarDeliveries)
            if (pending.index == index)
                return;
        PendingCarDelivery pending;
        pending.index = index;
        pending.itemId = itemId;
        pending.car = car;
        g_pendingCarDeliveries.push_back(pending);
        Log("AP CAR DELIVERY QUEUED: index=" + std::to_string(index) + " car='" + car + "'.");
    }

    DWORD WINAPI StoreRuntimeThread(LPVOID)
    {
        if (!g_enabled)
        {
            Log("AP Store runtime disabled by configuration.");
            return 0;
        }

        Log("AP Store runtime 1.0.1 started. Native store UI + live PVehicle spawn proxy enabled.");
        Log("Car Lot: dealership-first seeds keep FE record lookups and BuildRide calls vanilla; native AP merchandise owns the showroom.");
        Log("AP shops: native selection, scouted item labels and controller Accept own the purchase. No merchandise mask or F6/F7 shop cursor is active.");
        Log("AP shop cash: embedded UserProfile+0xA8+0x0C CurrentCash. Received cars enter the garage; cash receipts are credited by the native cash delivery service.");

        bool starterResolved = false;
        InterlockedExchange(&g_starterRideProxyReady, 0);
        InterlockedExchange(&g_starterRideSourceHandle, 0);
        InterlockedExchange(&g_starterRideTargetHandle, 0);
        InterlockedExchange(&g_starterSpawnReady, 0);
        InterlockedExchange(&g_starterSpawnMappedCount, 0);
        InterlockedExchange(&g_lastHumanEffectiveVehicleKey, 0);
        InterlockedExchange(&g_purchaseSpawnOverrideReady, 0);
        InterlockedExchange(&g_purchaseSpawnSourceVehicleKey, 0);
        InterlockedExchange(&g_purchaseSpawnTargetVehicleKey, 0);
        InterlockedExchange(&g_purchaseSpawnMappedCount, 0);
        InterlockedExchange(&g_bossSpawnReady, 0);
        InterlockedExchange(&g_bossSpawnActive, 0);
        InterlockedExchange(&g_bossSpawnMappedCount, 0);
        Log("AP STARTER: dealership-first seeds have no free seed car. The legacy spawn proxy is disabled for them.");
        Log("AP BLACKLIST SPAWN 1.0.1: all 15 vanilla boss source vehicle keys are pre-resolved to seed targets; Racer spawns are remapped immediately without waiting for rival frontend timing.");
        Log("AP DEALERSHIP POINTER SAFETY 1.0.1: FEPlayerCarDB_GetCarRecordByHandle proxy is disabled permanently; Car_Select receives only its original vanilla FECarRecord pointers.");

        const bool vehicleSpawnHookInstalled = InstallPVehicleConstructCallProxy();
        if (vehicleSpawnHookInstalled)
        {
            std::ostringstream spawnHookLine;
            spawnHookLine << "AP VEHICLE SPAWN ENTRY HOOK 1.0.1: INT3/VEH interception installed at "
                          << "PVehicle::construct @ 0x00689820; original_first_byte=0x"
                          << std::hex << std::uppercase
                          << static_cast<unsigned int>(g_pvehicleConstructOriginalByte)
                          << std::dec
                          << ". VehicleParams ABI is auto-detected (inline or invisible-reference) and only the temporary construction request is edited; no direct CALL-site scan is required.";
            Log(spawnHookLine.str());
        }
        else
        {
            Log("AP VEHICLE SPAWN ENTRY HOOK 1.0.1 NOT INSTALLED: could not arm the verified PVehicle::construct entry breakpoint @ 0x00689820. Starter and Blacklist live-spawn randomization are disabled; dealership remains stable.");
        }

        if (InstallFEPlayerCarDBLookupCallProxy())
        {
            std::ostringstream hookLine;
            hookLine << "AP CAR_SELECT LOOKUP CALLSITES DISCOVERED 1.0.1: found "
                     << g_patchedLookupCallsites.size()
                     << " vanilla CALL site(s) targeting FEPlayerCarDB_GetCarRecordByHandle @ 0x0056ECC0; lookup callsites remain permanently vanilla in 1.0.1.";
            Log(hookLine.str());
        }
        else
        {
            Log("AP CAR_SELECT LOOKUP CALL PROXY NOT INSTALLED: no direct CALL sites to 0x0056ECC0 were patched. Vanilla behavior retained.");
        }

        if (InstallFEPlayerCarDBBuildRideCallProxy())
        {
            std::ostringstream hookLine;
            hookLine << "AP CAR_SELECT BUILD-RIDE CALLSITES DISCOVERED 1.0.1: found "
                     << g_patchedBuildRideCallsites.size()
                     << " vanilla CALL site(s) targeting FEPlayerCarDB_BuildRideForPlayer @ 0x005910E0; not patched during startup.";
            Log(hookLine.str());
        }
        else
        {
            Log("AP CAR_SELECT BUILD-RIDE PROXY NOT INSTALLED: no direct CALL sites to 0x005910E0 were patched. Showroom model may remain vanilla.");
        }

        if (InstallFEPlayerCarDBCustomizationLookupCallProxy())
        {
            std::ostringstream hookLine;
            hookLine << "AP CAR_SELECT CUSTOMIZATION LOOKUP PROXY INSTALLED: redirected "
                     << g_patchedCustomizationLookupCallsites.size()
                     << " direct CALL site(s) targeting FEPlayerCarDB_GetCustomizationRecordByHandle @ 0x0056F100.";
            Log(hookLine.str());
        }
        else
        {
            Log("AP CAR_SELECT CUSTOMIZATION LOOKUP PROXY DISABLED 1.0.1: BuildRide is authoritative for the randomized showroom model; customization CALL sites remain vanilla for race-resume safety.");
        }

        std::string lastFriendly;
        bool purchaseWasDown = false;
        bool cycleWasDown = false;
        bool prevCycleWasDown = false;
        std::size_t perfIndex = 0;
        bool lastPerfMode = false;
        std::vector<FrontendProxySlot> frontendProxySlots;
        bool frontendProxyReady = false;
        bool wasCarLotPackage = false;
        bool purchaseDialogSession = false;
        DWORD purchaseDialogGraceUntil = 0;
        PurchaseMaterializationSnapshot purchaseMaterialization;
        ShopEntry nativePurchaseEntry;
        bool nativePurchaseEntryValid = false;
        bool nativePurchaseApSent = false;
        bool nativePurchaseCommitObserved = false;
        bool nativePurchaseGarageConverted = false;
        bool nativePurchaseOwnedSnapshotValid = false;
        VehicleIdentitySnapshot nativePurchaseSourceIdentity;
        VehicleIdentitySnapshot nativePurchaseTargetIdentity;
        std::uint32_t nativePurchasePreviousHumanVehicleKey = 0u;
        OwnedCarTableSnapshot nativePurchaseOwnedBefore;
        DWORD nativePurchaseLastGarageScanTick = 0;
        std::string nativePurchaseTargetCar;
        FECarRecordNative* lastProxySource = nullptr;
        FECarRecordNative* lastProxyTarget = nullptr;
        DWORD lastPackageLogTick = 0;
        LONG lastLookupCallCount = 0;
        LONG lastLookupMappedCount = 0;
        LONG lastCustomizationLookupCallCount = 0;
        LONG lastCustomizationLookupMappedCount = 0;
        LONG lastBuildRideCallCount = 0;
        LONG lastBuildRideMappedCount = 0;
        DWORD lastLookupStatsTick = 0;
        DWORD lastStarterRetryTick = 0;
        int lastPreparedBlacklistRank = 0;
        DWORD lastVehicleSpawnStatsTick = 0;
        LONG lastVehicleSpawnCalls = 0;
        LONG lastVehicleSpawnHumans = 0;
        LONG lastVehicleSpawnRacers = 0;
        LONG lastVehicleSpawnUnresolved = 0;
        LONG lastVehicleSpawnAbiInline = 0;
        LONG lastVehicleSpawnAbiIndirect = 0;
        LONG lastVehicleSpawnAbiScan = 0;
        LONG lastStarterSpawnMapped = 0;
        LONG lastBossSpawnMapped = 0;
        bool bossSpawnSessionArmed = false;
        bool bossSpawnSessionSawGameplay = false;
        bool allBossSpawnMappingsPrepared = false;
        DWORD lastBossSpawnTableRetryTick = 0;
        bool unresolvedStackLogged = false;
        int priorFlow=-1;
        DWORD worldLoadStarted=0;

        for (;;)
        {
            int flow = -1;
            ReadGameFlow(flow);


            if (flow==4 && priorFlow!=4) worldLoadStarted=GetTickCount();
            if (flow==6 && priorFlow!=6 && worldLoadStarted) {
                Log("AP PERF WORLD LOAD: flow4_to_gameplay_ms="+
                    std::to_string(GetTickCount()-worldLoadStarted));
                worldLoadStarted=0;
            }
            if (flow==3 && priorFlow==1) worldLoadStarted=0;
            priorFlow=flow;

            std::string controlledPackage;
            const bool havePackage = ReadControlledPackage(controlledPackage);
            const bool carLotPackage = havePackage && IsCarLotPackage(controlledPackage);
            const bool purchaseDialogPackage = havePackage && IsPurchaseDialogPackage(controlledPackage);
            const bool rivalChallengePackage = havePackage && IsRivalChallengePackage(controlledPackage);


            const bool earlyCarSelectExit = wasCarLotPackage && g_callsiteProxiesEnabled &&
                ((flow == 2) ||
                 (flow == 3 && !carLotPackage && !purchaseDialogPackage));
            if (earlyCarSelectExit)
            {
                InterlockedExchange(&g_carSelectLookupProxyActive, 0);
                const bool drained = WaitForCarSelectProxyCallsToDrain(100u);
                const bool restored = drained && SetCarSelectCallsiteProxiesEnabled(false);

                std::ostringstream safetyLine;
                safetyLine << "AP CAR_SELECT EARLY EXIT 1.0.1: flow=" << flow
                           << " package='" << (havePackage ? controlledPackage : std::string("<none>")) << "'"
                           << " buildride_calls_drained=" << (drained ? "yes" : "no")
                           << " vanilla_calls_restored=" << (restored ? "yes" : "no")
                           << " before_flow4=yes.";
                Log(safetyLine.str());

                wasCarLotPackage = false;
                lastProxySource = nullptr;
                lastProxyTarget = nullptr;
            }
            else if (g_callsiteProxiesEnabled &&
                     (flow != 3 || (!carLotPackage && !purchaseDialogPackage)))
            {


                InterlockedExchange(&g_carSelectLookupProxyActive, 0);

                if (wasCarLotPackage)
                {
                    std::ostringstream safetyLine;
                    safetyLine << "AP CAR_SELECT LATE EXIT 1.0.1: flow=" << flow
                               << " package='" << (havePackage ? controlledPackage : std::string("<none>")) << "'"
                               << " showroom_proxy_active=no late_code_rewrite=avoided.";
                    Log(safetyLine.str());
                    wasCarLotPackage = false;
                    lastProxySource = nullptr;
                    lastProxyTarget = nullptr;
                }
            }


            if (vehicleSpawnHookInstalled && !IsDealershipFirstStart() && !starterResolved && flow == 3 &&
                GetTickCount() - lastStarterRetryTick > 1000u)
            {
                lastStarterRetryTick = GetTickCount();
                starterResolved = PrepareStarterVehicleSpawnProxy();
                if (starterResolved)
                {
                    QueueNotification("ARCHIPELAGO STARTER", GetSeedStartingCar(),
                                      "LIVE SPAWN RANDOMIZER ARMED", 4000);
                }
            }


            if (vehicleSpawnHookInstalled && !allBossSpawnMappingsPrepared && flow == 3 &&
                GetTickCount() - lastBossSpawnTableRetryTick > 1000u)
            {
                lastBossSpawnTableRetryTick = GetTickCount();
                allBossSpawnMappingsPrepared = PrepareAllBossVehicleSpawnMappings();
            }


            int desiredBlacklistRank = GetActiveRivalRank();
            if ((desiredBlacklistRank < 1 || desiredBlacklistRank > 15) && rivalChallengePackage)
                desiredBlacklistRank = GetLastCareerRank();

            if (vehicleSpawnHookInstalled && flow == 3 && rivalChallengePackage &&
                desiredBlacklistRank >= 1 && desiredBlacklistRank <= 15)
            {
                if (!bossSpawnSessionArmed || desiredBlacklistRank != lastPreparedBlacklistRank ||
                    InterlockedCompareExchange(&g_bossSpawnReady, 0, 0) == 0)
                {
                    if (PrepareBossVehicleSpawnProxy(desiredBlacklistRank))
                    {
                        bossSpawnSessionArmed = true;
                        bossSpawnSessionSawGameplay = false;
                        lastPreparedBlacklistRank = desiredBlacklistRank;
                    }
                }
                else
                {
                    InterlockedExchange(&g_bossSpawnActive, 1);
                }
            }

            if (bossSpawnSessionArmed && flow == 6)
                bossSpawnSessionSawGameplay = true;


            if (bossSpawnSessionArmed && flow == 3 && havePackage && !rivalChallengePackage)
            {
                const std::string packageKey = UpperAlnum(controlledPackage);
                const bool transitionalPackage =
                    packageKey.find("LOADING") != std::string::npos ||
                    packageKey.find("BACKGROUND") != std::string::npos ||
                    packageKey.find("DIALOG") != std::string::npos ||
                    packageKey.find("TUTORIAL") != std::string::npos;
                if (!transitionalPackage &&
                    (bossSpawnSessionSawGameplay || GetActiveRivalRank() == 0))
                {
                    InterlockedExchange(&g_bossSpawnActive, 0);
                    InterlockedExchange(&g_bossSpawnReady, 0);
                    Log("AP BLACKLIST SPAWN PROXY 1.0.1: rival session ended; live Racer replacement disabled.");
                    bossSpawnSessionArmed = false;
                    bossSpawnSessionSawGameplay = false;
                    lastPreparedBlacklistRank = 0;
                }
            }


            if (InterlockedCompareExchange(&g_blacklistProxyActive, 0, 0) != 0)
                InterlockedExchange(&g_blacklistProxyActive, 0);

            if (vehicleSpawnHookInstalled && GetTickCount() - lastVehicleSpawnStatsTick > 1000u)
            {
                lastVehicleSpawnStatsTick = GetTickCount();
                const LONG calls = InterlockedCompareExchange(&g_vehicleSpawnProxyCallCount, 0, 0);
                const LONG humans = InterlockedCompareExchange(&g_vehicleSpawnHumanCount, 0, 0);
                const LONG racers = InterlockedCompareExchange(&g_vehicleSpawnRacerCount, 0, 0);
                const LONG unresolved = InterlockedCompareExchange(&g_vehicleSpawnUnresolvedCount, 0, 0);
                const LONG abiInline = InterlockedCompareExchange(&g_vehicleSpawnAbiInlineCount, 0, 0);
                const LONG abiIndirect = InterlockedCompareExchange(&g_vehicleSpawnAbiIndirectCount, 0, 0);
                const LONG abiScan = InterlockedCompareExchange(&g_vehicleSpawnAbiScanCount, 0, 0);
                const LONG starterMapped = InterlockedCompareExchange(&g_starterSpawnMappedCount, 0, 0);
                const LONG bossMapped = InterlockedCompareExchange(&g_bossSpawnMappedCount, 0, 0);
                if (calls != lastVehicleSpawnCalls || humans != lastVehicleSpawnHumans ||
                    racers != lastVehicleSpawnRacers || unresolved != lastVehicleSpawnUnresolved ||
                    abiInline != lastVehicleSpawnAbiInline || abiIndirect != lastVehicleSpawnAbiIndirect ||
                    abiScan != lastVehicleSpawnAbiScan || starterMapped != lastStarterSpawnMapped ||
                    bossMapped != lastBossSpawnMapped)
                {
                    std::ostringstream spawnStats;
                    spawnStats << "AP VEHICLE SPAWN STATS 1.0.1: total=" << calls
                               << " human=" << humans
                               << " racer=" << racers
                               << " unresolved=" << unresolved
                               << " abi_inline=" << abiInline
                               << " abi_indirect=" << abiIndirect
                               << " abi_scan=" << abiScan
                               << " starter_mapped=" << starterMapped
                               << " boss_mapped=" << bossMapped
                               << " boss_last_rank=#"
                               << InterlockedCompareExchange(&g_bossSpawnLastMappedRank, 0, 0)
                               << " boss_table="
                               << InterlockedCompareExchange(&g_bossSpawnTableCount, 0, 0) << "/15";
                    Log(spawnStats.str());

                    if (starterMapped != lastStarterSpawnMapped && starterMapped > lastStarterSpawnMapped)
                    {
                        Log("AP STARTER SPAWN MAP 1.0.1: replacement_count=" +
                            std::to_string(starterMapped) + " target='" + GetSeedStartingCar() + "'.");
                    }
                    if (bossMapped != lastBossSpawnMapped && bossMapped > lastBossSpawnMapped)
                    {
                        const int rank = static_cast<int>(InterlockedCompareExchange(&g_bossSpawnLastMappedRank, 0, 0));
                        Log("AP BLACKLIST SPAWN MAP 1.0.1: rank #" + std::to_string(rank) +
                            " replacement_count=" + std::to_string(bossMapped) +
                            " target='" + GetSeedBlacklistCar(rank) + "'.");
                    }

                    lastVehicleSpawnCalls = calls;
                    lastVehicleSpawnHumans = humans;
                    lastVehicleSpawnRacers = racers;
                    lastVehicleSpawnUnresolved = unresolved;
                    lastVehicleSpawnAbiInline = abiInline;
                    lastVehicleSpawnAbiIndirect = abiIndirect;
                    lastVehicleSpawnAbiScan = abiScan;
                    lastStarterSpawnMapped = starterMapped;
                    lastBossSpawnMapped = bossMapped;
                }
            }

            if (!unresolvedStackLogged &&
                InterlockedCompareExchange(&g_vehicleSpawnUnresolvedCaptured, 0, 0) != 0)
            {
                std::ostringstream raw;
                raw << "AP VEHICLE SPAWN ABI DIAGNOSTIC 1.0.1: stack_after_return=";
                for (int i = 0; i < 16; ++i)
                {
                    if (i) raw << ';';
                    raw << "d" << i << "=0x" << std::hex << std::uppercase
                        << g_vehicleSpawnUnresolvedStack[i];
                }
                raw << std::dec;
                if (InterlockedCompareExchange(&g_vehicleSpawnUnresolvedIndirectReadable, 0, 0) != 0)
                {
                    raw << " indirect_target=";
                    for (int i = 0; i < 16; ++i)
                    {
                        if (i) raw << ';';
                        raw << "d" << i << "=0x" << std::hex << std::uppercase
                            << g_vehicleSpawnUnresolvedIndirect[i];
                    }
                    raw << std::dec;
                }
                else
                {
                    raw << " indirect_target=<unreadable>";
                }
                Log(raw.str());
                unresolvedStackLogged = true;
            }

            if (carLotPackage && GetTickCount() - lastLookupStatsTick > 1000u)
            {
                lastLookupStatsTick = GetTickCount();
                const LONG calls = InterlockedCompareExchange(&g_lookupCallCount, 0, 0);
                const LONG mapped = InterlockedCompareExchange(&g_lookupMappedCount, 0, 0);
                if (calls != lastLookupCallCount || mapped != lastLookupMappedCount)
                {
                    std::ostringstream stats;
                    stats << "AP CAR_SELECT LOOKUP STATS: total_calls=" << calls
                          << " mapped_returns=" << mapped
                          << " delta_calls=" << (calls - lastLookupCallCount)
                          << " delta_mapped=" << (mapped - lastLookupMappedCount);
                    Log(stats.str());
                    lastLookupCallCount = calls;
                    lastLookupMappedCount = mapped;

                    const LONG rideCalls = InterlockedCompareExchange(&g_buildRideCallCount, 0, 0);
                    const LONG rideMapped = InterlockedCompareExchange(&g_buildRideMappedCount, 0, 0);
                    if (rideCalls != lastBuildRideCallCount || rideMapped != lastBuildRideMappedCount)
                    {
                        std::ostringstream rideStats;
                        rideStats << "AP CAR_SELECT BUILD-RIDE STATS: total_calls=" << rideCalls
                                  << " remapped_handles=" << rideMapped
                                  << " delta_calls=" << (rideCalls - lastBuildRideCallCount)
                                  << " delta_remapped=" << (rideMapped - lastBuildRideMappedCount);
                        Log(rideStats.str());
                        lastBuildRideCallCount = rideCalls;
                        lastBuildRideMappedCount = rideMapped;
                    }

                    const LONG customCalls = InterlockedCompareExchange(&g_customizationLookupCallCount, 0, 0);
                    const LONG customMapped = InterlockedCompareExchange(&g_customizationLookupMappedCount, 0, 0);
                    if (customCalls != lastCustomizationLookupCallCount || customMapped != lastCustomizationLookupMappedCount)
                    {
                        std::ostringstream customStats;
                        customStats << "AP CAR_SELECT CUSTOMIZATION STATS: total_calls=" << customCalls
                                    << " remapped_handles=" << customMapped
                                    << " delta_calls=" << (customCalls - lastCustomizationLookupCallCount)
                                    << " delta_remapped=" << (customMapped - lastCustomizationLookupMappedCount);
                        Log(customStats.str());
                        lastCustomizationLookupCallCount = customCalls;
                        lastCustomizationLookupMappedCount = customMapped;
                    }
                }
            }
            if (havePackage && controlledPackage != g_lastFrontendPackage)
            {
                g_lastFrontendPackage = controlledPackage;
                Log("AP FRONTEND PACKAGE: '" + controlledPackage + "'.");
            }
            else if (!havePackage && GetTickCount() - lastPackageLogTick > 5000u)
            {
                lastPackageLogTick = GetTickCount();
                Log("AP FRONTEND PACKAGE: <none/unreadable>.");
            }

            if (flow == 3 && IsSeedConfigReady() && GetShopEntryCount() >= 32 && !IsDealershipFirstStart())
            {
                std::string friendly;
                std::string raw;
                int typeId = -1;
                std::uintptr_t recordAddress = 0;

                if (carLotPackage)
                {
                    if (!g_callsiteProxiesEnabled)
                    {
                        const bool repatched = SetCarSelectCallsiteProxiesEnabled(true);
                        Log(std::string("AP CAR_SELECT CALLSITES 1.0.1: BuildRide-only showroom proxy enabled=") +
                            (repatched ? "yes" : "no") + ".");
                    }

                    if (purchaseDialogSession)
                    {
                        if (nativePurchaseGarageConverted && nativePurchaseEntryValid &&
                            !nativePurchaseEntry.checked && !nativePurchaseApSent)
                        {
                            nativePurchaseApSent = BeginTransactionalShopPurchase(
                                nativePurchaseEntry, nativePurchaseTargetCar);
                            Log(std::string("AP NATIVE PURCHASE FINALIZED 1.0.1: returned to Car_Select after carrier rollback; AP location request=") +
                                (nativePurchaseApSent ? "sent" : "failed") +
                                " target_car='" + nativePurchaseTargetCar + "'.");
                        }

                        Log(std::string("AP NATIVE PURCHASE TRANSITION 1.0.1: returned to Car_Select; commit_observed=") +
                            (nativePurchaseCommitObserved ? "yes" : "no") +
                            " carrier_resolved=" + (nativePurchaseGarageConverted ? "yes" : "no") + ".");
                        purchaseDialogSession = false;
                        purchaseDialogGraceUntil = 0;
                        nativePurchaseEntryValid = false;
                        nativePurchaseApSent = false;
                        nativePurchaseCommitObserved = false;
                        nativePurchaseGarageConverted = false;
                        nativePurchaseOwnedSnapshotValid = false;
                        nativePurchaseSourceIdentity = VehicleIdentitySnapshot{};
                        nativePurchaseTargetIdentity = VehicleIdentitySnapshot{};
                        nativePurchasePreviousHumanVehicleKey = 0u;
                        InterlockedExchange(&g_purchaseSpawnOverrideReady, 0);
                        nativePurchaseOwnedBefore = OwnedCarTableSnapshot{};
                        nativePurchaseLastGarageScanTick = 0;
                        nativePurchaseTargetCar.clear();
                    }
                    if (purchaseMaterialization.active)
                    {
                        const bool restored = RestorePurchaseSourceNative(&purchaseMaterialization);
                        Log(std::string("AP NATIVE PURCHASE MATERIALIZATION: source restored on Car_Select return=") +
                            (restored ? "yes" : "no") + ".");
                    }
                    InterlockedExchange(&g_carSelectLookupProxyActive, 1);
                    FECarRecordNative* observed = nullptr;
                    if (ReadSelectedCar(friendly, raw, typeId, recordAddress))
                    {
                        FECarRecordNative* candidate = reinterpret_cast<FECarRecordNative*>(recordAddress);
                        if (IsStockRecordNative(candidate))
                            observed = candidate;
                    }

                    if (!frontendProxyReady)
                    {
                        frontendProxyReady = BuildFrontendDealershipProxy(observed, frontendProxySlots);
                        if (frontendProxyReady)
                        {
                            PublishLookupProxyMap(frontendProxySlots);
                            QueueNotification("ARCHIPELAGO CAR LOT", "3D RANDOMIZER ACTIVE", GetSeedStartingCar(), 4500);
                            Log("AP FRONTEND CAR LOT 1.0.1: 32-entry source->target map published; FE record lookup stays vanilla, BuildRide handles are randomized.");
                        }
                    }

                    if (frontendProxyReady && observed)
                    {
                        FECarRecordNative* source = observed;
                        if (observed == lastProxyTarget && lastProxySource)
                            source = lastProxySource;

                        FrontendProxySlot* proxy = FindFrontendProxySlot(frontendProxySlots, source);
                        if (proxy && proxy->target)
                        {
                            if (source != lastProxySource || proxy->target != lastProxyTarget)
                            {
                                lastProxySource = source;
                                lastProxyTarget = proxy->target;
                                std::ostringstream line;
                                line << "AP FRONTEND CAR LOT SELECT 1.0.1: " << proxy->sourceName << " -> "
                                     << proxy->targetName << " source=0x" << std::hex << std::uppercase
                                     << reinterpret_cast<std::uintptr_t>(source) << " target=0x"
                                     << reinterpret_cast<std::uintptr_t>(proxy->target)
                                     << std::dec << " current_fe_record_mutation=no";
                                Log(line.str());
                            }


                            friendly = proxy->targetName;
                            raw = proxy->targetName;
                            recordAddress = reinterpret_cast<std::uintptr_t>(proxy->target);
                        }
                    }
                    if (!wasCarLotPackage)
                    {
                        Log("AP CAR_SELECT ACTIVE 1.0.1: BuildRide-only showroom proxy enabled; FE record lookup remains vanilla.");
                    }
                    wasCarLotPackage = true;
                    purchaseDialogSession = false;
                    purchaseDialogGraceUntil = 0;
                }
                else if (purchaseDialogPackage && wasCarLotPackage && !purchaseDialogSession)
                {


                    const unsigned int sourceHandle = static_cast<unsigned int>(
                        InterlockedCompareExchange(&g_lastMappedBuildRideSourceHandle, 0, 0));
                    const unsigned int targetHandle = static_cast<unsigned int>(
                        InterlockedCompareExchange(&g_lastMappedBuildRideTargetHandle, 0, 0));

                    FECarRecordNative* purchaseSource = nullptr;
                    FECarRecordNative* purchaseTarget = nullptr;
                    std::string targetCar;
                    for (FrontendProxySlot& slot : frontendProxySlots)
                    {
                        if (slot.source && slot.target &&
                            slot.source->handle == sourceHandle &&
                            slot.target->handle == targetHandle)
                        {
                            purchaseSource = slot.source;
                            purchaseTarget = slot.target;
                            targetCar = slot.targetName;
                            break;
                        }
                    }
                    if ((!purchaseSource || !purchaseTarget) && lastProxySource && lastProxyTarget)
                    {
                        purchaseSource = lastProxySource;
                        purchaseTarget = lastProxyTarget;
                        const FrontendProxySlot* fallbackSlot = FindFrontendProxySlot(frontendProxySlots, lastProxySource);
                        if (fallbackSlot)
                            targetCar = fallbackSlot->targetName;
                    }


                    if (purchaseMaterialization.active)
                        RestorePurchaseSourceNative(&purchaseMaterialization);

                    InterlockedExchange(&g_carSelectLookupProxyActive, 0);
                    const bool callsRestored = SetCarSelectCallsiteProxiesEnabled(false);
                    const bool selectedSource = purchaseSource && WriteCurrentFECarRecordNative(purchaseSource);

                    nativePurchaseEntry = ShopEntry{};
                    nativePurchaseEntryValid = !targetCar.empty() &&
                        GetShopEntryForCar("dealership", targetCar, nativePurchaseEntry);
                    nativePurchaseApSent = false;
                    nativePurchaseCommitObserved = false;
                    nativePurchaseGarageConverted = false;
                    nativePurchaseSourceIdentity = VehicleIdentitySnapshot{};
                    nativePurchaseTargetIdentity = VehicleIdentitySnapshot{};
                    nativePurchasePreviousHumanVehicleKey = 0u;
                    InterlockedExchange(&g_purchaseSpawnOverrideReady, 0);
                    nativePurchaseOwnedBefore = OwnedCarTableSnapshot{};
                    const bool sourceIdentityReady = CaptureVehicleIdentityNative(
                        purchaseSource, &nativePurchaseSourceIdentity);
                    const bool targetIdentityReady = CaptureVehicleIdentityNative(
                        purchaseTarget, &nativePurchaseTargetIdentity);


                    nativePurchasePreviousHumanVehicleKey = static_cast<std::uint32_t>(
                        InterlockedCompareExchange(&g_lastHumanEffectiveVehicleKey, 0, 0));
                    InterlockedExchange(&g_purchaseSpawnOverrideReady, 0);
                    if (sourceIdentityReady && nativePurchasePreviousHumanVehicleKey != 0u)
                    {
                        InterlockedExchange(&g_purchaseSpawnSourceVehicleKey,
                                            static_cast<LONG>(nativePurchaseSourceIdentity.vehicleKey));
                        InterlockedExchange(&g_purchaseSpawnTargetVehicleKey,
                                            static_cast<LONG>(nativePurchasePreviousHumanVehicleKey));
                        InterlockedExchange(&g_purchaseSpawnOverrideReady, 1);
                    }

                    nativePurchaseOwnedSnapshotValid = CaptureOwnedCarTableSnapshotNative(
                        &nativePurchaseOwnedBefore);
                    nativePurchaseLastGarageScanTick = 0;
                    nativePurchaseTargetCar = targetCar;
                    purchaseDialogSession = true;


                    purchaseDialogGraceUntil = GetTickCount() + 120000u;

                    std::ostringstream purchaseState;
                    purchaseState << "AP NATIVE PURCHASE DIALOG 1.0.1 STABLE-SOURCE: buildride_source_handle=0x"
                                  << std::hex << std::uppercase << sourceHandle
                                  << " buildride_target_handle=0x" << targetHandle
                                  << " source=0x" << reinterpret_cast<std::uintptr_t>(purchaseSource)
                                  << " target=0x" << reinterpret_cast<std::uintptr_t>(purchaseTarget)
                                  << std::dec
                                  << " selected_source=" << (selectedSource ? "yes" : "no")
                                  << " record_mutation=no"
                                  << " callsites_restored_to_vanilla=" << (callsRestored ? "yes" : "no")
                                  << " source_identity=" << (sourceIdentityReady ? "yes" : "no")
                                  << " target_identity=" << (targetIdentityReady ? "yes" : "no")
                                  << " owned_snapshot=" << (nativePurchaseOwnedSnapshotValid ? "yes" : "no")
                                  << " ap_entry=" << (nativePurchaseEntryValid ? "yes" : "no")
                                  << " carrier_car='" << targetCar << "'"
                                  << " ap_item='" << (nativePurchaseEntryValid ? nativePurchaseEntry.itemName : std::string()) << "'"
                                  << " ap_item_type='" << (nativePurchaseEntryValid ? nativePurchaseEntry.itemType : std::string()) << "'"
                                  << " recipient='" << (nativePurchaseEntryValid ? nativePurchaseEntry.recipientName : std::string()) << "'"
                                  << " recipient_local=" << (nativePurchaseEntryValid && nativePurchaseEntry.recipientIsLocal ? "yes" : "no")
                                  << " previous_human_vehicle_key=0x" << std::hex << std::uppercase << nativePurchasePreviousHumanVehicleKey << std::dec
                                  << " buildride_proxy=physically_unpatched_for_native_purchase; lookup_proxy=disabled_permanently.";
                    Log(purchaseState.str());
                }
                else if (purchaseDialogSession)
                {


                    InterlockedExchange(&g_carSelectLookupProxyActive, 0);
                    if (g_callsiteProxiesEnabled)
                        SetCarSelectCallsiteProxiesEnabled(false);

                    if (flow == 3 && havePackage && !purchaseDialogPackage)
                    {
                        if (nativePurchaseGarageConverted && nativePurchaseEntryValid &&
                            !nativePurchaseEntry.checked && !nativePurchaseApSent)
                        {
                            nativePurchaseApSent = BeginTransactionalShopPurchase(
                                nativePurchaseEntry, nativePurchaseTargetCar);
                            Log(std::string("AP NATIVE PURCHASE FINALIZED 1.0.1: concrete frontend returned after carrier rollback; AP location request=") +
                                (nativePurchaseApSent ? "sent" : "failed") +
                                " target_car='" + nativePurchaseTargetCar + "'.");
                        }

                        Log(std::string("AP NATIVE PURCHASE TRANSITION 1.0.1: concrete frontend returned; commit_observed=") +
                            (nativePurchaseCommitObserved ? "yes" : "no") +
                            " carrier_resolved=" + (nativePurchaseGarageConverted ? "yes" : "no") + ".");
                        purchaseDialogSession = false;
                        purchaseDialogGraceUntil = 0;
                        nativePurchaseEntryValid = false;
                        nativePurchaseApSent = false;
                        nativePurchaseCommitObserved = false;
                        nativePurchaseGarageConverted = false;
                        nativePurchaseOwnedSnapshotValid = false;
                        nativePurchaseSourceIdentity = VehicleIdentitySnapshot{};
                        nativePurchaseTargetIdentity = VehicleIdentitySnapshot{};
                        nativePurchasePreviousHumanVehicleKey = 0u;
                        InterlockedExchange(&g_purchaseSpawnOverrideReady, 0);
                        nativePurchaseOwnedBefore = OwnedCarTableSnapshot{};
                        nativePurchaseLastGarageScanTick = 0;
                        nativePurchaseTargetCar.clear();
                        wasCarLotPackage = false;
                        lastProxySource = nullptr;
                        lastProxyTarget = nullptr;
                    }
                }
                else
                {
                    InterlockedExchange(&g_carSelectLookupProxyActive, 0);


                    if (wasCarLotPackage)
                    {
                        Log("AP FRONTEND CAR LOT 1.0.1: dealership session ended; showroom mapping inactive.");
                        lastProxySource = nullptr;
                        lastProxyTarget = nullptr;
                    }
                    wasCarLotPackage = false;
                    purchaseDialogGraceUntil = 0;
                }


                if (ReadSelectedCar(friendly, raw, typeId, recordAddress))
                {


                    const bool perfMode = havePackage && !carLotPackage &&
                                          IsPartsStorePackage(controlledPackage);
                    const bool selectionContextChanged = friendly != lastFriendly || perfMode != lastPerfMode;
                    if (selectionContextChanged)
                    {
                        lastFriendly = friendly;
                        lastPerfMode = perfMode;
                        perfIndex = 0;
                    }

                    const bool nextCycleDown = ((GetAsyncKeyState(VK_F6) & 0x8000) != 0) ||
                                               ((GetAsyncKeyState(VK_RIGHT) & 0x8000) != 0) ||
                                               ((GetAsyncKeyState(VK_DOWN) & 0x8000) != 0);
                    const bool prevCycleDown = ((GetAsyncKeyState(VK_LEFT) & 0x8000) != 0) ||
                                               ((GetAsyncKeyState(VK_UP) & 0x8000) != 0);
                    const bool purchaseDown = (GetAsyncKeyState(g_purchaseHotkey) & 0x8000) != 0;

                    if (NativeShopRequested())
                    {


                        ClearStoreOverlay();
                    }
                    else if (perfMode)
                    {
                        auto entries = GetShopEntriesForCar("performance_shop", friendly);
                        if (!entries.empty())
                        {
                            bool apSelectionChanged = selectionContextChanged;
                            if (nextCycleDown && !cycleWasDown)
                            {
                                perfIndex = (perfIndex + 1) % entries.size();
                                apSelectionChanged = true;
                            }
                            if (prevCycleDown && !prevCycleWasDown)
                            {
                                perfIndex = perfIndex == 0 ? entries.size() - 1 : perfIndex - 1;
                                apSelectionChanged = true;
                            }
                            if (perfIndex >= entries.size())
                                perfIndex = 0;

                            const ShopEntry& entry = entries[perfIndex];
                            ShowShopOverlay(
                                entry,
                                "PARTS STORE",
                                static_cast<int>(perfIndex + 1u),
                                static_cast<int>(entries.size()),
                                "ARROWS/F6 BROWSE AP ITEMS / F7 BUY WITH CAREER CASH");
                            if (apSelectionChanged)
                            {


                                Log("AP PARTS STORE 1.0.1: slot=" + std::to_string(perfIndex + 1) +
                                    "/" + std::to_string(entries.size()) +
                                    " item='" + entry.itemName + "' recipient='" + entry.recipientName +
                                    "' native_icons=replaced_by_2d_ap_logo career_cash_purchase=yes.");
                            }

                            if (purchaseDown && !purchaseWasDown)
                            {
                                if (entry.checked)
                                    QueueNotification("ARCHIPELAGO PARTS STORE", "ALREADY PURCHASED", entry.itemName, 3000);
                                else if (BeginTransactionalShopPurchase(entry, friendly, true))
                                    QueueNotification("ARCHIPELAGO PARTS STORE", "PURCHASE REQUEST SENT", entry.itemName + " / " + MoneyText(entry.price), 3000);
                                else
                                    QueueNotification("ARCHIPELAGO PARTS STORE", "PURCHASE REQUEST FAILED", entry.itemName, 3000);
                            }
                        }
                        else
                        {
                            ClearStoreOverlay();
                        }
                    }
                    else if (carLotPackage)
                    {
                        ShopEntry entry;
                        if (GetShopEntryForCar("dealership", friendly, entry))
                        {
                            int dealershipSlot = entry.locationId % 100;
                            if (dealershipSlot <= 0 || dealershipSlot > 32)
                                dealershipSlot = 1;
                            ShowShopOverlay(
                                entry,
                                "CAR LOT",
                                dealershipSlot,
                                32,
                                "ENTER BUY WITH CAREER CASH");
                            static std::string lastShownCar;
                            if (lastShownCar != friendly)
                            {
                                lastShownCar = friendly;
                                const bool starter = UpperAlnum(friendly) == UpperAlnum(GetSeedStartingCar());
                                std::ostringstream log;
                                log << "AP CAR LOT SELECT: native='" << raw << "' friendly='" << friendly
                                    << "' type_id=" << typeId << " record=0x" << std::hex << std::uppercase << recordAddress
                                    << std::dec << " location=" << entry.locationId << " item='" << entry.itemName
                                    << "' recipient='" << entry.recipientName << "' price=" << entry.price
                                    << " checked=" << (entry.checked ? "yes" : "no") << (starter ? " STARTER" : "");
                                Log(log.str());

                                if (!entry.checked)
                                {
                                    const std::string title = starter ? "ARCHIPELAGO STARTER CAR" : "ARCHIPELAGO CAR LOT";
                                    const std::string line1 = entry.itemName.empty() ? entry.locationName : entry.itemName;
                                    std::string line2 = MoneyText(starter ? GetSeedStartingCarPrice() : entry.price);
                                    if (!entry.recipientName.empty()) line2 += " -> " + entry.recipientName;
                                    QueueNotification(title, line1, line2, 3500);
                                }
                            }

                            if (purchaseDown && !purchaseWasDown)
                            {
                                QueueNotification("ARCHIPELAGO CAR LOT",
                                                  "USE ENTER TO BUY",
                                                  "CAREER CASH REQUIRED",
                                                  3000);
                            }
                        }
                        else
                        {
                            ClearStoreOverlay();
                        }
                    }
                    else
                    {
                        ClearStoreOverlay();
                    }

                    cycleWasDown = nextCycleDown;
                    prevCycleWasDown = prevCycleDown;
                    purchaseWasDown = purchaseDown;
                }
            }
            else
            {
                ClearStoreOverlay();
                lastFriendly.clear();
                cycleWasDown = false;
                prevCycleWasDown = false;
                purchaseWasDown = false;
                lastPerfMode = false;
                perfIndex = 0;
            }

            if (flow != 3 && purchaseDialogSession)
            {


                InterlockedExchange(&g_carSelectLookupProxyActive, 0);
                if (g_callsiteProxiesEnabled)
                    SetCarSelectCallsiteProxiesEnabled(false);

                if (!nativePurchaseCommitObserved)
                {
                    nativePurchaseCommitObserved = true;
                    Log("AP NATIVE PURCHASE COMMIT 1.0.1: native flow left frontend; FE callsites are vanilla. Waiting for the native carrier record so it can be rolled back before sending the AP check.");
                }

                const DWORD now = GetTickCount();
                if (nativePurchaseCommitObserved && !nativePurchaseGarageConverted &&
                    nativePurchaseOwnedSnapshotValid && nativePurchaseSourceIdentity.valid &&
                    flow != 4 && flow != 5 &&
                    now - nativePurchaseLastGarageScanTick >= 250u)
                {
                    nativePurchaseLastGarageScanTick = now;
                    std::size_t changedOwnedCount = 0u;
                    FECarRecordNative* purchasedOwned = FindNewOwnedCarAfterPurchaseNative(
                        &nativePurchaseOwnedBefore, nativePurchaseSourceIdentity.vehicleKey,
                        &changedOwnedCount);

                    if (purchasedOwned)
                    {
                        int beforeType = -1;
                        char beforeRaw[128] = {};
                        std::string beforeFriendly = "<unreadable>";
                        if (ReadRecordNative(purchasedOwned, &beforeType, beforeRaw, sizeof(beforeRaw)))
                            beforeFriendly = FriendlyCarNameFromType(beforeRaw);

                        const std::uint32_t purchasedHandle = purchasedOwned->handle;
                        const std::uint32_t purchasedFilter = purchasedOwned->filterBits;
                        const std::uint8_t purchasedCareerHandle = purchasedOwned->careerHandle;


                        const bool rolledBack = RestorePurchasedOwnedRowFromSnapshotNative(
                            purchasedOwned, &nativePurchaseOwnedBefore);

                        std::ostringstream garageLog;
                        garageLog << "AP NATIVE PURCHASE CARRIER ROLLBACK 1.0.1: record=0x"
                                  << std::hex << std::uppercase
                                  << reinterpret_cast<std::uintptr_t>(purchasedOwned)
                                  << " allocated_handle=0x" << purchasedHandle
                                  << " filter=0x" << purchasedFilter
                                  << " career_handle=0x" << static_cast<unsigned int>(purchasedCareerHandle)
                                  << std::dec
                                  << " changed_owned_records=" << changedOwnedCount
                                  << " carrier='" << beforeFriendly << "'"
                                  << " ap_item='" << (nativePurchaseEntryValid ? nativePurchaseEntry.itemName : std::string()) << "'"
                                  << " recipient='" << (nativePurchaseEntryValid ? nativePurchaseEntry.recipientName : std::string()) << "'"
                                  << " rollback=" << (rolledBack ? "yes" : "no")
                                  << " local_car_grant=no";
                        Log(garageLog.str());

                        if (rolledBack)
                        {
                            nativePurchaseGarageConverted = true;
                            const std::string purchasedItem = nativePurchaseEntryValid && !nativePurchaseEntry.itemName.empty()
                                ? nativePurchaseEntry.itemName : std::string("ARCHIPELAGO ITEM");
                            const std::string recipient = nativePurchaseEntryValid && !nativePurchaseEntry.recipientName.empty()
                                ? std::string("TO: ") + nativePurchaseEntry.recipientName
                                : std::string("AP ROUTING");


                            if (nativePurchaseEntryValid && !nativePurchaseEntry.checked &&
                                !nativePurchaseApSent)
                            {
                                nativePurchaseApSent = BeginTransactionalShopPurchase(
                                    nativePurchaseEntry, nativePurchaseTargetCar);
                                Log(std::string("AP NATIVE PURCHASE FINALIZED 1.0.1: carrier rolled back; AP location request=") +
                                    (nativePurchaseApSent ? "sent" : "failed") +
                                    " carrier='" + nativePurchaseTargetCar +
                                    "' item='" + nativePurchaseEntry.itemName +
                                    "' recipient='" + nativePurchaseEntry.recipientName + "'.");
                            }
                            else if (nativePurchaseEntryValid && nativePurchaseEntry.checked)
                            {
                                Log("AP NATIVE PURCHASE FINALIZED 1.0.1: carrier rolled back; AP location was already checked, so no duplicate item was granted.");
                            }
                        }
                        else
                        {
                            QueueNotification("ARCHIPELAGO PURCHASE", "CARRIER ROLLBACK FAILED",
                                              "AP CHECK NOT SENT", 5000);
                            Log("AP NATIVE PURCHASE 1.0.1: carrier rollback failed; location deliberately left unchecked to avoid granting the wrong local car.");
                        }
                    }
                }

                if (now > purchaseDialogGraceUntil)
                {
                    purchaseDialogSession = false;
                    purchaseDialogGraceUntil = 0;
                    nativePurchaseEntryValid = false;
                    nativePurchaseApSent = false;
                    nativePurchaseCommitObserved = false;
                    nativePurchaseGarageConverted = false;
                    nativePurchaseOwnedSnapshotValid = false;
                    nativePurchaseSourceIdentity = VehicleIdentitySnapshot{};
                    nativePurchaseTargetIdentity = VehicleIdentitySnapshot{};
                    nativePurchasePreviousHumanVehicleKey = 0u;
                    InterlockedExchange(&g_purchaseSpawnOverrideReady, 0);
                    nativePurchaseOwnedBefore = OwnedCarTableSnapshot{};
                    nativePurchaseLastGarageScanTick = 0;
                    nativePurchaseTargetCar.clear();
                    wasCarLotPackage = false;
                    lastProxySource = nullptr;
                    lastProxyTarget = nullptr;
                    Log("AP NATIVE PURCHASE TRANSITION 1.0.1: 120s safety timeout; no in-flight dealership state retained.");
                }
            }


            Sleep(16);
        }
    }
}
