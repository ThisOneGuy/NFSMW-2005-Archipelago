#pragma once
#include <cstdint>
#include <string>
namespace NFSMWAP
{
    void ConfigureDeathLink(bool enabled,const std::string& session);
    void ReceiveDeathLink(const std::string& id,const std::string& source,const std::string& session);
    void AuthorizeDeathLink(const std::string& id,const std::string& runtime,const std::string& session,bool allowed);
    void ObserveDeathLinkArrest(std::uint32_t handle);
    void ObserveDeathLinkPursuitEntered();
    void ObserveDeathLinkPursuitEnded(std::uint32_t handle);
    void DeathLinkMainThreadTick();
}
