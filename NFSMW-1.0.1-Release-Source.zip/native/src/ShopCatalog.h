#pragma once

#include <cstddef>
#include <string>
#include <vector>

namespace NFSMWAP
{
    struct ShopEntry
    {
        int locationId = 0;
        std::string locationType;
        std::string locationName;
        std::string car;
        std::string category;
        std::string tier;
        int price = 0;
        int itemId = 0;
        std::string itemName;
        std::string itemType;
        std::string itemCar;
        std::string itemCategory;
        std::string itemTier;
        int recipientPlayer = 0;
        std::string recipientName;
        std::string recipientGame;
        bool recipientIsLocal = false;
        int flags = 0;
        bool checked = false;
    };

    void UpdateShopEntry(const ShopEntry& entry);
    bool GetShopEntry(int locationId, ShopEntry& entry);
    bool GetShopEntryForCar(const std::string& locationType, const std::string& car, ShopEntry& entry);
    std::vector<ShopEntry> GetShopEntriesForCar(const std::string& locationType, const std::string& car);
    void SetShopEntryChecked(int locationId, bool checked);
    std::size_t GetShopEntryCount();
    bool RequestShopPurchase(int locationId);
}
