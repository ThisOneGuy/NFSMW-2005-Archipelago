#pragma once
#include "MilestoneTargets.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <map>
#include <set>
#include <string>
#include <vector>

namespace NFSMWAP
{
    struct PhotoCamera { std::uint32_t key=0;double requiredMph=0;bool completed=false; };
    struct PhotoCompletion { int location=0,rank=0;PhotoCamera camera;double targetMph=0; };
    inline std::vector<PhotoCompletion> MatchPhotoCameras(int rank,const std::vector<PhotoCamera>& cameras)
    {
        std::map<double,std::vector<int>> targets;
        for (const auto& row:MilestoneTargets)
            if (row.rank==rank && std::string(row.category)=="Photo Ticket") targets[row.threshold].push_back(row.location);
        std::map<double,std::vector<PhotoCamera>> groups;
        std::set<std::uint32_t> seen;
        for (const auto& camera:cameras) {
            if (!camera.key || !std::isfinite(camera.requiredMph) || camera.requiredMph<=0 || !seen.insert(camera.key).second) return {};
            double best=0,difference=2.0;
            for (const auto& target:targets) if (std::abs(camera.requiredMph-target.first)<difference) {
                best=target.first;difference=std::abs(camera.requiredMph-target.first);
            }

            if (difference<=1.05) groups[best].push_back(camera);
        }
        std::vector<PhotoCompletion> result;
        for (auto& group:groups) {
            auto ids=targets[group.first];
            if (ids.size()!=group.second.size()) continue;
            std::sort(ids.begin(),ids.end());
            std::sort(group.second.begin(),group.second.end(),[](const PhotoCamera& a,const PhotoCamera& b){return a.key<b.key;});
            for (std::size_t n=0;n<ids.size();++n)
                if (group.second[n].completed) result.push_back({ids[n],rank,group.second[n],group.first});
        }
        return result;
    }
}
