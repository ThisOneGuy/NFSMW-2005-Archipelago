#pragma once
#include <cstdint>
namespace NFSMWAP {
inline int NextBlacklistRank(int rank,int direction) {
    if(rank<1||rank>15)rank=15;
    rank+=direction;
    return rank<1?15:rank>15?1:rank;
}
inline int RivalRankFromMembership(unsigned ranks,int view) {
    if(view>=1&&view<=15&&(ranks&(1u<<view)))return view;
    int result=0;
    for(int rank=1;rank<=15;++rank)if(ranks&(1u<<rank)){if(result)return 0;result=rank;}
    return result;
}
inline std::uint32_t CareerRaceUnlockFlags(std::uint32_t flags,bool world,bool boss,bool permitted) {
    if(boss)return permitted?flags|8u:flags&~8u;
    return world?flags|8u:flags;
}
inline bool RivalChallengeRequirementsMet(int wins,int requiredWins,int challenges,int requiredChallenges,unsigned bounty,int requiredBounty) {
    return wins>=0&&challenges>=0&&requiredWins>=0&&requiredChallenges>=0&&requiredBounty>=0&&
        wins>=requiredWins&&challenges>=requiredChallenges&&bounty>=static_cast<unsigned>(requiredBounty);
}
bool InstallRandomizedCareerHooks();
bool IsRandomizedCareerActive();
bool RandomizedRivalLockVisible();
void RandomizedCareerMainThreadTick();
}
