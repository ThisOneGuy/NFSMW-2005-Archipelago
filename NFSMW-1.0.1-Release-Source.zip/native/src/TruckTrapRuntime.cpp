#include "TruckTrapRuntime.h"
#include <Windows.h>
#include <algorithm>
#include <cmath>
#include <cstring>

namespace {
using TruckWord=std::uint32_t;
struct TruckVector {float x,y,z;};
struct TruckRotation {float m[16];};
struct TruckParam {TruckWord type,name,data,padding;};
struct TruckVehicleParams {
    TruckParam param;
    TruckWord driverClass,vehicleKey,direction,position,customization,cache,performance,flags;
};
static_assert(sizeof(TruckParam)==0x10 && sizeof(TruckVehicleParams)==0x30,"Retail spawn ABI");

TruckVehicleParams truckParams{};
TruckVector truckInitialPosition{},truckInitialForward{0,0,1};
TruckWord truckHandle=0,truckSimable=0,truckVehicle=0,truckProfile=0,truckStatus=0,truckKey=0;
int truckRace=-1;
bool truckReady=false,truckLaunched=false;
const char* truckPrepareStatus="not requested";
std::uint64_t truckAge=0,truckLoadAge=0;

bool VerifyTruckNative() {
    __try {
        const unsigned char road[]={0x81,0xEC,0x88,0x00,0x00,0x00,0x53};
        const unsigned char dimensions[]={0x8B,0x44,0x24,0x04,0x81,0xC1,0x98,0x00,0x00,0x00};
        const unsigned char factory[]={0xA1,0x6C,0xC6,0x92,0,0x85,0xC0,0x74,0x12};
        const unsigned char find[]={0x8B,0x44,0x24,0x04,0x85,0xC0,0x74,0x21,0x8B,0x0D,0xBC,0xFE,0x92,0};
        const unsigned char ground[]={0x6A,0xFF,0x64,0xA1,0,0,0,0,0x68,0x58,0xB7,0x87,0};
        const unsigned char handle[]={0x8B,0x41,0x34,0xC3};
        const unsigned char mode[]={0x8B,0x44,0x24,0x04,0x56,0x8B,0xF1,0x39,0x86,0x98,0,0,0};
        const unsigned char key[]={0x8B,0x4C,0x24,0x04,0x85,0xC9,0x74,0x23};
        const unsigned char kill[]={0x51,0x56,0x8B,0xF1,0x57,0x8D,0x46,0xD4};
        const unsigned char position[]={0x8B,0x41,0x30,0x8B,0,0x83,0xC0,0x10,0xC3};
        const unsigned char setPosition[]={0x8B,0x41,0x30,0x8B,0x08,0x8B,0x54,0x24,0x04,0x8B,0x02,0x83,0xC1,0x10};
        const unsigned char setOrientation[]={0x53,0x55,0x56,0x8B,0x74,0x24,0x10,0x8B,0xE9,0x8B,0x45,0x30};
        const unsigned char spawnFields[]={0x8B,0x40,0x08,0x8B,0x50,0x18,0x8B,0x48,0x14,0x8B,0x78,0x10};
        const unsigned char pvehicleClass[]={0x68,0x8F,0xEC,0x97,0x4A};
        const auto vehicle=reinterpret_cast<const TruckWord*>(0x8AA828u);
        const auto sim=reinterpret_cast<const TruckWord*>(0x8AA940u);
        return std::memcmp(reinterpret_cast<void*>(0x789870u),road,sizeof(road))==0&&
            std::memcmp(reinterpret_cast<void*>(0x670E50u),dimensions,sizeof(dimensions))==0&&
            std::memcmp(reinterpret_cast<void*>(0x696FB0u),setPosition,sizeof(setPosition))==0&&
            std::memcmp(reinterpret_cast<void*>(0x696D90u),setOrientation,sizeof(setOrientation))==0&&
            std::memcmp(reinterpret_cast<void*>(0x689877u),spawnFields,sizeof(spawnFields))==0&&
            std::memcmp(reinterpret_cast<void*>(0x4E4EC8u),pvehicleClass,sizeof(pvehicleClass))==0&&
            std::memcmp(reinterpret_cast<void*>(0x41CB10u),factory,sizeof(factory))==0&&
            std::memcmp(reinterpret_cast<void*>(0x41AD40u),find,sizeof(find))==0&&
            std::memcmp(reinterpret_cast<void*>(0x685810u),ground,sizeof(ground))==0&&
            std::memcmp(reinterpret_cast<void*>(0x686AA0u),handle,sizeof(handle))==0&&
            std::memcmp(reinterpret_cast<void*>(0x687690u),mode,sizeof(mode))==0&&
            std::memcmp(reinterpret_cast<void*>(0x454640u),key,sizeof(key))==0&&
            std::memcmp(reinterpret_cast<void*>(0x6851D0u),kill,sizeof(kill))==0&&
            std::memcmp(reinterpret_cast<void*>(0x671180u),position,sizeof(position))==0&&
            vehicle[12]==0x6880C0u&&vehicle[14]==0x688210u&&vehicle[20]==0x6880A0u&&
            vehicle[22]==0x6880B0u&&vehicle[23]==0x6691D0u&&vehicle[26]==0x685810u&&
            vehicle[32]==0x6693A0u&&vehicle[33]==0x6693C0u&&sim[2]==0x6851D0u&&sim[13]==0x686AA0u&&
            reinterpret_cast<const TruckWord*>(0x8AC880u)[8]==0x671180u&&
            reinterpret_cast<const TruckWord*>(0x8ACAF0u)[8]==0x671180u&&
            reinterpret_cast<const TruckWord*>(0x8ACAF0u)[9]==0x671190u&&
            reinterpret_cast<const TruckWord*>(0x8ACAF0u)[13]==0x671270u&&
            reinterpret_cast<const TruckWord*>(0x8ACAF0u)[24]==0x696FD0u;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
void ForgetTruck() {
    truckHandle=truckSimable=truckVehicle=truckProfile=truckStatus=0;
    truckLaunched=false;truckAge=truckLoadAge=0;
}
TruckWord* FindTruck() {


    if(!truckHandle)return nullptr;
    auto* sim=reinterpret_cast<TruckWord*(__cdecl*)(TruckWord)>(0x41AD40u)(truckHandle);
    if(reinterpret_cast<std::uintptr_t>(sim)!=truckSimable)return nullptr;
    if(*sim!=0x8AA940u)return nullptr;
    TruckWord* vehicle=nullptr;
    if(!reinterpret_cast<bool(__thiscall*)(TruckWord*,TruckWord**)>(0x40E040u)(sim,&vehicle)||
       reinterpret_cast<std::uintptr_t>(vehicle)!=truckVehicle||*vehicle!=0x8AA828u)return nullptr;
    if(reinterpret_cast<TruckWord(__thiscall*)(TruckWord*)>(0x6880A0u)(vehicle)!=truckKey||
       reinterpret_cast<int(__thiscall*)(TruckWord*)>(0x6880B0u)(vehicle)!=4)return nullptr;
    return sim;
}
void RemoveTruck() {
    __try {
        if(auto* sim=FindTruck()) {

            reinterpret_cast<void(__thiscall*)(TruckWord*)>(0x6851D0u)(sim);
        }
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
    ForgetTruck();
}
bool TruckScope() {
    const auto db=*reinterpret_cast<TruckWord*>(0x91CF90u);
    if(*reinterpret_cast<int*>(0x925E90u)!=6||!db||*reinterpret_cast<TruckWord*>(db+0x10u)!=truckProfile||
        *reinterpret_cast<TruckWord*>(0x91E000u)!=truckStatus||!truckStatus)return false;
    return reinterpret_cast<int(__thiscall*)(void*)>(0x404A70u)(reinterpret_cast<void*>(truckStatus))==truckRace;
}
TruckWord* TruckBody(TruckWord simable) {
    auto* sim=reinterpret_cast<TruckWord*>(simable);
    if(!sim||*sim!=0x8AA940u)return nullptr;
    return reinterpret_cast<TruckWord*(__thiscall*)(TruckWord*)>(0x686AB0u)(sim);
}
bool TruckPose(TruckWord player,TruckVector& position,TruckVector& direction,float& speed,TruckVector* motion=nullptr) {
    auto* body=TruckBody(player);if(!body||(*body!=0x8AC880u&&*body!=0x8ACAF0u))return false;
    const auto p=reinterpret_cast<const TruckVector*(__thiscall*)(TruckWord*)>(0x671180u)(body);
    const auto v=reinterpret_cast<const TruckVector*(__thiscall*)(TruckWord*)>(0x671190u)(body);
    reinterpret_cast<void(__thiscall*)(TruckWord*,TruckVector&)>(0x671270u)(body,direction);
    if(!p||!v)return false;
    position=*p;
    const float length=std::sqrt(direction.x*direction.x+direction.z*direction.z);
    speed=std::sqrt(v->x*v->x+v->z*v->z);
    if(!std::isfinite(position.x)||!std::isfinite(position.y)||!std::isfinite(position.z)||
       !std::isfinite(length)||length<0.01f||!std::isfinite(speed)||speed>250.0f)return false;
    if(motion)*motion={v->x,0,v->z};
    direction={direction.x/length,0,direction.z/length};return true;
}
}

namespace NFSMWAP {
bool InitializeTruckTrapNative() {truckReady=VerifyTruckNative();return truckReady;}
bool TruckTrapVehiclePending() {return truckHandle!=0;}
void CancelPreparedTruckTrap() {if(!truckLaunched)RemoveTruck();}
void ClearTruckTrapVehicle() {RemoveTruck();}
void TruckTrapWorldTick(bool driving,std::uint64_t elapsedMs) {
    if(!truckHandle)return;
    __try {
        if(!TruckScope()||!FindTruck()){RemoveTruck();return;}
        if(driving) {
            if(truckLaunched)truckAge+=std::min<std::uint64_t>(elapsedMs,1000);
            else truckLoadAge+=std::min<std::uint64_t>(elapsedMs,1000);
        }
        if(truckAge>=10000||truckLoadAge>=15000)RemoveTruck();
    } __except(EXCEPTION_EXECUTE_HANDLER) {RemoveTruck();}
}
const char* TruckTrapPreparationStatus(){return truckPrepareStatus;}
bool PrepareTruckTrapVehicle(TruckWord player,TruckWord profile) {
    if(!truckReady||truckLaunched){truckPrepareStatus=!truckReady?"native signatures unavailable":"previous truck still active";return false;}
    __try {
        if(truckHandle) {
            truckPrepareStatus="prepared vehicle handle/world validation";
            if(!TruckScope()||truckProfile!=profile||!FindTruck()){RemoveTruck();return false;}
            auto* vehicle=reinterpret_cast<TruckWord*>(truckVehicle);
            const bool loading=reinterpret_cast<bool(__thiscall*)(TruckWord*)>(0x6691D0u)(vehicle);
            truckPrepareStatus=loading?"waiting for semi model/physics streaming":"ready";
            return !loading;
        }
        truckPrepareStatus="local vehicle pose unavailable";
        float speed=0;if(!TruckPose(player,truckInitialPosition,truckInitialForward,speed))return false;


        truckPrepareStatus="semi pvehicle collection lookup";
        truckKey=reinterpret_cast<TruckWord(__cdecl*)(const char*)>(0x454640u)("semi");
        if(!reinterpret_cast<void*(__cdecl*)(TruckWord,TruckWord)>(0x455FD0u)
            (0x4A97EC8Fu,truckKey))return false;
        truckParams={};truckParams.param.name=0xA6B47FACu;
        truckParams.param.data=static_cast<TruckWord>(reinterpret_cast<std::uintptr_t>(&truckParams));
        reinterpret_cast<void(__cdecl*)(TruckVehicleParams*)>(0x4040F0u)(&truckParams);
        truckParams.driverClass=4u;
        truckParams.vehicleKey=truckKey;
        truckParams.direction=static_cast<TruckWord>(reinterpret_cast<std::uintptr_t>(&truckInitialForward));
        truckParams.position=static_cast<TruckWord>(reinterpret_cast<std::uintptr_t>(&truckInitialPosition));
        truckParams.flags=1u;
        const auto factoryKey=reinterpret_cast<TruckWord(__cdecl*)(const char*)>(0x5CC240u)("PVehicle");
        truckPrepareStatus="native PVehicle factory construction";
        auto* sim=reinterpret_cast<TruckWord*(__cdecl*)(TruckWord,TruckParam)>(0x41CB10u)(factoryKey,truckParams.param);
        if(!sim)return false;
        truckPrepareStatus="created semi handle/interface validation";
        truckSimable=static_cast<TruckWord>(reinterpret_cast<std::uintptr_t>(sim));
        truckHandle=reinterpret_cast<TruckWord(__thiscall*)(TruckWord*)>(0x686AA0u)(sim);
        TruckWord* vehicle=nullptr;
        if(!reinterpret_cast<bool(__thiscall*)(TruckWord*,TruckWord**)>(0x40E040u)(sim,&vehicle)) {
            reinterpret_cast<void(__thiscall*)(TruckWord*)>(0x6851D0u)(sim);ForgetTruck();return false;
        }
        truckVehicle=static_cast<TruckWord>(reinterpret_cast<std::uintptr_t>(vehicle));
        truckProfile=profile;truckStatus=*reinterpret_cast<TruckWord*>(0x91E000u);
        truckRace=truckStatus?reinterpret_cast<int(__thiscall*)(void*)>(0x404A70u)(reinterpret_cast<void*>(truckStatus)):-1;
        truckPrepareStatus="semi vehicle key/driver validation";
        if(!truckHandle||!vehicle||*vehicle!=0x8AA828u||
           reinterpret_cast<TruckWord(__thiscall*)(TruckWord*)>(0x6880A0u)(vehicle)!=truckKey||
           reinterpret_cast<int(__thiscall*)(TruckWord*)>(0x6880B0u)(vehicle)!=4) {RemoveTruck();return false;}
        reinterpret_cast<void(__thiscall*)(TruckWord*)>(0x6693C0u)(vehicle);
        const bool loading=reinterpret_cast<bool(__thiscall*)(TruckWord*)>(0x6691D0u)(vehicle);
        truckPrepareStatus=loading?"waiting for semi model/physics streaming":"ready";
        return !loading;
    } __except(EXCEPTION_EXECUTE_HANDLER) {truckPrepareStatus="native preparation exception";RemoveTruck();return false;}
}
bool SpawnTruckTrapVehicle(TruckWord player,TruckWord profile) {
    if(!truckReady||truckLaunched||truckProfile!=profile)return false;
    __try {
        truckPrepareStatus="cue vehicle/world validation";
        if(!TruckScope()||!FindTruck())return false;
        auto* vehicle=reinterpret_cast<TruckWord*>(truckVehicle);
        truckPrepareStatus="cue model resources still loading";
        if(reinterpret_cast<bool(__thiscall*)(TruckWord*)>(0x6691D0u)(vehicle))return false;
        TruckVector position{},forward{},motion{};float speed=0;
        truckPrepareStatus="cue player pose unavailable";
        if(!TruckPose(player,position,forward,speed,&motion))return false;


        truckPrepareStatus="cue activate simulated collision physics";
        reinterpret_cast<void(__thiscall*)(TruckWord*)>(0x6693A0u)(vehicle);
        reinterpret_cast<void(__thiscall*)(TruckWord*,int)>(0x687690u)(vehicle,1);
        auto* body=TruckBody(truckSimable);
        if(!body||(*body!=0x8AC880u&&*body!=0x8ACAF0u)){RemoveTruck();return false;}
        const auto table=reinterpret_cast<const TruckWord*>(*body);
        if(table[18]!=0x670E50u||table[23]!=0x696FB0u||table[28]!=0x696D90u){RemoveTruck();return false;}
        TruckVector half{};
        reinterpret_cast<void(__thiscall*)(TruckWord*,TruckVector&)>(0x670E50u)(body,half);
        if(!std::isfinite(half.y)||half.y<0.2f||half.y>5.0f){RemoveTruck();return false;}
        const TruckVector side{forward.z,0,-forward.x};
        TruckWord collision[2]={0,3};
        float playerRoad=0;TruckVector roadNormal{};
        auto road=reinterpret_cast<bool(__thiscall*)(TruckWord*,const TruckVector&,float&,TruckVector*)>(0x789870u);
        if(!road(collision,position,playerRoad,&roadNormal)||!std::isfinite(playerRoad)||
           std::abs(position.y-playerRoad)>6.0f){RemoveTruck();return false;}
        TruckVector velocity{},direction{};bool placed=false;
        truckPrepareStatus="no road surface beside player";
        for(const float lateral:{6.0f,-6.0f,4.0f,-4.0f,8.0f,-8.0f}) {
            const float sign=lateral>0?1.0f:-1.0f;
            TruckVector candidate{position.x+side.x*lateral,position.y,position.z+side.z*lateral};
            float height=0;TruckVector up{};
            if(!road(collision,candidate,height,&up)||!std::isfinite(height)||
               std::abs(height-playerRoad)>2.0f||!std::isfinite(up.y)||up.y<0.65f)continue;


            velocity={motion.x-side.x*sign*35.0f,0,motion.z-side.z*sign*35.0f};
            const float magnitude=std::sqrt(velocity.x*velocity.x+velocity.z*velocity.z);
            if(!std::isfinite(magnitude)||magnitude<1.0f)continue;
            direction={velocity.x/magnitude,0,velocity.z/magnitude};


            direction.y=-(up.x*direction.x+up.z*direction.z)/up.y;
            const float fl=std::sqrt(direction.x*direction.x+direction.y*direction.y+direction.z*direction.z);
            direction={direction.x/fl,direction.y/fl,direction.z/fl};
            const float ul=std::sqrt(up.x*up.x+up.y*up.y+up.z*up.z);
            if(!std::isfinite(ul)||ul<0.5f)continue;
            up={up.x/ul,up.y/ul,up.z/ul};
            const TruckVector right{up.y*direction.z-up.z*direction.y,up.z*direction.x-up.x*direction.z,up.x*direction.y-up.y*direction.x};
            const TruckRotation rotation{{right.x,right.y,right.z,0,up.x,up.y,up.z,0,direction.x,direction.y,direction.z,0,0,0,0,1}};


            const float rideHeight=half.y*0.5f;
            candidate.y=height+rideHeight*up.y+0.02f;
            candidate.x+=rideHeight*up.x;candidate.z+=rideHeight*up.z;
            reinterpret_cast<void(__thiscall*)(TruckWord*,const TruckRotation&)>(0x696D90u)(body,rotation);
            reinterpret_cast<void(__thiscall*)(TruckWord*,const TruckVector&)>(0x696FB0u)(body,candidate);
            const auto actual=reinterpret_cast<const TruckVector*(__thiscall*)(TruckWord*)>(0x671180u)(body);
            if(!actual||!std::isfinite(actual->x)||!std::isfinite(actual->y)||!std::isfinite(actual->z)||
               std::abs(actual->x-candidate.x)>0.25f||std::abs(actual->y-candidate.y)>0.25f||std::abs(actual->z-candidate.z)>0.25f)continue;
            reinterpret_cast<void(__thiscall*)(TruckWord*,float)>(0x670210u)(vehicle,magnitude);
            velocity={direction.x*magnitude,direction.y*magnitude,direction.z*magnitude};
            reinterpret_cast<void(__thiscall*)(TruckWord*,const TruckVector&)>(0x696FD0u)(body,velocity);
            placed=true;break;
        }
        if(!placed){RemoveTruck();return false;}
        truckPrepareStatus="side-impact truck launched";
        truckLaunched=true;truckAge=0;return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {RemoveTruck();return false;}
}
}
