#include "SaveIsolation.h"

#include <Windows.h>

#include <cstdint>
#include <atomic>
#include <cstring>
#include <string>
#include <algorithm>
#include <cctype>

#include "Logger.h"

namespace
{
    constexpr int CsidPersonal = 0x0005;

    using FnSHGetFolderPathA =
        HRESULT (WINAPI*)(
            HWND,
            int,
            HANDLE,
            DWORD,
            LPSTR);

    using FnSHGetFolderPathW =
        HRESULT (WINAPI*)(
            HWND,
            int,
            HANDLE,
            DWORD,
            LPWSTR);

    using FnSHGetSpecialFolderPathA =
        BOOL (WINAPI*)(
            HWND,
            LPSTR,
            int,
            BOOL);

    using FnSHGetSpecialFolderPathW =
        BOOL (WINAPI*)(
            HWND,
            LPWSTR,
            int,
            BOOL);

    using FnCreateFileA = HANDLE (WINAPI*)(LPCSTR, DWORD, DWORD,
        LPSECURITY_ATTRIBUTES, DWORD, DWORD, HANDLE);
    FnCreateFileA g_originalCreateFileA = nullptr;
    std::string g_slotFileName;
    std::atomic_uint g_slotOpenCount{0};
    std::atomic_uint g_slotRedirectCount{0};
    SRWLOCK g_profileTraceLock = SRWLOCK_INIT;
    char g_lastSlotOpen[MAX_PATH] = {};
    char g_lastSlotRedirect[MAX_PATH] = {};

    FnSHGetFolderPathA g_originalFolderPathA = nullptr;
    FnSHGetFolderPathW g_originalFolderPathW = nullptr;
    FnSHGetSpecialFolderPathA g_originalSpecialPathA = nullptr;
    FnSHGetSpecialFolderPathW g_originalSpecialPathW = nullptr;

    std::wstring g_documentsRootW;
    std::string g_documentsRootA;
    bool g_active = false;
    bool g_primedEarly = false;
    int g_hookCount = 0;
    std::atomic_uint g_redirectCount{0};

    bool IsPersonalFolder(int csidl)
    {

        return (csidl & 0x00FF) == CsidPersonal;
    }

    bool EnsureDirectoryTree(const std::wstring& path)
    {
        if (path.empty())
            return false;

        std::wstring partial;
        partial.reserve(path.size());

        for (std::size_t i = 0; i < path.size(); ++i)
        {
            const wchar_t c = path[i];
            partial.push_back(c);

            const bool atSeparator =
                c == L'\\' || c == L'/';

            const bool atEnd =
                i + 1 == path.size();

            if (!atSeparator && !atEnd)
                continue;


            if (partial.size() <= 3)
                continue;

            while (!partial.empty() &&
                   (partial.back() == L'\\' ||
                    partial.back() == L'/'))
            {
                partial.pop_back();
            }

            if (partial.empty())
                continue;

            if (!CreateDirectoryW(
                    partial.c_str(),
                    nullptr))
            {
                const DWORD error =
                    GetLastError();

                if (error != ERROR_ALREADY_EXISTS)
                    return false;
            }

            if (!atEnd)
                partial.push_back(L'\\');
        }

        if (!CreateDirectoryW(
                path.c_str(),
                nullptr))
        {
            const DWORD error =
                GetLastError();

            if (error != ERROR_ALREADY_EXISTS)
                return false;
        }

        return true;
    }

    std::string WideToAnsi(
        const std::wstring& value)
    {
        if (value.empty())
            return {};

        const int required =
            WideCharToMultiByte(
                CP_ACP,
                0,
                value.c_str(),
                -1,
                nullptr,
                0,
                nullptr,
                nullptr);

        if (required <= 1)
            return {};

        std::string result(
            static_cast<std::size_t>(
                required),
            '\0');

        const int written =
            WideCharToMultiByte(
                CP_ACP,
                0,
                value.c_str(),
                -1,
                result.data(),
                required,
                nullptr,
                nullptr);

        if (written <= 1)
            return {};

        if (!result.empty() &&
            result.back() == '\0')
        {
            result.pop_back();
        }

        return result;
    }

    HRESULT WINAPI HookSHGetFolderPathA(
        HWND hwnd,
        int csidl,
        HANDLE token,
        DWORD flags,
        LPSTR outPath)
    {
        if (g_active &&
            outPath &&
            IsPersonalFolder(csidl))
        {
            ++g_redirectCount;
            lstrcpynA(
                outPath,
                g_documentsRootA.c_str(),
                MAX_PATH);

            return S_OK;
        }

        if (!g_originalFolderPathA)
            return E_FAIL;

        return g_originalFolderPathA(
            hwnd,
            csidl,
            token,
            flags,
            outPath);
    }

    HRESULT WINAPI HookSHGetFolderPathW(
        HWND hwnd,
        int csidl,
        HANDLE token,
        DWORD flags,
        LPWSTR outPath)
    {
        if (g_active &&
            outPath &&
            IsPersonalFolder(csidl))
        {
            ++g_redirectCount;
            lstrcpynW(
                outPath,
                g_documentsRootW.c_str(),
                MAX_PATH);

            return S_OK;
        }

        if (!g_originalFolderPathW)
            return E_FAIL;

        return g_originalFolderPathW(
            hwnd,
            csidl,
            token,
            flags,
            outPath);
    }

    BOOL WINAPI HookSHGetSpecialFolderPathA(
        HWND hwnd,
        LPSTR outPath,
        int csidl,
        BOOL create)
    {
        if (g_active &&
            outPath &&
            IsPersonalFolder(csidl))
        {
            ++g_redirectCount;
            lstrcpynA(
                outPath,
                g_documentsRootA.c_str(),
                MAX_PATH);

            return TRUE;
        }

        if (!g_originalSpecialPathA)
            return FALSE;

        return g_originalSpecialPathA(
            hwnd,
            outPath,
            csidl,
            create);
    }

    BOOL WINAPI HookSHGetSpecialFolderPathW(
        HWND hwnd,
        LPWSTR outPath,
        int csidl,
        BOOL create)
    {
        if (g_active &&
            outPath &&
            IsPersonalFolder(csidl))
        {
            ++g_redirectCount;
            lstrcpynW(
                outPath,
                g_documentsRootW.c_str(),
                MAX_PATH);

            return TRUE;
        }

        if (!g_originalSpecialPathW)
            return FALSE;

        return g_originalSpecialPathW(
            hwnd,
            outPath,
            csidl,
            create);
    }


    HANDLE WINAPI HookCreateFileA(LPCSTR name, DWORD access, DWORD sharing,
        LPSECURITY_ATTRIBUTES attributes, DWORD disposition, DWORD flags,
        HANDLE templateFile) {
        if (!g_originalCreateFileA) {
            SetLastError(ERROR_INVALID_FUNCTION);
            return INVALID_HANDLE_VALUE;
        }
        if (!g_active || !name || g_slotFileName.empty())
            return g_originalCreateFileA(name,access,sharing,attributes,disposition,flags,templateFile);

        std::string path(name);
        if (path.size() >= MAX_PATH)
            return g_originalCreateFileA(name,access,sharing,attributes,disposition,flags,templateFile);
        std::replace(path.begin(),path.end(),'/', '\\');
        std::string lower(path);
        std::transform(lower.begin(), lower.end(), lower.begin(),
            [](unsigned char c){return static_cast<char>(std::tolower(c));});
        std::string slotLower(g_slotFileName);
        std::transform(slotLower.begin(),slotLower.end(),slotLower.begin(),
            [](unsigned char c){return static_cast<char>(std::tolower(c));});
        const std::string component="\\nfs most wanted\\";
        const auto directory=lower.rfind(component);


        const bool relativeSlot=(lower==slotLower || lower==".\\"+slotLower);
        if (directory==std::string::npos && !relativeSlot)
            return g_originalCreateFileA(name,access,sharing,attributes,disposition,flags,templateFile);
        const auto suffix=relativeSlot ? g_slotFileName : path.substr(directory+component.size());
        if(!relativeSlot && (suffix.size()<g_slotFileName.size() ||
           lower.compare(directory+component.size(),slotLower.size(),slotLower)!=0))
            return g_originalCreateFileA(name,access,sharing,attributes,disposition,flags,templateFile);
        if(suffix.size()>slotLower.size()) {
            const char next=suffix[slotLower.size()];
            if(next!='.' && next!='\\' && next!='~')
                return g_originalCreateFileA(name,access,sharing,attributes,disposition,flags,templateFile);
        }
        ++g_slotOpenCount;
        std::string destination=g_documentsRootA+"\\NFS Most Wanted\\"+suffix;


        if(!relativeSlot&&lower.substr(directory+component.size())==slotLower+"\\"+slotLower) {
            const auto flat=g_documentsRootA+"\\NFS Most Wanted\\"+g_slotFileName;
            const DWORD flatFileAttributes=GetFileAttributesA(flat.c_str());
            if(flatFileAttributes!=INVALID_FILE_ATTRIBUTES&&!(flatFileAttributes&FILE_ATTRIBUTE_DIRECTORY))destination=flat;
        }
        if(destination.size()>=MAX_PATH) {
            SetLastError(ERROR_FILENAME_EXCED_RANGE);
            return INVALID_HANDLE_VALUE;
        }
        AcquireSRWLockExclusive(&g_profileTraceLock);
        lstrcpynA(g_lastSlotOpen,path.c_str(),MAX_PATH);
        lstrcpynA(g_lastSlotRedirect,destination.c_str(),MAX_PATH);
        ReleaseSRWLockExclusive(&g_profileTraceLock);
        ++g_slotRedirectCount;
        return g_originalCreateFileA(destination.c_str(),access,sharing,attributes,disposition,flags,templateFile);
    }

    bool PatchIatByName(
        const char* importName,
        void* replacement,
        void** originalOut)
    {
        HMODULE module =
            GetModuleHandleW(nullptr);

        if (!module)
            return false;

        auto* base =
            reinterpret_cast<unsigned char*>(
                module);

        auto* dos =
            reinterpret_cast<IMAGE_DOS_HEADER*>(
                base);

        if (dos->e_magic !=
            IMAGE_DOS_SIGNATURE)
        {
            return false;
        }

        auto* nt =
            reinterpret_cast<IMAGE_NT_HEADERS*>(
                base + dos->e_lfanew);

        if (nt->Signature !=
            IMAGE_NT_SIGNATURE)
        {
            return false;
        }

        const auto& directory =
            nt->OptionalHeader
                .DataDirectory[
                    IMAGE_DIRECTORY_ENTRY_IMPORT];

        if (!directory.VirtualAddress ||
            !directory.Size)
        {
            return false;
        }

        auto* descriptor =
            reinterpret_cast<
                IMAGE_IMPORT_DESCRIPTOR*>(
                    base +
                    directory.VirtualAddress);

        bool patched = false;

        for (;
             descriptor->Name != 0;
             ++descriptor)
        {
            auto* firstThunk =
                reinterpret_cast<
                    IMAGE_THUNK_DATA*>(
                        base +
                        descriptor->FirstThunk);

            auto* originalThunk =
                descriptor->OriginalFirstThunk
                    ? reinterpret_cast<
                        IMAGE_THUNK_DATA*>(
                            base +
                            descriptor
                                ->OriginalFirstThunk)
                    : nullptr;

            if (!originalThunk)
                continue;

            for (std::size_t index = 0;
                 firstThunk[index].u1.Function != 0;
                 ++index)
            {
                const auto value =
                    originalThunk[
                        index].u1.Ordinal;

                if (IMAGE_SNAP_BY_ORDINAL(
                        value))
                {
                    continue;
                }

                auto* byName =
                    reinterpret_cast<
                        IMAGE_IMPORT_BY_NAME*>(
                            base +
                            originalThunk[
                                index]
                                .u1.AddressOfData);

                if (!byName)
                    continue;

                const char* name =
                    reinterpret_cast<
                        const char*>(
                            byName->Name);

                if (!name ||
                    std::strcmp(
                        name,
                        importName) != 0)
                {
                    continue;
                }

                auto* slot =
                    reinterpret_cast<
                        ULONG_PTR*>(
                            &firstThunk[
                                index]
                                .u1.Function);

                if (originalOut &&
                    !*originalOut)
                {
                    *originalOut =
                        reinterpret_cast<void*>(
                            *slot);
                }

                DWORD oldProtect = 0;

                if (!VirtualProtect(
                        slot,
                        sizeof(*slot),
                        PAGE_READWRITE,
                        &oldProtect))
                {
                    continue;
                }

                *slot =
                    reinterpret_cast<
                        ULONG_PTR>(
                            replacement);

                DWORD ignored = 0;

                VirtualProtect(
                    slot,
                    sizeof(*slot),
                    oldProtect,
                    &ignored);

                FlushInstructionCache(
                    GetCurrentProcess(),
                    slot,
                    sizeof(*slot));

                patched = true;
            }
        }

        return patched;
    }

    bool ReadIsolationEnvironment()
    {
        wchar_t buffer[32768]{};

        const DWORD count =
            GetEnvironmentVariableW(
                L"NFSMW_AP_DOCUMENTS_ROOT",
                buffer,
                static_cast<DWORD>(
                    sizeof(buffer) /
                    sizeof(buffer[0])));

        if (count == 0 || count >= MAX_PATH ||
            count >=
                static_cast<DWORD>(
                    sizeof(buffer) /
                    sizeof(buffer[0])))
        {
            return false;
        }

        g_documentsRootW.assign(
            buffer,
            count);

        g_documentsRootA =
            WideToAnsi(
                g_documentsRootW);

        char slot[32]{};
        const DWORD countSlot=GetEnvironmentVariableA("NFSMW_AP_SLOT_NAME",slot,sizeof(slot));
        if(countSlot>0 && countSlot<sizeof(slot)) {
            bool valid=true;
            for(DWORD n=0;n<countSlot;++n) {
                const unsigned char c=static_cast<unsigned char>(slot[n]);
                if(c<32 || c>126 || std::strchr("<>:\"/\\|?*",slot[n])){valid=false;break;}
            }
            if(valid)g_slotFileName.assign(slot,countSlot);
        }
        return !g_documentsRootA.empty() && g_documentsRootA.size() < MAX_PATH && !g_slotFileName.empty();
    }
    int InstallDocumentHooks()
    {
        int hooks = 0;


        PatchIatByName("CreateFileA", reinterpret_cast<void*>(&HookCreateFileA),
            reinterpret_cast<void**>(&g_originalCreateFileA));

        if (PatchIatByName(
                "SHGetFolderPathA",
                reinterpret_cast<void*>(
                    &HookSHGetFolderPathA),
                reinterpret_cast<void**>(
                    &g_originalFolderPathA)))
        {
            ++hooks;
        }

        if (PatchIatByName(
                "SHGetFolderPathW",
                reinterpret_cast<void*>(
                    &HookSHGetFolderPathW),
                reinterpret_cast<void**>(
                    &g_originalFolderPathW)))
        {
            ++hooks;
        }

        if (PatchIatByName(
                "SHGetSpecialFolderPathA",
                reinterpret_cast<void*>(
                    &HookSHGetSpecialFolderPathA),
                reinterpret_cast<void**>(
                    &g_originalSpecialPathA)))
        {
            ++hooks;
        }

        if (PatchIatByName(
                "SHGetSpecialFolderPathW",
                reinterpret_cast<void*>(
                    &HookSHGetSpecialFolderPathW),
                reinterpret_cast<void**>(
                    &g_originalSpecialPathW)))
        {
            ++hooks;
        }

        return hooks;
    }

}

namespace NFSMWAP
{
    bool PrimeSaveIsolationEarly()
    {
        if (g_primedEarly)
            return g_active;

        g_primedEarly = true;

        if (!ReadIsolationEnvironment())
            return false;


        g_active = true;
        g_hookCount = InstallDocumentHooks();

        if (g_hookCount == 0 || !g_originalCreateFileA)
        {
            g_active = false;
            return false;
        }

        return true;
    }

    bool InitializeSaveIsolation()
    {
        if (!g_primedEarly)
        {
            PrimeSaveIsolationEarly();
        }

        if (!g_active)
        {
            Log(
                "AP save isolation: inactive. "
                "Either NFSMW was not launched by the Archipelago client "
                "or the early My Documents IAT hook could not be installed.");
            return false;
        }

        if (!EnsureDirectoryTree(
                g_documentsRootW))
        {
            Log(
                "ERROR: AP save isolation could not create/verify "
                "the isolated Documents root: "
                + g_documentsRootA);

            return false;
        }

        Log(
            "AP SAVE ISOLATION PRIMED BEFORE PROFILE MANAGER.");

        Log(
            "AP SAVE ISOLATION ACTIVE: intercepted "
            + std::to_string(g_hookCount)
            + " My Documents import(s) for this speed.exe process.");

        Log(
            "AP isolated Documents root: "
            + g_documentsRootA);

        Log(
            "NFSMW will append \\\\NFS Most Wanted to this isolated root. "
            "Vanilla launches remain on the normal Documents folder.");

        Log("AP SAVE I/O: retail CreateFileA slot redirect " +
            std::string(g_originalCreateFileA?"installed":"unavailable") +
            "; only the AP slot's NFS Most Wanted files are eligible.");
        return true;
    }

    bool IsSaveIsolationActive()
    {
        return g_active;
    }

    bool WasSaveIsolationPrimedEarly()
    {
        return g_primedEarly;
    }

    int GetSaveIsolationHookCount()
    {
        return g_hookCount;
    }

    unsigned GetSaveIsolationRedirectCount()
    {
        return g_redirectCount.load();
    }
    unsigned GetSaveIsolationProfileOpenCount() {return g_slotOpenCount.load();}
    unsigned GetSaveIsolationProfileRedirectCount() {return g_slotRedirectCount.load();}
    std::string GetSaveIsolationLastProfileOpenPath() {
        AcquireSRWLockShared(&g_profileTraceLock);
        std::string result(g_lastSlotOpen);
        ReleaseSRWLockShared(&g_profileTraceLock);
        return result;
    }

    std::string GetIsolatedDocumentsRoot()
    {
        return g_documentsRootA;
    }
}
