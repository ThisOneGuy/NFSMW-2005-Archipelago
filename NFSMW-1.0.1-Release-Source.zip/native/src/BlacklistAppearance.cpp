#include "BlacklistAppearance.h"
#include "Logger.h"
#include <Windows.h>
#include <array>
#include <cstring>
#include <string>

namespace
{

    constexpr std::uintptr_t CarPartDB=0x9B26A8u;
    constexpr int Body=23,Spoiler=44,RoofScoop=62,Hood=63,FrontWheel=66,RearWheel=67;
    constexpr int BasePaint=76,Vinyl=77,RimPaint=78,FirstVinylColor=79,WindowTint=131;
    struct Appearance
    {
        alignas(16) unsigned char record[0x198]{};
        int carType=-1,seed=0;
        std::uint32_t vehicleKey=0;
        bool ready=false;
    };
    std::array<Appearance,16> g_appearances{};

    std::uint32_t Mix(std::uint32_t value)
    {
        value^=value>>16;value*=0x7FEB352Du;value^=value>>15;
        value*=0x846CA68Bu;return value^(value>>16);
    }


    bool BuildNative(unsigned char* output,int carType,std::uint32_t entropy,int* applied,int* vinylApplied)
    {
        __try
        {
            std::uint32_t ride[0x310/4]{};
            using InitFn=void(__thiscall*)(void*,int,int,int,int);
            using StockFn=void(__thiscall*)(void*);
            using NextFn=std::uint32_t(__thiscall*)(void*,int,int,int,std::uint32_t,int);
            using GetFn=std::uint32_t(__thiscall*)(void*,int);
            using SetFn=std::uint32_t(__thiscall*)(void*,int,std::uint32_t,bool);
            using CtorFn=void*(__thiscall*)(void*);
            using WriteFn=void(__thiscall*)(void*,const void*);
            reinterpret_cast<InitFn>(0x739A70u)(ride,carType,0,0,0);
            reinterpret_cast<StockFn>(0x7594A0u)(ride);


            const int slots[]={Spoiler,RoofScoop,Hood,FrontWheel,BasePaint,Vinyl,RimPaint,
                               FirstVinylColor,FirstVinylColor+1,FirstVinylColor+2,FirstVinylColor+3,WindowTint};
            for (int slot:slots)
            {
                const auto original=reinterpret_cast<GetFn>(0x739C70u)(ride,slot);
                std::uint32_t previous=0,chosen=0,count=0;


                for (std::uint32_t n=0;n<4096;++n)
                {
                    const auto part=reinterpret_cast<NextFn>(0x747C40u)(reinterpret_cast<void*>(CarPartDB),
                        carType,slot,0,previous,-1);
                    if (!part || part==previous) break;
                    previous=part;
                    if (part==original) continue;
                    ++count;
                    if (Mix(entropy^static_cast<std::uint32_t>(slot)*0x9E3779B9u^count)%count==0) chosen=part;
                }
                if (!chosen) continue;
                reinterpret_cast<SetFn>(0x756E90u)(ride,slot,chosen,true);
                ++*applied;
                if (slot==Vinyl) *vinylApplied=1;
                if (slot==FrontWheel)
                    reinterpret_cast<SetFn>(0x756E90u)(ride,RearWheel,chosen,true);
            }
            alignas(16) unsigned char completed[0x198]{};
            reinterpret_cast<CtorFn>(0x581C20u)(completed);
            reinterpret_cast<WriteFn>(0x56F2F0u)(completed,ride);

            std::memcpy(output,completed,sizeof(completed));
            return true;
        }
        __except(EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
}

namespace NFSMWAP
{
    std::uintptr_t PrepareBlacklistAppearance(int rank,int carType,std::uint32_t vehicleKey,int seed)
    {
        if (rank<1 || rank>15 || carType<0 || carType>=256 || !vehicleKey) return 0;
        auto& appearance=g_appearances[static_cast<std::size_t>(rank)];
        if (appearance.ready && appearance.carType==carType && appearance.vehicleKey==vehicleKey && appearance.seed==seed)
            return reinterpret_cast<std::uintptr_t>(appearance.record);
        const auto entropy=Mix(static_cast<std::uint32_t>(seed)^vehicleKey^static_cast<std::uint32_t>(rank)*0x9E3779B9u);
        int applied=0,vinyl=0;
        if (!BuildNative(appearance.record,carType,entropy,&applied,&vinyl)) return 0;
        appearance.carType=carType;appearance.vehicleKey=vehicleKey;appearance.seed=seed;appearance.ready=true;
        Log("AP BLACKLIST APPEARANCE: rank="+std::to_string(rank)+" model="+std::to_string(carType)+
            " seed="+std::to_string(seed)+" visual_categories="+std::to_string(applied)+
            " vinyl="+(vinyl ? std::string("randomized") : std::string("stock fallback"))+" player_garage_mutation=no");
        return reinterpret_cast<std::uintptr_t>(appearance.record);
    }
}
