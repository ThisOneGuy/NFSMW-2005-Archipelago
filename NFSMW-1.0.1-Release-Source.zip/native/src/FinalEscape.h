#pragma once
namespace NFSMWAP {
inline bool FinalEscapeSucceeded(bool career,bool ready,bool epic,bool matchesFinal,bool evaded) {
    return career&&ready&&epic&&matchesFinal&&evaded;
}
bool InstallFinalEscapeHooks();
void FinalEscapeMainThreadTick();
}
