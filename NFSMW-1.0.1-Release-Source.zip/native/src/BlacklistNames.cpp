#include "BlacklistNames.h"
#include "JsonLite.h"
#include "Logger.h"
#include <Windows.h>
#include <array>
#include <cctype>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <list>
#include <mutex>
#include <vector>
#include <utility>

namespace {
using Word=std::uint32_t;
const char* originals[]={"", "Razor","Bull","Ronnie","JV","Webster","Ming","Kaze","Jewels","Earl","Baron","Big Lou","Izzy","Vic","Taz","Sonny","Cross"};
std::mutex nameMutex;
std::array<std::string,17> configured{};
unsigned revision=0,appliedRevision=~0u;
Word lastTable=0;int lastCount=0;
bool validated=false,attempted=false;
struct Row {Word* entry;Word original;int rank;};
std::vector<Row> rows;

std::list<std::string> retainedNames;
bool Validate() {
    __try {
        const unsigned char expected[]={0x53,0x8B,0x1D,0x80,0xCF,0x91,0x00};
        return std::memcmp(reinterpret_cast<void*>(0x56BB80u),expected,sizeof(expected))==0;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool Table(Word& table,int& count) {
    __try {
        table=*reinterpret_cast<Word*>(0x91CF80u);count=*reinterpret_cast<int*>(0x91CF78u);
        return table&&count>0&&count<100000;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool ReadText(Word pointer,char* out,unsigned capacity) {
    __try {
        if(!pointer||!capacity)return false;
        const auto* text=reinterpret_cast<const char*>(pointer);
        for(unsigned i=0;i<capacity;++i){out[i]=text[i];if(!out[i])return true;}
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
    return false;
}
Word Hash(const char* text){Word h=~0u;while(*text)h=h*33u+static_cast<unsigned char>(*text++);return h;}
int DirectRank(Word hash,const std::string& text) {
    for(int rank=1;rank<=15;++rank) {
        char key[64];
        for(const auto* suffix:{"NAME","AKA","LEADERBOARD"}) {
            std::snprintf(key,sizeof(key),"BLACKLIST_RIVAL_%02d_%s",rank,suffix);
            if(hash==Hash(key))return rank;
        }
    }
    for(int rank=1;rank<=15;++rank) {
        const auto* name=originals[rank];std::size_t i=0;
        while(i<text.size()&&name[i]&&std::tolower(static_cast<unsigned char>(text[i]))==std::tolower(static_cast<unsigned char>(name[i])))++i;
        if(i==text.size()&&!name[i])return rank;
    }
    const auto* cross=originals[16];
    std::size_t i=0;
    while(i<text.size()&&cross[i]&&std::tolower(static_cast<unsigned char>(text[i]))==std::tolower(static_cast<unsigned char>(cross[i])))++i;
    if(i==text.size()&&!cross[i])return 16;
    return 0;
}
bool WordCharacter(unsigned char c){return std::isalnum(c)||c=='_'||c>=128;}
std::string ReplaceMentions(const std::string& text,bool detectOnly=false) {
    std::string result;
    for(std::size_t at=0;at<text.size();) {
        bool replaced=false;
        for(int rank=1;rank<=15;++rank) {
            const auto* name=originals[rank];const auto length=std::strlen(name);
            if(at+length>text.size()||(at&&WordCharacter(static_cast<unsigned char>(text[at-1])))||
               (at+length<text.size()&&WordCharacter(static_cast<unsigned char>(text[at+length]))))continue;
            std::size_t i=0;while(i<length&&std::tolower(static_cast<unsigned char>(text[at+i]))==std::tolower(static_cast<unsigned char>(name[i])))++i;
            if(i!=length)continue;
            if(detectOnly)return "matched";
            result+=configured[rank].empty()?text.substr(at,length):configured[rank];
            at+=length;replaced=true;break;
        }
        if(!replaced)result+=text[at++];
    }
    return detectOnly?std::string{}:result;
}

}
namespace NFSMWAP {
void ConfigureBlacklistNames(const std::string& packet) {
    std::array<std::string,17> next{};
    for(int rank=1;rank<=16;++rank) {
        const auto key=rank==16?std::string("cross_name"):"blacklist_name_"+std::to_string(rank);
        JsonLite::GetString(packet,key.c_str(),next[rank]);
        auto& name=next[rank];
        for(auto& c:name)if(static_cast<unsigned char>(c)<32)c=' ';

        if(name.size()>48){std::size_t end=48;while(end&&(static_cast<unsigned char>(name[end])&0xC0)==0x80)--end;name.resize(end);}
        if(name.empty()||name==originals[rank])name.clear();
    }
    std::lock_guard<std::mutex> lock(nameMutex);
    if(next!=configured){configured=std::move(next);++revision;}
}
void BlacklistNamesMainThreadTick() {
    if(!attempted){attempted=true;validated=Validate();Log(validated?"NFSMW_AP_BLACKLIST_NAMES_V3: native localized Blacklist names enabled; rank/check identity retained.":"AP BLACKLIST NAMES: unsupported language table; default names retained.");}
    if(!validated)return;
    Word table=0;int count=0;if(!Table(table,count))return;
    std::lock_guard<std::mutex> lock(nameMutex);
    const bool reload=table!=lastTable||count!=lastCount;
    if(!reload&&appliedRevision==revision)return;
    if(reload) {
        rows.clear();lastTable=table;lastCount=count;
        for(int i=0;i<count;++i) {
            auto* entry=reinterpret_cast<Word*>(table+i*8u);
            char text[8192]={};if(!ReadText(entry[1],text,sizeof(text)))continue;
            const int rank=DirectRank(entry[0],text);
            if(rank||!ReplaceMentions(text,true).empty())rows.push_back({entry,entry[1],rank});
        }
    }
    std::array<Word,17> replacements{};
    for(int rank=1;rank<=16;++rank)if(!configured[rank].empty()) {
        retainedNames.push_back(configured[rank]);
        replacements[rank]=static_cast<Word>(reinterpret_cast<std::uintptr_t>(retainedNames.back().c_str()));
    }
    for(const auto& row:rows) {
        if(row.rank){row.entry[1]=replacements[row.rank]?replacements[row.rank]:row.original;continue;}
        char original[8192]={};if(!ReadText(row.original,original,sizeof(original)))continue;
        const auto changed=ReplaceMentions(original);
        if(changed==original){row.entry[1]=row.original;continue;}
        retainedNames.push_back(changed);
        row.entry[1]=static_cast<Word>(reinterpret_cast<std::uintptr_t>(retainedNames.back().c_str()));
    }
    appliedRevision=revision;
    Log("AP BLACKLIST NAMES: updated "+std::to_string(rows.size())+" native name labels; original names retained for unassigned ranks.");
}
}
