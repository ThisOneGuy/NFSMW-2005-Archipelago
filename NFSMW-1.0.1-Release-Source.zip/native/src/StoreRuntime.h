#pragma once

#include <Windows.h>
#include <string>

namespace NFSMWAP
{
    void ConfigureStoreRuntime(bool enabled, int purchaseHotkey);
    bool NativeShopRequested();
    bool GetNativeShopCar(std::string& car);
    bool GetNativeDealerCar(const void* screen, std::string& car);
    bool GetNativeStorePackage(std::string& package);
    bool PurchaseNativeShopEntry(int locationId, const std::string& car);
    void StorePurchaseMainThreadTick();
    bool GetNativeCareerCash(int& cash);
    bool GetReceivedCareerStartChoice(unsigned int& handle);
    void NotifyReceivedCareerStartChoice();
    void NotifyShopPurchaseAck(int locationId, int requestId, bool accepted, const std::string& reason);
    void NotifyReceivedCarItem(int index, int itemId, const std::string& car);
    DWORD WINAPI StoreRuntimeThread(LPVOID);
}
