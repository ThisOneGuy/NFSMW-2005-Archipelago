#pragma once
#include <d3d9.h>
#include <string>

namespace NFSMWAP
{

    void NativeShopMainThreadTick();
    bool RequestNativeModelResource(const std::string& path);
    void ServiceNativeModelResources();
    void DrawNativeShopModel(IDirect3DDevice9* device);
    bool NativeShopsEnabled();
}
