#pragma once
#include <string>
namespace NFSMWAP {
    inline int CashItemAmount(int item) {
        return item==1900001 ? 5000 : item==1900002 ? 10000 : item==1900003 ? 25000 : 0;
    }
    void QueueReceivedCash(int index,int item,const std::string& session);
    void CashDeliveryMainThreadTick();
    void RequestCareerAutosave();
}
