#include "EventDiscovery.h"

#include <Windows.h>
#include <cstdint>
#include <cstring>
#include <string>

#include "BridgeClient.h"
#include "CareerContext.h"
#include "Logger.h"
#include "NativeRewardUI.h"

namespace
{


    constexpr std::uintptr_t SafeHouseEventCallAddress = 0x00547995u;


    constexpr std::uintptr_t GRaceParametersGetEventIDAddress = 0x005FBA70u;

    using GetEventIDFn = char* (__thiscall*)(void*);

    CRITICAL_SECTION g_selectionLock{};
    bool g_lockInitialized = false;
    char g_selectedEventID[128]{};

    char* SafeGetEventID(void* raceParameters) noexcept
    {
        if (!raceParameters)
            return nullptr;

        const auto fn =
            reinterpret_cast<GetEventIDFn>(
                GRaceParametersGetEventIDAddress);

        __try
        {
            return fn(raceParameters);
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return nullptr;
        }
    }

    void StoreSelectedEventID(const char* value)
    {
        if (!g_lockInitialized || !value || !*value)
            return;

        EnterCriticalSection(&g_selectionLock);

        strncpy_s(
            g_selectedEventID,
            sizeof(g_selectedEventID),
            value,
            _TRUNCATE);

        LeaveCriticalSection(&g_selectionLock);
    }

    void ReadSelectedEventID(char* out, std::size_t outSize)
    {
        if (!out || outSize == 0)
            return;

        out[0] = '\0';

        if (!g_lockInitialized)
            return;

        EnterCriticalSection(&g_selectionLock);

        strncpy_s(
            out,
            outSize,
            g_selectedEventID,
            _TRUNCATE);

        LeaveCriticalSection(&g_selectionLock);
    }


    int __stdcall SafeHouseEventIDHook(const char*                )
    {
        void* raceParameters = nullptr;

#if defined(_M_IX86)
        __asm mov raceParameters, edi
#endif

        char* eventID = SafeGetEventID(raceParameters);

        if (eventID && *eventID)
        {
            StoreSelectedEventID(eventID);
            NFSMWAP::ObserveNativeRaceReward(eventID,raceParameters);
            NFSMWAP::ObserveCareerEventID(eventID);
        }

        return 0;
    }

    bool PatchRelativeCall(
        std::uintptr_t address,
        const void* target)
    {
        BYTE* site = reinterpret_cast<BYTE*>(address);


        if (site[0] != 0xE8)
            return false;

        DWORD oldProtect = 0;

        if (!VirtualProtect(
                site,
                5,
                PAGE_EXECUTE_READWRITE,
                &oldProtect))
        {
            return false;
        }

        const std::intptr_t displacement =
            reinterpret_cast<const BYTE*>(target) -
            (site + 5);

        site[0] = 0xE8;

        *reinterpret_cast<std::int32_t*>(site + 1) =
            static_cast<std::int32_t>(displacement);

        DWORD unused = 0;
        VirtualProtect(site, 5, oldProtect, &unused);

        FlushInstructionCache(
            GetCurrentProcess(),
            site,
            5);

        return true;
    }

    std::string EscapeJson(const std::string& text)
    {
        std::string out;
        out.reserve(text.size() + 8);

        for (char c : text)
        {
            switch (c)
            {
            case '\\': out += "\\\\"; break;
            case '"':  out += "\\\""; break;
            case '\n': out += "\\n";  break;
            case '\r': out += "\\r";  break;
            case '\t': out += "\\t";  break;
            default:   out += c;      break;
            }
        }

        return out;
    }
}

namespace NFSMWAP
{
    bool InstallEventDiscoveryHook()
    {
        if (!g_lockInitialized)
        {
            InitializeCriticalSection(&g_selectionLock);
            g_lockInitialized = true;
        }

        if (!PatchRelativeCall(
                SafeHouseEventCallAddress,
                reinterpret_cast<const void*>(&SafeHouseEventIDHook)))
        {
            Log(
                "ERROR: SafeHouse EventID discovery hook was not installed. "
                "Expected CALL opcode at 0x00547995.");
            return false;
        }

        Log(
            "Career race-menu EventID discovery hook installed at 0x00547995.");
        Log(
            "Highlight a Career race in the Safe House menu to discover its internal Event ID.");

        return true;
    }

    DWORD WINAPI EventDiscoveryThread(LPVOID)
    {
        std::string lastReported;

        while (true)
        {
            char buffer[128]{};
            ReadSelectedEventID(buffer, sizeof(buffer));

            if (buffer[0] != '\0')
            {
                const std::string current(buffer);

                if (current != lastReported)
                {
                    Log("CAREER MENU SELECTED EVENT ID: " + current);

                    const std::string payload =
                        std::string("{\"type\":\"event_selected\",")
                        + "\"event_id\":\""
                        + EscapeJson(current)
                        + "\"}";

                    if (!SendBridgeLine(payload))
                    {
                        Log(
                            "Bridge not connected; selected Event ID was not forwarded.");
                    }

                    lastReported = current;
                }
            }

            Sleep(100);
        }
    }
}
