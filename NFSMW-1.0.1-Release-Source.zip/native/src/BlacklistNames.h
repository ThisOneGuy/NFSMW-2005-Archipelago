#pragma once
#include <string>
namespace NFSMWAP {
void ConfigureBlacklistNames(const std::string& packet);
void BlacklistNamesMainThreadTick();
}
