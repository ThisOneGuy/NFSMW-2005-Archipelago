#include "NativeVisualTreatment.h"
#include "Logger.h"
#include <Windows.h>
#include <cstdint>
#include <cstring>
#include <cmath>

namespace {
using Word=std::uint32_t;
bool blueAlertActive=false;
bool PoliceAlertWindow(void* object) {
    const auto* bytes=static_cast<const unsigned char*>(object);
    const Word state=*reinterpret_cast<const Word*>(bytes);
    if(state==1u)return true;
    if(state!=0u)return false;
    for(Word offset:{0x1C0u,0x1C8u}) {
        const Word address=*reinterpret_cast<const Word*>(bytes+offset);
        if(!address)continue;
        const auto* effect=reinterpret_cast<const unsigned char*>(address);
        const float start=*reinterpret_cast<const float*>(effect+4);
        const float length=*reinterpret_cast<const float*>(effect+8);
        if(!std::isfinite(start)||!std::isfinite(length)||start==0.0f||length<=0.0f)continue;
        const Word clock=effect[0xC] ? 0x925AE8u : 0x925B14u;
        const float now=static_cast<float>(*reinterpret_cast<const int*>(clock))*
            *reinterpret_cast<const float*>(0x890984u);
        const float elapsed=now-start;
        if(elapsed>=0.0f&&elapsed<=length)return true;
    }
    return false;
}
void __fastcall NeutralBase(void* object,void*,float* result,float baseWeight,float policeWeight,Word getter) {
    reinterpret_cast<void(__thiscall*)(void*,float*,float,float,Word)>(0x73E180u)
        (object,result,baseWeight,policeWeight,getter);
    if(getter!=0x73D9B0u||PoliceAlertWindow(object))return;
    for(int i=0;i<3;++i)result[i]=0.84f;
}
void __fastcall Update(void* object,void*,void* view) {
    reinterpret_cast<void(__thiscall*)(void*,void*)>(0x74C000u)(object,view);
    auto* values=static_cast<float*>(object);
    blueAlertActive=PoliceAlertWindow(object);
    if(blueAlertActive)return;
    values[0x90/4]=0.0f;
    values[0x94/4]=0.0f;
    values[0x98/4]=1.0f;
    if(*static_cast<Word*>(object)==2u)
        for(int i=0;i<3;++i)values[0xA0/4+i]=0.84f;
}
void __cdecl SkipTunnelBloom(void*) {}
void __cdecl SkipSunGlare() {}
void __cdecl OverbrightPass(void* view) {
    if(blueAlertActive)reinterpret_cast<void(__cdecl*)(void*)>(0x6DC040u)(view);
}
void __cdecl SkyLayer(void* view,int layer,float intensity) {
    if(layer>=0&&layer<=2&&intensity>0.0f)intensity*=0.65f;
    reinterpret_cast<void(__cdecl*)(void*,int,float)>(0x6DB310u)(view,layer,intensity);
}
struct Call {Word site,target;std::uintptr_t hook;DWORD protection;};
bool Install() {
    Call calls[]={
        {0x74BD61u,0x73E180u,reinterpret_cast<std::uintptr_t>(&NeutralBase),0},
        {0x6DF599u,0x74C000u,reinterpret_cast<std::uintptr_t>(&Update),0},
        {0x504C65u,0x72AAC0u,reinterpret_cast<std::uintptr_t>(&SkipTunnelBloom),0},
        {0x504C6Fu,0x72AAC0u,reinterpret_cast<std::uintptr_t>(&SkipTunnelBloom),0},
        {0x504C56u,0x503830u,reinterpret_cast<std::uintptr_t>(&SkipSunGlare),0},
        {0x6DF8ABu,0x6DC040u,reinterpret_cast<std::uintptr_t>(&OverbrightPass),0},
        {0x6DE271u,0x6DB310u,reinterpret_cast<std::uintptr_t>(&SkyLayer),0},
        {0x6DE27Fu,0x6DB310u,reinterpret_cast<std::uintptr_t>(&SkyLayer),0},
        {0x6DE28Du,0x6DB310u,reinterpret_cast<std::uintptr_t>(&SkyLayer),0}
    };
    for(const auto& call:calls) {
        std::int32_t displacement=0;
        std::memcpy(&displacement,reinterpret_cast<const void*>(call.site+1u),4);
        if(*reinterpret_cast<const unsigned char*>(call.site)!=0xE8u||
           call.site+5u+displacement!=call.target)return false;
    }
    const unsigned char originalDesaturation[]={0xD9,0x9E,0x98,0x00,0x00,0x00};
    const unsigned char retainDesaturation[]={0xDD,0xD8,0x90,0x90,0x90,0x90};
    if(std::memcmp(reinterpret_cast<const void*>(0x6D514Fu),originalDesaturation,6))return false;
    unsigned prepared=0;
    for(auto& call:calls) {
        if(!VirtualProtect(reinterpret_cast<void*>(call.site),5,PAGE_EXECUTE_READWRITE,&call.protection)) {
            DWORD ignored=0;
            for(unsigned i=prepared;i>0;--i)
                VirtualProtect(reinterpret_cast<void*>(calls[i-1].site),5,calls[i-1].protection,&ignored);
            return false;
        }
        ++prepared;
    }
    DWORD saturationProtection=0;
    if(!VirtualProtect(reinterpret_cast<void*>(0x6D514Fu),6,PAGE_EXECUTE_READWRITE,&saturationProtection)) {
        DWORD ignored=0;
        for(unsigned i=prepared;i>0;--i)
            VirtualProtect(reinterpret_cast<void*>(calls[i-1].site),5,calls[i-1].protection,&ignored);
        return false;
    }
    for(const auto& call:calls) {
        const auto relative=static_cast<std::int32_t>(call.hook-(call.site+5u));
        std::memcpy(reinterpret_cast<void*>(call.site+1u),&relative,4);
    }
    std::memcpy(reinterpret_cast<void*>(0x6D514Fu),retainDesaturation,6);
    DWORD ignored=0;
    VirtualProtect(reinterpret_cast<void*>(0x6D514Fu),6,saturationProtection,&ignored);
    FlushInstructionCache(GetCurrentProcess(),reinterpret_cast<void*>(0x6D514Fu),6);
    for(unsigned i=prepared;i>0;--i) {
        const auto& call=calls[i-1];
        DWORD callIgnored=0;
        VirtualProtect(reinterpret_cast<void*>(call.site),5,call.protection,&callIgnored);
        FlushInstructionCache(GetCurrentProcess(),reinterpret_cast<void*>(call.site),5);
    }
    return true;
}
}
namespace NFSMWAP {
void NativeVisualTreatmentMainThreadTick() {
    static bool attempted=false;
    if(attempted)return;
    attempted=true;
    Log(Install()?"NFSMW_AP_NATIVE_LOW_GLARE_V5: native police transition and pulse timers preserve the complete blue alert; normal glare reduced.":
        "AP VISUAL TREATMENT: retail calls changed; original graphics retained.");
}
}
