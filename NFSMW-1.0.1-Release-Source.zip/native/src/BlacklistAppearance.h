#pragma once
#include <cstdint>

namespace NFSMWAP
{


    std::uintptr_t PrepareBlacklistAppearance(int rank,int carType,std::uint32_t vehicleKey,int seed);
}
