#include "MilestoneJournal.h"
#include "MilestoneTargets.h"
#include "JsonLite.h"
#include "Logger.h"
#include <Windows.h>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <map>
#include <mutex>
#include <vector>

namespace NFSMWAP { bool SendBridgeLine(const std::string&); }
namespace
{
    struct Record { std::string payload; bool acknowledged=false; };
    std::mutex mutex;
    std::map<int,Record> records;
    std::filesystem::path path;
    std::string session;
    bool loaded=false;

    std::string Packet(int location,const Record& record)
    {
        return "{\"type\":\"milestone_journal\",\"location_id\":"+std::to_string(location)+
            ",\"session_key\":\""+NFSMWAP::JsonLite::Escape(session)+"\",\"payload\":\""+
            NFSMWAP::JsonLite::Escape(record.payload)+"\",\"acknowledged\":"+
            (record.acknowledged ? "true}" : "false}");
    }

    void Load()
    {
        if (loaded) return;
        loaded=true;
        char root[4096]={},key[512]={};
        const auto rootLength=GetEnvironmentVariableA("NFSMW_AP_DOCUMENTS_ROOT",root,sizeof(root));
        const auto keyLength=GetEnvironmentVariableA("NFSMW_AP_SESSION_KEY",key,sizeof(key));
        if (!rootLength || rootLength>=sizeof(root) || !keyLength || keyLength>=sizeof(key)) return;
        session=key;
        path=std::filesystem::path(root)/"NFSMW_AP_MilestoneJournal.jsonl";
        std::ifstream file(path);
        std::string line;
        while (std::getline(file,line))
        {
            int id=0;std::string keyValue,payload;bool acknowledged=false;
            if (line.size()>16384 || !NFSMWAP::JsonLite::GetInt(line,"location_id",id) ||
                !NFSMWAP::JsonLite::GetString(line,"session_key",keyValue) || keyValue!=session ||
                !NFSMWAP::JsonLite::GetString(line,"payload",payload)) continue;
            bool known=false;
            for (const auto& target:NFSMWAP::MilestoneTargets) if (target.location==id) known=true;
            if (!known) continue;
            NFSMWAP::JsonLite::GetBool(line,"acknowledged",acknowledged);
            records[id]={payload,acknowledged};
        }
    }

    bool SaveRecord(int location,const Record& record)
    {
        if(path.empty())return false;
        std::ofstream file(path,std::ios::binary|std::ios::app);
        if(!file)return false;
        file << '\n' << Packet(location,record) << '\n';
        file.flush();if(!file)return false;
        file.close();return static_cast<bool>(file);
    }

}

namespace NFSMWAP
{
    bool HasRecordedMilestone(int location)
    {
        std::lock_guard<std::mutex> lock(mutex);Load();
        const auto found=records.find(location);
        if (found==records.end()) return false;
        std::string category,name;JsonLite::GetString(found->second.payload,"ap_category",category);
        JsonLite::GetString(found->second.payload,"event_name",name);
        return found->second.acknowledged || category!="Photo Ticket" || name=="PhotoTrapCompleted";
    }

    void ReplayMilestoneJournal()
    {
        std::vector<std::string> pending;
        { std::lock_guard<std::mutex> lock(mutex);Load();
          for (const auto& record:records) if (!record.second.acknowledged) pending.push_back(Packet(record.first,record.second)); }
        for (const auto& packet:pending) if (!SendBridgeLine(packet)) break;
    }

    void AcknowledgeMilestoneJournal(int location,const std::string& key)
    {
        std::lock_guard<std::mutex> lock(mutex);Load();
        const auto found=records.find(location);
        if (key!=session || found==records.end() || found->second.acknowledged) return;
        found->second.acknowledged=true;
        if (!SaveRecord(location,found->second)) { found->second.acknowledged=false;Log("AP MILESTONE JOURNAL: acknowledgement save failed; retained for retry."); }
    }

    void SendRecordedMilestoneEvent(const std::string& event)
    {
        std::string name,category,valueText;int rank=0;bool career=false;
        JsonLite::GetString(event,"event_name",name);JsonLite::GetString(event,"ap_category",category);
        JsonLite::GetString(event,"value_float",valueText);JsonLite::GetInt(event,"blacklist_rank",rank);
        JsonLite::GetBool(event,"career_mode",career);
        double value=0;
        try { std::size_t used=0;value=std::stod(valueText,&used);if (used!=valueText.size()) return; }
        catch (...) { SendBridgeLine(event);return; }
        const bool photo=name=="PhotoTrapCompleted" && category=="Photo Ticket";
        int photoLocation=0;bool cameraComplete=false;std::string cameraKey,requiredText;double requiredMph=0;
        if (photo) {
            JsonLite::GetInt(event,"target_location_id",photoLocation);JsonLite::GetBool(event,"camera_completed",cameraComplete);
            JsonLite::GetString(event,"camera_key",cameraKey);JsonLite::GetString(event,"required_speed_mph",requiredText);
            try {std::size_t used=0;requiredMph=std::stod(requiredText,&used);if(used!=requiredText.size()) return;}
            catch (...) {return;}
            if (!cameraComplete || cameraKey.empty() || cameraKey=="0x00000000" || !std::isfinite(requiredMph) || requiredMph<=0) return;
        }
        const bool reached=name=="MNotifyMilestoneReached" || photo;
        const bool cumulative=category=="Trade Paint" || category=="Bounty" || category=="Cost to State" ||
            category=="Infractions" || category=="Roadblock" || category=="Spike Strip" || category=="Pursuit Time";
        if (!career || rank<1 || rank>15 || !std::isfinite(value) || value<0 ||
            (name!="MNotifyMilestoneProgress" && !reached) || (!reached && !cumulative) || (category=="Photo Ticket" && !photo))
        { SendBridgeLine(event);return; }
        std::vector<std::string> pending;
        { std::lock_guard<std::mutex> lock(mutex);Load();
          for (const auto& target:MilestoneTargets)
          {
              if (target.rank!=rank || category!=target.category || (photo && (target.location!=photoLocation || std::abs(requiredMph-target.threshold)>1.05 || std::abs(value-target.threshold)>=0.001)) ||
                  (target.less ? !(value>0 && value<target.threshold) : value<target.threshold)) continue;
              if (session.empty()) continue;
              const auto found=records.find(target.location);
              if (found!=records.end()) {
                  std::string oldName;JsonLite::GetString(found->second.payload,"event_name",oldName);
                  if (!photo || found->second.acknowledged || oldName=="PhotoTrapCompleted") continue;
              }
              const Record candidate{event,false};
              if(!SaveRecord(target.location,candidate)) {
                  Log("AP MILESTONE JOURNAL: disk write failed; observation retained for the next native update.");continue;
              }
              records[target.location]=candidate;
              pending.push_back(Packet(target.location,candidate));
              Log("AP PERSISTENT MILESTONE: location="+std::to_string(target.location)+" recorded for bridge/client reconciliation.");
          }
          }
        SendBridgeLine(event);
        for (const auto& packet:pending) SendBridgeLine(packet);
    }
}
