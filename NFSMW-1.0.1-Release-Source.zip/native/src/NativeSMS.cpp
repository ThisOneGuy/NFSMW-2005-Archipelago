#include "NativeSMS.h"
#include "NativeSMSLayout.h"
#include "NativeFrontend.h"
#include "JsonLite.h"
#include "BridgeClient.h"
#include "Logger.h"
#include <Windows.h>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <map>
#include <mutex>
#include <vector>


namespace {
using Word=std::uint32_t;
namespace PC=NFSMWAP::SMSPC;
using SMSRecord=PC::Record;
static_assert(sizeof(SMSRecord)==4);
struct Message {
    std::string id,from,to,subject,body,item;int sequence=0;bool read=false,deleted=false;
    SMSRecord record{254,2,0};unsigned char savedFlags=2;
};
std::mutex smsMutex;
std::map<std::string,Message> messages;
std::map<std::string,std::string> queuedPackets;
std::vector<std::string> queuedOrder;
std::string session;
std::filesystem::path journal;
int nextSequence=0;
bool loaded=false,hooksReady=false;
DWORD lastHookTry=0;
std::string selectedAP;
Word* inboxOwner=nullptr;
bool inboxVoice=true;
bool arrivalPending=false,incomingShown=false;
unsigned arrivalWaitReasons=0;
bool ItemMessageID(const std::string& id) {
    const bool received=id.compare(0,5,"recv:")==0;
    if(!received&&id.compare(0,5,"sent:")!=0)return false;
    const unsigned fields=received?1:4;
    std::size_t begin=5;
    for(unsigned field=0;field<fields;++field) {
        const auto colon=id.find(':',begin);
        if((field+1<fields)!=(colon!=std::string::npos))return false;
        const auto end=colon==std::string::npos?id.size():colon;
        if(!received&&begin<end&&id[begin]=='-')++begin;
        if(begin==end)return false;
        for(auto n=begin;n<end;++n)if(id[n]<'0'||id[n]>'9')return false;
        begin=end+1;
    }
    return true;
}
Word Hash(const char* value) {Word h=0xFFFFFFFFu;for(;*value;++value)h=h*33u+static_cast<unsigned char>(*value);return h;}
bool ReadCareer(Word& settings) {
    __try {
        const int flow=*reinterpret_cast<int*>(0x925E90u);if(flow!=3&&flow!=6)return false;
        const auto db=*reinterpret_cast<Word*>(0x91CF90u);
        if(!db || !NFSMWAP::NativeCareerDeliveryMode(*reinterpret_cast<Word*>(db+0x12Cu)))return false;
        const auto profile=*reinterpret_cast<Word*>(db+0x10u);
        if(profile<0x10000u || (profile&3u) || !*reinterpret_cast<unsigned char*>(profile+0x20u) ||
           *reinterpret_cast<unsigned char*>(profile+0xB0u)>15u)return false;
        settings=profile+0xA8u;return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool Save() {
    if(journal.empty())return false;
    const auto temp=std::filesystem::path(journal.string()+".tmp");
    std::ofstream file(temp,std::ios::trunc);
    for(const auto& pair:messages) {
        const auto& m=pair.second;
        file<<"{\"session_key\":\""<<NFSMWAP::JsonLite::Escape(session)<<"\",\"id\":\""<<NFSMWAP::JsonLite::Escape(m.id)
            <<"\",\"from\":\""<<NFSMWAP::JsonLite::Escape(m.from)<<"\",\"to\":\""<<NFSMWAP::JsonLite::Escape(m.to)
            <<"\",\"subject\":\""<<NFSMWAP::JsonLite::Escape(m.subject)<<"\",\"body\":\""<<NFSMWAP::JsonLite::Escape(m.body)
            <<"\",\"item_name\":\""<<NFSMWAP::JsonLite::Escape(m.item)<<"\",\"sequence\":"<<m.sequence<<",\"read\":"<<(m.read?"true":"false")<<",\"deleted\":"<<(m.deleted?"true":"false")<<"}\n";
    }
    file.flush();if(!file)return false;file.close();if(!file)return false;
#ifdef _WIN32
    return MoveFileExW(temp.c_str(),journal.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=0;
#else
    std::error_code error;std::filesystem::rename(temp,journal,error);return !error;
#endif
}
bool Parse(const std::string& line,Message& m) {
    std::string key;
    if(!NFSMWAP::JsonLite::GetString(line,"session_key",key)||key!=session)return false;
    NFSMWAP::JsonLite::GetString(line,"id",m.id);NFSMWAP::JsonLite::GetString(line,"from",m.from);
    NFSMWAP::JsonLite::GetString(line,"to",m.to);NFSMWAP::JsonLite::GetString(line,"subject",m.subject);
    NFSMWAP::JsonLite::GetString(line,"body",m.body);
    NFSMWAP::JsonLite::GetString(line,"item_name",m.item);
    return ItemMessageID(m.id)&&m.id.size()<=160 && !m.from.empty()&&m.from.size()<=240 &&
           !m.to.empty()&&m.to.size()<=240 && !m.subject.empty()&&m.subject.size()<=240 &&
           !m.body.empty()&&m.body.size()<=8192&&m.item.size()<=512;
}
void Load() {
    if(loaded)return;
    char root[4096]={},key[512]={};
    const auto a=GetEnvironmentVariableA("NFSMW_AP_DOCUMENTS_ROOT",root,sizeof(root));
    const auto b=GetEnvironmentVariableA("NFSMW_AP_SESSION_KEY",key,sizeof(key));
    if(!a||a>=sizeof(root)||!b||b>=sizeof(key))return;
    loaded=true;session=key;journal=std::filesystem::path(root)/"NFSMW_AP_SMS.jsonl";
    std::ifstream file(journal);std::string line;
    while(std::getline(file,line)) {
        Message m;if(line.size()>24576||!Parse(line,m))continue;
        NFSMWAP::JsonLite::GetInt(line,"sequence",m.sequence);
        NFSMWAP::JsonLite::GetBool(line,"read",m.read);m.record.flags=m.read?4:2;m.savedFlags=m.record.flags;
        NFSMWAP::JsonLite::GetBool(line,"deleted",m.deleted);
        if(m.sequence<1)continue;
        if(m.deleted)m.record.flags=m.savedFlags=0;
        m.record.order=static_cast<std::uint16_t>(m.sequence);
        nextSequence=std::max(nextSequence,m.sequence);messages.emplace(m.id,m);
    }
    NFSMWAP::Log("AP SMS JOURNAL: loaded="+std::to_string(messages.size())+" saved message(s).");
    for(const auto& pair:messages)if(!pair.second.deleted&&(pair.second.record.flags&2u))arrivalPending=true;
}
bool ForRecord(const SMSRecord* record,Message& result) {
    if(!record)return false;
    std::lock_guard<std::mutex> lock(smsMutex);
    for(const auto& pair:messages)if(&pair.second.record==record&&!pair.second.deleted){result=pair.second;return true;}
    return false;
}
const char* Package(Word* screen) {
    __try {return screen?reinterpret_cast<const char*>(screen[offsetof(PC::MenuScreen,packageName)/4u]):nullptr;}
    __except(EXCEPTION_EXECUTE_HANDLER) {return nullptr;}
}
bool IsString(Word* object) {
    __try {return object&&object[0x18u/4u]==2u;}
    __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
Word* Find(const char* package,Word hash) {
    return reinterpret_cast<Word*(__cdecl*)(const char*,Word)>(0x5251E0u)(package,hash);
}
struct TextStyle {Word guid=0,flags=0,format=0,width=0;};
std::map<Word*,TextStyle> textStyles;
void RememberStyle(Word* text) {
    auto old=textStyles.find(text);
    if(old==textStyles.end()||old->second.guid!=text[3])textStyles[text]={text[3],text[7],text[0x6Cu/4u],text[0x74u/4u]};
}
void RestoreStyleValue(Word* text,const TextStyle& style) {
    __try {if(IsString(text)&&text[3]==style.guid){text[7]=style.flags|(1u<<22u)|(1u<<25u);text[0x6Cu/4u]=style.format;text[0x74u/4u]=style.width;}}
    __except(EXCEPTION_EXECUTE_HANDLER) {}
}
void RestoreStyle(Word* text) {
    auto old=textStyles.find(text);if(old==textStyles.end())return;
    RestoreStyleValue(text,old->second);textStyles.erase(old);
}
void Literal(Word* text,const std::string& value) {
    if(!IsString(text))return;
    RememberStyle(text);
    const auto wide=NFSMWAP::NativeShopWideText(value);
    reinterpret_cast<void(__cdecl*)(Word*,const char16_t*)>(0x515CC0u)(text,wide.c_str());
    text[0x1Cu/4u]=(text[0x1Cu/4u]&~0x20u)|NFSMWAP::FERewardLiteral|(1u<<22u)|(1u<<25u);
    text[NFSMWAP::FEStringFormatOffset/4u]|=NFSMWAP::FEStringWordWrap;
}
struct LabelBackup {Word guid=0,flags=0,format=0;std::u16string text;};
std::map<Word*,LabelBackup> labelBackups;
bool SubjectLabel(Word* object) {
    if(!IsString(object))return false;
    const auto saved=labelBackups.find(object);
    if(saved!=labelBackups.end()&&saved->second.guid==object[3])return true;
    const auto text=reinterpret_cast<const char16_t*>(static_cast<std::uintptr_t>(object[0x64u/4u]));
    if(!text)return false;
    const char* expected="subject";unsigned n=0;
    for(;expected[n];++n){const auto c=text[n];if(c!=expected[n]&&c!=expected[n]-32)return false;}
    return text[n]==0||text[n]==u':';
}
Word* FindSubjectLabel(const char* package,Word* subject) {
    __try {
        for(const char* name:{"SUBJECT","SUBJECT_LABEL","SUBJECT_TITLE","SUBJECT_HEADING"}) {
            auto* label=Find(package,Hash(name));if(IsString(label))return label;
        }


        for(unsigned direction:{1u,2u}) {
            Word* node=subject;
            for(unsigned count=0;node&&count<64;++count) {
                node=reinterpret_cast<Word*>(static_cast<std::uintptr_t>(node[direction]));
                if(!node||node==subject)break;
                if(SubjectLabel(node))return node;
            }
        }
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
    return nullptr;
}
void RememberLabel(Word* label) {
    if(!label)return;
    auto found=labelBackups.find(label);
    if(found!=labelBackups.end()&&found->second.guid==label[3])return;
    LabelBackup backup;backup.guid=label[3];backup.flags=label[7];backup.format=label[0x6Cu/4u];
    const auto* text=reinterpret_cast<const char16_t*>(static_cast<std::uintptr_t>(label[0x64u/4u]));
    if(text)for(unsigned n=0;n<64&&text[n];++n)backup.text+=text[n];
    labelBackups[label]=backup;
}
void RestoreLabel(Word* label,const LabelBackup& backup) {
    __try {
        if(!IsString(label)||label[3]!=backup.guid)return;
        reinterpret_cast<void(__cdecl*)(Word*,const char16_t*)>(0x515CC0u)(label,backup.text.c_str());
        label[7]=backup.flags|(1u<<22u)|(1u<<25u);label[0x6Cu/4u]=backup.format;
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
}
void RestoreLabels() {
    for(auto& pair:labelBackups){RestoreLabel(pair.first,pair.second);RestoreStyle(pair.first);}
    labelBackups.clear();
}
struct OpeningContext {Word* screen=nullptr;SMSRecord* record=nullptr;};
OpeningContext* opening=nullptr;
SMSRecord* ConstructorMessage(Word* screen) {
    __try {
        const auto offset=offsetof(PC::MenuScreen,constructor)+offsetof(PC::ConstructorData,argument);
        return screen ? reinterpret_cast<SMSRecord*>(screen[offset/4u]) : nullptr;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return nullptr;}
}
bool ResolveMessage(Word* screen,Message& m) {
    if(opening && opening->screen==screen && ForRecord(opening->record,m))return true;


    return ForRecord(ConstructorMessage(screen),m);
}
void __fastcall Header(Word* screen,void*) {
    Message m;
    if(!ResolveMessage(screen,m)) {
        RestoreLabels();const char* package=Package(screen);
        if(package){RestoreStyle(Find(package,0xFECED617u));RestoreStyle(Find(package,0x2C167533u));}
        reinterpret_cast<void(__thiscall*)(Word*)>(0x531CF0u)(screen);return;
    }
    const char* package=Package(screen);if(!package)return;
    auto* from=Find(package,0xFECED617u);auto* subject=Find(package,0x2C167533u);
    Word* label=FindSubjectLabel(package,subject);
    if(label) {
        RememberLabel(label);Literal(label,"To:\nSubject:");Literal(from,m.from);Literal(subject,m.to+"\n"+m.subject);
    } else {


        Literal(from,m.from);Literal(subject,m.subject+"\nTo: "+m.to);
        static bool warned=false;if(!warned){warned=true;NFSMWAP::Log("AP SMS: subject caption unavailable; To field placed below subject.");}
    }
}
void BodyLiteral(const char* package,bool restore=false) {
    for(unsigned n=1;n<=10;++n) {
        const auto name="MESSAGE_TEXT_"+std::to_string(n);auto* text=Find(package,Hash(name.c_str()));
        if(restore){RestoreStyle(text);continue;}
        if(IsString(text)){RememberStyle(text);text[7]=(text[7]&~0x20u)|NFSMWAP::FERewardLiteral;}
    }
}
Word* TextOwner(Word* scroller) {
    __try {return scroller ? reinterpret_cast<Word*>(scroller[offsetof(PC::TextScroller,owner)/4u]) : nullptr;}
    __except(EXCEPTION_EXECUTE_HANDLER) {return nullptr;}
}
void __fastcall Text(Word* scroller,void*,Word hash) {
    auto* screen=TextOwner(scroller);Message m;
    const bool have=ResolveMessage(screen,m);
    const char* package=Package(screen);
    if(!have) {
        if(package)BodyLiteral(package,true);
        if(hash==Hash("SMS_MESSAGE_254")) {


            char16_t empty[1]={0};
            reinterpret_cast<void(__thiscall*)(Word*,char16_t*)>(0x59C1A0u)(scroller,empty);
            NFSMWAP::Log("AP SMS: unbound virtual message body blocked; saved mail retained.");return;
        }
        reinterpret_cast<void(__thiscall*)(Word*,Word)>(0x5A5FE0u)(scroller,hash);return;
    }
    if(package)BodyLiteral(package);
    auto wide=NFSMWAP::NativeShopWideText(m.body);
    NFSMWAP::Log("AP SMS BODY: id="+m.id+" chars="+std::to_string(wide.size()));
    reinterpret_cast<void(__thiscall*)(Word*,char16_t*)>(0x59C1A0u)(scroller,wide.data());
    NFSMWAP::Log("AP SMS BODY COMPLETE: "+m.id);
}
struct OpeningScope {
    OpeningContext* previous;
    explicit OpeningScope(OpeningContext& value):previous(opening){opening=&value;}
    ~OpeningScope(){opening=previous;}
};
void __fastcall MessageSetup(Word* screen,void*) {
    OpeningContext context{screen,ConstructorMessage(screen)};Message m;
    ForRecord(context.record,m);
    OpeningScope scope(context);
    NFSMWAP::Log("AP SMS OPEN: "+(m.id.empty()?std::string("native story"):m.id));
    reinterpret_cast<void(__thiscall*)(Word*)>(0x549150u)(screen);Header(screen,nullptr);
    NFSMWAP::Log("AP SMS OPEN COMPLETE");
}
bool __fastcall Voice(SMSRecord* record,void*) {
    Message m;if(ForRecord(record,m))return false;
    return reinterpret_cast<bool(__thiscall*)(SMSRecord*)>(0x56D750u)(record);
}
std::string InboxSubject(const Message& m) {
    std::string item=m.item;
    if(item.empty()) {
        const bool received=m.id.rfind("recv:",0)==0;
        const std::string prefix=received?m.from+" has sent ":"You have sent ";
        const std::string suffix=received?" to you.":" to "+m.to+".";
        if(m.body.size()>prefix.size()+suffix.size()&&m.body.compare(0,prefix.size(),prefix)==0&&
           m.body.compare(m.body.size()-suffix.size(),suffix.size(),suffix)==0)
            item=m.body.substr(prefix.size(),m.body.size()-prefix.size()-suffix.size());
    }
    return item.empty()?m.subject:m.subject+" - "+item;
}
bool InboxLineFits(Word fontHash,const char16_t* value,Word flags,Word width) {
    __try {
        auto* font=reinterpret_cast<void*(__cdecl*)(Word)>(0x585B50u)(fontHash);
        if(font) {
            using Height=float(__thiscall*)(void*,const char16_t*,int,Word,Word,bool);
            const auto height=reinterpret_cast<Height>(0x591FD0u);
            const auto line=height(font,u"Ag",0,flags,0,false);
            const auto actual=height(font,value,0,flags,width,true);
            if(std::isfinite(line)&&line>0&&std::isfinite(actual)&&actual>0)return actual<=line*1.05f;
        }
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
    unsigned length=0;while(value[length])++length;
    return length<=width/10u;
}
struct InboxPreview {Word guid=0,font=0,width=0,flags=0;std::string source;std::u16string text;};
std::map<Word*,InboxPreview> inboxPreviews;
void InboxLiteral(Word* text,const Message& m) {
    if(!IsString(text))return;
    RememberStyle(text);
    const Word width=std::min(500u,text[0x74u/4u]?text[0x74u/4u]:500u);
    const Word flags=(text[7]&~0x20u)|NFSMWAP::FERewardLiteral;
    const auto source=InboxSubject(m);
    auto& preview=inboxPreviews[text];
    if(preview.guid!=text[3]||preview.font!=text[0x24u/4u]||preview.width!=width||preview.flags!=flags||preview.source!=source) {
        preview.guid=text[3];preview.font=text[0x24u/4u];preview.width=width;preview.flags=flags;preview.source=source;
        preview.text=NFSMWAP::NativeShopWideText(source);
        for(auto& c:preview.text)if(c==u'\n'||c==u'\r'||c==u'\t')c=u' ';
        if(!InboxLineFits(preview.font,preview.text.c_str(),flags,width)&&m.subject=="Need for Speed: Most Wanted") {
            const auto prefix=NFSMWAP::NativeShopWideText(m.subject);
            if(preview.text.compare(0,prefix.size(),prefix)==0)preview.text.replace(0,prefix.size(),u"NFSMW");
        }
        if(!InboxLineFits(preview.font,preview.text.c_str(),flags,width)) {
            auto stem=preview.text;
            do {
                if(stem.empty()){preview.text=u"...";break;}
                stem.pop_back();
                if(!stem.empty()&&stem.back()>=0xD800u&&stem.back()<=0xDBFFu)stem.pop_back();
                preview.text=stem+u"...";
            } while(!InboxLineFits(preview.font,preview.text.c_str(),flags,width));
        }
    }
    reinterpret_cast<void(__cdecl*)(Word*,const char16_t*)>(0x515CC0u)(text,preview.text.c_str());
    text[7]=(text[7]&~0x20u)|NFSMWAP::FERewardLiteral|(1u<<22u)|(1u<<25u);
    text[NFSMWAP::FEStringFormatOffset/4u]|=NFSMWAP::FEStringWordWrap;
    text[0x74u/4u]=width;
}
void __fastcall SlotUpdate(Word* slot,void*,Word* datum,bool selected) {
    RestoreStyle(reinterpret_cast<Word*>(slot[offsetof(PC::Slot,text)/4u]));
    reinterpret_cast<void(__thiscall*)(Word*,Word*,bool)>(0x51FD60u)(slot,datum,selected);
    if(!datum)return;
    Message m;
    if(ForRecord(reinterpret_cast<SMSRecord*>(datum[offsetof(PC::Datum,message)/4u]),m)) {
        InboxLiteral(reinterpret_cast<Word*>(slot[offsetof(PC::Slot,text)/4u]),m);
        if(selected)selectedAP=m.id;
    }
}
bool SyncFlags() {
    bool changed=false;
    for(auto& pair:messages) {
        auto& m=pair.second;


        if(!m.deleted&&(m.record.flags&4u))m.read=true;
        m.record.flags=m.deleted?0:m.read?4:2;
        if(m.savedFlags!=m.record.flags)changed=true;
    }
    if(!changed)return true;
    if(!Save())return false;
    for(auto& pair:messages)pair.second.savedFlags=pair.second.record.flags;
    return true;
}
void UpdateMessageState(const std::string& id,bool remove) {
    std::lock_guard<std::mutex> lock(smsMutex);
    const auto found=messages.find(id);if(found==messages.end()||found->second.deleted)return;
    auto& m=found->second;
    if(remove)m.deleted=true;else m.read=true;
    m.record.flags=m.deleted?0:4;

    SyncFlags();
}
void __fastcall ReaderNotify(Word* screen,void*,Word message,Word* object,Word a,Word b) {
    Message m;
    if(ResolveMessage(screen,m)) {
        if(message==0x35F8620Bu)UpdateMessageState(m.id,false);
        if(message==0xD05FC3A3u)UpdateMessageState(m.id,true);
    }

    reinterpret_cast<void(__thiscall*)(Word*,Word,Word*,Word,Word)>(0x531D40u)(screen,message,object,a,b);
}
void __fastcall InboxSetup(Word* screen,void*) {
    std::vector<Message*> rows;const auto previous=selectedAP;
    {
        std::lock_guard<std::mutex> lock(smsMutex);Load();SyncFlags();
        for(auto& pair:messages)if(!pair.second.deleted)rows.push_back(&pair.second);
    }
    NFSMWAP::Log("AP SMS INBOX SETUP: queued="+std::to_string(rows.size()));
    reinterpret_cast<void(__thiscall*)(Word*)>(0x548AE0u)(screen);


    if(inboxOwner!=screen){inboxOwner=screen;inboxVoice=true;}
    if(inboxVoice)return;
    std::sort(rows.begin(),rows.end(),[](const Message* a,const Message* b){return a->sequence>b->sequence;});
    auto* scroller=reinterpret_cast<Word*>(reinterpret_cast<char*>(screen)+offsetof(PC::InboxScreen,list));
    const int start=reinterpret_cast<int(__thiscall*)(Word*)>(0x5106B0u)(scroller);
    int selection=start;
    for(std::size_t n=0;n<rows.size();++n) {
        reinterpret_cast<void(__thiscall*)(Word*,SMSRecord*)>(0x51FDF0u)(screen,&rows[n]->record);
        if(rows[n]->id==previous)selection=start+static_cast<int>(n);
    }
    if(!rows.empty()) {
        const char* package=Package(screen);
        if(package) {


            reinterpret_cast<void(__cdecl*)(const char*,Word,Word,bool)>(0x524920u)(package,0x07890734u,Hash("SHOW"),true);
            if(std::any_of(rows.begin(),rows.end(),[](const Message* m){return (m->record.flags&2u)!=0;}))
                reinterpret_cast<void(__cdecl*)(const char*,Word,Word,bool)>(0x524920u)(package,0x0D6FD6F9u,0x249DB7B7u,true);
        }
        reinterpret_cast<void(__thiscall*)(Word*,int)>(0x593560u)(scroller,selection);
        const auto* datum=reinterpret_cast<Word*(__thiscall*)(Word*)>(0x5106C0u)(scroller);


        reinterpret_cast<void(__thiscall*)(Word*)>(0x5931B0u)(scroller);

        if(datum)*reinterpret_cast<Word*>(0x91CA50u)=datum[offsetof(PC::Datum,message)/4u];
    }
    NFSMWAP::Log("AP SMS INBOX COMPLETE: appended="+std::to_string(rows.size()));
}
void __fastcall InitialInboxSetup(Word* screen,void*) {
    bool haveMail=false;
    {
        std::lock_guard<std::mutex> lock(smsMutex);Load();
        for(const auto& pair:messages)if(!pair.second.deleted) {haveMail=true;break;}
    }


    inboxOwner=screen;inboxVoice=true;
    const auto* argument=ConstructorMessage(screen);
    const bool wantText=argument ? !Voice(const_cast<SMSRecord*>(argument),nullptr) : haveMail;
    if(wantText){inboxVoice=false;reinterpret_cast<void(__thiscall*)(Word*,int)>(0x549130u)(screen,1);}
    else InboxSetup(screen,nullptr);
}
void __fastcall InboxNotify(Word* screen,void*,Word message,Word* object,Word a,Word b) {
    if(inboxOwner!=screen){inboxOwner=screen;inboxVoice=true;}


    if(message==0x9120409Eu||message==0xB5971BF1u)inboxVoice=!inboxVoice;
    if(message==0xD05FC3A3u) {

        auto* scroller=reinterpret_cast<Word*>(reinterpret_cast<char*>(screen)+offsetof(PC::InboxScreen,list));
        auto* datum=reinterpret_cast<Word*(__thiscall*)(Word*)>(0x5106C0u)(scroller);Message m;
        if(datum&&ForRecord(reinterpret_cast<SMSRecord*>(datum[offsetof(PC::Datum,message)/4u]),m))UpdateMessageState(m.id,true);
    }
    reinterpret_cast<void(__thiscall*)(Word*,Word,Word*,Word,Word)>(0x5534F0u)(screen,message,object,a,b);
}
void __fastcall InboxScrollerNotify(Word* scroller,void*,Word message,Word* object,Word a,Word b) {


    auto* screen=reinterpret_cast<Word*>(reinterpret_cast<char*>(scroller)-offsetof(PC::InboxScreen,list));
    InboxNotify(screen,nullptr,message,object,a,b);
}
bool VanillaUnread(Word settings) {
    __try {
        const auto manager=*reinterpret_cast<Word*>(0x91E00Cu);
        if(manager&&reinterpret_cast<bool(__thiscall*)(void*)>(0x5EDFC0u)(reinterpret_cast<void*>(manager)))return true;
        const auto* records=reinterpret_cast<const SMSRecord*>(settings+0x12u);
        for(unsigned n=0;n<150;++n)if(records[n].handle!=255u&&(records[n].flags&2u))return true;
        return false;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return true;}
}
bool IncomingIcon(bool show) {
    __try {
        const auto feng=*reinterpret_cast<Word*>(0x91CADCu);if(!feng)return false;


        reinterpret_cast<void(__thiscall*)(void*,Word,const char*,Word*)>(0x516C90u)(
            reinterpret_cast<void*>(feng),Hash(show?"SHOW_INCOMING":"HIDE_INCOMING"),nullptr,nullptr);
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool PhoneWait(unsigned reason,const char* detail) {


    if(!(arrivalWaitReasons&reason)) {
        arrivalWaitReasons|=reason;
        NFSMWAP::Log(std::string("AP SMS ARRIVAL WAIT: ")+detail);
    }
    return false;
}
bool RequestPhonePulse() {
    __try {
        if(*reinterpret_cast<int*>(0x925E90u)!=6)return PhoneWait(1u,"gameplay HUD not active");
        if(reinterpret_cast<bool(__thiscall*)(void*)>(0x64B680u)(reinterpret_cast<void*>(0x925E70u)))return PhoneWait(2u,"game paused");
        const auto card=*reinterpret_cast<Word*>(0x91CB20u);
        if(card&&reinterpret_cast<bool(__thiscall*)(void*)>(0x50EC90u)(reinterpret_cast<void*>(card)))return PhoneWait(4u,"native autosave active");
        const auto local=reinterpret_cast<Word*(__cdecl*)(int)>(0x425200u)(1);
        if(!local)return PhoneWait(8u,"local player unavailable");
        const auto playerTable=reinterpret_cast<const Word*>(*local);

        if(!playerTable||playerTable[8]!=0x6F8F10u)return PhoneWait(16u,"local player GetHud entry not recognized");
        const auto hud=reinterpret_cast<Word*(__thiscall*)(Word*)>(playerTable[8])(local);
        if(!hud)return PhoneWait(32u,"local player HUD unavailable");
        const auto hudTable=reinterpret_cast<const Word*>(*hud);
        if(!hudTable||hudTable[5]!=0x569680u||hudTable[6]!=0x5A0C20u)return PhoneWait(64u,"native HUD entries not recognized");
        if(!reinterpret_cast<bool(__thiscall*)(Word*)>(hudTable[5])(hud)||
           !reinterpret_cast<bool(__thiscall*)(Word*)>(hudTable[6])(hud))return PhoneWait(128u,"native HUD not loaded or visible");
        Word* zone=nullptr;


        if(!reinterpret_cast<bool(__thiscall*)(Word*,Word*&)>(0x579100u)(hud,zone)||!zone)return PhoneWait(256u,"HUD phone interface unavailable");
        const auto table=reinterpret_cast<const Word*>(*zone);


        if(!table||table[1]!=0x569010u||table[7]!=0x5A0640u)return PhoneWait(512u,"native phone entries not recognized");


        if(!reinterpret_cast<bool(__thiscall*)(Word*)>(table[1])(zone))return PhoneWait(1024u,"native phone cluster waiting for roaming");
        reinterpret_cast<void(__thiscall*)(Word*)>(table[7])(zone);
        IncomingIcon(true);
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return PhoneWait(2048u,"native phone lookup fault; arrival retained");}
}
struct Patch {std::uintptr_t address;Word old,value;};
bool Write(const Patch& p) {
    DWORD old=0,unused=0;if(*reinterpret_cast<Word*>(p.address)!=p.old || !VirtualProtect(reinterpret_cast<void*>(p.address),4,PAGE_EXECUTE_READWRITE,&old))return false;
    *reinterpret_cast<Word*>(p.address)=p.value;VirtualProtect(reinterpret_cast<void*>(p.address),4,old,&unused);
    FlushInstructionCache(GetCurrentProcess(),reinterpret_cast<void*>(p.address),4);return true;
}
void Calls(std::vector<Patch>& list,Word begin,Word end,Word target,const void* hook) {
    for(std::uintptr_t p=begin;p+5<=end;++p)if(*reinterpret_cast<unsigned char*>(p)==0xE8u) {
        const auto old=*reinterpret_cast<std::int32_t*>(p+1);
        if(p+5+old==target){list.push_back({p+1,static_cast<Word>(old),static_cast<Word>(reinterpret_cast<std::uintptr_t>(hook)-p-5)});p+=4;}
    }
}
bool HasStore(Word begin,Word end,Word offset) {
    for(std::uintptr_t p=begin;p+3<=end;++p) {
        const auto opcode=*reinterpret_cast<unsigned char*>(p);
        if(opcode!=0x89u&&opcode!=0xC6u&&opcode!=0xC7u)continue;
        const auto modrm=*reinterpret_cast<unsigned char*>(p+1);

        if((modrm&7u)==4u)continue;
        if((modrm&0xC0u)==0x40u&&*reinterpret_cast<unsigned char*>(p+2)==offset)return true;
        if((modrm&0xC0u)==0x80u&&p+6<=end&&*reinterpret_cast<Word*>(p+2)==offset)return true;
    }
    return false;
}
bool LayoutMatchesCode() {
    const bool datum=HasStore(0x51FCB0u,0x51FCCFu,offsetof(PC::Datum,message));
    if(!datum) {
        NFSMWAP::Log("AP SMS PC layout validation failed: datum="+std::to_string(datum)+
            "; native SMS left unpatched.");
        return false;
    }
    return true;
}
bool Install() {
    if(!LayoutMatchesCode())return false;
    std::vector<Patch> list;
    Calls(list,0x549150u,0x549275u,0x5A5FE0u,reinterpret_cast<void*>(&Text));
    if(list.size()!=1)return false;
    Calls(list,0x553810u,0x5538E0u,0x549150u,reinterpret_cast<void*>(&MessageSetup));
    if(list.size()!=2)return false;
    Calls(list,0x549150u,0x549275u,0x531CF0u,reinterpret_cast<void*>(&Header));
    for(std::uintptr_t p=0x890000u;p<0x8C0000u;p+=4u)
        if(*reinterpret_cast<Word*>(p)==0x51FD60u)list.push_back({p,0x51FD60u,static_cast<Word>(reinterpret_cast<std::uintptr_t>(&SlotUpdate))});
    if(list.size()<3||list.size()>6)return false;
    unsigned notifyTables=0;
    for(std::uintptr_t p=0x890000u;p<0x8C0000u;p+=4u)
        if(*reinterpret_cast<Word*>(p)==0x5534F0u){list.push_back({p,0x5534F0u,static_cast<Word>(reinterpret_cast<std::uintptr_t>(&InboxNotify))});++notifyTables;}
    if(!notifyTables||notifyTables>2)return false;
    unsigned scrollerTables=0;
    for(std::uintptr_t p=0x890000u;p<0x8C0000u;p+=4u)
        if(*reinterpret_cast<Word*>(p)==0x559FA0u){list.push_back({p,0x559FA0u,static_cast<Word>(reinterpret_cast<std::uintptr_t>(&InboxScrollerNotify))});++scrollerTables;}
    if(scrollerTables!=1)return false;
    unsigned readerTables=0;
    for(std::uintptr_t p=0x890000u;p<0x8C0000u;p+=4u)
        if(*reinterpret_cast<Word*>(p)==0x531D40u){list.push_back({p,0x531D40u,static_cast<Word>(reinterpret_cast<std::uintptr_t>(&ReaderNotify))});++readerTables;}
    if(!readerTables||readerTables>2)return false;
    const auto before=list.size();
    Calls(list,0x553260u,0x55349Eu,0x548AE0u,reinterpret_cast<void*>(&InitialInboxSetup));
    if(list.size()!=before+1)return false;
    const auto other=list.size();
    Calls(list,0x5534F0u,0x553803u,0x548AE0u,reinterpret_cast<void*>(&InboxSetup));
    Calls(list,0x549130u,0x549149u,0x548AE0u,reinterpret_cast<void*>(&InboxSetup));
    if(list.size()<other+2)return false;
    for(const auto& range:std::vector<std::pair<Word,Word>>{{0x549150u,0x549275u},{0x531D40u,0x531E9Du},
        {0x511FA0u,0x511FC6u},{0x51FDF0u,0x51FEB8u},{0x553260u,0x55349Eu},{0x548AE0u,0x549124u}})
        Calls(list,range.first,range.second,0x56D750u,reinterpret_cast<void*>(&Voice));
    std::size_t n=0;for(;n<list.size();++n)if(!Write(list[n]))break;
    if(n!=list.size()){while(n){const auto p=list[--n];Write({p.address,p.value,p.old});}return false;}
    NFSMWAP::Log("NFSMW_AP_NATIVE_SMS_V8: phone interface queried from local player HUD; native roaming gate; immediate inbox repaint; item transfers only.");return true;
}

}
namespace NFSMWAP {
void PersistNativeSMS(const std::string& packet) {
    std::string id,key;bool durable=false,added=false;
    {
        std::lock_guard<std::mutex> lock(smsMutex);Load();Message m;
        if(!loaded||!Parse(packet,m))return;
        id=m.id;key=session;
        if(!messages.count(id)){m.sequence=++nextSequence;m.record.order=static_cast<std::uint16_t>(m.sequence);messages.emplace(id,m);added=true;if(!arrivalPending)arrivalWaitReasons=0;arrivalPending=true;}
        durable=Save();
    }
    Log("AP SMS STORE: id="+id+" new="+(added?"yes":"no")+" durable="+(durable?"yes":"no"));
    if(durable)SendBridgeLine("{\"type\":\"sms_notification_ack\",\"id\":\""+JsonLite::Escape(id)+"\",\"session_key\":\""+JsonLite::Escape(key)+"\"}");
}
void RegisterNativeSMS(const std::string& packet) {
    std::string id,key;char expected[512]={};
    const auto size=GetEnvironmentVariableA("NFSMW_AP_SESSION_KEY",expected,sizeof(expected));
    if(!size||size>=sizeof(expected)||packet.size()>24576 ||
       !JsonLite::GetString(packet,"id",id)||!ItemMessageID(id)||id.size()>160 ||
       !JsonLite::GetString(packet,"session_key",key)||key!=expected)return;
    std::lock_guard<std::mutex> lock(smsMutex);
    if(queuedPackets.emplace(id,packet).second)queuedOrder.push_back(id);
}
void NativeSMSMainThreadTick() {
    std::vector<std::string> pending;
    {std::lock_guard<std::mutex> lock(smsMutex);
        for(const auto& id:queuedOrder)pending.push_back(std::move(queuedPackets.at(id)));
        queuedPackets.clear();queuedOrder.clear();}
    for(const auto& packet:pending)PersistNativeSMS(packet);
    Word settings=0;if(!ReadCareer(settings))return;
    if(!hooksReady) {
        const auto now=GetTickCount();if(lastHookTry&&now-lastHookTry<5000u)return;lastHookTry=now;
        hooksReady=Install();if(!hooksReady){Log("AP SMS: native hook validation failed; messages remain queued in the session journal.");return;}
    }

    bool unread=false;
    {
        std::lock_guard<std::mutex> lock(smsMutex);Load();if(loaded)SyncFlags();
        for(const auto& pair:messages)if(!pair.second.deleted&&(pair.second.record.flags&2u)){unread=true;break;}
        if(!unread){arrivalPending=false;arrivalWaitReasons=0;}
    }
    if(unread&&arrivalPending&&RequestPhonePulse()) {
        arrivalPending=false;arrivalWaitReasons=0;incomingShown=true;Log("AP SMS ARRIVAL: local HUD phone interface requested.");
    }
    if(!unread&&incomingShown&&!VanillaUnread(settings)&&IncomingIcon(false))incomingShown=false;
}
}
