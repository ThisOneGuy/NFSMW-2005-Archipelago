#pragma once
#include <string>
namespace NFSMWAP {
    void RegisterNativeSMS(const std::string& packet);
    void NativeSMSMainThreadTick();
}
