#pragma once
#include <cstdint>
#include <string>
namespace NFSMWAP {
    void ObserveNativeRaceReward(const char* eventID,void* raceParameters=nullptr);
    void RegisterNativeReward(const std::string& packet);
    bool InstallNativeRewardHooks();
    void NativeRewardMainThreadTick();
    void ReportViewedShopLocation(int location);
    bool WriteNativeRewardText(const char* package,std::uint32_t hash,const std::string& text);
}
