#include "FinalEscape.h"
#include "CareerBootstrap.h"
#include "GameEventJournal.h"
#include "JsonLite.h"
#include "Logger.h"
#include <Windows.h>
#include <cstdint>
#include <cstring>
#include <mutex>
#include <vector>
namespace {
using Word=std::uint32_t;
struct Evidence {char profile[32]{},event[128]{};};
Evidence pending;
bool dirty=false,installed=false;
std::mutex mutex;
bool Copy(const char* source,char* destination,unsigned capacity) {
    if(!source)return false;
    for(unsigned n=0;n<capacity;++n){destination[n]=source[n];if(!source[n])return n!=0;}
    return false;
}
bool Capture(bool evaded,Evidence& evidence) {
    __try {
        if(!evaded||!NFSMWAP::IsCareerProfileReady()||*reinterpret_cast<int*>(0x925E90u)!=6)return false;
        const Word frontend=*reinterpret_cast<Word*>(0x91CF90u);
        const Word database=*reinterpret_cast<Word*>(0x91E004u),status=*reinterpret_cast<Word*>(0x91E000u);
        if(!frontend||!database||!status)return false;
        const Word flags=*reinterpret_cast<Word*>(frontend+0x12Cu),profile=*reinterpret_cast<Word*>(frontend+0x10u);
        if(!(flags&1u)||(flags&0xEu)||profile<0x10000u||!(*reinterpret_cast<unsigned char*>(profile+0x20u)))return false;
        auto* parameters=*reinterpret_cast<void**>(status+0x1968u);if(!parameters)return false;
        const bool epic=reinterpret_cast<bool(__thiscall*)(void*)>(0x5FC560u)(parameters);
        if(!epic)return false;
        const auto* event=reinterpret_cast<const char*(__thiscall*)(void*)>(0x5FBA70u)(parameters);
        const auto* expected=reinterpret_cast<const char*(__thiscall*)(void*)>(0x565DE0u)(reinterpret_cast<void*>(database));
        char finalEvent[128]{};
        if(!Copy(event,evidence.event,sizeof(evidence.event))||!Copy(expected,finalEvent,sizeof(finalEvent)))return false;
        return NFSMWAP::FinalEscapeSucceeded(true,true,epic,std::strcmp(evidence.event,finalEvent)==0,evaded)&&
            Copy(reinterpret_cast<const char*>(profile),evidence.profile,sizeof(evidence.profile));
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
void __fastcall PursuitEnded(void* manager,void*,bool evaded) {
    Evidence evidence;const bool success=Capture(evaded,evidence);
    reinterpret_cast<void(__thiscall*)(void*,bool)>(0x602770u)(manager,evaded);
    if(success){std::lock_guard<std::mutex> lock(mutex);pending=evidence;dirty=true;}
}
struct Patch {Word address,before,after;};
bool Write(const Patch& patch) {
    __try {
        auto* target=reinterpret_cast<Word*>(patch.address);DWORD protection=0;
        if(*target!=patch.before||!VirtualProtect(target,4,PAGE_EXECUTE_READWRITE,&protection))return false;
        *target=patch.after;DWORD ignored=0;VirtualProtect(target,4,protection,&ignored);
        FlushInstructionCache(GetCurrentProcess(),target,4);return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
}
namespace NFSMWAP {
bool InstallFinalEscapeHooks() {
    if(installed)return true;
    std::vector<Patch> patches;
    for(Word address=0x401000u;address+5u<0x890000u;++address) {
        const auto opcode=*reinterpret_cast<const unsigned char*>(address);
        if(opcode!=0xE8u&&opcode!=0xE9u)continue;
        const Word old=*reinterpret_cast<const Word*>(address+1u);
        if(address+5u+old!=0x602770u)continue;
        patches.push_back({address+1u,old,static_cast<Word>(reinterpret_cast<std::uintptr_t>(&PursuitEnded)-address-5u)});
        address+=4u;
    }
    if(patches.empty()||patches.size()>32u){Log("AP FINAL ESCAPE: native pursuit-end references did not match.");return false;}
    std::size_t count=0;for(;count<patches.size();++count)if(!Write(patches[count]))break;
    if(count!=patches.size()) {
        while(count){const auto& p=patches[--count];Write({p.address,p.after,p.before});}return false;
    }
    installed=true;Log("NFSMW_AP_GOALS_V1: final-escape completion follows a successful native final pursuit.");return true;
}
void FinalEscapeMainThreadTick() {
    Evidence evidence;
    {std::lock_guard<std::mutex> lock(mutex);if(!dirty)return;evidence=pending;}
    const std::string payload="{\"type\":\"final_escape_complete\",\"career_mode\":true,\"source\":\"native_final_escape\",\"epic_pursuit\":true,\"evaded\":true,\"profile_name\":\""+
        JsonLite::Escape(evidence.profile)+"\",\"event_id\":\""+JsonLite::Escape(evidence.event)+"\"}";
    if(RecordGameEvent("career:final_escape",payload)) {
        std::lock_guard<std::mutex> lock(mutex);dirty=false;
    }
}
}
