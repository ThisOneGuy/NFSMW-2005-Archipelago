#include "BlacklistNames.h"
#include "BridgeClient.h"
#include "BuildVersion.h"
#include "BountyRequirements.h"
#include "CareerBootstrap.h"

#include <atomic>
#include <condition_variable>
#include <deque>
#include <thread>
#include <mutex>
#include <sstream>
#include <string>

#include "ItemInventory.h"
#include "TurboTrap.h"
#include "ConnectionSetup.h"
#include "JsonLite.h"
#include "Logger.h"
#include "NotificationOverlay.h"
#include "ShopCatalog.h"
#include "SeedConfig.h"
#include "StoreRuntime.h"
#include "MilestoneJournal.h"
#include "GameEventJournal.h"
#include "DeathLinkRuntime.h"
#include "CashDelivery.h"
#include "NativeRewardUI.h"
#include "NativeSMS.h"

namespace
{
    std::string g_host = "127.0.0.1";
    int g_port = 38283;

    SOCKET g_socket = INVALID_SOCKET;
    std::mutex g_socketMutex;
    std::atomic_bool g_connected{ false };
    struct Outbound {std::uint64_t generation;std::string payload;};
    std::mutex g_outboundMutex;
    std::condition_variable g_outboundReady;
    std::deque<Outbound> g_outbound;
    std::size_t g_outboundBytes=0;
    std::atomic<std::uint64_t> g_generation{0};


    void CloseSocketLocked()
    {
        if (g_socket != INVALID_SOCKET)
        {
            shutdown(g_socket, SD_BOTH);
            closesocket(g_socket);
            g_socket = INVALID_SOCKET;
        }
        g_connected = false;
        ++g_generation;
        {std::lock_guard<std::mutex> queueLock(g_outboundMutex);g_outbound.clear();g_outboundBytes=0;}
        NFSMWAP::SetMultiworldStatus(false);
    }

    SOCKET ConnectSocket()
    {
        addrinfo hints{};
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_STREAM;
        hints.ai_protocol = IPPROTO_TCP;

        addrinfo* result = nullptr;
        const std::string portString = std::to_string(g_port);

        if (getaddrinfo(
                g_host.c_str(),
                portString.c_str(),
                &hints,
                &result) != 0)
        {
            return INVALID_SOCKET;
        }

        SOCKET connectedSocket = INVALID_SOCKET;
        for (addrinfo* ptr = result; ptr != nullptr; ptr = ptr->ai_next)
        {
            SOCKET candidate = socket(
                ptr->ai_family,
                ptr->ai_socktype,
                ptr->ai_protocol);

            if (candidate == INVALID_SOCKET)
                continue;

            if (connect(
                    candidate,
                    ptr->ai_addr,
                    static_cast<int>(ptr->ai_addrlen)) == 0)
            {
                connectedSocket = candidate;
                break;
            }

            closesocket(candidate);
        }

        freeaddrinfo(result);
        return connectedSocket;
    }

    bool StartsWithType(const std::string& line, const char* type)
    {
        std::string actual;
        return NFSMWAP::JsonLite::GetString(line, "type", actual) && actual == type;
    }

    void HandleSeedConfig(const std::string& line)
    {
        bool performance=true,visual=true,rewards=true,permits=false;
        NFSMWAP::JsonLite::GetBool(line,"shuffle_performance_parts",performance);
        NFSMWAP::JsonLite::GetBool(line,"visual_store_checks",visual);
        NFSMWAP::JsonLite::GetBool(line,"reveal_event_rewards",rewards);
        NFSMWAP::JsonLite::GetBool(line,"randomize_blacklist_unlocks",permits);
        int goal=1;NFSMWAP::JsonLite::GetInt(line,"goal_blacklist",goal);
        NFSMWAP::ConfigureSeedFeatures(performance,visual,rewards,permits,goal);
        std::string bountyMode="original";int bountyPercent=100;
        NFSMWAP::JsonLite::GetString(line,"bounty_mode",bountyMode);
        NFSMWAP::JsonLite::GetInt(line,"bounty_multiplier_percent",bountyPercent);
        NFSMWAP::ConfigureBountyRequirements(bountyMode,bountyPercent);
        NFSMWAP::ConfigureBlacklistNames(line);
        bool trapsEnabled=false;
        NFSMWAP::JsonLite::GetBool(line,"traps_enabled",trapsEnabled);
        NFSMWAP::SetDrivingTrapsEnabled(trapsEnabled);
        std::string startingCar;
        bool randomizeOpponentCars = false;
        int opponentSeed = 0;
        int startingCarPrice = 5000;

        NFSMWAP::JsonLite::GetString(
            line,
            "starting_car",
            startingCar);

        NFSMWAP::JsonLite::GetBool(
            line,
            "randomize_opponent_cars",
            randomizeOpponentCars);

        NFSMWAP::JsonLite::GetInt(
            line,
            "opponent_car_seed",
            opponentSeed);

        NFSMWAP::JsonLite::GetInt(
            line,
            "starting_car_price",
            startingCarPrice);

        bool dealershipFirst=false;
        NFSMWAP::JsonLite::GetBool(line,"dealership_first_start",dealershipFirst);
        NFSMWAP::SetDealershipFirstStart(dealershipFirst);
        NFSMWAP::SetSeedStartingCar(startingCar);
        NFSMWAP::SetSeedStartingCarPrice(startingCarPrice);
        bool randomizeAppearance=true;
        int appearanceSeed=opponentSeed;
        NFSMWAP::JsonLite::GetBool(line,"randomize_blacklist_appearance",randomizeAppearance);
        NFSMWAP::JsonLite::GetInt(line,"blacklist_appearance_seed",appearanceSeed);
        NFSMWAP::SetSeedBlacklistAppearanceConfig(randomizeAppearance,appearanceSeed);
        NFSMWAP::SetSeedOpponentCarConfig(
            randomizeOpponentCars,
            opponentSeed);

        NFSMWAP::Log(
            "AP SEED CAR CONFIG: starting_car='"
            + startingCar
            + "', starter_price="
            + std::to_string(startingCarPrice)
            + ", randomize_opponents="
            + (randomizeOpponentCars ? "true" : "false")
            + ", opponent_seed="
            + std::to_string(opponentSeed)
            + ".");

        if (!startingCar.empty())
        {
            NFSMWAP::QueueNotification(
                "ARCHIPELAGO SEED",
                "STARTING CAR: " + startingCar,
                "CAR CONFIG RECEIVED",
                5000);
        }
    }

    void HandleBlacklistCarConfig(const std::string& line)
    {
        int rank = 0;
        std::string car;

        NFSMWAP::JsonLite::GetInt(
            line,
            "rank",
            rank);
        NFSMWAP::JsonLite::GetString(
            line,
            "car",
            car);

        NFSMWAP::SetSeedBlacklistCar(
            rank,
            car);

        if (rank >= 1 && rank <= 15 && !car.empty())
        {
            NFSMWAP::Log(
                "AP BLACKLIST CAR CONFIG: rank #"
                + std::to_string(rank)
                + " -> "
                + car
                + ".");
        }
    }

    void HandleReceivedItem(const std::string& line)
    {
        NFSMWAP::ReceivedItem item;

        NFSMWAP::JsonLite::GetInt(line, "index", item.index);
        NFSMWAP::JsonLite::GetInt(line, "item_id", item.itemId);
        NFSMWAP::JsonLite::GetString(line, "item_name", item.itemName);
        NFSMWAP::JsonLite::GetString(line, "item_type", item.itemType);
        NFSMWAP::JsonLite::GetString(line, "car", item.car);
        NFSMWAP::JsonLite::GetString(line, "category", item.category);
        NFSMWAP::JsonLite::GetString(line, "tier", item.tier);
        NFSMWAP::JsonLite::GetString(line, "source_name", item.sourceName);

        NFSMWAP::AddReceivedItem(item);

        if (item.itemType == "car" && !item.car.empty())
            NFSMWAP::NotifyReceivedCarItem(item.index, item.itemId, item.car);

        if (item.itemType == "cash") {
            std::string session;NFSMWAP::JsonLite::GetString(line,"session_key",session);
            NFSMWAP::QueueReceivedCash(item.index,item.itemId,session);
        }
        if(item.itemType=="trap") {
            std::string session;bool trigger=false;
            NFSMWAP::JsonLite::GetString(line,"session_key",session);
            NFSMWAP::JsonLite::GetBool(line,"trap_trigger",trigger);
            NFSMWAP::QueueTurboTrap(item.index,item.itemId,session,trigger);
        }


        if (item.index >= 0 && item.itemType != "car" && item.itemType != "cash" && item.itemType != "trap")
        {
            std::ostringstream ack;
            ack << "{\"type\":\"received_item_ack\",\"index\":"
                << item.index
                << "}";
            NFSMWAP::SendBridgeLine(ack.str());
        }
    }

    void HandleShopSlot(const std::string& line)
    {
        NFSMWAP::ShopEntry entry;
        NFSMWAP::JsonLite::GetInt(line, "location_id", entry.locationId);
        NFSMWAP::JsonLite::GetString(line, "location_type", entry.locationType);
        NFSMWAP::JsonLite::GetString(line, "location_name", entry.locationName);
        NFSMWAP::JsonLite::GetString(line, "car", entry.car);
        NFSMWAP::JsonLite::GetString(line, "category", entry.category);
        NFSMWAP::JsonLite::GetString(line, "tier", entry.tier);
        NFSMWAP::JsonLite::GetInt(line, "price", entry.price);
        NFSMWAP::JsonLite::GetInt(line, "item_id", entry.itemId);
        NFSMWAP::JsonLite::GetString(line, "item_name", entry.itemName);
        NFSMWAP::JsonLite::GetString(line, "item_type", entry.itemType);
        NFSMWAP::JsonLite::GetString(line, "item_car", entry.itemCar);
        NFSMWAP::JsonLite::GetString(line, "item_category", entry.itemCategory);
        NFSMWAP::JsonLite::GetString(line, "item_tier", entry.itemTier);
        NFSMWAP::JsonLite::GetInt(line, "recipient_player", entry.recipientPlayer);
        NFSMWAP::JsonLite::GetString(line, "recipient_name", entry.recipientName);
        NFSMWAP::JsonLite::GetString(line, "recipient_game", entry.recipientGame);
        NFSMWAP::JsonLite::GetBool(line, "recipient_is_local", entry.recipientIsLocal);
        NFSMWAP::JsonLite::GetInt(line, "flags", entry.flags);
        NFSMWAP::JsonLite::GetBool(line, "checked", entry.checked);
        NFSMWAP::UpdateShopEntry(entry);
    }

    void HandleRaceAck(const std::string& line)
    {
        bool sent = false;
        bool won = false;
        int locationId = 0;
        std::string eventId;
        std::string locationName;
        std::string reason;

        NFSMWAP::JsonLite::GetBool(line, "won", won);
        NFSMWAP::JsonLite::GetBool(line, "location_sent", sent);
        NFSMWAP::JsonLite::GetInt(line, "location_id", locationId);
        NFSMWAP::JsonLite::GetString(line, "event_id", eventId);
        NFSMWAP::JsonLite::GetString(line, "location_name", locationName);
        NFSMWAP::JsonLite::GetString(line, "reason", reason);

        if (sent)
        {
            NFSMWAP::QueueNotification(
                "ARCHIPELAGO LOCATION CHECK",
                locationName.empty() ? std::string("RACE WIN SENT") : locationName,
                eventId.empty() ? std::string("CHECK SENT") : std::string("EVENT: ") + eventId,
                3500);
        }
        else if (won && reason == "already_checked")
        {
            NFSMWAP::QueueNotification(
                "ARCHIPELAGO",
                "RACE ALREADY CHECKED",
                locationName.empty() ? eventId : locationName,
                3500);
        }
        else if (won && reason == "already_pending")
        {
            NFSMWAP::QueueNotification(
                "ARCHIPELAGO",
                "LOCATION CHECK ALREADY PENDING",
                locationName.empty() ? eventId : locationName,
                3500);
        }
        else if (won && reason == "queued_until_ap_connected")
        {
            NFSMWAP::QueueNotification(
                "ARCHIPELAGO CHECK QUEUED",
                locationName.empty() ? std::string("RACE WIN SAVED") : locationName,
                "WAITING FOR AP CONNECTION",
                5000);
        }
        else if (won && reason == "unmapped_event")
        {
            NFSMWAP::QueueNotification(
                "ARCHIPELAGO",
                "RACE WON - EVENT NOT MAPPED YET",
                eventId,
                4500);
        }
    }

    void HandleBlacklistDefeatAck(const std::string& line)
    {
        bool sent = false;
        int rank = 0;
        int locationId = 0;
        std::string locationName;
        std::string reason;

        NFSMWAP::JsonLite::GetBool(line, "location_sent", sent);
        NFSMWAP::JsonLite::GetInt(line, "blacklist_rank", rank);
        NFSMWAP::JsonLite::GetInt(line, "location_id", locationId);
        NFSMWAP::JsonLite::GetString(line, "location_name", locationName);
        NFSMWAP::JsonLite::GetString(line, "reason", reason);

        if (sent)
        {
            NFSMWAP::QueueNotification(
                "ARCHIPELAGO BLACKLIST CHECK",
                locationName.empty() ? std::string("BLACKLIST DEFEATED") : locationName,
                rank > 0 ? std::string("RANK #") + std::to_string(rank) + " CHECK SENT" : std::string("CHECK SENT"),
                5000);
        }
        else if (reason == "already_checked")
        {
            NFSMWAP::QueueNotification(
                "ARCHIPELAGO BLACKLIST",
                "DEFEAT ALREADY CHECKED",
                locationName.empty() ? std::string("RANK #") + std::to_string(rank) : locationName,
                4000);
        }
        else if (reason == "queued_until_ap_connected")
        {
            NFSMWAP::QueueNotification(
                "ARCHIPELAGO CHECK QUEUED",
                locationName.empty() ? std::string("BLACKLIST DEFEATED") : locationName,
                "WAITING FOR AP CONNECTION",
                5000);
        }
        else if (reason == "defeat_location_not_in_seed")
        {
            NFSMWAP::QueueNotification(
                "ARCHIPELAGO BLACKLIST",
                "RIVAL WON - DEFEAT LOCATION MISSING",
                "UPDATE/REGENERATE AP WORLD IF NEEDED",
                6000);
        }
    }

    void HandleMilestoneAck(const std::string& line)
    {
        bool sent = false;
        int locationId = 0;
        int blacklistRank = 0;
        std::string locationName;
        std::string category;
        std::string metricName;
        std::string reason;

        NFSMWAP::JsonLite::GetBool(
            line,
            "location_sent",
            sent);

        NFSMWAP::JsonLite::GetInt(
            line,
            "location_id",
            locationId);

        NFSMWAP::JsonLite::GetInt(
            line,
            "blacklist_rank",
            blacklistRank);

        NFSMWAP::JsonLite::GetString(
            line,
            "location_name",
            locationName);

        NFSMWAP::JsonLite::GetString(
            line,
            "category",
            category);

        NFSMWAP::JsonLite::GetString(
            line,
            "metric_name",
            metricName);

        NFSMWAP::JsonLite::GetString(
            line,
            "reason",
            reason);

        if (sent)
        {
            std::string detail =
                category.empty()
                    ? std::string("MILESTONE CHECK SENT")
                    : category;

            if (blacklistRank > 0)
            {
                detail +=
                    " / BL#"
                    + std::to_string(
                        blacklistRank);
            }

            NFSMWAP::QueueNotification(
                "ARCHIPELAGO LOCATION CHECK",
                locationName.empty()
                    ? std::string("MILESTONE SENT")
                    : locationName,
                detail,
                5000);
        }
        else if (
            reason == "queued_until_ap_connected")
        {
            NFSMWAP::QueueNotification(
                "ARCHIPELAGO CHECK QUEUED",
                locationName.empty()
                    ? std::string("MILESTONE")
                    : locationName,
                "WAITING FOR AP CONNECTION",
                5000);
        }
        else if (
            reason != "already_checked" &&
            reason != "already_pending" &&
            reason != "already_queued")
        {
            NFSMWAP::QueueNotification(
                "ARCHIPELAGO MILESTONE",
                "CHECK NOT SENT",
                reason.empty()
                    ? metricName
                    : reason,
                4000);
        }
    }

    void HandleDeferredLocationCheck(const std::string& line)
    {
        int locationId = 0;
        std::string locationName;

        NFSMWAP::JsonLite::GetInt(line, "location_id", locationId);
        NFSMWAP::JsonLite::GetString(line, "location_name", locationName);

        NFSMWAP::QueueNotification(
            "ARCHIPELAGO LOCATION CHECK",
            locationName.empty() ? std::string("QUEUED CHECK SENT") : locationName,
            "SENT AFTER AP CONNECTED",
            4500);
    }

    void HandleShopPurchaseAck(const std::string& line)
    {
        bool accepted = false;
        int locationId = 0;
        int requestId = 0;
        std::string reason;
        std::string itemName;
        std::string recipientName;

        NFSMWAP::JsonLite::GetBool(line, "accepted", accepted);
        NFSMWAP::JsonLite::GetInt(line, "location_id", locationId);
        NFSMWAP::JsonLite::GetInt(line, "request_id", requestId);
        NFSMWAP::JsonLite::GetString(line, "reason", reason);
        NFSMWAP::JsonLite::GetString(line, "item_name", itemName);
        NFSMWAP::JsonLite::GetString(line, "recipient_name", recipientName);

        NFSMWAP::NotifyShopPurchaseAck(locationId, requestId, accepted, reason);

        if (accepted)
        {
            NFSMWAP::SetShopEntryChecked(locationId, true);
        }
        else if (reason != "already_checked" && reason != "already_pending")
        {
            NFSMWAP::QueueNotification(
                "ARCHIPELAGO SHOP",
                "PURCHASE CHECK NOT SENT",
                reason,
                4000);
        }
    }

    void HandleBridgeLine(const std::string& line)
    {
        std::string type;
        if (!NFSMWAP::JsonLite::GetString(line, "type", type))
        {
            NFSMWAP::Log("Unrecognized bridge message discarded.");
            return;
        }

        if (type=="deathlink_config" || type=="deathlink_received") {
            std::string key,id,source;bool enabled=false;
            NFSMWAP::JsonLite::GetString(line,"session_key",key);
            if (type=="deathlink_config") {
                NFSMWAP::JsonLite::GetBool(line,"enabled",enabled);NFSMWAP::ConfigureDeathLink(enabled,key);
            } else {
                NFSMWAP::JsonLite::GetString(line,"id",id);NFSMWAP::JsonLite::GetString(line,"source",source);
                NFSMWAP::ReceiveDeathLink(id,source,key);
            }
            return;
        }
        if (type=="deathlink_start") {
            std::string key,id,runtime;bool allowed=false;
            NFSMWAP::JsonLite::GetString(line,"session_key",key);NFSMWAP::JsonLite::GetString(line,"id",id);
            NFSMWAP::JsonLite::GetString(line,"runtime_id",runtime);NFSMWAP::JsonLite::GetBool(line,"authorized",allowed);
            NFSMWAP::AuthorizeDeathLink(id,runtime,key,allowed);return;
        }
        if (type=="deathlink_sent") {
            std::string key;char current[512]={};NFSMWAP::JsonLite::GetString(line,"session_key",key);
            GetEnvironmentVariableA("NFSMW_AP_SESSION_KEY",current,sizeof(current));
            if (!key.empty() && key==current) NFSMWAP::QueueNotification("DEATHLINK SENT","YOU WERE ARRESTED","LINKED PLAYERS NOTIFIED",4000);
            return;
        }

        if (type == "shop_slot")
        {
            HandleShopSlot(line);
            return;
        }

        if (type == "seed_config")
        {
            HandleSeedConfig(line);
            return;
        }

        if (type == "blacklist_car_config")
        {
            HandleBlacklistCarConfig(line);
            return;
        }

        if (type=="sms_notification") {NFSMWAP::RegisterNativeSMS(line);return;}
        if (type=="reward_slot") {NFSMWAP::RegisterNativeReward(line);return;}
        if (type=="connection_status")
        {
            std::string phase,message,car,server,slot,seed;
            NFSMWAP::JsonLite::GetString(line,"phase",phase);
            NFSMWAP::JsonLite::GetString(line,"message",message);
            NFSMWAP::JsonLite::GetString(line,"first_car",car);
            NFSMWAP::JsonLite::GetString(line,"server",server);
            NFSMWAP::JsonLite::GetString(line,"slot",slot);
            NFSMWAP::JsonLite::GetString(line,"seed",seed);
            NFSMWAP::SetConnectionStatus(phase,message,car,server,slot,seed);
            return;
        }
        if (type=="request_milestone_journal") { NFSMWAP::ReplayMilestoneJournal();return; }
        if (type=="request_game_journal") { NFSMWAP::ReplayGameEvents();return; }
        if (type=="game_journal_ack") {
            std::string key,session;
            NFSMWAP::JsonLite::GetString(line,"event_key",key);
            NFSMWAP::JsonLite::GetString(line,"session_key",session);
            NFSMWAP::AcknowledgeGameEvent(key,session);return;
        }
        if (type=="milestone_journal_ack")
        {
            int location=0;std::string session;
            NFSMWAP::JsonLite::GetInt(line,"location_id",location);
            NFSMWAP::JsonLite::GetString(line,"session_key",session);
            NFSMWAP::AcknowledgeMilestoneJournal(location,session);return;
        }
        if (type=="ap_status")
        {
            bool connected=false;int queued=0;
            NFSMWAP::JsonLite::GetBool(line,"connected",connected);
            NFSMWAP::JsonLite::GetInt(line,"queued_checks",queued);
            NFSMWAP::SetMultiworldStatus(connected,queued);
            static DWORD previousReplay=0;
            if (static_cast<DWORD>(GetTickCount()-previousReplay)>3000u)
            { previousReplay=GetTickCount();NFSMWAP::ReplayMilestoneJournal();NFSMWAP::ReplayGameEvents(); }
            return;
        }
        NFSMWAP::Log("BRIDGE <- " + line);

        if (type == "received_item")
            HandleReceivedItem(line);
        else if (type == "race_result_ack")
            HandleRaceAck(line);
        else if (type == "blacklist_defeat_ack")
            HandleBlacklistDefeatAck(line);
        else if (type == "goal_complete")
            NFSMWAP::QueueNotification("ARCHIPELAGO GOAL COMPLETE", "BLACKLIST GOAL REACHED",
                                      "RELEASING ALL REMAINING CHECKS", 9000);
        else if (type == "milestone_check_ack")
            HandleMilestoneAck(line);
        else if (type == "shop_purchase_ack")
            HandleShopPurchaseAck(line);
        else if (type == "location_check_sent")
            HandleDeferredLocationCheck(line);
        else if (type == "bridge_status")
        {
            bool apConnected = false;
            NFSMWAP::JsonLite::GetBool(line,"ap_connected",apConnected);
            NFSMWAP::SetMultiworldStatus(apConnected);
            if (NFSMWAP::JsonLite::GetBool(line, "ap_connected", apConnected) && apConnected)
            {
                NFSMWAP::Log("Local bridge confirms Archipelago is connected.");
            }
        }
    }
}

namespace NFSMWAP
{
    void ConfigureBridge(const std::string& host, int port)
    {
        if (!host.empty())
            g_host = host;
        if (port > 0 && port <= 65535)
            g_port = port;
    }

    bool IsBridgeConnected()
    {
        return g_connected.load();
    }

    bool SendBridgeLine(const std::string& line)
    {
        if(line.size()>65536u || !g_connected.load())return false;
        {std::lock_guard<std::mutex> lock(g_outboundMutex);
         if(!g_connected.load() || g_outbound.size()>=4096u || g_outboundBytes+line.size()+1u>4u*1024u*1024u)return false;
         g_outbound.push_back({g_generation.load(),line+"\n"});g_outboundBytes+=line.size()+1u;}
        g_outboundReady.notify_one();return true;
    }

    void BridgeSendWorker()
    {
        for(;;) {
            Outbound item;
            {std::unique_lock<std::mutex> lock(g_outboundMutex);
             g_outboundReady.wait(lock,[]{return !g_outbound.empty();});
             item=std::move(g_outbound.front());g_outbound.pop_front();g_outboundBytes-=item.payload.size();}
            std::lock_guard<std::mutex> lock(g_socketMutex);
            if(!g_connected.load() || item.generation!=g_generation.load() || g_socket==INVALID_SOCKET)continue;
            const char* data=item.payload.data();int remaining=static_cast<int>(item.payload.size());
            while(remaining>0) {
                const int sent=send(g_socket,data,remaining,0);
                if(sent<=0){CloseSocketLocked();Log("Bridge connection lost while sending; durable events retained for reconnect.");break;}
                data+=sent;remaining-=sent;
            }
        }
    }

    DWORD WINAPI BridgeClientThread(LPVOID)
    {
        WSADATA wsa{};
        if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
        {
            Log("ERROR: WSAStartup failed.");
            return 0;
        }

        {
            std::ostringstream line;
            line << "Local AP bridge target: " << g_host << ":" << g_port;
            Log(line.str());
        }

        std::thread(BridgeSendWorker).detach();

        std::string receiveBuffer;
        receiveBuffer.reserve(8192);

        while (true)
        {
            if (!g_connected.load())
            {
                SOCKET candidate = ConnectSocket();
                if (candidate == INVALID_SOCKET)
                {
                    Sleep(2000);
                    continue;
                }

                receiveBuffer.clear();
                Log("Connected to local NFSMW AP bridge.");
                char session[512]={};
                GetEnvironmentVariableA("NFSMW_AP_SESSION_KEY",session,sizeof(session));
                char setupToken[80]={};
                GetEnvironmentVariableA("NFSMW_AP_SETUP_TOKEN",setupToken,sizeof(setupToken));
                std::ostringstream hello;
                hello << "{\"type\":\"hello\",\"build\":\"" NFSMW_AP_BUILD "\",\"ui_protocol\":2,\"process_id\":" << GetCurrentProcessId()
                      << ",\"setup\":" << (IsConnectionSetupOnly() ? "true" : "false")
                      << ",\"session_key\":\"" << NFSMWAP::JsonLite::Escape(session)
                      << "\",\"setup_token\":\"" << NFSMWAP::JsonLite::Escape(setupToken) << "\"}";
                {
                    std::lock_guard<std::mutex> socketLock(g_socketMutex);
                    const DWORD timeout=250u;
                    setsockopt(candidate,SOL_SOCKET,SO_SNDTIMEO,reinterpret_cast<const char*>(&timeout),sizeof(timeout));
                    std::lock_guard<std::mutex> queueLock(g_outboundMutex);
                    g_outbound.clear();g_outboundBytes=0;
                    const auto generation=++g_generation;
                    g_outbound.push_back({generation,hello.str()+"\n"});
                    g_outbound.push_back({generation,"{\"type\":\"request_shop_catalog\"}\n"});
                    for(const auto& item:g_outbound)g_outboundBytes+=item.payload.size();
                    g_socket=candidate;g_connected=true;
                }
                g_outboundReady.notify_one();
                ReplayMilestoneJournal();
                ReplayGameEvents();
            }

            SOCKET activeSocket = INVALID_SOCKET;
            {
                std::lock_guard<std::mutex> lock(g_socketMutex);
                activeSocket = g_socket;
            }

            if (activeSocket == INVALID_SOCKET)
                continue;

            char buffer[4096]{};
            int received = recv(
                activeSocket,
                buffer,
                static_cast<int>(sizeof(buffer)),
                0);

            if (received > 0)
            {
                receiveBuffer.append(buffer, static_cast<std::size_t>(received));

                std::size_t newline = std::string::npos;
                while ((newline = receiveBuffer.find('\n')) != std::string::npos)
                {
                    std::string line = receiveBuffer.substr(0, newline);
                    receiveBuffer.erase(0, newline + 1);
                    if (!line.empty() && line.back() == '\r')
                        line.pop_back();
                    if (!line.empty())
                        HandleBridgeLine(line);
                }

                if (receiveBuffer.size() > 1024 * 1024)
                {
                    Log("ERROR: Bridge receive buffer exceeded 1 MiB; clearing malformed stream.");
                    receiveBuffer.clear();
                }
            }
            else
            {
                {
                    std::lock_guard<std::mutex> lock(g_socketMutex);
                    if (g_socket == activeSocket)
                        CloseSocketLocked();
                }
                receiveBuffer.clear();
                Log("Disconnected from local NFSMW AP bridge.");
                Sleep(1000);
            }
        }

        WSACleanup();
        return 0;
    }
}
