#include "BridgeClient.h"
#include "TurboTrap.h"
#include "TruckTrapRuntime.h"
#include "CareerBootstrap.h"
#include "GameVersion.h"
#include "JsonLite.h"
#include "Logger.h"
#include "StoreRuntime.h"
#include <Windows.h>
#include <mmsystem.h>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <set>
#include <map>
#include <cwchar>
#include <cstdlib>
#include <limits>

namespace {
using Word=std::uint32_t;
std::mutex trapMutex;
bool ready=false,ledgerLoaded=false,active=false;


std::atomic<bool> drivingTrapsEnabled{false};

std::set<int> consumed,pendingTraps;
std::map<int,int> trapItems;
int activeTrapItem=NFSMWAP::TurboTrapItemId;
std::string sessionKey;
std::filesystem::path receiptPath;
std::uint64_t elapsedDriving=0,lastDrivingTick=0,nextAudioTry=0;

bool wasDriving=false,audioOpen=false,audioErrorLogged=false,suspendedRestored=false;


struct TurboVector {float x=0,y=0,z=0;};
struct TurboCar {Word vehicle=0,simable=0,profile=0;float speed=0;};
TurboCar boostedCar;
bool boosted=false;
bool boostReported=false;
bool truckNativeReady=false,truckCueAttempted=false;
std::string truckPrepareWaitStatus;
std::uint64_t lastTruckTick=0;
std::atomic<std::uint64_t> turboVisualStart{0};
std::atomic<std::uint64_t> flashVisualStart{0};
bool turboVisualsInstalled=false;
bool __fastcall TurboNosEngaged(Word* nos,void*);
struct BrakeControls {float value[8]={};Word buttons=0;};
static_assert(sizeof(BrakeControls)==0x24u,"Retail InputControls layout");
thread_local BrakeControls brakeReadControls;
std::atomic<std::uint64_t> brakeControlDeadline{0};
bool brakeControlsInstalled=false;
BrakeControls* __fastcall BrakeGetControls(Word*,void*);

bool VerifyBrakeNative() {
    __try {
        const unsigned char query[]={0x8B,0x49,0x04,0x68,0x90,0x3F,0x40,0};
        const unsigned char controls[]={0x8D,0x41,0x08,0xC3};
        const unsigned char gas[]={0x8B,0x44,0x24,0x04,0x89,0x41,0x1C,0xC2,0x04,0};
        const unsigned char brake[]={0x8B,0x44,0x24,0x04,0x89,0x41,0x20,0xC2,0x04,0};
        const Word getter=brakeControlsInstalled?static_cast<Word>(reinterpret_cast<std::uintptr_t>(&BrakeGetControls)):0x69CBB0u;
        return std::memcmp(reinterpret_cast<void*>(0x40E3B0u),query,sizeof(query))==0&&
            std::memcmp(reinterpret_cast<void*>(0x69CBB0u),controls,sizeof(controls))==0&&
            std::memcmp(reinterpret_cast<void*>(0x69CB90u),gas,sizeof(gas))==0&&
            std::memcmp(reinterpret_cast<void*>(0x69CBA0u),brake,sizeof(brake))==0&&
            *reinterpret_cast<Word*>(0x8AB5D0u)==getter&&*reinterpret_cast<Word*>(0x8AC678u)==getter&&
            *reinterpret_cast<Word*>(0x8AC710u)==getter;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}

bool VerifyTurboPhysicsNative() {
    __try {
        const unsigned char body[]={0x8B,0x41,0x4C,0xC3};
        const unsigned char forward[]={0x8B,0x41,0x30,0x8B,0,0x8B,0x4C,0x24,0x04,0x05,0x90,0,0,0};
        const unsigned char getVelocity[]={0x8B,0x41,0x30,0x8B,0,0x83,0xC0,0x20,0xC3};
        const unsigned char velocity[]={0x8B,0x41,0x30,0x8B,0x08,0x8B,0x54,0x24,0x04,0x8B,0x02,0x83,0xC1,0x20};
        const unsigned char pause[]={0xB9,0xA0,0x0F,0x9B,0,0xE8,0x96,0x9F,0x0E,0};
        const unsigned char race[]={0x8B,0x89,0x68,0x19,0,0};
        const unsigned char racer[]={0x8B,0x44,0x24,0x04,0x69,0xC0,0x94,0x01,0,0};
        return std::memcmp(reinterpret_cast<void*>(0x686AB0u),body,sizeof(body))==0&&
            std::memcmp(reinterpret_cast<void*>(0x671270u),forward,sizeof(forward))==0&&
            std::memcmp(reinterpret_cast<void*>(0x671190u),getVelocity,sizeof(getVelocity))==0&&
            std::memcmp(reinterpret_cast<void*>(0x696FD0u),velocity,sizeof(velocity))==0&&
            std::memcmp(reinterpret_cast<void*>(0x64B680u),pause,sizeof(pause))==0&&
            std::memcmp(reinterpret_cast<void*>(0x404A70u),race,sizeof(race))==0&&
            std::memcmp(reinterpret_cast<void*>(0x5DBED0u),racer,sizeof(racer))==0&&
            *reinterpret_cast<const Word*>(0x8AA994u)==0x686AB0u&&
            reinterpret_cast<const Word*>(0x8AC880u)[9]==0x671190u&&
            reinterpret_cast<const Word*>(0x8AC880u)[13]==0x671270u&&
            reinterpret_cast<const Word*>(0x8AC880u)[24]==0x696FD0u;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool VerifyTurboNative() {
    __try {

        const unsigned char query[]={0x8B,0x49,0x04,0x68,0xE0,0x40,0x40,0x00};
        const unsigned char speed[]={0xD9,0x41,0x70,0xC3};
        const unsigned char set[]={0x8B,0x44,0x24,0x04,0x83,0xEC,0x0C,0x56,0x8B,0xF1,0x89,0x46,0x70};
        const auto vehicle=reinterpret_cast<const Word*>(0x8AA828u);
        const unsigned char nosQuery[]={0x8B,0x49,0x04,0x68,0x20,0x40,0x40,0x00};
        const unsigned char nosEngaged[]={0xD9,0x81,0xAC,0,0,0,0xD8,0x1D,0x6C,0x09,0x89,0};
        const unsigned char cameraNos[]={0x8B,0x07,0x8B,0xCF,0xFF,0x50,0x20};
        const unsigned char packetNos[]={0x8B,0x01,0xFF,0x50,0x20,0x88,0x47,0x71};
        const Word nosTarget=turboVisualsInstalled ? static_cast<Word>(reinterpret_cast<std::uintptr_t>(&TurboNosEngaged)) : 0x6A0410u;
        return VerifyTurboPhysicsNative()&&std::memcmp(reinterpret_cast<const void*>(0x40E040u),query,sizeof(query))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x40E4A0u),nosQuery,sizeof(nosQuery))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x6A0410u),nosEngaged,sizeof(nosEngaged))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x472EF7u),cameraNos,sizeof(cameraNos))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x6B73ABu),packetNos,sizeof(packetNos))==0&&
            *reinterpret_cast<const Word*>(0x8AB700u)==nosTarget&&
            *reinterpret_cast<const Word*>(0x8ABFA8u)==nosTarget&&
            std::memcmp(reinterpret_cast<const void*>(0x6881B0u),speed,sizeof(speed))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x670210u),set,sizeof(set))==0&&
            vehicle[34]==0x688200u&&vehicle[36]==0x6881B0u&&vehicle[37]==0x670210u&&
            reinterpret_cast<const Word*>(0x8B0B10u)[1]==0x6F8FB0u&&
            reinterpret_cast<const Word*>(0x8B0BD0u)[1]==0x6F8FB0u;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool ReadTurboCar(TurboCar& car) {
    __try {
        if(*reinterpret_cast<int*>(0x925E90u)!=6)return false;
        const Word db=*reinterpret_cast<Word*>(0x91CF90u);
        if(db<0x10000u)return false;
        car.profile=*reinterpret_cast<Word*>(db+0x10u);
        if(car.profile<0x10000u||*reinterpret_cast<unsigned char*>(car.profile+0xB0u)>15u)return false;
        auto* player=reinterpret_cast<Word*(__cdecl*)(int)>(0x425200u)(1);
        if(!player)return false;
        const auto playerTable=reinterpret_cast<const Word*>(*player);
        if(!playerTable||playerTable[1]!=0x6F8FB0u)return false;
        auto* simable=reinterpret_cast<Word*(__thiscall*)(Word*)>(playerTable[1])(player);
        if(!simable)return false;
        Word* vehicle=nullptr;
        if(!reinterpret_cast<bool(__thiscall*)(Word*,Word**)>(0x40E040u)(simable,&vehicle)||!vehicle)return false;
        const auto table=reinterpret_cast<const Word*>(*vehicle);
        if(!table||table[34]!=0x688200u||table[36]!=0x6881B0u||table[37]!=0x670210u)return false;
        if(!reinterpret_cast<bool(__thiscall*)(Word*)>(table[34])(vehicle))return false;
        car.vehicle=static_cast<Word>(reinterpret_cast<std::uintptr_t>(vehicle));
        car.simable=static_cast<Word>(reinterpret_cast<std::uintptr_t>(simable));
        car.speed=reinterpret_cast<float(__thiscall*)(Word*)>(table[36])(vehicle);
        return std::isfinite(car.speed)&&std::abs(car.speed)<2000.0f;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool SetTurboSpeed(const TurboCar& car,float speed) {
    __try {
        auto* vehicle=reinterpret_cast<Word*>(car.vehicle);
        const auto table=reinterpret_cast<const Word*>(*vehicle);
        if(!table||table[37]!=0x670210u)return false;
        reinterpret_cast<void(__thiscall*)(Word*,float)>(table[37])(vehicle,speed);
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool SameCar(const TurboCar& a,const TurboCar& b) {
    return a.vehicle==b.vehicle&&a.simable==b.simable&&a.profile==b.profile;
}
bool TurboDrivingNative() {
    __try {
        if(*reinterpret_cast<int*>(0x925E90u)!=6||*reinterpret_cast<unsigned char*>(0x91606Cu)||
           reinterpret_cast<bool(__thiscall*)(void*)>(0x64B680u)(reinterpret_cast<void*>(0x925E70u)))return false;
        const Word db=*reinterpret_cast<Word*>(0x91CF90u);if(db<0x10000u)return false;
        const Word mode=*reinterpret_cast<Word*>(db+0x12Cu);
        if(!(mode&1u)||(mode&0xEu))return false;
        const Word status=*reinterpret_cast<Word*>(0x91E000u);
        if(status&&reinterpret_cast<int(__thiscall*)(void*)>(0x404A70u)(reinterpret_cast<void*>(status))!=-1) {
            const auto racer=reinterpret_cast<const unsigned char*(__thiscall*)(void*,int)>(0x5DBED0u)(reinterpret_cast<void*>(status),0);
            if(!racer||racer[0x21u])return false;
        }
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
#if defined(_MSC_VER)
__declspec(noinline)
#endif
bool TurboDriving() {
    if(!TurboDrivingNative())return false;
    std::string package;


    if(NFSMWAP::GetNativeStorePackage(package)&&!package.empty()&&
       package!="HUD.fng"&&package!="HUD_Race.fng"&&package!="InGameHUD.fng")return false;
    return true;
}
bool ReadBrakeInput(const TurboCar& car,Word*& input) {
    input=nullptr;
    __try {
        if(!reinterpret_cast<bool(__thiscall*)(Word*,Word**)>(0x40E3B0u)(reinterpret_cast<Word*>(car.simable),&input)||!input)return false;
        const Word table=*input;
        return (table==0x8AB5C8u||table==0x8AC670u||table==0x8AC708u)&&
            reinterpret_cast<const Word*>(table)[2]==static_cast<Word>(reinterpret_cast<std::uintptr_t>(&BrakeGetControls));
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool BrakeCarReady(const TurboCar& car) {
    __try {
        Word* input=nullptr;if(!ReadBrakeInput(car,input))return false;
        auto* sim=reinterpret_cast<Word*>(car.simable);
        const auto table=reinterpret_cast<const Word*>(*sim);
        if(table[21]!=0x686AB0u)return false;
        auto* body=reinterpret_cast<Word*(__thiscall*)(Word*)>(table[21])(sim);
        if(!body)return false;
        const auto bt=reinterpret_cast<const Word*>(*body);
        return bt[9]==0x671190u&&bt[24]==0x696FD0u;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool StopBrakeCar(const TurboCar& car) {
    __try {
        if(!BrakeCarReady(car))return false;
        auto* sim=reinterpret_cast<Word*>(car.simable);
        auto* body=reinterpret_cast<Word*(__thiscall*)(Word*)>(0x686AB0u)(sim);
        const auto velocity=reinterpret_cast<const TurboVector*(__thiscall*)(Word*)>(0x671190u)(body);
        if(!velocity||!std::isfinite(velocity->y))return false;
        const TurboVector stopped{0,std::min(velocity->y,0.0f),0};
        if(!SetTurboSpeed(car,0))return false;
        reinterpret_cast<void(__thiscall*)(Word*,const TurboVector&)>(0x696FD0u)(body,stopped);
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
BrakeControls* __fastcall BrakeGetControls(Word* input,void*) {
    auto* original=reinterpret_cast<BrakeControls*(__thiscall*)(Word*)>(0x69CBB0u)(input);
    const auto deadline=drivingTrapsEnabled.load()?brakeControlDeadline.load():0;
    if(!original||!deadline||GetTickCount64()>=deadline)return original;
    __try {
        TurboCar current;Word* localInput=nullptr;
        if(!NFSMWAP::IsCareerProfileReady()||!TurboDrivingNative()||!ReadTurboCar(current)||
           !ReadBrakeInput(current,localInput)||localInput!=input)return original;


        std::memcpy(&brakeReadControls,original,sizeof(brakeReadControls));
        brakeReadControls.value[5]=0;
        brakeReadControls.value[6]=1;
        return &brakeReadControls;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return original;}
}
bool InstallBrakeControls() {
    if(brakeControlsInstalled)return true;
    __try {
        DWORD old=0,ignored=0;
        if(!VirtualProtect(reinterpret_cast<void*>(0x8AB5D0u),0x1144u,PAGE_READWRITE,&old))return false;
        const Word hook=static_cast<Word>(reinterpret_cast<std::uintptr_t>(&BrakeGetControls));
        *reinterpret_cast<Word*>(0x8AB5D0u)=hook;*reinterpret_cast<Word*>(0x8AC678u)=hook;*reinterpret_cast<Word*>(0x8AC710u)=hook;
        VirtualProtect(reinterpret_cast<void*>(0x8AB5D0u),0x1144u,old,&ignored);
        brakeControlsInstalled=true;return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}


bool SetForwardTurboSpeed(const TurboCar& car,float speed) {
    __try {
        auto* sim=reinterpret_cast<Word*>(car.simable);
        const auto simTable=reinterpret_cast<const Word*>(*sim);
        if(!simTable||simTable[21]!=0x686AB0u)return false;
        auto* body=reinterpret_cast<Word*(__thiscall*)(Word*)>(simTable[21])(sim);
        if(!body)return false;
        const auto bodyTable=reinterpret_cast<const Word*>(*body);


        if(!bodyTable||bodyTable[9]!=0x671190u||bodyTable[13]!=0x671270u||bodyTable[24]!=0x696FD0u)return false;
        TurboVector forward;
        reinterpret_cast<void(__thiscall*)(Word*,TurboVector&)>(bodyTable[13])(body,forward);
        const auto previous=reinterpret_cast<const TurboVector*(__thiscall*)(Word*)>(bodyTable[9])(body);
        if(!previous||!std::isfinite(forward.x)||!std::isfinite(forward.z)||!std::isfinite(previous->y))return false;
        const float length=std::sqrt(forward.x*forward.x+forward.z*forward.z);
        if(!std::isfinite(length)||length<0.001f)return false;
        const TurboVector velocity{forward.x/length*speed,std::min(previous->y,0.0f),forward.z/length*speed};


        if(!SetTurboSpeed(car,speed))return false;
        reinterpret_cast<void(__thiscall*)(Word*,const TurboVector&)>(bodyTable[24])(body,velocity);
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool DrainSpeedbreaker(const TurboCar& car) {
    __try {
        auto* player=reinterpret_cast<Word*(__cdecl*)(int)>(0x425200u)(1);
        if(!player)return false;
        const auto table=reinterpret_cast<const Word*>(*player);
        if(!table||table[1]!=0x6F8FB0u||table[18]!=0x6E9B20u)return false;
        if(reinterpret_cast<Word*(__thiscall*)(Word*)>(table[1])(player)!=reinterpret_cast<Word*>(car.simable))return false;
        auto* meter=reinterpret_cast<float*>(reinterpret_cast<unsigned char*>(player)+0x38u);
        if(!std::isfinite(*meter)||*meter<0.0f||*meter>1.0f)return false;
        reinterpret_cast<void(__thiscall*)(Word*,bool)>(table[18])(player,false);
        return *meter==0.0f&&!*(reinterpret_cast<unsigned char*>(player)+0x34u);
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool IsDrivingTrap(int item) {
    return item==NFSMWAP::TurboTrapItemId||item==NFSMWAP::BrakeTrapItemId||item==NFSMWAP::FlashBangTrapItemId||item==NFSMWAP::TruckTrapItemId||item==NFSMWAP::SpeedbreakerTrapItemId;
}
const char* TrapName(int item) {
    return item==NFSMWAP::SpeedbreakerTrapItemId?"SPEEDBREAKER":item==NFSMWAP::TruckTrapItemId?"TRUCK":item==NFSMWAP::FlashBangTrapItemId?"FLASH BANG":item==NFSMWAP::BrakeTrapItemId?"BRAKE":"TURBO";
}
void CloseTurboAudio() {
    if(audioOpen)mciSendStringW(L"close NFSMWAPTurbo",nullptr,0,nullptr);
    audioOpen=false;
}
bool OpenTurboAudio(int item) {
    CloseTurboAudio();
    const auto file=item==NFSMWAP::TruckTrapItemId?"NFSMW_TruckTrap.wav":
        item==NFSMWAP::FlashBangTrapItemId?"NFSMW_FlashBangTrap.wav":"NFSMW_TurboTrap.wav";
    const auto path=(std::filesystem::path(NFSMWAP::GetGameDirectory())/"scripts"/file).wstring();
    if(mciSendStringW((L"open \""+path+L"\" type waveaudio alias NFSMWAPTurbo").c_str(),nullptr,0,nullptr))return false;
    audioOpen=true;
    if(mciSendStringW(L"set NFSMWAPTurbo time format milliseconds",nullptr,0,nullptr)){CloseTurboAudio();return false;}
    return true;
}
bool PlayTurboAudio(std::uint64_t offset) {


    if(audioOpen&&mciSendStringW((L"play NFSMWAPTurbo from "+std::to_wstring(offset)).c_str(),nullptr,0,nullptr)) {
        CloseTurboAudio();NFSMWAP::Log("AP DRIVING TRAP: playback failed; driving-only effect clock remains active.");
        return false;
    }

    return audioOpen;
}
bool TruckAudioCueReached() {
    if(!audioOpen)return false;
    wchar_t position[32]{};
    if(mciSendStringW(L"status NFSMWAPTurbo position",position,32,nullptr))return false;
    wchar_t* end=nullptr;const auto played=std::wcstoull(position,&end,10);
    return end!=position&&*end==0&&played>=NFSMWAP::TruckTrapCueMs;
}
bool TurboVisualFor(Word* nos) {
    const auto start=turboVisualStart.load();
    if(!start||!drivingTrapsEnabled.load())return false;
    const auto elapsed=GetTickCount64()-start;
    if(elapsed<NFSMWAP::TurboLeadMs||elapsed>=NFSMWAP::TurboEndMs)return false;
    __try {


        TurboCar current;
        if(!NFSMWAP::IsCareerProfileReady()||!TurboDrivingNative()||!ReadTurboCar(current))return false;
        Word* localNos=nullptr;
        if(!reinterpret_cast<bool(__thiscall*)(Word*,Word**)>(0x40E4A0u)
            (reinterpret_cast<Word*>(current.simable),&localNos)||localNos!=nos)return false;
        const Word table=*localNos;
        return table==0x8AB6E0u||table==0x8ABF88u;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool __fastcall TurboNosEngaged(Word* nos,void*) {


    return TurboVisualFor(nos)||reinterpret_cast<bool(__thiscall*)(Word*)>(0x6A0410u)(nos);
}
bool InstallTurboVisuals() {
    if(turboVisualsInstalled)return true;
    __try {
        DWORD old=0,ignored=0;


        if(!VirtualProtect(reinterpret_cast<void*>(0x8AB700u),0x8ACu,PAGE_READWRITE,&old))return false;
        const auto hook=static_cast<Word>(reinterpret_cast<std::uintptr_t>(&TurboNosEngaged));
        *reinterpret_cast<Word*>(0x8AB700u)=hook;
        *reinterpret_cast<Word*>(0x8ABFA8u)=hook;
        VirtualProtect(reinterpret_cast<void*>(0x8AB700u),0x8ACu,old,&ignored);
        turboVisualsInstalled=true;return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool LoadReceipts(const std::string& key) {
    char root[4096]={},actual[512]={};
    const auto n=GetEnvironmentVariableA("NFSMW_AP_DOCUMENTS_ROOT",root,sizeof(root));
    const auto k=GetEnvironmentVariableA("NFSMW_AP_SESSION_KEY",actual,sizeof(actual));
    if(!n||n>=sizeof(root)||!k||k>=sizeof(actual)||key!=actual)return false;
    if(ledgerLoaded)return key==sessionKey;
    sessionKey=actual;receiptPath=std::filesystem::path(root)/"NFSMW_AP_TrapReceipts.jsonl";
    std::ifstream input(receiptPath);std::string line;
    while(std::getline(input,line)) {
        int index=-1,item=0;std::string stored,state;
        if(line.size()<2048&&NFSMWAP::JsonLite::GetInt(line,"index",index)&&index>=0&&
           NFSMWAP::JsonLite::GetInt(line,"item_id",item)&&IsDrivingTrap(item)&&
           NFSMWAP::JsonLite::GetString(line,"session_key",stored)&&stored==sessionKey) {
            if(trapItems.count(index)&&trapItems[index]!=item)continue;
            trapItems[index]=item;
            NFSMWAP::JsonLite::GetString(line,"state",state);
            if(state=="pending")pendingTraps.insert(index);
            else if(state.empty()||state=="consumed")consumed.insert(index);
        }
    }
    for(int index:consumed)pendingTraps.erase(index);
    ledgerLoaded=true;return true;
}
bool SaveReceipts() {
    const auto temp=std::filesystem::path(receiptPath.string()+".tmp");
    std::ofstream file(temp,std::ios::trunc);
    const auto write=[&](int index,const char* state){file<<"{\"index\":"<<index<<",\"item_id\":"<<trapItems.at(index)
        <<",\"session_key\":\""<<NFSMWAP::JsonLite::Escape(sessionKey)<<"\",\"state\":\""<<state<<"\"}\n";};
    for(const int index:consumed)write(index,"consumed");
    for(const int index:pendingTraps)write(index,"pending");
    file.flush();if(!file)return false;file.close();if(!file)return false;
#ifdef _WIN32
    return MoveFileExW(temp.c_str(),receiptPath.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=0;
#else
    std::error_code error;std::filesystem::rename(temp,receiptPath,error);return !error;
#endif
}
}

namespace NFSMWAP {

void SetDrivingTrapsEnabled(bool enabled) {drivingTrapsEnabled.store(enabled);}
bool InitializeTurboTraps() {
    std::lock_guard<std::mutex> lock(trapMutex);
    ready=VerifyTurboNative()&&VerifyBrakeNative()&&InstallTurboVisuals()&&InstallBrakeControls();
    truckNativeReady=InitializeTruckTrapNative();
    Log("NFSMW_AP_SEED_OPTIONS_V1: traps remain off until seed_config enables them from YAML slot data.");
    Log(ready ? "NFSMW_AP_TURBO_TRAP_V6: retail RBVehicle velocity interface; horizontal 350 mph (156.464 m/s) boost without car resets; driving-only audio and durable receipts."
        : "AP TURBO TRAP: supported native speed/visual interfaces did not validate; effect disabled.");
    if(ready)Log("NFSMW_AP_BRAKE_TRAP_V2: three driving seconds of full brake/zero throttle; native inputs preserved; durable typed receipts.");
    if(ready)Log("NFSMW_AP_FLASH_BANG_TRAP_V1: driving-only clip; final-frame whiteout at 1000 ms, fade over last 500 ms, release at 6316 ms; durable typed receipts.");
    Log(truckNativeReady?"NFSMW_AP_TRUCK_TRAP_V7: private native semi, one grounded collision spawn at the spoken cue; no police/AI spawn loop.":
        "AP TRUCK TRAP: retail vehicle factory interfaces did not validate; Truck receipts remain pending.");
    Log("NFSMW_AP_SPEEDBREAKER_TRAP_V1: one-shot native meter drain; normal recharge retained.");

    return ready;
}
bool QueueTurboTrap(int index,int item,const std::string& key,bool trigger) {
    if(index<0||!IsDrivingTrap(item))return false;
    trigger=trigger&&drivingTrapsEnabled.load();
    bool ack=false,queued=false;
    {
        std::lock_guard<std::mutex> lock(trapMutex);
        if(!ready||!LoadReceipts(key))return false;
        if(trapItems.count(index)&&trapItems[index]!=item)return false;
        trapItems[index]=item;
        if(consumed.count(index))ack=true;
        else if(trigger) {
            if(!pendingTraps.count(index)) {
                pendingTraps.insert(index);
                if(!SaveReceipts()){pendingTraps.erase(index);return false;}
                queued=true;
            }
        } else {
            const bool pending=pendingTraps.erase(index)!=0;consumed.insert(index);
            if(!SaveReceipts()){consumed.erase(index);if(pending)pendingTraps.insert(index);return false;}
            ack=true;
        }
    }
    if(queued)Log(std::string("AP ")+TrapName(item)+" TRAP QUEUED: receipt="+std::to_string(index)+"; waiting for live Career driving.");
    if(ack)SendBridgeLine("{\"type\":\"received_item_ack\",\"index\":"+std::to_string(index)+
        ",\"item_id\":"+std::to_string(item)+",\"trap_consumed\":true,\"session_key\":\""+JsonLite::Escape(key)+"\"}");
    return true;
}
bool DrivingTrapsPending() {
    std::lock_guard<std::mutex> lock(trapMutex);
    return ready&&(active||boosted||!pendingTraps.empty()||TruckTrapVehiclePending());
}
unsigned char FlashBangOpacity() {
    const auto start=flashVisualStart.load();
    if(!start||!drivingTrapsEnabled.load())return 0;
    const auto elapsed=GetTickCount64()-start;
    if(elapsed<FlashBangLeadMs||elapsed>=FlashBangEndMs||!IsCareerProfileReady()||!TurboDriving())return 0;
    TurboCar current;if(!ReadTurboCar(current))return 0;
    if(elapsed<=FlashBangEndMs-FlashBangFadeMs)return 255;
    return static_cast<unsigned char>((FlashBangEndMs-elapsed)*255u/FlashBangFadeMs);
}

void TurboTrapMainThreadTick() {
    std::unique_lock<std::mutex> lock(trapMutex);
    brakeControlDeadline.store(0);
    if(!ready)return;
    if(!active&&!boosted&&pendingTraps.empty()&&!TruckTrapVehiclePending())return;

    const auto now=GetTickCount64();
    TurboCar current;
    const bool haveCar=IsCareerProfileReady()&&ReadTurboCar(current);
    if(!drivingTrapsEnabled.load()) {
        active=false;wasDriving=false;turboVisualStart.store(0);flashVisualStart.store(0);
        CloseTurboAudio();ClearTruckTrapVehicle();
        if(boosted&&haveCar) {
            if(!SameCar(current,boostedCar)||SetTurboSpeed(current,boostedCar.speed))boosted=false;
        }
        return;
    }
    const bool driving=haveCar&&TurboDriving()&&(!active||activeTrapItem!=BrakeTrapItemId||BrakeCarReady(current));
    TruckTrapWorldTick(driving,lastTruckTick?now-lastTruckTick:0);lastTruckTick=now;
    if(driving&&drivingTrapsEnabled.load()) {
        for(auto it=pendingTraps.begin();it!=pendingTraps.end();++it) {
            const int index=*it;
            if(trapItems.at(index)!=SpeedbreakerTrapItemId)continue;
            if(!DrainSpeedbreaker(current))return;
            pendingTraps.erase(it);consumed.insert(index);
            if(!SaveReceipts()){consumed.erase(index);pendingTraps.insert(index);return;}
            const auto key=sessionKey;
            lock.unlock();
            Log("AP SPEEDBREAKER TRAP: meter emptied; active Speedbreaker stopped; normal recharge retained.");
            SendBridgeLine("{\"type\":\"received_item_ack\",\"index\":"+std::to_string(index)+
                ",\"item_id\":"+std::to_string(SpeedbreakerTrapItemId)+",\"trap_consumed\":true,\"session_key\":\""+JsonLite::Escape(key)+"\"}");
            return;
        }
    }
    if(!active&&!boosted&&pendingTraps.empty())return;
    if(active) {

        const auto duration=activeTrapItem==BrakeTrapItemId?BrakeTrapDurationMs:
            activeTrapItem==FlashBangTrapItemId?FlashBangEndMs:activeTrapItem==TruckTrapItemId?TruckTrapEndMs:TurboEndMs;
        if(wasDriving)elapsedDriving=std::min(duration,elapsedDriving+now-lastDrivingTick);
        lastDrivingTick=now;

        if(elapsedDriving>=duration){


            if(activeTrapItem==TruckTrapItemId&&driving&&!truckCueAttempted&&TruckAudioCueReached()) {
                truckCueAttempted=true;SpawnTruckTrapVehicle(current.simable,current.profile);
            }
            active=false;turboVisualStart.store(0);flashVisualStart.store(0);CloseTurboAudio();CancelPreparedTruckTrap();
        }
        else if(activeTrapItem!=BrakeTrapItemId&&!driving&&wasDriving){
            if(audioOpen&&mciSendStringW(L"pause NFSMWAPTurbo",nullptr,0,nullptr))CloseTurboAudio();
            turboVisualStart.store(0);
            flashVisualStart.store(0);
        }
        else if(activeTrapItem!=BrakeTrapItemId&&driving&&!wasDriving){


            if(!audioOpen)OpenTurboAudio(activeTrapItem);
            PlayTurboAudio(elapsedDriving);
            if(activeTrapItem==TurboTrapItemId)turboVisualStart.store(now-elapsedDriving);
            else if(activeTrapItem==FlashBangTrapItemId)flashVisualStart.store(now-elapsedDriving);
        }
        wasDriving=active&&driving;
    }
    if(!active&&boosted) {
        if(!haveCar)return;
        if(SameCar(current,boostedCar)&&!SetTurboSpeed(current,boostedCar.speed))return;
        boosted=false;suspendedRestored=false;
    }
    int activated=-1,activatedItem=0;
    if(!active&&driving&&drivingTrapsEnabled.load()&&!pendingTraps.empty()&&now>=nextAudioTry) {
        const int nextIndex=*pendingTraps.begin(),nextItem=trapItems.at(nextIndex);
        const bool brake=nextItem==BrakeTrapItemId;
        const bool truck=nextItem==TruckTrapItemId;
        if(truck)nextAudioTry=now+2000;
        if(truck&&(!truckNativeReady||!PrepareTruckTrapVehicle(current.simable,current.profile))) {
            const std::string status=truckNativeReady?TruckTrapPreparationStatus():"native signatures unavailable";
            if(truckPrepareWaitStatus!=status) {
                truckPrepareWaitStatus=status;
                Log("AP TRUCK TRAP WAIT: "+status+"; receipt retained; preparation retry limited to once every two seconds.");
            }
            return;
        }
        truckPrepareWaitStatus.clear();
        if(brake&&!BrakeCarReady(current))return;
        nextAudioTry=now+2000;
        if(!brake&&!OpenTurboAudio(nextItem)) {
            if(truck)CancelPreparedTruckTrap();
            if(!audioErrorLogged){audioErrorLogged=true;Log(std::string("AP ")+TrapName(nextItem)+" TRAP: audio unavailable; pending receipt retained for retry.");}
            return;
        }


        if(truck&&!PlayTurboAudio(0)){CancelPreparedTruckTrap();return;}
        const int index=*pendingTraps.begin();pendingTraps.erase(index);consumed.insert(index);
        if(!SaveReceipts()){consumed.erase(index);pendingTraps.insert(index);CloseTurboAudio();CancelPreparedTruckTrap();return;}
        active=true;wasDriving=true;suspendedRestored=false;audioErrorLogged=false;
        activeTrapItem=nextItem;activatedItem=nextItem;
        truckCueAttempted=false;
        boostReported=false;
        elapsedDriving=0;lastDrivingTick=GetTickCount64();activated=index;
        if(brake)Log("AP BRAKE TRAP START: receipt="+std::to_string(index)+"; full brake and zero throttle for three driving seconds.");
        else if(nextItem==FlashBangTrapItemId) {
            flashVisualStart.store(lastDrivingTick);PlayTurboAudio(0);
            Log("AP FLASH BANG TRAP START: receipt="+std::to_string(index)+"; whiteout at one second, fades out with clip at 6.316 seconds.");
        }
        else if(truck)Log("AP TRUCK TRAP START: receipt="+std::to_string(index)+"; supplied clip; one native semi at cue="+std::to_string(TruckTrapCueMs)+" ms.");
        else {
            turboVisualStart.store(lastDrivingTick);PlayTurboAudio(0);
            Log("AP TURBO TRAP START: receipt="+std::to_string(index)+"; driving-only audio; forward 350 mph (156.464 m/s) boost at 2 seconds, restore speed at 17 seconds.");
        }
    }
    if(active&&activeTrapItem==TruckTrapItemId&&driving&&!truckCueAttempted&&TruckAudioCueReached()) {


        truckCueAttempted=true;
        const bool spawned=SpawnTruckTrapVehicle(current.simable,current.profile);
        if(!spawned)CancelPreparedTruckTrap();
        Log(spawned?"AP TRUCK TRAP: semi launched across player path from the side; native collision resolves impact.":
            std::string("AP TRUCK TRAP: placement unavailable at cue: ")+TruckTrapPreparationStatus()+"; no repeated spawn.");
    }
    if(active&&activeTrapItem==BrakeTrapItemId&&driving) {
        if(StopBrakeCar(current))brakeControlDeadline.store(now+BrakeTrapDurationMs-elapsedDriving);
        else wasDriving=false;
    }
    const bool boost=active&&activeTrapItem==TurboTrapItemId&&driving&&elapsedDriving>=TurboLeadMs&&elapsedDriving<TurboEndMs;
    if(!driving&&boosted&&haveCar&&!suspendedRestored&&SameCar(current,boostedCar)) {
        suspendedRestored=SetTurboSpeed(current,boostedCar.speed);
    }
    if(boost) {
        if(!boosted||!SameCar(current,boostedCar)){boostedCar=current;boosted=true;}
        suspendedRestored=false;
        const bool applied=SetForwardTurboSpeed(current,TurboSpeedMps);
        if(!applied)SetTurboSpeed(current,boostedCar.speed);
        if(!boostReported){
            boostReported=true;
            Log(applied?"AP TURBO BOOST APPLIED: retail RBVehicle forward velocity=350 mph (156.464 m/s); no throttle required; upward thrust suppressed.":
                "AP TURBO BOOST BLOCKED: live vehicle physics interface unavailable; original speed retained.");
        }
    }
    const auto key=sessionKey;
    lock.unlock();
    if(activated>=0)SendBridgeLine("{\"type\":\"received_item_ack\",\"index\":"+std::to_string(activated)+
        ",\"item_id\":"+std::to_string(activatedItem)+",\"trap_consumed\":true,\"session_key\":\""+JsonLite::Escape(key)+"\"}");
}
}
