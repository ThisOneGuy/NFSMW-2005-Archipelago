#include "GameEventJournal.h"
#include "JsonLite.h"
#include "Logger.h"
#include <Windows.h>
#include <filesystem>
#include <fstream>
#include <map>
#include <mutex>
#include <vector>

namespace NFSMWAP {bool SendBridgeLine(const std::string&);}
namespace {
struct GameRecord {std::string payload;bool acknowledged=false;};
std::mutex gameEventMutex;
std::map<std::string,GameRecord> gameEvents;
std::filesystem::path gameEventPath;
std::string gameEventSession;
bool gameEventsLoaded=false;
std::string GamePacket(const std::string& key,const GameRecord& record) {
    return "{\"type\":\"game_journal\",\"event_key\":\""+NFSMWAP::JsonLite::Escape(key)+
        "\",\"session_key\":\""+NFSMWAP::JsonLite::Escape(gameEventSession)+"\",\"payload\":\""+
        NFSMWAP::JsonLite::Escape(record.payload)+"\",\"acknowledged\":"+(record.acknowledged?"true}":"false}");
}
bool LoadGameEvents() {
    if(gameEventsLoaded)return !gameEventPath.empty();
    char root[4096]={},session[512]={};
    const auto r=GetEnvironmentVariableA("NFSMW_AP_DOCUMENTS_ROOT",root,sizeof(root));
    const auto s=GetEnvironmentVariableA("NFSMW_AP_SESSION_KEY",session,sizeof(session));
    if(!r||r>=sizeof(root)||!s||s>=sizeof(session))return false;
    gameEventSession=session;gameEventPath=std::filesystem::path(root)/"NFSMW_AP_GameEvents.jsonl";
    std::ifstream input(gameEventPath);std::string line;
    while(std::getline(input,line)) {
        std::string key,scope,payload;bool acknowledged=false;
        if(line.size()>65536||!NFSMWAP::JsonLite::GetString(line,"event_key",key)||key.empty()||key.size()>256||
           !NFSMWAP::JsonLite::GetString(line,"session_key",scope)||scope!=gameEventSession||
           !NFSMWAP::JsonLite::GetString(line,"payload",payload)||payload.size()>16384)continue;
        NFSMWAP::JsonLite::GetBool(line,"acknowledged",acknowledged);
        gameEvents[key]={payload,acknowledged};
    }
    gameEventsLoaded=true;return true;
}
bool SaveGameEvent(const std::string& key,const GameRecord& record) {
    std::ofstream output(gameEventPath,std::ios::binary|std::ios::app);
    if(!output)return false;
    output << '\n' << GamePacket(key,record) << '\n';
    output.flush();if(!output)return false;
    output.close();return static_cast<bool>(output);
}
}
namespace NFSMWAP {
bool RecordGameEvent(const std::string& key,const std::string& payload) {
    if(key.empty()||key.size()>256||payload.empty()||payload.size()>16384)return false;
    std::string packet;
    {
        std::lock_guard<std::mutex> lock(gameEventMutex);
        if(!LoadGameEvents())return false;
        if(gameEvents.count(key))return true;
        gameEvents[key]={payload,false};
        if(!SaveGameEvent(key,gameEvents.at(key))){gameEvents.erase(key);Log("AP GAME JOURNAL: could not save event; retaining native observation for retry.");return false;}
        packet=GamePacket(key,gameEvents.at(key));
    }
    SendBridgeLine(packet);return true;
}
void ReplayGameEvents() {
    std::vector<std::string> packets;
    {std::lock_guard<std::mutex> lock(gameEventMutex);if(!LoadGameEvents())return;
     for(const auto& row:gameEvents)if(!row.second.acknowledged)packets.push_back(GamePacket(row.first,row.second));}
    for(const auto& packet:packets)if(!SendBridgeLine(packet))break;
}
void AcknowledgeGameEvent(const std::string& key,const std::string& session) {
    std::lock_guard<std::mutex> lock(gameEventMutex);if(!LoadGameEvents()||session!=gameEventSession)return;
    const auto found=gameEvents.find(key);if(found==gameEvents.end()||found->second.acknowledged)return;
    found->second.acknowledged=true;
    if(!SaveGameEvent(key,found->second))found->second.acknowledged=false;
}
}
