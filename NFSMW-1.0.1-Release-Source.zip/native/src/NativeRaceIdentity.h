#pragma once
#include <string>
namespace NFSMWAP {
struct NativeRaceIdentity {
    char activity[96]{},track[192]{};
    int rank=0,stage=0,stages=0,index=0,count=0;
    bool boss=false;
};
bool ReadNativeRaceIdentity(void* parameters,int preferredRank,NativeRaceIdentity& identity,bool careerSheet=false);
std::string NativeRaceIdentityJson(const NativeRaceIdentity& identity);
}
