#pragma once
#include <cstdint>

namespace NFSMWAP
{


    constexpr std::uintptr_t ProfileCareerOffset=0xA8u;
    constexpr std::uintptr_t CareerCashOffset=0x0Cu;
    template<class ReadWord>
    bool ResolveCareerCashAddress(std::uintptr_t database, ReadWord read, std::uintptr_t& address)
    {
        address=0;
        std::uint32_t mode=0, profile=0, cash=0;
        if (!database || !read(database+0x12Cu,mode) || !(mode&0x8001u) ||
            !read(database+0x10u,profile) || profile<0x10000u || (profile&3u) ||
            profile>0xFFFFFFFCu-ProfileCareerOffset-CareerCashOffset ||
            !read(profile+ProfileCareerOffset+CareerCashOffset,cash) || cash>999999999u)
            return false;
        address=profile+ProfileCareerOffset+CareerCashOffset;
        return true;
    }
}
