#pragma once
#include <string>

namespace NFSMWAP
{
    inline std::string CarIdentityKey(const std::string& value)
    {


        std::string key;
        for (unsigned char c:value) {
            if (c>='a' && c<='z') key.push_back(static_cast<char>(c-'a'+'A'));
            else if ((c>='A' && c<='Z') || (c>='0' && c<='9')) key.push_back(static_cast<char>(c));
        }


        if (key=="BMWM3GTRE46" || key=="BMWM3GTR" || key=="M3GTRE46" ||
            key=="M3GTR" || key=="M3GTRCAREERSTART") return "BMWM3GTR";
        if (key=="LAMBORGHINIMURCILAGO" || key=="MURCILAGO" || key=="MURCIELAGO") return "LAMBORGHINIMURCIELAGO";
        return key;
    }

    inline std::string CarDisplayName(const std::string& value)
    {
        return CarIdentityKey(value)=="LAMBORGHINIMURCIELAGO" ? u8"Lamborghini Murci\u00E9lago" : value;
    }
}
