#pragma once
#include <string>
#include <cstdint>
#include <vector>
#include "ShopCatalog.h"

namespace NFSMWAP
{
    enum class NativeMoneyRole { Price, Cash, TradeIn, Unrecognized };
    inline NativeMoneyRole NativeMoneyRoleFromName(std::string name)
    {
        for (char& c:name) if (c>='a' && c<='z') c=static_cast<char>(c-'a'+'A');
        if (name.find("CASH")!=std::string::npos) return NativeMoneyRole::Cash;
        if (name.find("TRADE")!=std::string::npos) return NativeMoneyRole::TradeIn;
        if (name.find("COST")!=std::string::npos || name.find("PRICE")!=std::string::npos ||
            name.find("TOTAL")!=std::string::npos) return NativeMoneyRole::Price;
        return NativeMoneyRole::Unrecognized;
    }
    inline int NativeShopCurrencyValue(NativeMoneyRole role,int original,int price)
    {
        return role==NativeMoneyRole::Price ? price : role==NativeMoneyRole::TradeIn ? 0 : original;
    }
    inline bool AccumulateNativeDestination(std::uintptr_t candidate, std::uintptr_t& selected)
    {
        if (!candidate || (selected && selected!=candidate)) return false;
        selected=candidate;
        return true;
    }

    inline std::string CanonicalPerformanceCategory(const std::string& category)
    {

        return category=="Tyres" ? "Tires" : category;
    }

    inline const char* NativePerformanceCategory(int type)
    {
        static const char* categories[] = {"Tires", "Brakes", "Suspension",
            "Transmission", "Engine", "Turbo/Supercharger", "Nitrous"};
        return type >= 0 && type < 7 ? categories[type] : "";
    }

    inline std::vector<ShopEntry> NativeShopEntries(
        const std::vector<ShopEntry>& entries, int performanceType)
    {
        if (performanceType < 0) return entries;
        std::vector<ShopEntry> result;
        const std::string category = NativePerformanceCategory(performanceType);
        for (const auto& entry : entries)
            if (CanonicalPerformanceCategory(entry.category) == category) result.push_back(entry);
        return result;
    }

    inline int NativeShopHomeMenu(const ShopEntry& entry)
    {


        if (entry.category=="Engine") return entry.tier=="Race" ? 0x101 : 0x201;
        if (entry.category=="Transmission") return entry.tier=="Race" ? 0x102 : entry.tier=="Pro" ? 0x301 : 0x202;
        if (entry.category=="Suspension") return entry.tier=="Pro" ? 0x105 : entry.tier=="Super Pro" ? 0x303 : 0x203;
        if (entry.category=="Nitrous") return entry.tier=="Pro" ? 0x402 : 0x204;
        if (CanonicalPerformanceCategory(entry.category)=="Tires") return entry.tier=="Pro" ? 0x704 : 0x205;
        if (entry.category=="Brakes") return entry.tier=="Race" ? 0x304 : 0x206;
        if (entry.category=="Turbo/Supercharger") return entry.tier=="Pro" ? 0x104 : 0x207;
        return 0;
    }

    inline std::uint32_t NativeShopFamilyMenu(std::uint32_t menu)
    {


        if (menu>=0x701u && menu<=0x70Bu) return 0x103u;
        if (menu>=0x401u && menu<=0x409u) return 0x302u;
        return menu;
    }
    inline bool NativeShopHasHome(std::uint32_t menu)
    {
        menu=NativeShopFamilyMenu(menu);
        return (menu>=0x101u && menu<=0x105u) || (menu>=0x201u && menu<=0x207u) ||
            (menu>=0x301u && menu<=0x304u);
    }
    inline bool NativeShopCatalogChanged(const std::vector<ShopEntry>& before,const std::vector<ShopEntry>& after)
    {
        if (before.size()!=after.size()) return true;
        for (std::size_t n=0;n<before.size();++n) if (before[n].locationId!=after[n].locationId) return true;
        return false;
    }
    inline std::vector<ShopEntry> NativeShopMenuEntries(const std::vector<ShopEntry>& entries,std::uint32_t menu)
    {
        menu=NativeShopFamilyMenu(menu);
        std::vector<ShopEntry> result;
        for (const auto& entry:entries)
            if (NativeShopFamilyMenu(NativeShopHomeMenu(entry))==menu)
            {
                bool duplicate=false;
                for (const auto& found:result) if (found.locationId==entry.locationId) duplicate=true;
                if (!duplicate) result.push_back(entry);
            }
        return result;
    }
}
