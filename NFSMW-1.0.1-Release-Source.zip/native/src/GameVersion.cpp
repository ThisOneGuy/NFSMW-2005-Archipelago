#include "GameVersion.h"

#include <Windows.h>
#include <filesystem>

namespace NFSMWAP
{
    std::string GetGameDirectory()
    {
        char path[MAX_PATH]{};
        DWORD length = GetModuleFileNameA(nullptr, path, MAX_PATH);
        if (length == 0 || length >= MAX_PATH)
            return ".";

        std::filesystem::path exe(path);
        return exe.parent_path().string();
    }

    GameVersionInfo DetectGameVersion()
    {
        GameVersionInfo result;

        char path[MAX_PATH]{};
        DWORD length = GetModuleFileNameA(nullptr, path, MAX_PATH);
        if (length == 0 || length >= MAX_PATH)
            return result;

        result.exePath = path;

        WIN32_FILE_ATTRIBUTE_DATA data{};
        if (!GetFileAttributesExA(path, GetFileExInfoStandard, &data))
            return result;

        ULARGE_INTEGER size{};
        size.HighPart = data.nFileSizeHigh;
        size.LowPart = data.nFileSizeLow;
        result.fileSize = size.QuadPart;

        std::filesystem::path exe(path);
        const std::string filename = exe.filename().string();

        result.supported =
            (_stricmp(filename.c_str(), "speed.exe") == 0) &&
            (result.fileSize == SupportedSpeedExeSize);

        return result;
    }
}
