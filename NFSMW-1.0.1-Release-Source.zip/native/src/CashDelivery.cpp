#include "CareerBootstrap.h"
#include "CashDelivery.h"
#include "BridgeClient.h"
#include "JsonLite.h"
#include "Logger.h"
#include "NotificationOverlay.h"
#include "NativeFrontend.h"
#include <Windows.h>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <map>
#include <mutex>

namespace {
    std::mutex cashMutex;
    std::map<int,int> pendingCash,creditedCash;
    std::string cashSession;
    std::filesystem::path cashPath;
    bool loaded=false;
    void LoadCashReceipts() {
        if (loaded) return;
        loaded=true;
        char root[4096]={},key[512]={};
        const auto a=GetEnvironmentVariableA("NFSMW_AP_DOCUMENTS_ROOT",root,sizeof(root));
        const auto b=GetEnvironmentVariableA("NFSMW_AP_SESSION_KEY",key,sizeof(key));
        if (!a || a>=sizeof(root) || !b || b>=sizeof(key)) return;
        cashSession=key;NFSMWAP::Log("NFSMW_AP_CASH_DELIVERY_V1: native cash delivery and per-receipt deduplication active.");cashPath=std::filesystem::path(root)/"NFSMW_AP_CashReceipts.jsonl";
        std::ifstream file(cashPath);std::string line;
        while (std::getline(file,line)) {
            int index=-1,item=0;std::string session;
            if (line.size()<=2048 && NFSMWAP::JsonLite::GetInt(line,"index",index) && index>=0 &&
                NFSMWAP::JsonLite::GetInt(line,"item_id",item) && NFSMWAP::CashItemAmount(item)>0 &&
                NFSMWAP::JsonLite::GetString(line,"session_key",session) && session==cashSession)
                creditedCash[index]=item;
        }
    }
    bool SaveCashReceipts() {
        if (cashPath.empty()) return false;
        const auto temp=std::filesystem::path(cashPath.string()+".tmp");
        std::ofstream file(temp,std::ios::trunc);
        for (const auto& row:creditedCash)
            file<<"{\"index\":"<<row.first<<",\"item_id\":"<<row.second
                <<",\"session_key\":\""<<NFSMWAP::JsonLite::Escape(cashSession)<<"\"}\n";
        file.flush();if (!file) return false;file.close();if (!file) return false;
#ifdef _WIN32
        return MoveFileExW(temp.c_str(),cashPath.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=0;
#else
        std::error_code error;std::filesystem::rename(temp,cashPath,error);return !error;
#endif
    }
    bool ReadCashContext(std::uint32_t& settings,int& cash) {
        __try {
            const auto flow=*reinterpret_cast<int*>(0x925E90u);
            if (flow!=3 && flow!=6) return false;
            const auto db=*reinterpret_cast<std::uint32_t*>(0x91CF90u);
            if (!db || !NFSMWAP::NativeCareerDeliveryMode(*reinterpret_cast<std::uint32_t*>(db+0x12Cu))) return false;
            const auto profile=*reinterpret_cast<std::uint32_t*>(db+0x10u);
            if (profile<0x10000u || (profile&3u) || !*reinterpret_cast<unsigned char*>(profile+0x20u) ||
                *reinterpret_cast<unsigned char*>(profile+0xB0u)>15u) return false;
            if (flow==6) {
                const auto race=*reinterpret_cast<std::uint32_t*>(0x91E000u);
                if (!race || reinterpret_cast<int(__thiscall*)(void*)>(0x404A70u)(reinterpret_cast<void*>(race))!=-1) return false;
            }
            settings=profile+0xA8u;cash=*reinterpret_cast<int*>(settings+0xCu);
            return cash>=0 && cash<=999999999;
        } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }
    bool CreditCash(std::uint32_t settings,int amount,int before) {
        __try {
            reinterpret_cast<void(__thiscall*)(void*,int)>(0x566010u)(reinterpret_cast<void*>(settings),amount);
            if (*reinterpret_cast<int*>(settings+0xCu)==before+amount) return true;
            *reinterpret_cast<int*>(settings+0xCu)=before;return false;
        } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }
    void UndoCash(std::uint32_t settings,int before) {
        __try {*reinterpret_cast<int*>(settings+0xCu)=before;}
        __except(EXCEPTION_EXECUTE_HANDLER) {}
    }
}

namespace NFSMWAP {
    void RequestCareerAutosave() {
        __try {
            const auto card=*reinterpret_cast<std::uint32_t*>(0x91CB20u);
            if (card>=0x10000u && !reinterpret_cast<bool(__cdecl*)()>(0x5436B0u)())
                reinterpret_cast<void(__thiscall*)(void*,bool)>(0x562AB0u)(reinterpret_cast<void*>(card),false);
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
    }
    void QueueReceivedCash(int index,int item,const std::string& session) {
        if (index<0 || CashItemAmount(item)<=0) return;
        std::lock_guard<std::mutex> lock(cashMutex);LoadCashReceipts();
        if (cashSession.empty() || session!=cashSession) return;
        const auto old=creditedCash.find(index);
        if (old!=creditedCash.end() && old->second!=item) return;
        pendingCash.emplace(index,item);
    }
    void CashDeliveryMainThreadTick() {
        if (!IsCareerProfileReady()) return;
        int index=-1,item=0,amount=0;std::string session;bool credit=false;
        {
            std::lock_guard<std::mutex> lock(cashMutex);LoadCashReceipts();
            if (pendingCash.empty()) return;
            const auto row=pendingCash.begin();index=row->first;item=row->second;amount=CashItemAmount(item);session=cashSession;
            if (!creditedCash.count(index)) {
                std::uint32_t settings=0;int before=0;
                if (!ReadCashContext(settings,before) || before>999999999-amount || !CreditCash(settings,amount,before)) return;
                creditedCash[index]=item;
                if (!SaveCashReceipts()) {
                    creditedCash.erase(index);UndoCash(settings,before);
                    Log("AP CASH: receipt could not be saved; credit rolled back and retained for retry.");return;
                }
                credit=true;
            }
        }
        if (credit) {
            RequestCareerAutosave();
            Log("AP CASH CREDITED: index="+std::to_string(index)+" amount="+std::to_string(amount)+"; native Career balance updated.");

        }
        const auto ack="{\"type\":\"received_item_ack\",\"index\":"+std::to_string(index)+
            ",\"item_id\":"+std::to_string(item)+",\"cash_credited\":true,\"session_key\":\""+JsonLite::Escape(session)+"\"}";
        if (SendBridgeLine(ack)) {std::lock_guard<std::mutex> lock(cashMutex);pendingCash.erase(index);}
    }
}
