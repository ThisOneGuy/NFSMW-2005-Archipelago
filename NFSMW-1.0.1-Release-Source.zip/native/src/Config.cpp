#include "Config.h"

#include <Windows.h>

namespace
{
    std::string ReadString(
        const std::string& iniPath,
        const char* section,
        const char* key,
        const char* fallback)
    {
        char buffer[1024]{};
        GetPrivateProfileStringA(
            section,
            key,
            fallback,
            buffer,
            static_cast<DWORD>(sizeof(buffer)),
            iniPath.c_str());
        return buffer;
    }
}

namespace NFSMWAP
{
    Config LoadConfig(const std::string& gameDirectory)
    {
        Config config;
        const std::string iniPath =
            gameDirectory + "\\NFSMWArchipelago.ini";

        config.serverAddress =
            ReadString(iniPath, "Archipelago", "Server", "localhost:38281");

        config.slotName =
            ReadString(iniPath, "Archipelago", "Slot", "Nathan");

        config.password =
            ReadString(iniPath, "Archipelago", "Password", "");

        config.deathLink =
            GetPrivateProfileIntA(
                "Archipelago",
                "DeathLink",
                0,
                iniPath.c_str()) != 0;

        config.bridgeHost =
            ReadString(iniPath, "Bridge", "Host", "127.0.0.1");

        config.bridgePort =
            GetPrivateProfileIntA(
                "Bridge",
                "Port",
                38283,
                iniPath.c_str());

        config.inGameNotifications =
            GetPrivateProfileIntA(
                "Display",
                "InGameNotifications",
                1,
                iniPath.c_str()) != 0;

        config.storeRuntime =
            GetPrivateProfileIntA(
                "Randomization",
                "EnableStoreRuntime",
                1,
                iniPath.c_str()) != 0;

        config.storePurchaseHotkey =
            GetPrivateProfileIntA(
                "Randomization",
                "StorePurchaseHotkey",
                VK_F7,
                iniPath.c_str());

        return config;
    }
}
