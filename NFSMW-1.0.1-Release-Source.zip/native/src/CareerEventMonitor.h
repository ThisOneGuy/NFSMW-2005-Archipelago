#pragma once

#include <Windows.h>

namespace NFSMWAP
{
    DWORD WINAPI CareerEventMonitorThread(LPVOID);


    void CareerEventMainThreadTick();
}
