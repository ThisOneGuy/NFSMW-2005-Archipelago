#include "ItemInventory.h"

#include <mutex>
#include <unordered_map>

namespace
{
    std::mutex g_itemMutex;
    std::unordered_map<int, NFSMWAP::ReceivedItem> g_itemsById;
}

namespace NFSMWAP
{
    void AddReceivedItem(const ReceivedItem& item)
    {
        if (item.itemId <= 0)
            return;
        std::lock_guard<std::mutex> lock(g_itemMutex);
        g_itemsById[item.itemId] = item;
    }

    bool HasReceivedItem(int itemId)
    {
        std::lock_guard<std::mutex> lock(g_itemMutex);
        return g_itemsById.find(itemId) != g_itemsById.end();
    }

    std::size_t GetReceivedItemCount()
    {
        std::lock_guard<std::mutex> lock(g_itemMutex);
        return g_itemsById.size();
    }

    std::vector<ReceivedItem> GetReceivedInventory()
    {
        std::lock_guard<std::mutex> lock(g_itemMutex);
        std::vector<ReceivedItem> result;
        for (const auto& row : g_itemsById) result.push_back(row.second);
        return result;
    }
}
