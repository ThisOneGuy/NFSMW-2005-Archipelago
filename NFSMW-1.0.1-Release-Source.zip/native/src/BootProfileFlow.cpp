#include "BootProfileFlow.h"
#include "SaveIsolation.h"
#include "GameVersion.h"
#include "CareerBootstrap.h"
#include "Logger.h"
#include <Windows.h>
namespace {
using Word=std::uint32_t;
const char emptyBootStep[]="";
unsigned skippedSteps=0;
bool bootFlowReady=false,aliasGuardReady=false;
bool ManagedAutoLoad(Word operation) {
    __try {return operation==0xF1u&&*reinterpret_cast<int*>(0x925E90u)==3&&NFSMWAP::IsCareerStartupManaged();}
    __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
void __cdecl StartupAutoLoad(const char* from,const char* to,Word operation,void* callback,void* parameter,Word success,Word failure) {
    if(!from&&!to&&!callback&&!parameter&&!success&&!failure&&ManagedAutoLoad(operation)) {
        NFSMWAP::Log("AP STARTUP PROFILE FLOW: native menu auto-load deferred to the bound session slot.");return;
    }
    reinterpret_cast<void(__cdecl*)(const char*,const char*,Word,void*,void*,Word,Word)>(0x527940u)
        (from,to,operation,callback,parameter,success,failure);
}
bool ContinueBoundAlias(Word* screen,Word language,Word prompt) {
    __try {
        const auto operation=*reinterpret_cast<Word*>(0x91CBACu);
        if(!NFSMWAP::IsCareerStartupAliasPrompt(NFSMWAP::IsSaveIsolationActive(),NFSMWAP::IsCareerStartupManaged(),
            *reinterpret_cast<int*>(0x925E90u),language,prompt,operation)||!screen)return false;
        const auto* table=reinterpret_cast<const Word*>(*screen);
        if(!table||(table[1]!=0x564630u&&table[1]!=0x5644F0u))return false;
        const auto* package=reinterpret_cast<const char*>(screen[4]);
        if(!package||(std::strncmp(package,"MC_Main",7)&&std::strncmp(package,"MC_Bootup",9)))return false;
        auto* feng=*reinterpret_cast<void**>(0x91CADCu);if(!feng)return false;
        auto* setup=reinterpret_cast<void*>(0x91CBACu);
        reinterpret_cast<void(__thiscall*)(void*,int)>(0x50EAF0u)(setup,static_cast<int>(prompt));
        reinterpret_cast<void(__thiscall*)(void*)>(0x50EB40u)(setup);
        reinterpret_cast<void(__thiscall*)(void*)>(0x54F9A0u)(screen);
        reinterpret_cast<void(__thiscall*)(void*,Word,const char*,Word)>(0x516C50u)(feng,0x8867412Du,package,0xFFu);
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
void __fastcall StartupAliasPrompt(Word* screen,void*,Word language,Word prompt) {
    if(ContinueBoundAlias(screen,language,prompt)) {
        NFSMWAP::Log("AP STARTUP PROFILE FLOW: alias creation declined before display; continuing the bound session load.");return;
    }
    reinterpret_cast<void(__thiscall*)(void*,Word,Word)>(0x543CC0u)(screen,language,prompt);
}
bool HasConstant(const unsigned char* code,std::size_t size,Word value) {
    for(std::size_t offset=0;offset+4u<=size;++offset) {
        Word actual=0;std::memcpy(&actual,code+offset,4);if(actual==value)return true;
    }
    return false;
}
bool InstallAliasGuard() {
    if(aliasGuardReady)return true;
    const auto* menu=reinterpret_cast<const unsigned char*>(0x559FC0u);
    const auto* saveFlow=reinterpret_cast<const unsigned char*>(0x544370u);
    NFSMWAP::CareerBootBranches loads,prompts;
    if(!HasConstant(menu,0x2A0u,0xF1u)||!HasConstant(menu,0x2A0u,0x35F8620Bu)||
       !HasConstant(saveFlow,0x166u,0xBE97590Fu)||!HasConstant(saveFlow,0x166u,0x01000000u)||
       !NFSMWAP::FindCareerBootBranches(menu,0x2A0u,0x559FC0u,0x527940u,loads)||loads.count!=1u||
       !NFSMWAP::FindCareerBootBranches(saveFlow,0x166u,0x544370u,0x543CC0u,prompts))return false;
    struct Patch {Word* address;Word original,replacement;DWORD protection;};
    Patch patches[4]{};unsigned count=0;
    const auto add=[&](const NFSMWAP::CareerBootBranches& entries,Word address,const void* hook) {
        for(unsigned n=0;n<entries.count;++n) {
            const auto& entry=entries.slots[n];const Word site=address+entry.offset;
            patches[count++]={reinterpret_cast<Word*>(site),entry.original,
                static_cast<Word>(reinterpret_cast<std::uintptr_t>(hook)-site-4u),0};
        }
    };
    add(loads,0x559FC0u,reinterpret_cast<const void*>(&StartupAutoLoad));
    add(prompts,0x544370u,reinterpret_cast<const void*>(&StartupAliasPrompt));
    unsigned writable=0;
    for(;writable<count;++writable)if(*patches[writable].address!=patches[writable].original||
        !VirtualProtect(patches[writable].address,4,PAGE_EXECUTE_READWRITE,&patches[writable].protection))break;
    if(writable!=count) {
        while(writable){const auto& p=patches[--writable];DWORD unused=0;VirtualProtect(p.address,4,p.protection,&unused);}return false;
    }
    for(unsigned n=0;n<count;++n)*patches[n].address=patches[n].replacement;
    for(unsigned n=count;n;) {
        const auto& p=patches[--n];DWORD unused=0;VirtualProtect(p.address,4,p.protection,&unused);
        FlushInstructionCache(GetCurrentProcess(),p.address,4);
    }
    aliasGuardReady=true;return true;
}
}
namespace NFSMWAP {
bool PrimeCareerBootFlowEarly() {
    if(bootFlowReady)return true;
    char mode[8]={};
    if(!IsSaveIsolationActive()||GetEnvironmentVariableA("NFSMW_AP_BOOTSTRAP",mode,sizeof(mode))!=1u||mode[0]!='2')return true;
    char path[MAX_PATH]={};WIN32_FILE_ATTRIBUTE_DATA file{};
    if(!GetModuleFileNameA(nullptr,path,MAX_PATH)||!GetFileAttributesExA(path,GetFileExInfoStandard,&file)||file.nFileSizeHigh||file.nFileSizeLow!=SupportedSpeedExeSize)return false;
    __try {
        auto* image=reinterpret_cast<unsigned char*>(GetModuleHandleW(nullptr));if(!image)return false;
        const auto* dos=reinterpret_cast<const IMAGE_DOS_HEADER*>(image);
        if(dos->e_magic!=IMAGE_DOS_SIGNATURE||dos->e_lfanew<64||dos->e_lfanew>0x800)return false;
        const auto* nt=reinterpret_cast<const IMAGE_NT_HEADERS32*>(image+dos->e_lfanew);
        if(nt->Signature!=IMAGE_NT_SIGNATURE||nt->FileHeader.Machine!=IMAGE_FILE_MACHINE_I386||
           nt->OptionalHeader.Magic!=IMAGE_NT_OPTIONAL_HDR32_MAGIC||nt->OptionalHeader.ImageBase!=0x400000u||
           reinterpret_cast<std::uintptr_t>(image)!=0x400000u||nt->OptionalHeader.SizeOfImage<0x530000u)return false;
        if(!InstallAliasGuard())return false;
        BootProfileEntries entries;if(!FindBootProfileEntries(image,nt->OptionalHeader.SizeOfImage,entries))return true;
        DWORD protection[32]={};unsigned writable=0;
        for(;writable<entries.count;++writable)if(!VirtualProtect(entries.slots[writable],4,PAGE_READWRITE,&protection[writable]))break;
        if(writable!=entries.count) {
            while(writable){--writable;DWORD unused=0;VirtualProtect(entries.slots[writable],4,protection[writable],&unused);}return false;
        }
        for(unsigned index=0;index<entries.count;++index)*entries.slots[index]=static_cast<std::uint32_t>(reinterpret_cast<std::uintptr_t>(emptyBootStep));
        for(unsigned index=entries.count;index;){--index;DWORD unused=0;VirtualProtect(entries.slots[index],4,protection[index],&unused);}
        skippedSteps=entries.count;bootFlowReady=true;return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
unsigned CareerBootProfileStepsSkipped(){return skippedSteps;}
}
