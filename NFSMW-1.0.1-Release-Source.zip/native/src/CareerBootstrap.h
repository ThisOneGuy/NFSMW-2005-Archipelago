#pragma once
namespace NFSMWAP {
    bool InstallCareerBootstrapHooks();
    bool IsCareerStartupManaged();
    void CareerBootstrapMainThreadTick();
    bool InitialDealershipNeedsCar();
    bool InitialDealershipSelectionPending();
    bool IsCareerProfileReady();
    const char* CareerLoadStatusText();
    void NotifyInitialCareerCarSelected();
}
