#include "DeathLinkRuntime.h"
#include "BridgeClient.h"
#include "JsonLite.h"
#include "Logger.h"
#include "NotificationOverlay.h"
#include <Windows.h>
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <deque>
#include <mutex>
#include <set>

namespace
{
    using Word=std::uint32_t;
    struct Incoming {
        std::string id,source;
        bool announced=false,requested=false,authorized=false,denied=false,forceAttempted=false,frontSpawned=false,sawPursuit=false;
        DWORD lastRequest=0,startedAt=0,lastPoll=0;
        Word frontPursuit=0,frontManager=0;
        const char* model=nullptr;
    };
    struct ArrestNotice {std::string id,key,line;DWORD created=0,lastTry=0;};
    std::deque<ArrestNotice> outgoing;
    bool commitHookTried=false,commitHookReady=false,linkedBustPending=false,linkedArrestCommitted=false;
    Word counterProfile=0;unsigned counterTotal=0,arrestSequence=0;
    bool counterReady=false,counterArmed=false;
    DWORD arrestRecoverySince=0;
    std::mutex mutex;
    std::deque<Incoming> pending;
    std::set<std::string> applied;
    bool enabled=false,suppressed=false,arrestLatched=false,episodeActive=false,episodeArmed=false,penaltyActive=false;
    std::string session,runtimeID;
    unsigned episode=0;
    DWORD recoverySince=0;
    constexpr DWORD RecoveryDrivingMs=1500u,FrontSpawnDeadlineMs=15000u;
    bool restorePolice=false;Word restoreStatus=0,restoreProfile=0;int restoreRace=-1,originalDisable=0;
    bool releaseHeat=false,heatSawPursuit=false;
    Word heatProfile=0,heatPerp=0,heatPursuit=0,heatStatus=0;int heatRace=-1;
    float heatBefore=1,heatRaised=1;DWORD heatStartedAt=0;

    bool MatchesSession(const std::string& key)
    {
        char current[512]={};
        const auto length=GetEnvironmentVariableA("NFSMW_AP_SESSION_KEY",current,sizeof(current));
        return length && length<sizeof(current) && key==current;
    }

    bool LocalCareerPlayer(Word handle)
    {
        __try {
            const Word db=*reinterpret_cast<Word*>(0x91CF90u);
            if (!handle || !db || !(*reinterpret_cast<Word*>(db+0x12Cu)&1u) ||
                (*reinterpret_cast<Word*>(db+0x12Cu)&0xEu)) return false;
            const Word profile=*reinterpret_cast<Word*>(db+0x10u);
            if (!profile || *reinterpret_cast<unsigned char*>(profile+0xB0u)>15u) return false;
            void* simable=reinterpret_cast<void*(__cdecl*)(void*)>(0x41AD40u)(reinterpret_cast<void*>(handle));
            return simable && reinterpret_cast<bool(__cdecl*)(void*)>(0x60A760u)(simable);
        }
        __except(EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    Word ResolveInterfaceObject(Word interfaceAddress,unsigned int slot,Word destination)
    {


        __try {
            Word code=*reinterpret_cast<Word*>(*reinterpret_cast<Word*>(interfaceAddress)+slot*4u);
            std::int64_t address=interfaceAddress;
            for (int depth=0;depth<4;++depth) {
                if (code==destination) return address>=0x10000 && address<=0xFFFFFFFFu && !(address&3) ? static_cast<Word>(address) : 0;
                if (code<0x400000u || code>=0x880000u) return 0;
                const auto bytes=reinterpret_cast<const unsigned char*>(code);
                unsigned length=0;
                if (bytes[0]==0x83 && bytes[1]==0xE9) {address-=static_cast<std::int8_t>(bytes[2]);length=3;}
                else if (bytes[0]==0x81 && bytes[1]==0xE9) {address-=*reinterpret_cast<const std::int32_t*>(bytes+2);length=6;}
                else if (bytes[0]==0x83 && bytes[1]==0xC1) {address+=static_cast<std::int8_t>(bytes[2]);length=3;}
                else if (bytes[0]==0x81 && bytes[1]==0xC1) {address+=*reinterpret_cast<const std::int32_t*>(bytes+2);length=6;}
                else if (bytes[0]==0x8D && bytes[1]==0x49) {address+=static_cast<std::int8_t>(bytes[2]);length=3;}
                else if (bytes[0]==0x8D && bytes[1]==0x89) {address+=*reinterpret_cast<const std::int32_t*>(bytes+2);length=6;}
                if (bytes[length]==0xE9) code=code+length+5u+*reinterpret_cast<const std::int32_t*>(bytes+length+1);
                else if (bytes[length]==0xEB) code=code+length+2u+static_cast<std::int8_t>(bytes[length+1]);
                else return 0;
            }
            return 0;
        }
        __except(EXCEPTION_EXECUTE_HANDLER) { return 0; }
    }

    struct World { Word manager=0,cops=0,pursuit=0,pursuitObject=0,perp=0,status=0,profile=0;float cap=0;int race=-1,disabled=0;bool busted=false,bailed=false,finishedRace=false,cooldown=false; };
    bool ReadWorld(World& world)
    {

        __try {
            if (*reinterpret_cast<int*>(0x925E90u)!=6 ||
                reinterpret_cast<bool(__thiscall*)(void*)>(0x64B680u)(reinterpret_cast<void*>(0x925E70u))) return false;
            const Word db=*reinterpret_cast<Word*>(0x91CF90u);
            if (!db || !(*reinterpret_cast<Word*>(db+0x12Cu)&1u) || (*reinterpret_cast<Word*>(db+0x12Cu)&0xEu)) return false;
            const Word status=*reinterpret_cast<Word*>(0x91E000u);
            if (!status) return false;
            world.status=status;
            const int race=reinterpret_cast<int(__thiscall*)(void*)>(0x404A70u)(reinterpret_cast<void*>(status));
            world.race=race;world.disabled=*reinterpret_cast<int*>(0x90D5ECu);
            if (race!=-1) {
                const auto racer=reinterpret_cast<unsigned char*(__thiscall*)(void*,int)>(0x5DBED0u)(reinterpret_cast<void*>(status),0);
                if (!racer) return false;
                world.finishedRace=racer[0x21u]!=0;
            }
            const Word profile=*reinterpret_cast<Word*>(db+0x10u),database=*reinterpret_cast<Word*>(0x91E004u);
            if (!profile || !database) return false;
            world.profile=profile;
            const unsigned rank=*reinterpret_cast<unsigned char*>(profile+0xB0u);
            if (rank>15) return false;
            void* bin=reinterpret_cast<void*(__thiscall*)(void*,int)>(0x5E3980u)(reinterpret_cast<void*>(database),rank);
            if (!bin) return false;
            world.cap=reinterpret_cast<float(__thiscall*)(void*)>(0x5DCF00u)(bin);
            if (!std::isfinite(world.cap) || world.cap<1 || world.cap>10) return false;
            world.manager=*reinterpret_cast<Word*>(0x91E00Cu);
            const Word copInterface=*reinterpret_cast<Word*>(0x92C67Cu);
            if (!world.manager || !copInterface) return false;


            world.cops=ResolveInterfaceObject(copInterface,13u,0x42EBF0u);
            if (!world.cops) world.cops=ResolveInterfaceObject(copInterface,11u,0x42EBF0u);
            if (!world.cops) return false;
            reinterpret_cast<void(__thiscall*)(void*,Word&,Word&)>(0x5EB9E0u)(reinterpret_cast<void*>(world.manager),world.pursuit,world.perp);
            if (world.pursuit) {
                world.pursuitObject=ResolveInterfaceObject(world.pursuit,3u,0x433C90u);
                if (!world.pursuitObject) world.pursuitObject=ResolveInterfaceObject(world.pursuit,78u,0x40A9B0u);
                if (!world.pursuitObject) return false;
                world.busted=reinterpret_cast<bool(__thiscall*)(void*)>(0x433890u)(reinterpret_cast<void*>(world.pursuitObject));
                world.bailed=reinterpret_cast<bool(__thiscall*)(void*)>(0x433920u)(reinterpret_cast<void*>(world.pursuitObject));
                world.cooldown=reinterpret_cast<int(__thiscall*)(void*)>(0x433B60u)(reinterpret_cast<void*>(world.pursuitObject))==2;
            }
            return world.perp!=0;
        }
        __except(EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    Word VerifiedArrest(Word handle)
    {
        if (!LocalCareerPlayer(handle)) return 0;
        __try {
            Word pursuit=0,perp=0;
            const auto manager=*reinterpret_cast<Word*>(0x91E00Cu);
            if (!manager) return 0;
            reinterpret_cast<void(__thiscall*)(void*,Word&,Word&)>(0x5EB9E0u)(reinterpret_cast<void*>(manager),pursuit,perp);
            if (!pursuit) return 0;
            const auto owner=ResolveInterfaceObject(pursuit,3u,0x433C90u);
            return owner && reinterpret_cast<bool(__thiscall*)(void*)>(0x433890u)(reinterpret_cast<void*>(owner)) ? owner : 0;
        }
        __except(EXCEPTION_EXECUTE_HANDLER) {return 0;}
    }

    bool ForcePursuit(const World& world)
    {
        __try {

            const Word table=*reinterpret_cast<Word*>(world.perp);
            const auto setter=*reinterpret_cast<Word*>(table+8u);
            if (setter<0x400000u || setter>=0x880000u) return false;


            const auto getter=*reinterpret_cast<Word*>(table+4u);
            if(getter<0x400000u||getter>=0x880000u)return false;
            const float prior=reinterpret_cast<float(__thiscall*)(void*)>(getter)(reinterpret_cast<void*>(world.perp));
            if(!std::isfinite(prior)||prior<0||prior>10)return false;
            heatBefore=prior;heatRaised=std::max(prior,world.cap);
            heatProfile=world.profile;heatPerp=world.perp;heatStartedAt=GetTickCount();
            heatPursuit=world.pursuitObject;heatStatus=world.status;heatRace=world.race;
            heatSawPursuit=world.pursuit!=0;releaseHeat=heatBefore<heatRaised;
            reinterpret_cast<void(__thiscall*)(void*,float)>(setter)(reinterpret_cast<void*>(world.perp),heatRaised);
            *reinterpret_cast<int*>(0x90D5ECu)=0;
            reinterpret_cast<void(__thiscall*)(void*,bool)>(0x411410u)(reinterpret_cast<void*>(world.cops),false);
            reinterpret_cast<void(__cdecl*)(int)>(0x60AAC0u)(static_cast<int>(std::floor(world.cap)));
            return true;
        }
        __except(EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    void ReleaseHeatBoost(const World& world,DWORD now)
    {
        if(!releaseHeat)return;
        if(world.profile!=heatProfile||world.perp!=heatPerp){releaseHeat=false;return;}
        if(world.pursuit&&!world.busted&&!world.bailed&&!world.finishedRace&&!world.cooldown&&
           world.status==heatStatus&&world.race==heatRace) {
            if(!heatSawPursuit){heatSawPursuit=true;heatPursuit=world.pursuitObject;}
            if(world.pursuitObject==heatPursuit)return;
        }
        if(!world.pursuit&&!heatSawPursuit&&now-heatStartedAt<2000u)return;
        __try {
            const auto table=*reinterpret_cast<Word*>(world.perp);
            const auto get=*reinterpret_cast<Word*>(table+4u),set=*reinterpret_cast<Word*>(table+8u);
            if(get<0x400000u||get>=0x880000u||set<0x400000u||set>=0x880000u){releaseHeat=false;return;}
            const float current=reinterpret_cast<float(__thiscall*)(void*)>(get)(reinterpret_cast<void*>(world.perp));


            if(std::isfinite(current)&&current>heatBefore&&current<=heatRaised+0.001f)
                reinterpret_cast<void(__thiscall*)(void*,float)>(set)(reinterpret_cast<void*>(world.perp),heatBefore);
            releaseHeat=false;
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
    }

    struct Vector3 {float x,y,z;};
    struct TargetPose {
        Word table,next,previous,owner;Vector3 position;Word simable;
        Vector3 direction;unsigned char valid,padding[3];Vector3 delta;float distance;
    };
    static_assert(sizeof(TargetPose)==0x40u,"Retail AITarget layout");
    static_assert(offsetof(TargetPose,position)==0x10u && offsetof(TargetPose,direction)==0x20u,"Retail target pose offsets");
    bool frontHookTried=false,frontHookReady=false;
    Word frontHookSlot=0,frontHookOperand=0;


    Word frontAttemptManager=0;
    bool frontAttemptSeen=false,frontAttemptSucceeded=false;
    bool __fastcall TryFrontCop(void* manager,void*,const void* request)
    {
        const bool ours=frontAttemptManager==reinterpret_cast<std::uintptr_t>(manager)&&!frontAttemptSeen;
        if(!ours)return reinterpret_cast<bool(__thiscall*)(void*,const void*)>(0x42E6C0u)(manager,request);
        frontAttemptSeen=true;
        __try {frontAttemptSucceeded=reinterpret_cast<bool(__thiscall*)(void*,const void*)>(0x42E6C0u)(manager,request);}
        __except(EXCEPTION_EXECUTE_HANDLER) {frontAttemptSucceeded=false;}


        return true;
    }
    bool InstallFrontCopHook()
    {
        Word slot=0;
        for(Word at=0x42E8D0u;at+5u<=0x42E927u;++at) {
            if(*reinterpret_cast<const unsigned char*>(at)!=0xE8u ||
               at+5u+*reinterpret_cast<const std::int32_t*>(at+1u)!=0x42E6C0u)continue;
            if(slot)return false;slot=at+1u;at+=4u;
        }
        if(!slot)return false;
        DWORD old=0,unused=0;
        if(!VirtualProtect(reinterpret_cast<void*>(slot),4,PAGE_EXECUTE_READWRITE,&old))return false;
        frontHookOperand=static_cast<Word>(reinterpret_cast<std::uintptr_t>(&TryFrontCop)-slot-4u);
        *reinterpret_cast<Word*>(slot)=frontHookOperand;frontHookSlot=slot;
        VirtualProtect(reinterpret_cast<void*>(slot),4,old,&unused);
        FlushInstructionCache(GetCurrentProcess(),reinterpret_cast<void*>(slot),4);
        return true;
    }
    bool PlaceFrontCop(const World& world,const char*& model)
    {


        __try {
            if (!frontHookReady || !frontHookSlot || *reinterpret_cast<Word*>(frontHookSlot)!=frontHookOperand ||
                !world.pursuitObject || world.cooldown ||
                reinterpret_cast<bool(__thiscall*)(void*)>(0x411060u)(reinterpret_cast<void*>(world.cops))) return false;
            if (!model) model=reinterpret_cast<const char*(__cdecl*)()>(0x419AE0u)();
            if (!model || !reinterpret_cast<void*(__thiscall*)(void*,const char*)>(0x41ECD0u)(reinterpret_cast<void*>(world.cops),model)) return false;
            const auto target=reinterpret_cast<const TargetPose*(__thiscall*)(void*)>(0x40AE70u)(reinterpret_cast<void*>(world.pursuitObject));
            if (!target || !target->valid) return false;
            Vector3 position=target->position,direction=target->direction;
            const float length=std::sqrt(direction.x*direction.x+direction.z*direction.z);
            if (!std::isfinite(position.x) || !std::isfinite(position.y) || !std::isfinite(position.z) || !std::isfinite(length) || length<0.01f) return false;
            direction={direction.x/length,0,direction.z/length};
            position.x+=direction.x*50.0f;position.z+=direction.z*50.0f;
            Vector3 roadPosition{},roadDirection{};
            if (reinterpret_cast<bool(__thiscall*)(void*,void*,Vector3&,Vector3&,float)>(0x41EED0u)(reinterpret_cast<void*>(world.cops),reinterpret_cast<void*>(world.pursuit),roadPosition,roadDirection,50.0f)) {
                position=roadPosition;direction=roadDirection;
            }
            frontAttemptManager=world.cops;frontAttemptSeen=false;frontAttemptSucceeded=false;
            reinterpret_cast<void(__thiscall*)(void*,Vector3&,Vector3&,const char*,bool,bool)>(0x439DD0u)(reinterpret_cast<void*>(world.cops),position,direction,model,true,false);
            reinterpret_cast<void(__thiscall*)(void*)>(0x42E8D0u)(reinterpret_cast<void*>(world.cops));
            frontAttemptManager=0;
            return frontAttemptSeen&&frontAttemptSucceeded;
        }
        __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }
    void RestorePoliceOverride()
    {
        if(!restorePolice)return;
        __try {
            if(*reinterpret_cast<int*>(0x90D5ECu)==0)*reinterpret_cast<int*>(0x90D5ECu)=originalDisable;
            restorePolice=false;
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
    }
    void RestorePoliceOnSceneChange()
    {
        if(!restorePolice)return;


        __try {
            const auto db=*reinterpret_cast<Word*>(0x91CF90u);
            const auto profile=db?*reinterpret_cast<Word*>(db+0x10u):0;
            const auto status=*reinterpret_cast<Word*>(0x91E000u);
            if(*reinterpret_cast<int*>(0x925E90u)!=6||profile!=restoreProfile||status!=restoreStatus)
                RestorePoliceOverride();
            else if(status&&reinterpret_cast<int(__thiscall*)(void*)>(0x404A70u)(reinterpret_cast<void*>(status))!=restoreRace)
                RestorePoliceOverride();
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
    }
    void RestorePolicePolicy(const World& world)
    {
        if (!restorePolice) return;
        if (world.status!=restoreStatus || world.profile!=restoreProfile || world.race!=restoreRace) {RestorePoliceOverride();return;}
        if (world.pursuit && !world.busted && !world.bailed && !world.finishedRace && !world.cooldown) return;
        RestorePoliceOverride();
    }
    bool ReadCleanupWorld(World& world)
    {


        __try {
            const int flow=*reinterpret_cast<int*>(0x925E90u);if(flow!=3&&flow!=6)return false;
            const auto db=*reinterpret_cast<Word*>(0x91CF90u);
            if(!db||!(*reinterpret_cast<Word*>(db+0x12Cu)&1u)||(*reinterpret_cast<Word*>(db+0x12Cu)&0xEu))return false;
            world.profile=*reinterpret_cast<Word*>(db+0x10u);
            world.manager=*reinterpret_cast<Word*>(0x91E00Cu);
            if(!world.profile||!world.manager)return false;
            world.status=*reinterpret_cast<Word*>(0x91E000u);
            if(world.status) {
                world.race=reinterpret_cast<int(__thiscall*)(void*)>(0x404A70u)(reinterpret_cast<void*>(world.status));
                if(world.race!=-1) {
                    const auto racer=reinterpret_cast<unsigned char*(__thiscall*)(void*,int)>(0x5DBED0u)(reinterpret_cast<void*>(world.status),0);
                    world.finishedRace=racer&&racer[0x21u]!=0;
                }
            }
            reinterpret_cast<void(__thiscall*)(void*,Word&,Word&)>(0x5EB9E0u)(reinterpret_cast<void*>(world.manager),world.pursuit,world.perp);
            if(world.pursuit) {
                world.pursuitObject=ResolveInterfaceObject(world.pursuit,3u,0x433C90u);
                if(!world.pursuitObject)return false;
                world.busted=reinterpret_cast<bool(__thiscall*)(void*)>(0x433890u)(reinterpret_cast<void*>(world.pursuitObject));
                world.bailed=reinterpret_cast<bool(__thiscall*)(void*)>(0x433920u)(reinterpret_cast<void*>(world.pursuitObject));
                world.cooldown=reinterpret_cast<int(__thiscall*)(void*)>(0x433B60u)(reinterpret_cast<void*>(world.pursuitObject))==2;
            }
            return world.perp!=0;
        } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }

    void Ack(const std::string& id,const std::string& key,const std::string& result)
    {
        NFSMWAP::SendBridgeLine("{\"type\":\"deathlink_applied\",\"id\":\""+NFSMWAP::JsonLite::Escape(id)+
            "\",\"session_key\":\""+NFSMWAP::JsonLite::Escape(key)+"\",\"runtime_id\":\""+runtimeID+
            "\",\"result\":\""+result+"\"}");
    }
    void Finish(const Incoming& item,const std::string& key,const std::string& result)
    {
        {
            std::lock_guard<std::mutex> lock(mutex);
            if (session!=key || pending.empty() || pending.front().id!=item.id) return;
            pending.pop_front();applied.insert(item.id);
        }
        Ack(item.id,key,result);
        NFSMWAP::Log("AP DEATHLINK TERMINAL: id="+item.id+" result="+result+"; no additional spawn/restart requests.");
    }


    struct ArrestStats {Word profile=0,pursuit=0;unsigned total=0;int flow=-1;bool paused=true,pursuitReadable=false;};
    bool ReadArrestStats(ArrestStats& stats,bool committedTransition=false)
    {
        __try {
            stats.flow=*reinterpret_cast<int*>(0x925E90u);
            if (!committedTransition && stats.flow!=3 && stats.flow!=6) return false;
            const auto db=*reinterpret_cast<Word*>(0x91CF90u);
            if (!db || !(*reinterpret_cast<Word*>(db+0x12Cu)&1u) || (*reinterpret_cast<Word*>(db+0x12Cu)&0xEu)) return false;
            stats.profile=*reinterpret_cast<Word*>(db+0x10u);
            if (stats.profile<0x10000u || *reinterpret_cast<unsigned char*>(stats.profile+0xB0u)>15u) return false;
            stats.total=reinterpret_cast<unsigned(__thiscall*)(void*)>(0x5905A0u)(reinterpret_cast<void*>(stats.profile+0x414u));
            if (stats.total>2000000u) return false;
            if (stats.flow==6) {
                stats.paused=reinterpret_cast<bool(__thiscall*)(void*)>(0x64B680u)(reinterpret_cast<void*>(0x925E70u));
                const auto manager=*reinterpret_cast<Word*>(0x91E00Cu);
                if (manager) {
                    Word perp=0;
                    reinterpret_cast<void(__thiscall*)(void*,Word&,Word&)>(0x5EB9E0u)(reinterpret_cast<void*>(manager),stats.pursuit,perp);
                    stats.pursuitReadable=true;
                }
            }
            return true;
        }
        __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }
    bool ReadLocalCareerRecord(void* record,unsigned& count)
    {
        __try {
            const auto db=*reinterpret_cast<Word*>(0x91CF90u);
            if (!record || !db || !(*reinterpret_cast<Word*>(db+0x12Cu)&1u) || (*reinterpret_cast<Word*>(db+0x12Cu)&0xEu)) return false;
            const auto profile=*reinterpret_cast<Word*>(db+0x10u);
            if (profile<0x10000u || *reinterpret_cast<unsigned char*>(profile+0xB0u)>15u) return false;
            const auto index=*reinterpret_cast<Word*>(profile+0xA8u);
            if (index>=200u) return false;
            void* stable=reinterpret_cast<void*>(profile+0x414u);
            const auto car=reinterpret_cast<const unsigned char*(__thiscall*)(void*,Word)>(0x56ECF0u)(stable,index);
            if (!car || !(*reinterpret_cast<const Word*>(car+12u)&2u) || car[17]>=25u) return false;
            const auto career=reinterpret_cast<void*(__thiscall*)(void*,unsigned char)>(0x56F120u)(stable,car[17]);
            if (career!=record) return false;
            count=reinterpret_cast<unsigned(__thiscall*)(void*)>(0x50DFD0u)(record);
            return count<=65535u;
        }
        __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }
    void QueueCommittedArrest(unsigned count,const char* verification,bool capturedEcho=false)
    {
        ArrestNotice notice;bool echo=false;
        {
            std::lock_guard<std::mutex> lock(mutex);
            if (!enabled || !MatchesSession(session)) return;
            echo=capturedEcho||(suppressed && !linkedArrestCommitted)||linkedBustPending;linkedBustPending=false;
            if (echo) linkedArrestCommitted=true;
            arrestLatched=true;episodeArmed=false;
            if (!echo) {
                notice.id=runtimeID+"_bust_"+std::to_string(++arrestSequence);notice.key=session;
                notice.created=GetTickCount();notice.lastTry=notice.created;
                notice.line="{\"type\":\"deathlink_bust\",\"event_id\":\""+notice.id+"\",\"pursuit_id\":\""+notice.id+
                    "\",\"native_busted\":true,\"career_mode\":true,\"verification\":\""+verification+
                    "\",\"bust_count\":"+std::to_string(count)+",\"session_key\":\""+NFSMWAP::JsonLite::Escape(session)+"\"}";
            }
        }
        if (echo) {NFSMWAP::Log("AP DEATHLINK: committed linked arrest suppressed.");return;}
        const bool sent=NFSMWAP::SendBridgeLine(notice.line);
        NFSMWAP::Log("AP DEATHLINK VERIFIED ARREST: proof="+std::string(verification)+" count="+std::to_string(count)+
            " bridge="+(sent ? "sent" : "retrying")+" id="+notice.id);
        if (!sent) {std::lock_guard<std::mutex> lock(mutex);if (session==notice.key && enabled && outgoing.size()<4u) outgoing.push_back(notice);}
    }
    void FlushArrests(DWORD now)
    {
        ArrestNotice notice;
        {
            std::lock_guard<std::mutex> lock(mutex);
            if (outgoing.empty()) return;
            if (!enabled || outgoing.front().key!=session || now-outgoing.front().created>5000u) {outgoing.pop_front();return;}
            if (now-outgoing.front().lastTry<250u) return;
            outgoing.front().lastTry=now;notice=outgoing.front();
        }
        if (NFSMWAP::SendBridgeLine(notice.line)) {
            std::lock_guard<std::mutex> lock(mutex);
            if (!outgoing.empty() && outgoing.front().id==notice.id) outgoing.pop_front();
        }
    }
    using CommitCareer=void(__thiscall*)(void*,unsigned,Word,bool);
    void __fastcall CommitCareerArrestHook(void* record,void*,unsigned infractions,Word bounty,bool evaded)
    {
        unsigned before=0,after=0;
        const bool local=!evaded && ReadLocalCareerRecord(record,before);
        reinterpret_cast<CommitCareer>(0x56F7C0u)(record,infractions,bounty,evaded);
        if (local && ReadLocalCareerRecord(record,after) && after>before) {


            ArrestStats stats;
            if (ReadArrestStats(stats,true)) {std::lock_guard<std::mutex> lock(mutex);
                counterReady=true;counterProfile=stats.profile;counterTotal=stats.total;}
            QueueCommittedArrest(after,"career_record_commit");
        } else if (!evaded) NFSMWAP::Log("AP DEATHLINK: arrest commit did not match local Career record; saved-total monitor remains active.");
    }
    bool InstallArrestCommitHook()
    {


        Word slot=0;
        for (Word address=0x411240u;address+5u<=0x4113E4u;++address) {
            if (*reinterpret_cast<const unsigned char*>(address)!=0xE8u ||
                address+5u+*reinterpret_cast<const std::int32_t*>(address+1u)!=0x56F7C0u) continue;
            if (slot) return false;slot=address+1u;address+=4u;
        }
        if (!slot) return false;
        DWORD old=0,unused=0;
        if (!VirtualProtect(reinterpret_cast<void*>(slot),4,PAGE_EXECUTE_READWRITE,&old)) return false;
        *reinterpret_cast<Word*>(slot)=static_cast<Word>(reinterpret_cast<std::uintptr_t>(&CommitCareerArrestHook)-slot-4u);
        VirtualProtect(reinterpret_cast<void*>(slot),4,old,&unused);
        FlushInstructionCache(GetCurrentProcess(),reinterpret_cast<void*>(slot),4);
        NFSMWAP::Log("AP DEATHLINK: local Career arrest-commit hook installed at "+std::to_string(slot-1u));
        return true;
    }
    void PollArrestsAndRecovery(DWORD now)
    {
        ArrestStats stats;
        if (!ReadArrestStats(stats)) {
            std::lock_guard<std::mutex> lock(mutex);
            arrestRecoverySince=0;
            if (stats.flow!=3 && stats.flow!=6) counterArmed=false;
            return;
        }
        bool committed=false,committedEcho=false;
        {
            std::lock_guard<std::mutex> lock(mutex);
            if (!counterReady || stats.profile!=counterProfile) {counterReady=true;counterProfile=stats.profile;counterTotal=stats.total;counterArmed=false;}
            else {
                committed=counterArmed && stats.total>counterTotal;
                committedEcho=(suppressed && !linkedArrestCommitted)||linkedBustPending;
                counterTotal=stats.total;
            }
            if (stats.flow==6) counterArmed=true;
            if (stats.flow==6 && !stats.paused && stats.pursuitReadable && !stats.pursuit && pending.empty()) {
                if (!arrestRecoverySince) arrestRecoverySince=now;
                else if (now-arrestRecoverySince>=RecoveryDrivingMs) {

                    suppressed=false;penaltyActive=false;episodeActive=false;episodeArmed=false;arrestLatched=false;
                }
            } else arrestRecoverySince=0;
        }
        if (committed) QueueCommittedArrest(stats.total,"career_bust_total",committedEcho);
    }
    void RecordVerifiedArrest(Word owner)
    {
        if (!owner) return;


        std::lock_guard<std::mutex> lock(mutex);
        if (enabled && suppressed && !linkedArrestCommitted) linkedBustPending=true;
    }

}

namespace NFSMWAP
{
    void ConfigureDeathLink(bool active,const std::string& key)
    {
        if (!MatchesSession(key)) return;
        std::lock_guard<std::mutex> lock(mutex);
        if (runtimeID.empty()) runtimeID=std::to_string(GetCurrentProcessId())+"_"+std::to_string(GetTickCount());
        if (session!=key || enabled!=active)
            Log("NFSMW_AP_DEATHLINK_PURSUIT_V8: committed Career arrests, immediate bounded front-cop placement, cooldown heat release " + std::string(active ? "ON." : "OFF."));
        if (session!=key) {pending.clear();applied.clear();outgoing.clear();counterReady=false;counterArmed=false;linkedBustPending=false;linkedArrestCommitted=false;arrestRecoverySince=0;suppressed=false;arrestLatched=false;episodeActive=false;episodeArmed=false;penaltyActive=false;recoverySince=0;}
        session=key;enabled=active;
        if (!enabled) {for (const auto& item:pending) applied.insert(item.id);pending.clear();outgoing.clear();}
    }

    void ReceiveDeathLink(const std::string& id,const std::string& source,const std::string& key)
    {
        if (id.empty() || id.size()>128 || !MatchesSession(key)) return;
        std::string result;
        {
            std::lock_guard<std::mutex> lock(mutex);
            if (!enabled || key!=session) return;
            if (applied.count(id)) result="already_consumed";
            else if (!pending.empty() && pending.front().id==id) return;
            else if (penaltyActive || !pending.empty()) {applied.insert(id);result="coalesced";}
            else pending.push_back({id,source.substr(0,200)});
        }
        if (!result.empty()) Ack(id,key,result);
    }

    void AuthorizeDeathLink(const std::string& id,const std::string& runtime,const std::string& key,bool allowed)
    {
        if (!MatchesSession(key)) return;
        std::lock_guard<std::mutex> lock(mutex);
        if (!enabled || key!=session || runtime!=runtimeID || pending.empty() || pending.front().id!=id || !pending.front().requested) return;

        pending.front().authorized=allowed;pending.front().denied=!allowed;
    }

    void ObserveDeathLinkArrest(Word handle) {RecordVerifiedArrest(VerifiedArrest(handle));}
    void ObserveDeathLinkPursuitEntered() {}
    void ObserveDeathLinkPursuitEnded(Word) {}

    void DeathLinkMainThreadTick()
    {
        Incoming item;std::string key;bool hasPending=false,active=false;
        const DWORD now=GetTickCount();
        static DWORD lastPolicyTick=0;
        if(lastPolicyTick && now-lastPolicyTick<50u)return;
        lastPolicyTick=now;
        RestorePoliceOnSceneChange();
        if(restorePolice||releaseHeat) {
            World cleanup;
            if(ReadCleanupWorld(cleanup)){RestorePolicePolicy(cleanup);ReleaseHeatBoost(cleanup,now);}
        }
        {
            std::lock_guard<std::mutex> lock(mutex);
            active=enabled;if (!active && !restorePolice && !releaseHeat) return;
            key=session;hasPending=!pending.empty();if (hasPending) item=pending.front();
        }
        if (active) {
            if (!commitHookTried) {
                commitHookTried=true;commitHookReady=InstallArrestCommitHook();
                if (!commitHookReady) Log("AP DEATHLINK: arrest-commit callsite unavailable; using committed Career bust-total fallback.");
            }
            PollArrestsAndRecovery(now);FlushArrests(now);
        }
        if (hasPending && item.denied) {Finish(item,key,"already_consumed");return;}
        if (hasPending && item.forceAttempted && now-item.startedAt>=FrontSpawnDeadlineMs) {
            Finish(item,key,"spawn_timeout");return;
        }
        World world;
        if (!ReadWorld(world)) {
            bool notify=false;
            {std::lock_guard<std::mutex> lock(mutex);recoverySince=0;
             if (hasPending && !pending.empty() && !pending.front().announced) {pending.front().announced=true;notify=true;}}
            if (notify) QueueNotification("DEATHLINK RECEIVED","FROM: "+item.source,"WAITING FOR CAREER DRIVING",4500);
            return;
        }
        RestorePolicePolicy(world);
        ReleaseHeatBoost(world,now);
        if (!active) return;
        if (world.finishedRace) {
            {std::lock_guard<std::mutex> lock(mutex);recoverySince=0;}
            if (hasPending && item.forceAttempted) Finish(item,key,"race_finished");
            return;
        }
        if (world.busted || world.bailed) {
            if (world.busted) RecordVerifiedArrest(world.pursuitObject);
            {std::lock_guard<std::mutex> lock(mutex);recoverySince=0;}
            if (hasPending && item.forceAttempted) Finish(item,key,world.busted ? "busted" : "pursuit_ended");
            return;
        }
        {
            std::lock_guard<std::mutex> lock(mutex);
            if (world.pursuit) {
                recoverySince=0;
                if (!episodeActive) {episodeActive=true;episodeArmed=true;arrestLatched=false;++episode;}
            } else if (!hasPending) {
                if (!recoverySince) recoverySince=now;
                else if (now-recoverySince>=RecoveryDrivingMs) {

                    episodeActive=false;episodeArmed=false;arrestLatched=false;suppressed=false;penaltyActive=false;
                }
            }
        }
        if (!hasPending) return;
        if (!item.authorized) {
            bool request=false;
            {std::lock_guard<std::mutex> lock(mutex);
             if (pending.empty() || pending.front().id!=item.id || session!=key) return;
             auto& current=pending.front();
             if (!current.requested || now-current.lastRequest>=2000u) {current.requested=true;current.lastRequest=now;request=true;}}
            if (request) SendBridgeLine("{\"type\":\"deathlink_start_request\",\"id\":\""+JsonLite::Escape(item.id)+
                "\",\"runtime_id\":\""+runtimeID+"\",\"session_key\":\""+JsonLite::Escape(key)+"\"}");
            return;
        }
        if (!item.forceAttempted) {
            if(!frontHookTried){frontHookTried=true;frontHookReady=InstallFrontCopHook();}
            if(!frontHookReady){Finish(item,key,"spawn_guard_unavailable");Log("AP DEATHLINK: native spawn callsite unavailable; penalty skipped safely.");return;}
            {
                std::lock_guard<std::mutex> lock(mutex);
                if (pending.empty() || pending.front().id!=item.id || session!=key) return;
                auto& current=pending.front();current.forceAttempted=true;current.startedAt=now;item=current;
                suppressed=true;linkedBustPending=false;linkedArrestCommitted=false;penaltyActive=true;recoverySince=0;
            }
            if (world.disabled!=0) {restorePolice=true;restoreStatus=world.status;restoreProfile=world.profile;restoreRace=world.race;originalDisable=world.disabled;}
            if (!ForcePursuit(world)) {RestorePoliceOverride();Finish(item,key,"force_failed");return;}
            if (!ReadWorld(world)) return;

            if (world.pursuit && !world.busted && !world.bailed) {
                if(releaseHeat){heatPursuit=world.pursuitObject;heatSawPursuit=true;}
                std::lock_guard<std::mutex> lock(mutex);
                if (!episodeActive) {episodeActive=true;episodeArmed=true;arrestLatched=false;++episode;}
            }
        }
        if (world.busted || world.bailed || world.finishedRace || world.cooldown) {Finish(item,key,"pursuit_ended");return;}
        if (!world.pursuit) {
            if (item.sawPursuit || now-item.startedAt>=2000u) Finish(item,key,"pursuit_ended");
            return;
        }
        if (item.sawPursuit && (item.frontPursuit!=world.pursuitObject || item.frontManager!=world.cops)) {
            Finish(item,key,"pursuit_changed");return;
        }
        if (!item.frontSpawned && (!item.lastPoll || now-item.lastPoll>=500u)) {
            const bool spawned=PlaceFrontCop(world,item.model);
            std::lock_guard<std::mutex> lock(mutex);
            if (pending.empty() || pending.front().id!=item.id || session!=key) return;
            auto& current=pending.front();current.sawPursuit=true;current.lastPoll=now;current.model=item.model;
            current.frontPursuit=world.pursuitObject;current.frontManager=world.cops;
            if (spawned)current.frontSpawned=true;
            item=current;
        }
        if (item.frontSpawned) {
            Finish(item,key,"front_cop_spawned");
            QueueNotification("DEATHLINK - "+item.source,"MAX CAREER HEAT | COP AHEAD","ESCAPE THE PURSUIT",5000);
        }

    }
}
