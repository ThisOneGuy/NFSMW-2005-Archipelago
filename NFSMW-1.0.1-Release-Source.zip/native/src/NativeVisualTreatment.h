#pragma once
namespace NFSMWAP { void NativeVisualTreatmentMainThreadTick(); }
