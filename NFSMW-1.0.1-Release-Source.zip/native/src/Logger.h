#pragma once

#include <string>

namespace NFSMWAP
{
    void InitializeLogger(const std::string& gameDirectory);
    void Log(const std::string& message);
    std::string GetLogPath();
}
