#pragma once
#include <string>

namespace NFSMWAP
{
    bool HasRecordedMilestone(int location);
    void SendRecordedMilestoneEvent(const std::string& event);
    void ReplayMilestoneJournal();
    void AcknowledgeMilestoneJournal(int location,const std::string& session);
}
