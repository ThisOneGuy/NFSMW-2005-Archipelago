#pragma once
#include <string>
struct IDirect3DDevice9;
namespace NFSMWAP
{
    struct ConnectionView
    {
        bool visible=false;
        int field=0;
        std::string phase, server, slot, passwordMask, status, firstCar, expectedSeed, seed;
    };
    void ConfigureConnectionSetup(const std::string& server,const std::string& slot,const std::string& password);
    bool IsConnectionSetupOnly();
    bool ConnectionSetupVisible();
    ConnectionView GetConnectionView();
    void ConnectionInputTick(IDirect3DDevice9* device);
    void SetConnectionStatus(const std::string& phase,const std::string& message,const std::string& firstCar,const std::string& server="",const std::string& slot="",const std::string& seed="");
    void ConnectionPromptRendered();
}
