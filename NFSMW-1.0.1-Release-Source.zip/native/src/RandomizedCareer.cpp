#include "RandomizedCareer.h"
#include "SeedConfig.h"
#include "CareerBootstrap.h"
#include "Logger.h"
#include "NotificationOverlay.h"
#include <Windows.h>
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <mutex>
#include <vector>

namespace {
using Word=std::uint32_t;
struct BytePatch {Word address;unsigned char desired;bool raceBarrier;unsigned char original=0;bool captured=false,owned=false;};
BytePatch patches[]={
    {0x8B282Bu,0x4A,true},{0x8B2838u,0x4A,true},{0x8B2844u,0x4A,true},
    {0x8B2817u,0x20,false},{0x8B2810u,0x54,false},{0x89B15Du,0,false},
    {0x57BF01u,0xEB,false},{0x57BF19u,0xEB,false},{0x57BF5Fu,0xEB,false},{0x57BF7Cu,0xEB,false}
};
struct RaceEntry {Word hash=0;unsigned world=0,boss=0;};
struct Roster {Word database=0,bins=0,scores=0;unsigned count=0;RaceEntry races[2048]{};};
Roster roster;
std::mutex rosterMutex;
bool hooksReady=false,logged=false;
DWORD lastUnlock=0,lastUi=0,lastBlocked=0;
int lastFlow=0;
constexpr Word Hash(const char* name) {
    Word result=~0u;while(*name)result=result*33u+static_cast<unsigned char>(*name++);return result;
}
int ViewRank() {
    __try {return *reinterpret_cast<int*>(0x91CA3Cu);} __except(EXCEPTION_EXECUTE_HANDLER) {return 0;}
}
bool Owners(Word& database,Word& bins,Word& scores) {
    __try {
        database=*reinterpret_cast<Word*>(0x91E004u);
        if(database<0x10000u||(database&3u))return false;
        bins=*reinterpret_cast<Word*>(database+0x24u);scores=*reinterpret_cast<Word*>(database+0x3Cu);
        return bins>=0x10000u&&!(bins&3u)&&scores>=0x10000u&&!(scores&3u);
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool CaptureRoster(Roster& result) {
    __try {
        if(!Owners(result.database,result.bins,result.scores))return false;
        for(int rank=1;rank<=15;++rank) {
            void* bin=reinterpret_cast<void*(__thiscall*)(void*,int)>(0x5E3980u)(reinterpret_cast<void*>(result.database),rank);
            if(!bin)return false;
            for(unsigned boss=0;boss<2u;++boss) {
                const Word count=reinterpret_cast<Word(__thiscall*)(void*)>(boss?0x5DCF60u:0x5DCF70u)(bin);
                if(count>256u)return false;
                for(Word index=0;index<count;++index) {
                    const Word hash=reinterpret_cast<Word(__thiscall*)(void*,Word)>(boss?0x601020u:0x601060u)(bin,index);
                    if(!hash||result.count>=2048u)return false;
                    result.races[result.count++]={hash,boss?0u:1u<<rank,boss?1u<<rank:0u};
                }
            }
        }
        return result.count!=0;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool ReadRoster(Roster& result) {
    std::lock_guard<std::mutex> lock(rosterMutex);
    Word database=0,bins=0,scores=0;if(!Owners(database,bins,scores))return false;
    if(roster.database!=database||roster.bins!=bins||roster.scores!=scores||!roster.count) {
        Roster captured;if(!CaptureRoster(captured))return false;
        std::sort(captured.races,captured.races+captured.count,[](const RaceEntry& a,const RaceEntry& b){return a.hash<b.hash;});
        unsigned count=0;
        for(unsigned n=0;n<captured.count;++n) {
            const auto value=captured.races[n];
            if(count&&captured.races[count-1u].hash==value.hash) {
                captured.races[count-1u].world|=value.world;captured.races[count-1u].boss|=value.boss;
            } else captured.races[count++]=value;
        }
        captured.count=count;roster=captured;
    }
    result=roster;return true;
}
RaceEntry FindRace(const Roster& table,Word hash) {
    const auto* end=table.races+table.count;
    const auto* found=std::lower_bound(table.races,end,hash,[](const RaceEntry& value,Word key){return value.hash<key;});
    return found!=end&&found->hash==hash?*found:RaceEntry{};
}
bool RaceKey(void* parameters,Word& hash,bool& boss) {
    __try {
        if(!parameters)return false;
        hash=reinterpret_cast<Word(__thiscall*)(void*)>(0x5FAB40u)(parameters);
        boss=reinterpret_cast<bool(__thiscall*)(void*)>(0x5FBD90u)(parameters);return hash!=0;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool RequirementsMet(int rank) {
    __try {
        if(rank<1||rank>15)return false;
        void* database=*reinterpret_cast<void**>(0x91E004u);
        void* frontend=*reinterpret_cast<void**>(0x91CF90u);
        if(!database||!frontend)return false;
        void* bin=reinterpret_cast<void*(__thiscall*)(void*,int)>(0x5E3980u)(database,rank);
        void* stable=reinterpret_cast<void*(__thiscall*)(void*,int)>(0x4061B0u)(frontend,0);
        if(!bin||!stable)return false;
        using Read=int(__thiscall*)(void*);
        return NFSMWAP::RivalChallengeRequirementsMet(
            reinterpret_cast<Read>(0x5DD1D0u)(bin),reinterpret_cast<Read>(0x5DD1A0u)(bin),
            reinterpret_cast<Read>(0x5DD1C0u)(bin),reinterpret_cast<Read>(0x5DD180u)(bin),
            reinterpret_cast<unsigned(__thiscall*)(void*)>(0x590500u)(stable),reinterpret_cast<Read>(0x5DD160u)(bin));
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool Ready(int rank) {return NFSMWAP::IsSeedRivalPermitted(rank)&&RequirementsMet(rank);}
bool Permitted(const RaceEntry& entry) {
    const int rank=NFSMWAP::RivalRankFromMembership(entry.boss,ViewRank());
    return rank&&Ready(rank);
}
bool AnyPermitted(unsigned ranks) {
    for(int rank=1;rank<=15;++rank)if((ranks&(1u<<rank))&&Ready(rank))return true;
    return false;
}
void LockedNotice() {
    const DWORD now=GetTickCount();if(lastBlocked&&now-lastBlocked<1500u)return;lastBlocked=now;
    const int rank=ViewRank();
    const bool received=rank>=1&&rank<=15&&NFSMWAP::IsSeedRivalPermitted(rank);
    NFSMWAP::QueueNotification("BLACKLIST LOCKED",received?"REQUIREMENTS NOT MET":"UNLOCK ITEM NOT RECEIVED",
        received?"Complete this rival's race, milestone and bounty targets.":"Find this rival's unlock in your Archipelago session.",4000);
}
bool AllowedRace(void* parameters) {
    Word hash=0;bool boss=false;
    if(!RaceKey(parameters,hash,boss))return false;
    Roster table;if(!ReadRoster(table))return !boss;
    const auto entry=FindRace(table,hash);
    return entry.boss?Permitted(entry):!boss;
}
bool __fastcall RaceAvailable(void* parameters,void*,int context) {
    if(context==2&&NFSMWAP::IsRandomizedCareerActive()) {
        Word hash=0;bool boss=false;
        if(RaceKey(parameters,hash,boss)) {
            Roster table;
            if(ReadRoster(table)) {
                const auto entry=FindRace(table,hash);
                if(entry.boss)return Permitted(entry);
                if(entry.world&&!boss)return true;
            }
            if(boss)return false;
        }
    }
    return reinterpret_cast<bool(__thiscall*)(void*,int)>(0x5FD160u)(parameters,context);
}
void __fastcall SetStartupRace(void* database,void*,void* custom,int context) {
    if(context==2&&custom&&NFSMWAP::IsRandomizedCareerActive()&&!AllowedRace(custom)) {
        reinterpret_cast<void(__thiscall*)(void*)>(0x5DC9D0u)(database);LockedNotice();return;
    }
    reinterpret_cast<void(__thiscall*)(void*,void*,int)>(0x600AB0u)(database,custom,context);
}
void __fastcall StartInGameRace(void* manager,void*,Word hash) {
    if(NFSMWAP::IsRandomizedCareerActive()) {
        void* database=*reinterpret_cast<void**>(0x91E004u);
        void* parameters=database?reinterpret_cast<void*(__thiscall*)(void*,Word)>(0x5FB710u)(database,hash):nullptr;
        if(!AllowedRace(parameters)){LockedNotice();return;}
    }
    reinterpret_cast<void(__thiscall*)(void*,Word)>(0x5FDCB0u)(manager,hash);
}
void __fastcall InitMap(void* streamer,void*,void* race,void* image,int level,int region) {
    reinterpret_cast<void(__thiscall*)(void*,void*,void*,int,int)>(0x546400u)(streamer,race,image,level,
        NFSMWAP::IsRandomizedCareerActive()?0:region);
}
const char* OverviewPackage(void* screen) {
    __try {
        if(!screen)return nullptr;
        const auto* name=reinterpret_cast<const char**>(screen)[4];
        if(name&&(!std::strcmp(name,"SafeHouseReputationOverview.fng")||!std::strcmp(name,"InGameReputationOverview.fng")))return name;
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
    return nullptr;
}
bool BossCompleted(int rank) {
    __try {
        auto* database=*reinterpret_cast<void**>(0x91E004u);if(!database||rank<1||rank>15)return false;
        auto* bin=reinterpret_cast<void*(__thiscall*)(void*,int)>(0x5E3980u)(database,rank);if(!bin)return false;
        const Word count=reinterpret_cast<Word(__thiscall*)(void*)>(0x5DCF60u)(bin);if(!count||count>64u)return false;
        for(Word n=0;n<count;++n) {
            const Word hash=reinterpret_cast<Word(__thiscall*)(void*,Word)>(0x601020u)(bin,n);
            if(!hash||!reinterpret_cast<bool(__thiscall*)(void*,Word,int)>(0x5DCA70u)(database,hash,2))return false;
        }
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
void Visible(const char* package,Word hash,bool visible) {
    reinterpret_cast<void(__cdecl*)(const char*,Word)>(visible?0x527DF0u:0x527DB0u)(package,hash);
}
void Text(const char* package,Word hash,const char* value) {
    reinterpret_cast<int(__cdecl*)(const char*,Word,const char*,...)>(0x5252D0u)(package,hash,"%s",value);
}
void ApplyOverview(const char* package) {
    if(!package||!NFSMWAP::IsRandomizedCareerActive())return;
    __try {
        const int rank=ViewRank();if(rank<1||rank>15)return;
        const bool received=NFSMWAP::IsSeedRivalPermitted(rank),ready=Ready(rank),completed=BossCompleted(rank);
        const char* description=completed?"Rival defeated.":!received?
            "Locked: receive this rival's Archipelago unlock item and complete the race, milestone and bounty targets.":
            !ready?"Unlock received. Complete the race, milestone and bounty targets to challenge this rival.":
            "Unlock received and all requirements met. This rival is ready to challenge.";
        Text(package,0x79CF0442u,description);
        Visible(package,0x34D4433Bu,completed);
        Visible(package,0x7FE4020Fu,completed);
        Visible(package,0x47B22FCAu,true);Visible(package,0x72AD598Cu,true);
        Visible(package,0x55F6AA1Au,ready&&!completed);
        auto* feng=*reinterpret_cast<void**>(0x91CADCu);
        if(feng)reinterpret_cast<void(__thiscall*)(void*,Word,const char*,void*)>(0x516C90u)(feng,
            Hash(ready&&!completed?"RIVAL_CHALLENGE_DEACTIVATED":"RIVAL_CHALLENGE_ACTIVATED"),package,nullptr);
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
}
void __fastcall UpdateOverview(void* screen,void*) {
    reinterpret_cast<void(__thiscall*)(void*)>(0x52EE50u)(screen);ApplyOverview(OverviewPackage(screen));
}
void __fastcall OverviewTextureLoaded(void* screen,void*) {
    reinterpret_cast<void(__thiscall*)(void*)>(0x52EE10u)(screen);ApplyOverview(OverviewPackage(screen));
}
void SwitchOverview(const char* package) {
    void* feng=*reinterpret_cast<void**>(0x91CADCu);
    if(feng)reinterpret_cast<void(__thiscall*)(void*,const char*,int,Word,bool)>(0x525940u)(feng,package,package[0]=='I'?1:0,0,false);
}
void __fastcall OverviewNotify(void* screen,void*,Word message,void* object,Word first,Word second) {
    const char* package=OverviewPackage(screen);
    if(package&&NFSMWAP::IsRandomizedCareerActive()) {
        if(message==0x911C0A4Bu||message==0x72619778u) {
            *reinterpret_cast<int*>(0x91CA3Cu)=NFSMWAP::NextBlacklistRank(ViewRank(),message==0x911C0A4Bu?-1:1);
            SwitchOverview(package);return;
        }
        if(message==0xC519BFC3u) {
            const int rank=ViewRank();
            if(rank<1||rank>15||!Ready(rank)){LockedNotice();return;}
            if(!BossCompleted(rank))SwitchOverview(package[0]=='I'?"InGameRivalChallenge.fng":"SafeHouseRivalChallenge.fng");
            return;
        }
    }
    reinterpret_cast<void(__thiscall*)(void*,Word,void*,Word,Word)>(0x55A4D0u)(screen,message,object,first,second);
    ApplyOverview(package);
}
bool SetByte(BytePatch& patch,bool enabled) {
    __try {
        auto* target=reinterpret_cast<unsigned char*>(patch.address);
        if(!enabled) {
            if(!patch.owned)return true;
            if(*target!=patch.desired){patch.owned=false;return false;}
        } else {
            if(patch.owned)return *target==patch.desired;
            if(!patch.captured) {
                if(patch.desired==0xEB&&*target!=0xEB&&(*target<0x70||*target>0x7F))return false;
                patch.original=*target;patch.captured=true;
            }
            if(*target==patch.desired)return true;
            if(*target!=patch.original)return false;
        }
        DWORD protection=0;if(!VirtualProtect(target,1,PAGE_EXECUTE_READWRITE,&protection))return false;
        *target=enabled?patch.desired:patch.original;
        DWORD unused=0;VirtualProtect(target,1,protection,&unused);FlushInstructionCache(GetCurrentProcess(),target,1);
        patch.owned=enabled;return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
int Flow() {
    __try {return *reinterpret_cast<int*>(0x925E90u);} __except(EXCEPTION_EXECUTE_HANDLER) {return 0;}
}
bool IsRaceRunning() {
    __try {
        if(Flow()!=6)return false;
        auto* status=*reinterpret_cast<void**>(0x91E000u);
        if(!status)return false;
        const int type=reinterpret_cast<int(__thiscall*)(void*)>(0x404A70u)(status);
        return type>=0&&type<=8;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return true;}
}
unsigned UnlockRaceEvents(const Roster& table) {
    __try {
        const Word count=*reinterpret_cast<Word*>(table.database),rows=table.scores;
        if(!count||count>4096u||rows>0xFFFFFFFFu-count*16u)return 0;
        unsigned changed=0;
        for(Word index=0;index<count;++index) {
            const auto row=rows+index*16u;const auto entry=FindRace(table,*reinterpret_cast<Word*>(row));
            auto* flags=reinterpret_cast<Word*>(row+4u);
            const Word desired=NFSMWAP::CareerRaceUnlockFlags(*flags,entry.world!=0,entry.boss!=0,AnyPermitted(entry.boss));
            if(*flags!=desired){*flags=desired;++changed;}
        }
        return changed;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return 0;}
}
void RefreshWorld(const Roster& table,bool refresh,bool barriers) {
    __try {
        if(!IsRaceRunning())for(int rank=1;rank<=15;++rank) {
            void* bin=reinterpret_cast<void*(__thiscall*)(void*,int)>(0x5E3980u)(reinterpret_cast<void*>(table.database),rank);
            if(bin)reinterpret_cast<void(__thiscall*)(void*)>(0x6010E0u)(bin);
        }
        if(barriers)for(int rank=1;rank<=15;++rank) {
            void* bin=reinterpret_cast<void*(__thiscall*)(void*,int)>(0x5E3980u)(reinterpret_cast<void*>(table.database),rank);
            if(bin)reinterpret_cast<void(__thiscall*)(void*)>(0x5DD140u)(bin);
        }
        if(!refresh)return;
        void* manager=*reinterpret_cast<void**>(0x91E00Cu);if(!manager)return;
        reinterpret_cast<void(__thiscall*)(void*)>(0x602840u)(manager);
        reinterpret_cast<void(__thiscall*)(void*)>(0x5E9DE0u)(manager);
        reinterpret_cast<void(__thiscall*)(void*)>(0x5FDAE0u)(manager);
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
}
struct Hook {Word target;const void* callback;unsigned count=0;};
struct WordPatch {Word address,before,after;};
bool WritePatch(const WordPatch& patch) {
    __try {
        auto* target=reinterpret_cast<Word*>(patch.address);DWORD protection=0;
        if(*target!=patch.before||!VirtualProtect(target,4,PAGE_EXECUTE_READWRITE,&protection))return false;
        *target=patch.after;DWORD ignored=0;VirtualProtect(target,4,protection,&ignored);FlushInstructionCache(GetCurrentProcess(),target,4);return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
}
namespace NFSMWAP {
bool IsRandomizedCareerActive(){return hooksReady&&IsSeedConfigReady()&&IsCareerProfileReady()&&RandomizeBlacklistUnlocks();}
bool RandomizedRivalLockVisible() {
    if(!IsRandomizedCareerActive())return false;
    __try {
        void* feng=*reinterpret_cast<void**>(0x91CADCu);if(!feng)return false;
        auto inControl=reinterpret_cast<bool(__thiscall*)(void*,const char*)>(0x516B90u);
        if(!inControl(feng,"SafeHouseReputationOverview.fng")&&!inControl(feng,"InGameReputationOverview.fng"))return false;
        const int rank=ViewRank();
        return rank>=1&&rank<=15&&!BossCompleted(rank)&&!Ready(rank);
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool InstallRandomizedCareerHooks() {
    if(hooksReady)return true;
    Hook hooks[]={
        {0x5FD160u,reinterpret_cast<const void*>(&RaceAvailable)},
        {0x600AB0u,reinterpret_cast<const void*>(&SetStartupRace)},
        {0x5FDCB0u,reinterpret_cast<const void*>(&StartInGameRace)},
        {0x546400u,reinterpret_cast<const void*>(&InitMap)},
        {0x52EE50u,reinterpret_cast<const void*>(&UpdateOverview)},
        {0x52EE10u,reinterpret_cast<const void*>(&OverviewTextureLoaded)}
    };
    std::vector<WordPatch> changes;
    for(Word address=0x401000u;address+5u<0x890000u;++address) {
        const auto opcode=*reinterpret_cast<const unsigned char*>(address);if(opcode!=0xE8u&&opcode!=0xE9u)continue;
        const Word old=*reinterpret_cast<const Word*>(address+1u),target=address+5u+old;
        for(auto& hook:hooks)if(hook.target==target) {
            changes.push_back({address+1u,old,static_cast<Word>(reinterpret_cast<std::uintptr_t>(hook.callback)-address-5u)});
            ++hook.count;address+=4u;break;
        }
    }
    if(*reinterpret_cast<const Word*>(0x89E700u)!=0x55A4D0u)return false;
    changes.push_back({0x89E700u,0x55A4D0u,static_cast<Word>(reinterpret_cast<std::uintptr_t>(&OverviewNotify))});
    for(const auto& hook:hooks)if((!hook.count&&hook.target!=0x52EE10u)||hook.count>128u) {
        Log("AP BLACKLIST HOOK VALIDATION FAILED: target="+std::to_string(hook.target)+" references="+std::to_string(hook.count));return false;
    }
    std::size_t applied=0;for(;applied<changes.size();++applied)if(!WritePatch(changes[applied]))break;
    if(applied!=changes.size()) {
        while(applied){const auto& p=changes[--applied];WritePatch({p.address,p.after,p.before});}
        return false;
    }
    hooksReady=true;
    Log("NFSMW_AP_RANDOMIZED_CAREER_V3: rival unlock items and native requirements enforced; browsing and city/event access retained.");
    return true;
}
void RandomizedCareerMainThreadTick() {
    const bool active=IsRandomizedCareerActive();
    const bool racing=active&&IsRaceRunning();
    bool valid=true;
    for(auto& patch:patches)if(!SetByte(patch,active&&(!patch.raceBarrier||!racing)))valid=false;
    if(!active){lastFlow=0;return;}
    const auto now=GetTickCount();const int flow=Flow();
    if(flow!=3&&flow!=6){lastFlow=flow;return;}
    if(now-lastUnlock>=1000u||flow!=lastFlow) {
        lastUnlock=now;Roster table;
        if(ReadRoster(table)) {
            const auto count=UnlockRaceEvents(table);
            RefreshWorld(table,count||flow!=lastFlow,flow==6&&!racing);
        }
    }
    lastFlow=flow;
    if(now-lastUi>=250u) {
        lastUi=now;ApplyOverview("SafeHouseReputationOverview.fng");ApplyOverview("InGameReputationOverview.fng");
    }
    if(!logged){logged=true;Log(valid?"AP OPEN WORLD: normal events unlocked; rival entries follow received items; completion records retained.":
        "AP OPEN WORLD: a city-map patch did not match this executable; existing data was preserved.");}
}
}
