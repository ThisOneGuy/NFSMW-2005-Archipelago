#pragma once

#include <Windows.h>

namespace NFSMWAP
{
    DWORD WINAPI RaceMonitorThread(LPVOID);
}
