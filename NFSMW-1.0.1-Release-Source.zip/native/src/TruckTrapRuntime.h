#pragma once
#include <cstdint>

namespace NFSMWAP {
    bool InitializeTruckTrapNative();
    const char* TruckTrapPreparationStatus();

    bool PrepareTruckTrapVehicle(std::uint32_t playerSimable,std::uint32_t profile);
    bool SpawnTruckTrapVehicle(std::uint32_t playerSimable,std::uint32_t profile);
    void CancelPreparedTruckTrap();
    void ClearTruckTrapVehicle();
    void TruckTrapWorldTick(bool driving,std::uint64_t elapsedMs);
    bool TruckTrapVehiclePending();
}
