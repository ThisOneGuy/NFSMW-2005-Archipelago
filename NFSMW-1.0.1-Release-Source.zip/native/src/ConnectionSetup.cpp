#include "ConnectionSetup.h"
#include "BridgeClient.h"
#include <Windows.h>
#include <d3d9.h>
#include <mutex>
#include "Logger.h"

namespace
{
    std::mutex g_mutex;
    NFSMWAP::ConnectionView g_view;
    std::string g_password;
    bool g_setupOnly=false, g_submit=false;
    HWND g_window=nullptr;
    WNDPROC g_previous=nullptr;
    wchar_t g_surrogate=0;
    bool g_replaceSelection=false;
    bool g_promptAnnounced=false;

    std::string Paste()
    {
        std::string result;
        if (!OpenClipboard(g_window)) return result;
        HANDLE data=GetClipboardData(CF_UNICODETEXT);
        const wchar_t* value=data ? static_cast<const wchar_t*>(GlobalLock(data)) : nullptr;
        if (value)
        {
            int length=0;
            while (length<240 && value[length] && value[length]!=L'\r' && value[length]!=L'\n') ++length;
            char encoded[1024]={};
            const int bytes=WideCharToMultiByte(CP_UTF8,0,value,length,encoded,sizeof(encoded),nullptr,nullptr);
            if (bytes>0) result.assign(encoded,static_cast<std::size_t>(bytes));
            GlobalUnlock(data);
        }
        CloseClipboard();
        return result;
    }

    std::string Escape(const std::string& text)
    {
        std::string out;
        for (unsigned char c:text)
        {
            if (c=='"' || c=='\\') out+='\\';
            if (c>=32u) out+=static_cast<char>(c);
        }
        return out;
    }

    LRESULT CALLBACK Input(HWND window,UINT message,WPARAM wParam,LPARAM lParam)
    {
        bool consume=false;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            if (message==WM_KEYDOWN && wParam==VK_F8)
            { if (!g_setupOnly) g_view.visible=!g_view.visible;consume=true; }
            if (g_view.visible)
            {
                const bool editable=g_view.phase=="input" || g_view.phase=="error";
                if (message==WM_KEYDOWN)
                {
                    if (wParam==VK_TAB && editable) { g_view.field=(g_view.field+1)%4;g_replaceSelection=false; }
                    if (wParam==VK_ESCAPE && g_view.phase=="connecting") { g_view.phase="input";g_view.status="Edit the connection and press Enter to retry."; }
                    if (wParam==VK_RETURN && editable) g_submit=true;
                    consume=true;
                }
                if (message==WM_CHAR)
                {
                    if (editable)
                    {
                        std::string& value=g_view.field==0 ? g_view.server : g_view.field==1 ? g_view.slot : g_view.field==2 ? g_password : g_view.expectedSeed;
                        if (wParam==1) g_replaceSelection=true;
                        if (g_replaceSelection && (wParam==8 || wParam==22 || wParam>=32))
                        { value.clear();g_replaceSelection=false; }
                        if (wParam==22)
                        {
                            const auto pasted=Paste();
                            if (value.size()+pasted.size()<=240) value+=pasted;
                        }
                        if (wParam==8 && !value.empty())
                        {
                            std::size_t n=value.size()-1;
                            while (n>0 && (static_cast<unsigned char>(value[n])&0xC0u)==0x80u) --n;
                            value.resize(n);
                        }
                        else if (wParam>=32 && wParam!=127 && value.size()<240)
                        {
                            wchar_t chars[2]={static_cast<wchar_t>(wParam),0};int count=1;
                            if (chars[0]>=0xD800 && chars[0]<=0xDBFF) g_surrogate=chars[0];
                            else
                            {
                                if (g_surrogate && chars[0]>=0xDC00 && chars[0]<=0xDFFF)
                                { chars[1]=chars[0];chars[0]=g_surrogate;count=2; }
                                g_surrogate=0;
                                char encoded[8]={};
                                const int size=WideCharToMultiByte(CP_UTF8,0,chars,count,encoded,8,nullptr,nullptr);
                                if (size>0) value.append(encoded,static_cast<std::size_t>(size));
                            }
                        }
                        g_view.passwordMask.assign(g_password.size(),'*');
                    }
                    consume=true;
                }
                if (message==WM_KEYUP || message==WM_SYSKEYDOWN || message==WM_SYSKEYUP ||
                    (message>=WM_MOUSEFIRST && message<=WM_MOUSELAST)) consume=true;
            }
        }
        return consume ? 0 : (g_previous ? CallWindowProcW(g_previous,window,message,wParam,lParam) : DefWindowProcW(window,message,wParam,lParam));
    }
}

namespace NFSMWAP
{
    void ConfigureConnectionSetup(const std::string& server,const std::string& slot,const std::string& password)
    {
        char setup[8]={},session[512]={};
        g_setupOnly=GetEnvironmentVariableA("NFSMW_AP_SETUP",setup,sizeof(setup))>0 && setup[0]=='1';
        const bool bound=GetEnvironmentVariableA("NFSMW_AP_SESSION_KEY",session,sizeof(session))>0;
        std::lock_guard<std::mutex> lock(g_mutex);
        g_view.visible=g_setupOnly || !bound;
        g_view.phase="input";g_view.server=bound ? server : "";g_view.slot=bound ? slot : "";
        g_password=bound ? password : "";g_view.passwordMask.assign(g_password.size(),'*');
        g_view.status="Enter server and slot, then press Enter. Tab changes fields.";
        Log("NFSMW_AP_CONNECTION_UI_V7: server/slot/password/optional seed form configured.");
    }
    bool IsConnectionSetupOnly() { return g_setupOnly; }
    bool ConnectionSetupVisible() { std::lock_guard<std::mutex> lock(g_mutex);return g_view.visible; }
    ConnectionView GetConnectionView() { std::lock_guard<std::mutex> lock(g_mutex);return g_view; }
    void SetConnectionStatus(const std::string& phase,const std::string& message,const std::string& firstCar,const std::string& server,const std::string& slot,const std::string& seed)
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        g_view.phase=phase;g_view.status=message;g_view.firstCar=firstCar;
        if (!server.empty()) g_view.server=server;
        if (!slot.empty()) g_view.slot=slot;
        if (!seed.empty()) g_view.seed=seed;
        if (g_setupOnly) g_view.visible=true;
        if (phase=="connected" && !g_setupOnly) g_view.visible=false;
    }
    void ConnectionPromptRendered()
    {
        if (!g_setupOnly || g_promptAnnounced) return;
        if (SendBridgeLine(R"({"type":"connection_ui_ready","ui_protocol":2})"))
        { g_promptAnnounced=true;Log("AP CONNECTION UI: prompt drawn in Present; F8 toggles connection status."); }
    }
    void ConnectionInputTick(IDirect3DDevice9* device)
    {
        if (!device) return;
        D3DDEVICE_CREATION_PARAMETERS params{};
        if (SUCCEEDED(device->GetCreationParameters(&params)) && params.hFocusWindow && !g_window)
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            SetLastError(0);
            const LONG_PTR previous=SetWindowLongPtrW(params.hFocusWindow,GWLP_WNDPROC,reinterpret_cast<LONG_PTR>(&Input));
            if (previous) { g_previous=reinterpret_cast<WNDPROC>(previous);g_window=params.hFocusWindow;Log("AP CONNECTION UI: game window input attached."); }
        }
        ConnectionView view;std::string password;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            if (!g_submit) return;
            g_submit=false;view=g_view;password=g_password;
            g_view.phase="connecting";g_view.status="Waiting for Archipelago...";
        }
        std::string request;
        request="{\"type\":\"connect_request\",\"server\":\""+Escape(view.server)+"\",\"slot\":\""+
            Escape(view.slot)+"\",\"password\":\""+Escape(password)+"\",\"seed\":\""+Escape(view.expectedSeed)+"\"}";
        if (!SendBridgeLine(request))
            SetConnectionStatus("error","Start RUN_NFSMW_AP_CLIENT.bat, then press Enter again.","");
    }
}
