#pragma once

#include <string>

namespace NFSMWAP
{
    struct Config
    {
        std::string serverAddress = "localhost:38281";
        std::string slotName = "Nathan";
        std::string password;
        bool deathLink = false;
        std::string bridgeHost = "127.0.0.1";
        int bridgePort = 38283;
        bool inGameNotifications = true;
        bool storeRuntime = true;
        int storePurchaseHotkey = 118;
    };

    Config LoadConfig(const std::string& gameDirectory);
}
