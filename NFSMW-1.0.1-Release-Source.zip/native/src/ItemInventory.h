#pragma once

#include <cstddef>
#include <string>
#include <vector>

namespace NFSMWAP
{
    struct ReceivedItem
    {
        int index = -1;
        int itemId = 0;
        std::string itemName;
        std::string itemType;
        std::string car;
        std::string category;
        std::string tier;
        std::string sourceName;
    };

    void AddReceivedItem(const ReceivedItem& item);
    bool HasReceivedItem(int itemId);
    std::size_t GetReceivedItemCount();
    std::vector<ReceivedItem> GetReceivedInventory();
}
