#pragma once
#include <cstddef>
#include <cstdint>

namespace NFSMWAP { namespace SMSPC {


using Pointer=std::uint32_t;
struct Vector2 {float x,y;};
struct Record {std::uint8_t handle,flags;std::uint16_t order;};
struct ConstructorData {Pointer packageName,package;std::int32_t argument;};
struct MenuScreen {
    Pointer vtable;
    std::uint8_t playSound,pad0[3];std::uint32_t direction;
    std::uint8_t enableMessenger,pad1[3];Pointer packageName;
    ConstructorData constructor;
    std::uint8_t isGarage,pad2[3];Pointer textInput;
    std::uint8_t captureKeyboard,pad3[3];
};
struct ScrollBar {
    std::uint8_t vertical,resizeHandle,handleGrabbed,arrowsOnly,visible,pad[3];
    Vector2 grabbedPosition,currentPosition,grabOffset,backingPosition,backingSize,handleMinSize;
    float segmentSize;std::uint32_t timer;
    Pointer backing,handle,firstArrow,secondArrow,firstBackingEnd,secondBackingEnd;
};
struct TextScroller {
    Pointer owner,font,scrollbar;char nameTemplate[32];
    std::int32_t viewWidth,visibleLines,numLines;Pointer lines,rawData;
    std::uint32_t dataSize,dataPosition;std::int32_t topLine;
    std::uint32_t scrollDown,scrollUp;
};


struct MessageScreen {MenuScreen menu;TextScroller text;ScrollBar bar;Pointer message;};
struct ArrayDatum {
    Pointer vtable,next,previous;std::uint32_t hash,description;
    std::uint8_t enabled,greyed,locked,checked;
};
struct Datum {ArrayDatum base;Pointer message;};
struct Slot {Pointer vtable,next,previous,object,scripts,icon,text;};
struct ArrayScripts {Pointer vtable;std::uint32_t grey,normal,highlight,unhighlight;};
struct ArrayScroller {
    Pointer vtable;std::uint8_t playSound,pad0[3];
    Pointer slotsNext,slotsPrevious,dataNext,dataPrevious,current;
    std::int32_t start,width,height;std::uint32_t description;
    Pointer packageName,package;ScrollBar bar;Pointer region;
    std::uint8_t selectable,pad1[3];ArrayScripts scripts;
    std::uint32_t mouseDown;std::uint8_t clickSelect,pad2[3];
};
struct InboxScreen {
    MenuScreen menu;ArrayScroller list;
    std::uint8_t lastMessages[2],pad[2];std::uint32_t buttonPressed;
    std::uint8_t voice,autoPlay,waitingForCard,initComplete;
};
static_assert(sizeof(Record)==4 && sizeof(MenuScreen)==0x2C);
static_assert(offsetof(MenuScreen,packageName)==0x10);
static_assert(offsetof(MenuScreen,constructor)+offsetof(ConstructorData,argument)==0x1C);
static_assert(sizeof(ScrollBar)==0x58 && sizeof(TextScroller)==0x54);
static_assert(offsetof(MessageScreen,text)==0x2C && offsetof(MessageScreen,message)==0xD8);
static_assert(sizeof(MessageScreen)==0xDC);
static_assert(sizeof(ArrayDatum)==0x18 && offsetof(Datum,message)==0x18 && sizeof(Datum)==0x1C);
static_assert(offsetof(Slot,text)==0x18);
static_assert(sizeof(ArrayScroller)==0xB0 && offsetof(InboxScreen,list)==0x2C);
static_assert(offsetof(InboxScreen,voice)==0xE4 && sizeof(InboxScreen)==0xE8);
} }
