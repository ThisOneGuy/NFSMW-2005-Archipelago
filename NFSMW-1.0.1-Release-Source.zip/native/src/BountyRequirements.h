#pragma once
#include <cstdint>
#include <string>

namespace NFSMWAP
{
    enum class BountyMode { Original, Multiplied, Removed };
    inline std::int32_t BountyRequirement(std::int32_t original,BountyMode mode,unsigned)
    {return original>0 && mode==BountyMode::Removed ? 0 : original;}
    void ConfigureBountyRequirements(const std::string& mode,int percent);
    unsigned EarnedBountyPercent();
    void BountyRequirementsMainThreadTick();
}
