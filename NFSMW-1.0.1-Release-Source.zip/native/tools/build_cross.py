from pathlib import Path
import argparse
import concurrent.futures
import json
import subprocess


def main():
    parser = argparse.ArgumentParser(description='Build the Windows x86 plugin with Clang and an MSVC/Windows SDK sysroot.')
    parser.add_argument('--clang', type=Path, required=True)
    parser.add_argument('--linker', type=Path, required=True)
    parser.add_argument('--sdk', type=Path, required=True)
    parser.add_argument('--destination', type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    output = (args.destination or root / 'dist').resolve()
    objects = output / 'objects'
    objects.mkdir(parents=True, exist_ok=True)
    sdk = args.sdk.resolve()
    flags = ['--target=i686-pc-windows-msvc', '-std=c++17', '-fms-compatibility-version=19.40',
             '-D_ALLOW_COMPILER_AND_STL_VERSION_MISMATCH', '-D_CRT_USE_BUILTIN_OFFSETOF',
             '-D_MT', '-DWIN32', '-D_WINDOWS', '-D_USRDLL', '-DWIN32_LEAN_AND_MEAN',
             '-DNOMINMAX', '-DNDEBUG', '-O2', '-ffunction-sections', '-fdata-sections']
    resource = Path(subprocess.check_output([str(args.clang.resolve()), '-print-resource-dir'], text=True).strip())
    flags.extend(('-isystem', str(resource / 'include')))
    for include in [sdk / 'crt/include', *(sdk / 'sdk/include' / folder for folder in ('ucrt', 'shared', 'um', 'winrt'))]:
        flags.extend(('-isystem', str(include)))
    sources = sorted((root / 'src').glob('*.cpp')) + [root / 'tests/host/sms_pc_abi_probe.cpp']
    def compile_source(source):
        local_flags = flags + (['-fasync-exceptions'] if '__try' in source.read_text() else [])
        result = subprocess.run([str(args.clang.resolve()), *local_flags, '-c', str(source), '-o', str(objects / (source.stem + '.obj'))],
                                capture_output=True, text=True)
        (objects / (source.stem + '.log')).write_text(result.stdout + result.stderr)
        return source.name, result.returncode
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(compile_source, sources))
    print(json.dumps(results))
    if any(code for _, code in results):
        return 1
    command = [str(args.linker.absolute()), '/dll', '/machine:x86', '/opt:ref', '/opt:icf', '/incremental:no',
               '/out:' + str(output / 'NFSMWArchipelago.asi')]
    for library in (sdk / 'crt/lib/x86', sdk / 'sdk/lib/um/x86', sdk / 'sdk/lib/ucrt/x86'):
        command.append('/libpath:' + str(library))
    command.extend(str(file) for file in sorted(objects.glob('*.obj')))
    command.extend(name + '.lib' for name in ('libcmt', 'libcpmt', 'libvcruntime', 'libucrt', 'oldnames',
                                            'kernel32', 'user32', 'ws2_32', 'd3d9', 'winmm'))
    subprocess.run(command, check=True)
    import shutil
    for source in (root / 'scripts').iterdir():
        if source.is_file():
            shutil.copy2(source, output / source.name)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
