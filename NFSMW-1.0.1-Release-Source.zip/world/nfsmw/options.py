from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

from Options import Choice, DefaultOnToggle, FreeText, PerGameCommonOptions, Range, Toggle, OptionSet


class StartingCar(Choice):
    __doc__ = 'Choose all customizable cars or the original starter pool for the free first dealership car.'
    display_name = "Guaranteed Dealership Car"

    option_randomized = 0
    option_vanilla_starter_pool = 1
    default = 0

    @classmethod
    def from_text(cls, text: str):
        if text.lower() == "random":
            return cls(cls.option_randomized)
        return super().from_text(text)


class RandomizeBlacklistCars(DefaultOnToggle):
    __doc__ = 'Randomize the vehicle driven by each of the 15 Blacklist racers.'
    display_name = "Randomize Blacklist Cars"


class RandomizeOpponentCars(DefaultOnToggle):
    __doc__ = 'Randomize normal opponent vehicles.'
    display_name = "Randomize Opponent Cars"


class ShopPriceMultiplier(Range):
    __doc__ = 'Multiplier for AP shop/location prices, expressed as a percentage.'
    display_name = "Shop Price Multiplier"
    range_start = 25
    range_end = 500
    default = 100


class IncomingItemPriceMultiplier(Range):
    __doc__ = 'Multiplier for received NFSMW items that must be purchased before use.'
    display_name = "Incoming Item Price Multiplier"
    range_start = 0
    range_end = 500
    default = 100


class BountyMode(Choice):
    __doc__ = 'Original keeps normal bounty earnings and requirements. Multiplied scales bounty earned while preserving rival requirements. Removed removes the bounty requirement; race and milestone requirements still apply.'
    display_name = "Bounty System"
    option_original = 0
    option_multiplied = 1
    option_removed = 2
    alias_no_bounty_requirement = 2
    default = 0


class BountyMultiplier(FreeText):
    __doc__ = 'Multiply bounty earned when bounty_mode is multiplied. Enter 0.01 to 100, with up to two decimal places; 2 doubles earnings and 0.5 halves them. Rival requirements are unchanged. Original and Removed use normal earnings.'
    display_name = "Bounty Multiplier"
    default = "1"

    def __init__(self,value):
        try:amount=Decimal(str(value))
        except (InvalidOperation,ValueError):raise ValueError('Bounty multiplier must be a number from 0.01 to 100.') from None
        if not amount.is_finite() or not Decimal('0.01')<=amount<=Decimal('100'):
            raise ValueError('Bounty multiplier must be a number from 0.01 to 100.')
        if amount*100!=(amount*100).to_integral_value():
            raise ValueError('Bounty multiplier supports up to two decimal places.')
        super().__init__(format(amount.normalize(),'f'))


class DeathLink(DefaultOnToggle):
    __doc__ = 'Enable DeathLink. A natural police bust can send a DeathLink.'
    display_name = "DeathLink"


class DeathLinkPenalty(Choice):
    __doc__ = 'Incoming DeathLink starts a pursuit at the current Career heat cap. Older names remain YAML-compatible.'
    display_name = "DeathLink Penalty"

    option_money = 0
    option_impound = 1
    option_money_and_impound = 2
    option_pursuit = 3
    default = 3


class DeathLinkMoneyPenalty(Range):
    __doc__ = 'Legacy YAML compatibility value; the current client applies the requested pursuit effect.'
    display_name = "DeathLink Money Penalty"
    range_start = 0
    range_end = 1_000_000
    default = 10_000


class TrapPercentage(Range):
    __doc__ = 'Percentage of cash filler replaced with Turbo, Brake, Flash Bang, Truck and Speedbreaker Traps. Does not replace cars or parts.\n\n    Traps wait for live driving and pause in menus. Turbo boosts to 350 mph\n    from seconds 2 to 17 of its clip; Brake forces a three-second stop.\n    Speedbreaker empties the meter once; normal recharge remains available.\n    Truck plays its clip, then launches a semi at the spoken truck cue.\n    Flash Bang whites out the screen at one second into its 6.316-second clip,\n    fading back during the last half-second.\n    '
    display_name = "Trap Percentage"
    range_start = 0
    range_end = 100
    default = 20


class ShufflePerformanceParts(DefaultOnToggle):
    display_name = "Shuffle Performance Parts"
    __doc__ = "Include performance upgrades in the item pool and performance shop checks. Disable to make upgrades available without Archipelago unlocks."


class VisualStoreChecks(DefaultOnToggle):
    display_name = "Visual Store Checks"
    __doc__ = "Include body parts, rims, paint, vinyls and other visual store locations. Disable to use normal visual customization without AP checks."


class RevealEventRewards(DefaultOnToggle):
    display_name = "Reveal Event Rewards"
    __doc__ = "Show rewards for races, milestones and events, and reveal hints when viewing them. Disable to hide rewards and prevent automatic event hints. Explicit hint requests remain available."


class AutoHintOnPreview(DefaultOnToggle):
    display_name = "Automatic Hints When Viewing Items"
    __doc__ = "Automatically share hints when viewing car, part, visual store, race or milestone rewards in game. Disable to keep those previews private. Manual hint requests and the Reveal hint button remain available."


class Traps(DefaultOnToggle):
    display_name = "Traps"
    __doc__ = "Allow driving traps. Disabled traps are neither generated nor activated by this slot."


class ExcludedTraps(OptionSet):
    display_name = "Excluded Traps"
    valid_keys = {"Turbo Trap", "Brake Trap", "Flash Bang Trap", "Truck Trap", "Speedbreaker Trap"}
    __doc__ = "List the trap names to exclude. Excluding every trap is supported."


class RandomizeBlacklistUnlocks(Toggle):
    display_name = "Randomized Blacklist Members"
    __doc__ = "Shuffle all 15 Blacklist challenge unlocks into the item pool. The city, races and milestones are open from the start, and the in-game Blacklist arrows let you browse all rivals. A rival challenge requires that rival's unlock item plus its normal race wins, milestones and bounty requirements. In multiplayer the unlock items are placed in other players' worlds. Each unlock is excluded from its own rival rewards, and full accessibility keeps every rival reachable. Disabled keeps normal Career progression."

    @classmethod
    def from_text(cls,text):
        if text.strip().lower() in ('multiworld','other_players'):
            return cls(1)
        return super().from_text(text)


class Goal(Choice):
    display_name = "Goal"
    option_blacklist_count = 0
    option_specific_blacklist = 1
    option_final_escape = 2
    default = 0
    __doc__ = "Finish by defeating a chosen number of distinct Blacklist racers, defeating one specific rival, or successfully escaping the final chase after Razor. Only the selected goal's settings apply."


class GoalBlacklistCount(Range):
    display_name = "Blacklist Racers to Defeat"
    range_start = 1
    range_end = 15
    default = 15
    __doc__ = "Number of distinct rivals to defeat when Goal is blacklist_count. Repeat wins against the same rival count once. With randomized unlocks, any rivals count."


class GoalBlacklist(Choice):
    display_name = "Target Blacklist Rival"
    option_razor = 1
    option_bull = 2
    option_ronnie = 3
    option_jv = 4
    option_webster = 5
    option_ming = 6
    option_kaze = 7
    option_jewels = 8
    option_earl = 9
    option_baron = 10
    option_big_lou = 11
    option_izzy = 12
    option_vic = 13
    option_taz = 14
    option_sonny = 15
    alias_all_blacklist = 1
    default = 1
    __doc__ = "The single rival required when Goal is specific_blacklist. Other rival victories do not replace this target. Normal Career progression still applies when randomized Blacklist unlocks are disabled."


@dataclass
class NFSMWOptions(PerGameCommonOptions):
    starting_car: StartingCar
    randomize_blacklist_cars: RandomizeBlacklistCars
    randomize_opponent_cars: RandomizeOpponentCars
    shop_price_multiplier: ShopPriceMultiplier
    incoming_item_price_multiplier: IncomingItemPriceMultiplier
    bounty_mode: BountyMode
    bounty_multiplier: BountyMultiplier
    death_link: DeathLink
    death_link_penalty: DeathLinkPenalty
    death_link_money_penalty: DeathLinkMoneyPenalty
    trap_percentage: TrapPercentage
    shuffle_performance_parts: ShufflePerformanceParts
    visual_store_checks: VisualStoreChecks
    reveal_event_rewards: RevealEventRewards
    auto_hint_on_preview: AutoHintOnPreview
    traps: Traps
    excluded_traps: ExcludedTraps
    randomize_blacklist_unlocks: RandomizeBlacklistUnlocks
    goal: Goal
    goal_blacklist_count: GoalBlacklistCount
    goal_blacklist: GoalBlacklist
