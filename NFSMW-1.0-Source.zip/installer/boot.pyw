import os
import sys

data=os.path.dirname(os.path.abspath(__file__))
runtime=os.path.join(data,'runtime')
dll_directories=[os.add_dll_directory(runtime),os.add_dll_directory(os.path.join(runtime,'DLLs'))]
sys._nfsmw_game_root=os.path.dirname(data)
sys._nfsmw_entry_name='client.exe'
sys._MEIPASS=data
sys._nfsmw_client_runtime=True
sys.frozen=True
from NFSMW_Standalone import entrypoint
entrypoint()
