Unicode True
!include "MUI2.nsh"
!include "nsDialogs.nsh"
!include "LogicLib.nsh"
!include "x64.nsh"
Name "NFSMW Archipelago Client"
OutFile "${OUTPUT}/NFSMW_Setup.exe"
InstallDir "$PROGRAMFILES32\EA GAMES\Need for Speed Most Wanted"
InstallDirRegKey HKCU "Software\NFSMW Archipelago" "GameDir"
RequestExecutionLevel user
SetCompressor /SOLID lzma
VIProductVersion "1.0.0.0"
VIAddVersionKey "ProductName" "NFSMW Archipelago Client"
VIAddVersionKey "FileDescription" "NFSMW Client Setup"
VIAddVersionKey "FileVersion" "1.0.0"
VIAddVersionKey "ProductVersion" "1.0.0"
VIAddVersionKey "LegalCopyright" "NFSMW Archipelago contributors"
Icon "${ICON}"
!define MUI_ABORTWARNING
!insertmacro MUI_PAGE_WELCOME
!define MUI_DIRECTORYPAGE_TEXT_TOP "Choose the game folder containing speed.exe. Existing saves and settings are preserved."
!define MUI_PAGE_CUSTOMFUNCTION_LEAVE CheckGame
!insertmacro MUI_PAGE_DIRECTORY
Page custom ScriptPage ScriptLeave
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_LANGUAGE "English"
Var Dialog
Var CopyScripts
Var CopyCheck

Function .onInit
  ${IfNot} ${RunningX64}
    MessageBox MB_ICONSTOP "This client requires 64-bit Windows. NFSMW itself remains 32-bit."
    Abort
  ${EndIf}
  InitPluginsDir
  SetOutPath "$PLUGINSDIR"
  File "${PAYLOAD}/client.exe"
FunctionEnd
Function CheckGame
  ExecWait '"$PLUGINSDIR\client.exe" --check-game "$INSTDIR"' $0
  ${If} $0 != 0
    MessageBox MB_ICONSTOP "Select the actual game folder containing the 32-bit speed.exe. Linked script/data folders are not supported."
    Abort
  ${EndIf}
FunctionEnd
Function ScriptPage
  nsDialogs::Create 1018
  Pop $Dialog
  ${NSD_CreateLabel} 0 0 100% 40u "Install the game plugin and remaining trap sounds into scripts. This update also removes the retired remix soundtrack and all custom character assets. Close the game and connection client before installing."
  Pop $0
  ${NSD_CreateCheckbox} 0 48u 100% 18u "Install the required game scripts and sounds"
  Pop $CopyCheck
  ${NSD_Check} $CopyCheck
  ${NSD_CreateLabel} 0 82u 100% 56u "The supplied plugin uses native build 1.0.0. The custom character and Umamusume systems are removed. Saves, other traps and the ASI loader are preserved. If you skip scripts, a compatible plugin must already be installed."
  Pop $0
  nsDialogs::Show
FunctionEnd
Function ScriptLeave
  ${NSD_GetState} $CopyCheck $CopyScripts
  ${If} $CopyScripts != ${BST_CHECKED}
    ExecWait '"$PLUGINSDIR\client.exe" --check-plugin "$INSTDIR\scripts\NFSMWArchipelago.asi"' $0
    ${If} $0 != 0
      MessageBox MB_ICONSTOP "A compatible native plugin was not found. Enable installation of the included game scripts."
      Abort
    ${EndIf}
  ${EndIf}
FunctionEnd
Section "Client"
  ClearErrors
  SetOutPath "$INSTDIR"
  File "${PAYLOAD}/client.exe"
  File "${PAYLOAD}/NFSMWClient.pyw"
  SetOutPath "$INSTDIR\NFSMWClient_Data"
  File /r "${PAYLOAD}/NFSMWClient_Data/*"
  IfErrors InstallFailed
  ExecWait '"$INSTDIR\client.exe" --check-files "$INSTDIR"' $0
  ${If} $0 != 0
    Goto InstallFailed
  ${EndIf}
  ${If} $CopyScripts == ${BST_CHECKED}
    SetOutPath "$INSTDIR\scripts"
    File "${CORE}/NFSMWArchipelago.asi"
    File "${CORE}/NFSMWArchipelago.tpk"
    File "${CORE}/NFSMW_TurboTrap.wav"
    File "${CORE}/NFSMW_FlashBangTrap.wav"
    File "${CORE}/NFSMW_TruckTrap.wav"
    IfErrors InstallFailed
  ${EndIf}
  ExecWait '"$INSTDIR\NFSMWClient_Data\runtime\pythonw.exe" -I -S -B "$INSTDIR\NFSMWClient_Data\remove_retired.pyw" "$INSTDIR"' $0
  ${If} $0 != 0
    MessageBox MB_ICONSTOP "Retired assets could not all be removed. Close the game and client, then run Setup again. The cleanup report is in NFSMWClient_Data\retired_cleanup.json. Saves are preserved."
    Abort
  ${EndIf}
  WriteRegStr HKCU "Software\NFSMW Archipelago" "GameDir" "$INSTDIR"
  CreateDirectory "$SMPROGRAMS\NFSMW Archipelago"
  CreateShortCut "$SMPROGRAMS\NFSMW Archipelago\NFSMW Client.lnk" "$INSTDIR\client.exe"
  DetailPrint "Installed. Open client.exe from the game folder to connect."
  Goto InstallComplete
InstallFailed:
  MessageBox MB_ICONSTOP "Some client files could not be installed. Close the client and game, check that the game folder is writable, then run Setup again. Existing saves are preserved."
  Abort
InstallComplete:
SectionEnd
