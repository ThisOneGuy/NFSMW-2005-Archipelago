using System;
using System.IO;
using System.Diagnostics;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

[assembly: AssemblyTitle("NFSMW Client")]
[assembly: AssemblyDescription("Archipelago connection for Need for Speed Most Wanted")]
[assembly: AssemblyCompany("NFSMW Archipelago")]
[assembly: AssemblyProduct("NFSMW Archipelago Client")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: System.Runtime.Versioning.TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName=".NET Framework 4.8")]

internal static class Client {
    static bool Pe32(string file) {
        if(!File.Exists(file))return false;
        using(var stream=File.OpenRead(file))using(var reader=new BinaryReader(stream)) {
            if(stream.Length<64 || reader.ReadUInt16()!=0x5a4d)return false;
            stream.Position=60;int offset=reader.ReadInt32();
            if(offset<64 || offset>stream.Length-6)return false;
            stream.Position=offset;return reader.ReadUInt32()==0x4550 && reader.ReadUInt16()==0x14c;
        }
    }
    internal static bool NormalFolder(string folder) {
        return !Directory.Exists(folder) || (File.GetAttributes(folder)&FileAttributes.ReparsePoint)==0;
    }
    internal static bool CheckGame(string folder) {
        string game=Path.Combine(folder,"speed.exe");
        return Directory.Exists(folder) && NormalFolder(folder) && Pe32(game) && (File.GetAttributes(game)&FileAttributes.ReparsePoint)==0 &&
            NormalFolder(Path.Combine(folder,"scripts")) && NormalFolder(Path.Combine(folder,"NFSMWClient_Data"));
    }
    internal static bool CheckPlugin(string file) {
        if(!Pe32(file))return false;
        string bytes=Encoding.ASCII.GetString(File.ReadAllBytes(file));
        return bytes.Contains("1.0.0") && bytes.Contains("NFSMW_AP_CONNECTION_UI_V7") &&
            bytes.Contains("NFSMW_AP_NATIVE_SMS_V8") && bytes.Contains("NFSMW_AP_DEALERSHIP_BOOT_V23") &&
            bytes.Contains("NFSMW_AP_RUNTIME_ABI_V1");
    }
    internal static string Hash(string file) {
        using(var sha=SHA256.Create())using(var stream=File.OpenRead(file))
            return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-","").ToLowerInvariant();
    }
    internal static void VerifyFiles(string root) {
        string data=Path.GetFullPath(Path.Combine(root,"NFSMWClient_Data"));
        if(!NormalFolder(data))throw new IOException("The client data folder must be a normal folder.");
        bool boot=false,python=false,app=false;
        foreach(string line in File.ReadAllLines(Path.Combine(data,"launcher_files.sha256"))) {
            if(line.Length<67 || line[64]!=' ' || line[65]!='*')throw new IOException("Invalid client file list.");
            string name=line.Substring(66);
            if(Path.IsPathRooted(name) || name.Contains("..") || name.Contains(":"))throw new IOException("Invalid client file path.");
            string file=Path.GetFullPath(Path.Combine(data,name.Replace('/',Path.DirectorySeparatorChar)));
            if(!file.StartsWith(data+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))throw new IOException("Invalid client file path.");
            for(var parent=new DirectoryInfo(Path.GetDirectoryName(file));parent!=null && parent.FullName.Length>=data.Length;parent=parent.Parent)
                if(parent.Exists && (parent.Attributes&FileAttributes.ReparsePoint)!=0)throw new IOException("Linked client data folders are not supported.");
            if(!File.Exists(file) || (File.GetAttributes(file)&FileAttributes.ReparsePoint)!=0 || Hash(file)!=line.Substring(0,64))
                throw new IOException("A client file is missing or damaged: "+name+". Run NFSMW Setup to repair it.");
            boot|=name=="boot.pyw";python|=name=="runtime/pythonw.exe";app|=name=="app.zip";
        }
        if(!boot || !python || !app)throw new IOException("The client file list is incomplete. Run NFSMW Setup to repair it.");
    }
    internal static ProcessStartInfo StartInfo(string root) {
        var info=new ProcessStartInfo(Path.Combine(root,"NFSMWClient_Data","runtime","pythonw.exe"));
        info.Arguments="-I -S -B \""+Path.Combine(root,"NFSMWClient_Data","boot.pyw")+"\"";
        info.WorkingDirectory=root;info.UseShellExecute=false;info.CreateNoWindow=true;
        return info;
    }
    static int SelfTest() {
        string root=Path.Combine(Path.GetTempPath(),"NFSMW client test "+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);
        try {
            byte[] pe=new byte[512];pe[0]=0x4d;pe[1]=0x5a;pe[60]=128;pe[128]=0x50;pe[129]=0x45;pe[132]=0x4c;pe[133]=1;
            File.WriteAllBytes(Path.Combine(root,"speed.exe"),pe);
            if(!CheckGame(root))throw new Exception("Game validation failed.");
            string plugin=Path.Combine(root,"NFSMWArchipelago.asi");File.WriteAllBytes(plugin,pe);
            if(CheckPlugin(plugin))throw new Exception("An incompatible plugin was accepted.");
            using(var stream=File.Open(plugin,FileMode.Append)) {
                byte[] markers=Encoding.ASCII.GetBytes("1.0.0 NFSMW_AP_CONNECTION_UI_V7 NFSMW_AP_NATIVE_SMS_V8 NFSMW_AP_DEALERSHIP_BOOT_V23");
                stream.Write(markers,0,markers.Length);
            }
            if(CheckPlugin(plugin))throw new Exception("A plugin with the incompatible x86 runtime was accepted.");
            using(var stream=File.Open(plugin,FileMode.Append)) {
                byte[] marker=Encoding.ASCII.GetBytes(" NFSMW_AP_RUNTIME_ABI_V1");stream.Write(marker,0,marker.Length);
            }
            if(!CheckPlugin(plugin))throw new Exception("Compatible plugin preflight failed.");
            var info=StartInfo(root);
            if(info.UseShellExecute || !info.CreateNoWindow || !info.Arguments.Contains("boot.pyw") || info.WorkingDirectory!=root)
                throw new Exception("Windowed process contract failed.");
            string data=Path.Combine(root,"NFSMWClient_Data");Directory.CreateDirectory(Path.Combine(data,"runtime"));string list="";
            foreach(string name in new[]{"boot.pyw","runtime/pythonw.exe","app.zip"}) {
                string file=Path.Combine(data,name.Replace('/',Path.DirectorySeparatorChar));File.WriteAllText(file,"sample");
                list+=Hash(file)+" *"+name+"\n";
            }
            File.WriteAllText(Path.Combine(data,"launcher_files.sha256"),list);VerifyFiles(root);
            File.WriteAllText(Path.Combine(data,"boot.pyw"),"damaged");
            bool rejected=false;try{VerifyFiles(root);}catch(IOException){rejected=true;}
            if(!rejected)throw new Exception("Damaged files accepted.");
            File.WriteAllText(Path.Combine(data,"launcher_files.sha256"),new String('0',64)+" *../outside\n");
            rejected=false;try{VerifyFiles(root);}catch(IOException){rejected=true;}
            if(!rejected)throw new Exception("Escaping path accepted.");
            Console.WriteLine("PASS: GUI launcher, no shell/console, quoted paths, game/plugin preflight, hashes, tamper rejection, path containment");return 0;
        }finally{Directory.Delete(root,true);}
    }
    [STAThread] static int Main(string[] args) {
        try {
            if(args.Length==1 && args[0]=="--self-test")return SelfTest();
            if(args.Length==2 && args[0]=="--check-game")return CheckGame(args[1])?0:2;
            if(args.Length==2 && args[0]=="--check-plugin")return CheckPlugin(args[1])?0:3;
            if(args.Length==2 && args[0]=="--check-files"){VerifyFiles(args[1]);return 0;}
#if PORTABLE
            return PortableSupport.Run(args);
#else
            string root=AppDomain.CurrentDomain.BaseDirectory;
            if(!CheckGame(root))throw new IOException("Place the complete manual package beside speed.exe, or use NFSMW Setup.");
            VerifyFiles(root);Process.Start(StartInfo(root));return 0;
#endif
        }catch(Exception error) {
            if(args.Length>0 && args[0].StartsWith("--",StringComparison.Ordinal)) {Console.Error.WriteLine(error.Message);return 1;}
            MessageBox.Show(error.Message,"NFSMW Client",MessageBoxButtons.OK,MessageBoxIcon.Error);return 1;
        }
    }
}
