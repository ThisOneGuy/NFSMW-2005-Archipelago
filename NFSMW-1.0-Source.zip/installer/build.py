
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import subprocess
from payload_files import ignored_data_files
from framework_build import framework_flags

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def build(args):
    out=args.destination.resolve()
    if out.exists() and any(out.iterdir()):raise ValueError('Use an empty build folder to avoid retaining obsolete files.')
    out.mkdir(parents=True,exist_ok=True)
    payload=out/'payload';payload.mkdir(exist_ok=True)
    data=payload/'NFSMWClient_Data';data.mkdir(exist_ok=True)
    for folder in ('runtime','site-packages','licenses'):
        shutil.copytree(args.runtime_data/folder,data/folder,dirs_exist_ok=True,
            ignore=ignored_data_files(args.runtime_data))
    if not (data/'runtime/pythonw.exe').is_file():
        raise RuntimeError('Supply the unmodified official CPython 3.13.17 x64 pythonw.exe and matching runtime.')
    (data/'runtime/python313._pth').write_text('python313.zip\n.\nDLLs\nLib\n../site-packages\n../app.zip\n')
    shutil.copy2(HERE/'boot.pyw',data/'boot.pyw')
    shutil.copy2(HERE/'remove_retired.pyw',data/'remove_retired.pyw')
    shutil.copy2(SOURCE/'client/NFSMWClient.pyw',payload/'NFSMWClient.pyw')
    shutil.copy2(SOURCE/'client/NFSMWClient_Data/app.zip',data/'app.zip')
    shutil.copytree(SOURCE/'client/NFSMWClient_Data/assets',data/'assets',dirs_exist_ok=True)
    (data/'launcher').mkdir(exist_ok=True)
    shutil.copy2(SOURCE/'world/nfsmw.apworld',data/'launcher/nfsmw.apworld')
    if args.launcher:
        shutil.copy2(args.launcher,payload/'client.exe')
    else:
        if not args.csc:
            raise ValueError('Supply --launcher or --csc.')
        compiler=[str(args.csc.resolve())]
        if args.mono:
            compiler=[str(args.mono.resolve())]+(['--config',str(args.mono_config.resolve())] if args.mono_config else [])+compiler
        subprocess.run(compiler+framework_flags(args.framework_reference,('System.Windows.Forms.dll','System.Drawing.dll'))+['-target:winexe','-optimize+',
            '-win32icon:'+str(HERE/'archipelago.ico'),'-out:'+str(payload/'client.exe'),str(HERE/'Client.cs')],check=True)
    files={}
    for file in sorted(data.rglob('*')):
        if file.is_file() and file.name not in ('bundle.json','launcher_files.sha256'):
            files[file.relative_to(data).as_posix()]={'bytes':file.stat().st_size,'sha256':digest(file)}
    manifest={'format':1,'client_build':'1.0.0','native_build':'1.0.0',
        'mode':'official-pythonw-process','runtime':'CPython 3.13.17 x64',
        'entrypoint':'client.exe','executable_sha256':digest(payload/'client.exe'),'files':files}
    (data/'bundle.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (data/'launcher_files.sha256').write_text(''.join(
        digest(file)+' *'+file.relative_to(data).as_posix()+'\n' for file in sorted(data.rglob('*'))
        if file.is_file() and file.name!='launcher_files.sha256'))
    flag='/D' if os.name=='nt' else '-D'
    subprocess.run([str(args.makensis.resolve()),flag+'OUTPUT='+str(out),flag+'ICON='+str(HERE/'archipelago.ico'),
        flag+'PAYLOAD='+str(payload),flag+'CORE='+str(args.core_scripts.resolve()),str(HERE/'Setup.nsi')],check=True)
    print(out/'NFSMW_Setup.exe')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description='Build the GUI connection launcher and the NSIS setup.')
    parser.add_argument('--runtime-data',type=Path,required=True)
    parser.add_argument('--core-scripts',type=Path,required=True)
    parser.add_argument('--destination',type=Path,required=True)
    parser.add_argument('--csc',type=Path)
    parser.add_argument('--framework-reference',type=Path)
    parser.add_argument('--launcher',type=Path)
    parser.add_argument('--mono',type=Path)
    parser.add_argument('--mono-config',type=Path)
    parser.add_argument('--makensis',type=Path,required=True)
    build(parser.parse_args())
