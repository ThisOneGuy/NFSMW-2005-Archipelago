using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

internal static class PortableSupport {
    const string Resource="NFSMW.Payload.zip";
    static readonly HashSet<string> Core=new HashSet<string>(StringComparer.OrdinalIgnoreCase) {
        "NFSMWArchipelago.asi","NFSMWArchipelago.tpk","NFSMW_TurboTrap.wav",
        "NFSMW_FlashBangTrap.wav","NFSMW_TruckTrap.wav"
    };
    sealed class FileRecord {
        internal string Name,Hash;
        internal long Bytes;
        internal ZipArchiveEntry Entry;
    }
    static string StreamHash(Stream stream) {
        using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-","").ToLowerInvariant();
    }
    internal static bool Allowed(string name) {
        if(String.IsNullOrEmpty(name) || name.Contains("\\") || name.Contains(":") || name.StartsWith("/",StringComparison.Ordinal))return false;
        foreach(string part in name.Split(new char[]{'/'},StringSplitOptions.None)) {
            if(part.Length==0 || part=="." || part==".." || part.TrimEnd(' ','.')!=part)return false;
            foreach(char c in part)if(c<32 || "<>\"|?*".IndexOf(c)>=0)return false;
            string stem=part.Split(new char[]{'.'},StringSplitOptions.None)[0].ToUpperInvariant();
            if(stem=="CON" || stem=="PRN" || stem=="AUX" || stem=="NUL" ||
                (stem.Length==4 && (stem.StartsWith("COM",StringComparison.Ordinal) || stem.StartsWith("LPT",StringComparison.Ordinal)) && stem[3]>='1' && stem[3]<='9'))return false;
        }
        if(name=="NFSMWClient.pyw")return true;
        if(name.StartsWith("scripts/",StringComparison.Ordinal))return Core.Contains(name.Substring(8));
        if(!name.StartsWith("NFSMWClient_Data/",StringComparison.Ordinal))return false;
        string relative=name.Substring(17);
        return relative=="app.zip" || relative=="bundle.json" || relative=="launcher_files.sha256" ||
            relative=="boot.pyw" || relative=="remove_retired.pyw" ||
            relative.StartsWith("assets/",StringComparison.Ordinal) || relative.StartsWith("licenses/",StringComparison.Ordinal) ||
            relative.StartsWith("runtime/",StringComparison.Ordinal) || relative.StartsWith("site-packages/",StringComparison.Ordinal) ||
            relative=="launcher/nfsmw.apworld";
    }
    internal static string SafeTarget(string root,string name) {
        if(!Allowed(name) && name!="client.exe")throw new IOException("Invalid installation path: "+name);
        root=Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar);
        string target=Path.GetFullPath(Path.Combine(root,name.Replace('/',Path.DirectorySeparatorChar)));
        if(!target.StartsWith(root+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))throw new IOException("Installation path leaves the game folder.");
        for(var item=new DirectoryInfo(root);item!=null;item=item.Parent)
            if(item.Exists && (item.Attributes&FileAttributes.ReparsePoint)!=0)throw new IOException("Linked game folders are not supported.");
        string current=root;
        foreach(string part in name.Split(new char[]{'/'},StringSplitOptions.None)) {
            current=Path.Combine(current,part);
            try {
                if((File.GetAttributes(current)&FileAttributes.ReparsePoint)!=0)throw new IOException("Linked installation paths are not supported: "+name);
            }catch(FileNotFoundException) {}catch(DirectoryNotFoundException) {}
        }
        return target;
    }
    static List<FileRecord> ReadRecords(ZipArchive archive,Stream manifest) {
        var files=new Dictionary<string,FileRecord>(StringComparer.OrdinalIgnoreCase);
        long total=0;
        using(var reader=new StreamReader(manifest,Encoding.UTF8)) {
            string line;
            while((line=reader.ReadLine())!=null) {
                string[] parts=line.Split(new[]{'\t'},3);long bytes;
                if(parts.Length!=3 || parts[0].Length!=64 || !Int64.TryParse(parts[1],NumberStyles.None,CultureInfo.InvariantCulture,out bytes) ||
                    bytes<0 || bytes>256L*1024*1024 || !Allowed(parts[2]) || files.ContainsKey(parts[2]))throw new IOException("Invalid embedded file list.");
                foreach(char c in parts[0])if(!((c>='0' && c<='9') || (c>='a' && c<='f')))throw new IOException("Invalid embedded file checksum.");
                files.Add(parts[2],new FileRecord{Name=parts[2],Hash=parts[0],Bytes=bytes});
                total+=bytes;
                if(files.Count>10000 || total>1024L*1024*1024)throw new IOException("The embedded package is too large.");
            }
        }
        if(files.Count!=archive.Entries.Count)throw new IOException("The embedded file list does not match the package.");
        foreach(var entry in archive.Entries) {
            FileRecord record;
            if(!files.TryGetValue(entry.FullName,out record) || record.Name!=entry.FullName || record.Entry!=null || entry.Length!=record.Bytes ||
                ((entry.ExternalAttributes>>16)&0xf000)==0xa000)throw new IOException("Invalid embedded package entry.");
            record.Entry=entry;
            using(var stream=entry.Open())if(StreamHash(stream)!=record.Hash)throw new IOException("The embedded package is damaged. Download the complete ZIP again.");
        }
        foreach(string name in new[]{"NFSMWClient.pyw","NFSMWClient_Data/boot.pyw","NFSMWClient_Data/remove_retired.pyw",
            "NFSMWClient_Data/app.zip","NFSMWClient_Data/runtime/pythonw.exe","NFSMWClient_Data/bundle.json","NFSMWClient_Data/launcher_files.sha256"})
            if(!files.ContainsKey(name))throw new IOException("The embedded package is incomplete.");
        foreach(string name in Core)if(!files.ContainsKey("scripts/"+name))throw new IOException("The embedded game scripts are incomplete.");
        return new List<FileRecord>(files.Values);
    }
    static bool Matches(string file,string hash,long bytes) {
        return File.Exists(file) && new FileInfo(file).Length==bytes && Client.Hash(file)==hash;
    }
    static void Replace(Stream source,string target) {
        Directory.CreateDirectory(Path.GetDirectoryName(target));
        string temporary=Path.Combine(Path.GetDirectoryName(target),".nfsmw-install-"+Guid.NewGuid().ToString("N")+".tmp");
        try {
            using(var output=new FileStream(temporary,FileMode.CreateNew,FileAccess.Write,FileShare.None)) {
                source.CopyTo(output);output.Flush(true);
            }
            if(File.Exists(target))File.Replace(temporary,target,null);
            else File.Move(temporary,target);
        }finally{if(File.Exists(temporary))File.Delete(temporary);}
    }
    static void CheckNotRunning(string root) {
        foreach(string name in new[]{"speed","pythonw","client"}) {
            foreach(var process in Process.GetProcessesByName(name))using(process) {
                if(process.Id==Process.GetCurrentProcess().Id)continue;
                try {
                    string file=Path.GetFullPath(process.MainModule.FileName);
                    if(file.StartsWith(root+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))
                        throw new IOException("Close the game and connection client before updating their files, then open client.exe again.");
                }catch(System.ComponentModel.Win32Exception) {
                    throw new IOException("Could not check a running "+name+" process. Close the game and connection client before installing.");
                }catch(InvalidOperationException) {}
            }
        }
    }
    static void Cleanup(string root,Action<int,string> progress) {
        if(Environment.OSVersion.Platform!=PlatformID.Win32NT)return;
        var info=Client.StartInfo(root);
        info.Arguments="-I -S -B \""+Path.Combine(root,"NFSMWClient_Data","remove_retired.pyw")+"\" \""+root+"\"";
        using(var process=Process.Start(info)) {
            while(!process.WaitForExit(100))progress(98,"Removing retired mod files...");
            if(process.ExitCode!=0)throw new IOException("Old mod files could not all be removed. Close the game and client, then retry. See NFSMWClient_Data\\retired_cleanup.json for details.");
        }
    }
    internal static int Install(string root,Action<int,string> progress) {
        root=Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar);
        if(!Client.CheckGame(root))throw new IOException("Choose the actual game folder containing the 32-bit speed.exe.");
        var assembly=Assembly.GetExecutingAssembly();
        using(var raw=assembly.GetManifestResourceStream(Resource))
        using(var hashes=assembly.GetManifestResourceStream("NFSMW.Payload.files"))
        using(var checksum=assembly.GetManifestResourceStream("NFSMW.Payload.sha256")) {
            if(raw==null || hashes==null || checksum==null)throw new IOException("The embedded installation files are missing.");
            string expected;
            using(var reader=new StreamReader(checksum,Encoding.ASCII))expected=reader.ReadToEnd().Trim();
            progress(1,"Checking installation files...");
            if(StreamHash(raw)!=expected)throw new IOException("The embedded installation is damaged. Download the complete ZIP again.");
            raw.Position=0;
            using(var archive=new ZipArchive(raw,ZipArchiveMode.Read)) {
                var files=ReadRecords(archive,hashes);var pending=new List<FileRecord>();
                foreach(var record in files) {
                    string target=SafeTarget(root,record.Name);
                    if(!Matches(target,record.Hash,record.Bytes))pending.Add(record);
                }
                string self=assembly.Location,targetExe=SafeTarget(root,"client.exe");
                bool copyExe=!String.Equals(Path.GetFullPath(self),targetExe,StringComparison.OrdinalIgnoreCase) &&
                    !Matches(targetExe,Client.Hash(self),new FileInfo(self).Length);
                if(pending.Count==0 && !copyExe) {
                    Client.VerifyFiles(root);
                    if(!Client.CheckPlugin(SafeTarget(root,"scripts/NFSMWArchipelago.asi")))throw new IOException("The game plugin does not match this client.");
                    progress(100,"Ready");return 0;
                }
                CheckNotRunning(root);
                int completed=0;
                foreach(var record in pending) {
                    progress(5+90*completed/Math.Max(1,pending.Count),"Installing "+record.Name);
                    string target=SafeTarget(root,record.Name);
                    using(var stream=record.Entry.Open())Replace(stream,target);
                    if(!Matches(target,record.Hash,record.Bytes))throw new IOException("Could not verify the installed file: "+record.Name);
                    completed++;
                }
                Client.VerifyFiles(root);
                if(!Client.CheckPlugin(SafeTarget(root,"scripts/NFSMWArchipelago.asi")))throw new IOException("The game plugin does not match this client.");
                Cleanup(root,progress);
                if(copyExe)using(var stream=File.OpenRead(self))Replace(stream,targetExe);
                progress(100,"Ready");return pending.Count+(copyExe?1:0);
            }
        }
    }
    internal static string GameFolder(string path) {
        path=Path.GetFullPath(path);
        if(File.Exists(path)) {
            if(!String.Equals(Path.GetFileName(path),"speed.exe",StringComparison.OrdinalIgnoreCase))throw new IOException("Drop speed.exe or its game folder onto client.exe.");
            path=Path.GetDirectoryName(path);
        }
        if(!Client.CheckGame(path))throw new IOException("Choose the actual game folder containing the 32-bit speed.exe.");
        return path;
    }
    static int SelfTest() {
        foreach(string name in new[]{"../speed.exe","NFSMWClient_Data/../speed.exe","scripts/other.asi","NFSMWClient_Data/user/save.json",
            "C:/speed.exe","/speed.exe","NFSMWClient_Data/runtime/link/../../../speed.exe","NFSMWClient_Data/runtime/bad. ",
            "NFSMWClient_Data/runtime/CON.txt","NFSMWClient_Data/runtime/LPT1","scripts\\NFSMWArchipelago.asi"})
            if(Allowed(name))throw new Exception("An unsafe package path was accepted: "+name);
        foreach(string name in new[]{"NFSMWClient.pyw","NFSMWClient_Data/runtime/pythonw.exe","scripts/NFSMWArchipelago.asi"})
            if(!Allowed(name))throw new Exception("A required package path was rejected.");
        Console.WriteLine("PASS: manual installation path allowlist and state-file protection");return 0;
    }
    internal static int Run(string[] args) {
        if(args.Length==1 && args[0]=="--portable-self-test")return SelfTest();
        if(args.Length==2 && args[0]=="--install-only") {
            int changed=Install(GameFolder(args[1]),delegate(int value,string message) {});
            Console.WriteLine("Installed files: "+changed);return 0;
        }
        if(args.Length>1 || (args.Length==1 && args[0].StartsWith("--",StringComparison.Ordinal)))throw new IOException("Drop one game folder or speed.exe onto client.exe.");
        string root=args.Length==1?GameFolder(args[0]):AppDomain.CurrentDomain.BaseDirectory;
        Application.EnableVisualStyles();
        if(!Client.CheckGame(root))using(var dialog=new FolderBrowserDialog()) {
            dialog.Description="Choose the NFSMW folder containing speed.exe. The client and required scripts will be installed there.";
            dialog.ShowNewFolderButton=false;
            if(dialog.ShowDialog()!=DialogResult.OK)return 0;
            root=GameFolder(dialog.SelectedPath);
        }
        using(var window=new Form()) {
            window.Text="NFSMW Client 1.0";window.ClientSize=new System.Drawing.Size(520,105);
            window.Icon=System.Drawing.Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location);
            window.FormBorderStyle=FormBorderStyle.FixedDialog;window.ControlBox=false;window.StartPosition=FormStartPosition.CenterScreen;
            var label=new Label {Left=18,Top=18,Width=484,Height=36,Text="Preparing the client...",AutoEllipsis=true};
            var bar=new ProgressBar {Left=18,Top=66,Width=484,Height=20};window.Controls.Add(label);window.Controls.Add(bar);window.Show();
            Install(root,delegate(int value,string message){bar.Value=value;label.Text=message;Application.DoEvents();});
        }
        Process.Start(Client.StartInfo(root));return 0;
    }
}
