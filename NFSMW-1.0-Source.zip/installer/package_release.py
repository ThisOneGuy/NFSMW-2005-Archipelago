from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from payload_files import temporary_copy,unnecessary_document


EXCLUDED={'__pycache__','system_tools','user','build','dist','objects'}
EXCLUDED_DOCUMENTS={'NATIVE_BUILD.json','BUNDLE_SOURCES.json','SOURCES.json','BUILDING.txt',
                    'strip_python_comments.py','NFSMW_RaceMap_Status.csv'}


def release_file(path):
    return not temporary_copy(path) and not unnecessary_document(path) and not path.name.casefold().startswith('readme') and path.suffix.casefold() not in (
        '.bat','.cmd','.pyc','.pyo','.log','.bak','.old','.tmp','.pdb')


def source_file(path,source):
    relative=path.relative_to(source)
    if relative.parts[0] not in ('client','native','world','installer','NFSMW.yaml'):return False
    if not path.is_file() or path.is_symlink() or EXCLUDED.intersection(relative.parts):return False
    if not release_file(path) or path.name in EXCLUDED_DOCUMENTS:return False
    if any(part.startswith(('kivy_home','chat_layout_home','hint_home')) for part in relative.parts):return False
    if relative.parts[0]=='qa' or relative.parts[:2]==('client','tests'):return False
    if relative.parts[:2]==('native','tests') and relative.as_posix()!='native/tests/host/sms_pc_abi_probe.cpp':return False
    return path.suffix!='.png' or path.name=='archipelago.png'


def empty_stage(destination):
    if destination.exists() and any(destination.iterdir()):
        raise ValueError('Use an empty staging folder to avoid including previous build files.')
    destination.mkdir(parents=True,exist_ok=True)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def package(source,setup,core,destination,output,portable):
    source=source.resolve();destination=destination.resolve();output=output.resolve()
    if destination.is_relative_to(source) or output.is_relative_to(source) or source.is_relative_to(destination):
        raise ValueError('Release staging and output must be outside the source folder.')
    if output.is_relative_to(destination):
        raise ValueError('Place the final archive outside the release staging folder.')
    empty_stage(destination);output.parent.mkdir(parents=True,exist_ok=True)
    version=json.loads((source/'world/nfsmw/archipelago.json').read_text())['world_version']
    parts=version.split('.')
    suffix='.'.join(parts[:2]) if len(parts)==3 and parts[2]=='0' else version
    subprocess.run([sys.executable,str(source/'client/tools/pack_python.py'),str(destination/'Python_Update'),
                    '--core-scripts',str(core.resolve())],check=True)
    for path in (source/'world/nfsmw.apworld',source/'NFSMW.yaml',setup):
        shutil.copy2(path,destination/('NFSMW_Setup.exe' if path==setup else path.name))
    shutil.copy2(portable,destination/'client.exe')
    source_zip=destination/('NFSMW-'+suffix+'-Source.zip')
    with zipfile.ZipFile(source_zip,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in sorted(source.rglob('*')):
            if not source_file(path,source):continue
            archive.write(path,path.relative_to(source).as_posix())
    with zipfile.ZipFile(source_zip) as archive:
        damaged=archive.testzip()
        if damaged:raise ValueError('Damaged source entry: '+damaged)
    return finalize(destination,output)


def finalize(destination,output):
    output.parent.mkdir(parents=True,exist_ok=True)
    paths=[p for p in sorted(destination.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt' and release_file(p)]
    fd,temporary=tempfile.mkstemp(prefix='.nfsmw-release-',suffix='.partial',dir=output.parent)
    try:
        with os.fdopen(fd,'w+b') as stream:
            with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
                for path in sorted(destination.rglob('*')):
                    if path.is_file() and release_file(path):archive.write(path,path.relative_to(destination).as_posix())
            stream.flush();os.fsync(stream.fileno())
            stream.seek(0)
            with zipfile.ZipFile(stream) as archive:
                damaged=archive.testzip()
                if damaged:raise ValueError('Damaged release entry: '+damaged)
                for path in paths:
                    if hashlib.sha256(archive.read(path.relative_to(destination).as_posix())).hexdigest()!=digest(path):
                        raise ValueError('Release content differs: '+path.name)
        os.replace(temporary,output)
        if os.name!='nt':
            directory=os.open(output.parent,os.O_RDONLY)
            try:os.fsync(directory)
            finally:os.close(directory)
    finally:
        if os.path.exists(temporary):os.unlink(temporary)
    return {'path':str(output),'bytes':output.stat().st_size,'sha256':digest(output)}

def python_package(release,destination,output):
    release=release.resolve();destination=destination.resolve();output=output.resolve()
    if destination.is_relative_to(release) or release.is_relative_to(destination) or output.is_relative_to(destination):
        raise ValueError('Use separate staging folders for the Python and complete releases.')
    empty_stage(destination)
    shutil.copytree(release/'Python_Update',destination,dirs_exist_ok=True)
    for path in release.iterdir():
        if path.name in ('nfsmw.apworld','NFSMW.yaml'):
            shutil.copy2(path,destination/path.name)
    if any(path.suffix.casefold() in ('.exe','.cmd','.bat') for path in destination.rglob('*') if path.is_file()):
        raise ValueError('The Python installation package must not contain EXE or command files.')
    return finalize(destination,output)


def portable_package(source,client,destination,output):
    destination=destination.resolve();output=output.resolve();source=source.resolve();client=client.resolve()
    if destination.is_relative_to(source) or output.is_relative_to(destination):
        raise ValueError('Use a separate folder and output filename for the manual release.')
    empty_stage(destination)
    shutil.copy2(client,destination/'client.exe')
    for name in ('NFSMW.yaml','world/nfsmw.apworld'):
        shutil.copy2(source/name,destination/Path(name).name)
    return finalize(destination,output)



if __name__=='__main__':
    parser=argparse.ArgumentParser(description='Build and verify a complete NFSMW release before publishing its filename.')
    parser.add_argument('--source',type=Path,default=Path(__file__).resolve().parent.parent)
    parser.add_argument('--setup',type=Path,required=True)
    parser.add_argument('--core-scripts',type=Path,required=True)
    parser.add_argument('--destination',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--python-output',type=Path)
    parser.add_argument('--portable-exe',type=Path,required=True)
    parser.add_argument('--portable-output',type=Path)
    args=parser.parse_args()
    result=package(args.source,args.setup,args.core_scripts,args.destination,args.output,args.portable_exe)
    if args.python_output:
        result={'release':result,'python':python_package(args.destination,args.destination.parent/(args.destination.name+'_variants')/'python',args.python_output)}
    if args.portable_output:
        if 'release' not in result:result={'release':result}
        result['portable']=portable_package(args.source,args.portable_exe,args.destination.parent/(args.destination.name+'_variants')/'portable',args.portable_output)
    print(json.dumps(result),flush=True)
