from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import zipfile
from payload_files import ignored_data_files
from framework_build import framework_flags


CORE=('NFSMWArchipelago.asi','NFSMWArchipelago.tpk','NFSMW_TurboTrap.wav',
      'NFSMW_FlashBangTrap.wav','NFSMW_TruckTrap.wav')
HERE=Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build(args):
    destination=args.destination.resolve()
    if destination.exists() and any(destination.iterdir()):
        raise ValueError('Use an empty folder for the standalone build.')
    destination.mkdir(parents=True,exist_ok=True)
    stage=destination/'payload';stage.mkdir()
    data=stage/'NFSMWClient_Data'
    shutil.copytree(args.payload/'NFSMWClient_Data',data,
                    ignore=ignored_data_files(args.payload/'NFSMWClient_Data'))
    shutil.copy2(args.payload/'NFSMWClient.pyw',stage/'NFSMWClient.pyw')
    scripts=stage/'scripts';scripts.mkdir()
    for name in CORE:shutil.copy2(args.core_scripts/name,scripts/name)
    manifest=json.loads((data/'bundle.json').read_text())
    manifest.pop('executable_sha256',None)
    manifest['distribution']='drag-and-drop'
    manifest['files']={p.relative_to(data).as_posix():{'bytes':p.stat().st_size,'sha256':digest(p)}
        for p in sorted(data.rglob('*')) if p.is_file() and p.name not in ('bundle.json','launcher_files.sha256')}
    (data/'bundle.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (data/'launcher_files.sha256').write_text(''.join(digest(p)+' *'+p.relative_to(data).as_posix()+'\n'
        for p in sorted(data.rglob('*')) if p.is_file() and p.name!='launcher_files.sha256'))
    paths=[p for p in sorted(stage.rglob('*')) if p.is_file()]
    archive_path=destination/'payload.zip'
    with zipfile.ZipFile(archive_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in paths:archive.write(path,path.relative_to(stage).as_posix())
    with zipfile.ZipFile(archive_path) as archive:
        if archive.testzip():raise ValueError('The embedded ZIP failed its integrity check.')
    file_list=destination/'payload.files'
    file_list.write_text(''.join(digest(p)+'\t'+str(p.stat().st_size)+'\t'+p.relative_to(stage).as_posix()+'\n' for p in paths))
    checksum=destination/'payload.sha256';checksum.write_text(digest(archive_path)+'\n')
    compiler=[str(args.csc.resolve())]
    if args.mono:
        compiler=[str(args.mono.resolve())]+(['--config',str(args.mono_config.resolve())] if args.mono_config else [])+compiler
    output=destination/'client.exe'
    command=compiler+framework_flags(args.framework_reference,('System.Windows.Forms.dll','System.Drawing.dll',
        'System.IO.Compression.dll','System.IO.Compression.FileSystem.dll'))+['-target:winexe','-optimize+','-define:PORTABLE',
        '-win32icon:'+str(HERE/'archipelago.ico'),
        '-out:'+str(output),'-resource:'+str(archive_path)+',NFSMW.Payload.zip',
        '-resource:'+str(file_list)+',NFSMW.Payload.files','-resource:'+str(checksum)+',NFSMW.Payload.sha256',
        str(HERE/'Client.cs'),str(HERE/'PortableSupport.cs')]
    subprocess.run(command,check=True)
    print(json.dumps({'path':str(output),'bytes':output.stat().st_size,'sha256':digest(output),
                      'embedded_files':len(paths),'expanded_bytes':sum(p.stat().st_size for p in paths)}),flush=True)
    return output


if __name__=='__main__':
    parser=argparse.ArgumentParser(description='Build client.exe with the complete drag-and-drop installation payload.')
    parser.add_argument('--payload',type=Path,required=True)
    parser.add_argument('--core-scripts',type=Path,required=True)
    parser.add_argument('--destination',type=Path,required=True)
    parser.add_argument('--csc',type=Path,required=True)
    parser.add_argument('--framework-reference',type=Path)
    parser.add_argument('--mono',type=Path)
    parser.add_argument('--mono-config',type=Path)
    build(parser.parse_args())
