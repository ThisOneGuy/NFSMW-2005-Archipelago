from pathlib import Path
import os


def framework_flags(reference,extra):
    candidates=[Path(reference)] if reference else [
        Path(os.environ.get('ProgramFiles(x86)',r'C:\Program Files (x86)'))/
        'Reference Assemblies/Microsoft/Framework/.NETFramework/v4.8']
    names=('mscorlib.dll','System.dll','System.Core.dll',*extra)
    for root in candidates:
        root=root.resolve()
        if all((root/name).is_file() for name in names):
            return ['-noconfig','-nostdlib+']+['-r:'+str(root/name) for name in names]
    raise ValueError('Supply the Microsoft .NET Framework 4.8 reference assemblies using --framework-reference.')
