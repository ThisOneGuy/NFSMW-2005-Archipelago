from pathlib import Path
import sys

SOURCE=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(SOURCE/'client/source'))
from NFSMW_RetiredFeatures import REMOVED_FILES,REMOVED_TREES


def unnecessary_document(path):
    path=Path(path)
    if path.name.casefold()=='cmakelists.txt':return False
    if path.suffix.casefold() not in ('.txt','.md','.rst','.pdf','.doc','.docx','.rtf'):return False
    if path.name.casefold()=='top_level.txt' and any(part.casefold().endswith('.dist-info') for part in path.parts):return False
    if 'licenses' in (part.casefold() for part in path.parts):return False
    return not path.name.upper().startswith(('LICENSE','COPYING','NOTICE','AUTHORS'))


def temporary_copy(path):
    path=Path(path)
    if not path.name.startswith('.') or '.' not in path.name[1:]:return False
    original=path.name[1:].rsplit('.',1)[0]
    return path.with_name(original).is_file()


def ignored_data_files(root):
    root=Path(root).absolute()
    obsolete=set(REMOVED_FILES)|set(REMOVED_TREES)
    def ignore(directory,names):
        ignored=[]
        for name in names:
            path=Path(directory)/name
            relative='NFSMWClient_Data/'+path.absolute().relative_to(root).as_posix()
            if (name in ('__pycache__','user','retired_cleanup.json') or
                name.casefold().startswith('readme') or relative in obsolete or unnecessary_document(path) or
                path.suffix.casefold() in ('.pyc','.pyo','.log','.partial','.tmp','.bat','.cmd','.pyi','.pdb') or
                temporary_copy(path)):
                ignored.append(name)
        return ignored
    return ignore
