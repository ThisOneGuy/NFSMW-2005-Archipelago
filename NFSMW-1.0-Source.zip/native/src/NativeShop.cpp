#include "NativeShop.h"
#include "CareerBootstrap.h"
#include "NativeShopLogic.h"
#include "NativeFrontend.h"
#include "NativeEquipment.h"
#include "CashDelivery.h"
#include "NativeRewardUI.h"
#include "APLogoMesh.h"
#include "StoreRuntime.h"
#include "Logger.h"
#include "GameVersion.h"
#include "NotificationOverlay.h"

#include <Windows.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace
{
    using Word = std::uint32_t;
    constexpr Word Accept = 0x406415E3u;
    constexpr Word Back = 0x911AB364u;
    constexpr Word FilterLeft = 0x5073EF13u, FilterRight = 0xD9FEEC59u;
    using SetupFn = void(__thiscall*)(Word*);
    using NotifyFn = void(__thiscall*)(Word*, Word, Word*, Word, Word);
    using AddFn = void(__thiscall*)(Word*, Word*, Word, Word, Word, Word, bool);
    using FindFn = Word*(__cdecl*)(const char*, Word);
    using PrintFn = int(__cdecl*)(Word*, const char*, ...);
    using TextureFn = void(__cdecl*)(Word*, Word);
    using GetSelectedFn = Word*(__thiscall*)(Word*);
    using GetTextureFn = void*(__cdecl*)(Word, int, int);
    using CreateResourceFn = void*(__cdecl*)(const char*, int, int, int, int);
    using LoadResourceFn = void(__fastcall*)(void*, void*, void*, void*);
    using ServiceResourceFn = void(__cdecl*)();

    struct ScreenHook
    {
        Word table;
        bool performance;
        SetupFn setup = nullptr;
        SetupFn refresh = nullptr;
        NotifyFn notify = nullptr;
    };

    std::array<ScreenHook, 5> g_screens{{
        {0x8B7EA4u, false},
        {0x8B7F24u, true},
        {0x8B7FBCu, false},
        {0x8B7FDCu, false},
        {0x8B8068u, false}
    }};
    bool g_initialized = false;
    std::atomic_bool g_ready{false};
    bool g_textureRequested = false;
    std::atomic_bool g_textureReady{false};
    std::atomic_bool g_partsReady{false};
    bool g_resourceReady = false;
    bool g_priceReady = false;
    bool g_showModel = false;
    struct DealerHook { Word table; NotifyFn notify; };
    std::vector<DealerHook> g_dealers;
    struct ActiveScreen { Word* object=nullptr; Word table=0; std::string package; };
    ActiveScreen g_activeParts, g_activeDealer, g_equipmentMain;
    bool g_visualBackroom=false,g_visualBackroomReady=false;
    bool g_backroomCarSwapReady=false,g_backroomCarSwapPending=false;
    Word g_backroomCarSwapMode=0;
    std::array<Word,2> g_backroomCarSwapOptionTable{};
    void UpdateShowroom(bool active);
    const SetupFn g_carSelectRefresh = reinterpret_cast<SetupFn>(0x7ADA50u);
    CreateResourceFn g_createResource = nullptr;
    LoadResourceFn g_loadResource = nullptr;
    ServiceResourceFn g_serviceResource = nullptr;
    int g_priceOverride = -1;
    Word Hash(const char* text);
    void ReadCurrencyObjectNative(Word* object,Word& hash,char (&name)[96])
    {
        __try
        {
            if (object)
            {
                hash=object[offsetof(NFSMWAP::NativeFEObjectPrefix,nameHash)/sizeof(Word)];
                const char* source=reinterpret_cast<const char*>(object[offsetof(NFSMWAP::NativeFEObjectPrefix,namePointer)/sizeof(Word)]);
                if (source) for (int n=0;n<95 && source[n];++n) name[n]=source[n];
            }
        }
        __except(EXCEPTION_EXECUTE_HANDLER) {}
    }
    NFSMWAP::NativeMoneyRole MoneyRole(Word* object)
    {
        Word hash=0;char name[96]={};
        ReadCurrencyObjectNative(object,hash,name);
        if (hash==0x1930B057u) return NFSMWAP::NativeMoneyRole::Cash;


        if (hash==0xA91EDA8Au) return NFSMWAP::NativeMoneyRole::TradeIn;
        if (hash==0xDBB80EDDu || hash==0x7A6D2F71u || hash==0x20C83C31u)
            return NFSMWAP::NativeMoneyRole::Price;
        for (const char* field:{"CASH","CASH_DATA","CASH_VALUE","CAREER_CASH","CASH_AMOUNT"})
            if (hash==Hash(field)) return NFSMWAP::NativeMoneyRole::Cash;
        for (const char* field:{"TRADE_IN","TRADEIN","TRADE_IN_DATA","TRADE_IN_VALUE","TRADE_IN_AMOUNT"})
            if (hash==Hash(field)) return NFSMWAP::NativeMoneyRole::TradeIn;
        for (const char* field:{"COST","COST_DATA","COST_VALUE","PRICE","PRICE_DATA","PART_COST","PART_PRICE","TOTAL","TOTAL_DATA","TOTAL_VALUE"})
            if (hash==Hash(field)) return NFSMWAP::NativeMoneyRole::Price;
        return NFSMWAP::NativeMoneyRoleFromName(name);
    }
#if defined(_M_IX86)
    Word g_nativeObjectPrintf = 0x515D70u;
    Word g_nativePackagePrintf = 0x5252D0u;
    void __cdecl ReplaceObjectCurrencyValue(Word* object,const char* format, int* value)
    {
        if (g_priceOverride < 0 || !format || !value) return;
        __try
        {
            if (std::strcmp(format, "%$d") == 0)
                *value = NFSMWAP::NativeShopCurrencyValue(MoneyRole(object),*value,g_priceOverride);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
    }
    void __cdecl ReplacePackageCurrencyValue(const char* package,Word hash,const char* format,int* value)
    {
        ReplaceObjectCurrencyValue(reinterpret_cast<FindFn>(0x5251E0u)(package,hash),format,value);
    }


    __declspec(naked) void NativeObjectPriceHook()
    {
        __asm
        {
            pushfd
            pushad
            lea eax, [esp + 48]
            push eax
            mov eax, [esp + 48]
            push eax
            mov eax, [esp + 48]
            push eax
            call ReplaceObjectCurrencyValue
            add esp, 12
            popad
            popfd
            jmp dword ptr [g_nativeObjectPrintf]
        }
    }
    __declspec(naked) void NativePackagePriceHook()
    {
        __asm
        {
            pushfd
            pushad
            lea eax, [esp + 52]
            push eax
            mov eax, [esp + 52]
            push eax
            mov eax, [esp + 52]
            push eax
            mov eax, [esp + 52]
            push eax
            call ReplacePackageCurrencyValue
            add esp, 16
            popad
            popfd
            jmp dword ptr [g_nativePackagePrintf]
        }
    }
#endif
    Word* g_buildScreen = nullptr;
    bool g_replaceMappingPending = false;
    std::size_t g_buildOrdinal = 0;
    std::vector<NFSMWAP::ShopEntry> g_buildEntries;
    std::vector<Word*> g_buildParts;
    std::vector<Word*> g_rejectedParts,g_rejectedDatums;
    using PositionFn=void(__thiscall*)(Word*,int);
    std::unordered_map<Word,PositionFn> g_iconPositions;
    bool EnsurePositionHook(Word* screen,bool paint);
    struct ScreenEntries
    {
        std::string car;
        std::unordered_map<Word*, int> locations;
        Word* lastUnmappedSelection = nullptr;
        std::vector<NFSMWAP::ShopEntry> catalog;
        bool equipment=false;
        int packages=0;
        std::size_t inventoryCount=0;
        Word menu=0;
    };
    std::unordered_map<Word*, ScreenEntries> g_entries;
    void __fastcall SetupHook(Word* screen,void*);
    struct LabelState { int location = 0; std::string item; bool written = false; };
    std::unordered_map<Word*, LabelState> g_labelStates;
    struct HiddenCar { Word address, rideKey; int visible; };
    std::vector<HiddenCar> g_hidden;

    Word Hash(const char* text)
    {
        Word hash = 0xFFFFFFFFu;
        while (*text) hash = hash * 33u + static_cast<unsigned char>(*text++);
        return hash;
    }

    bool CareerScope(bool dealership)
    {
        __try
        {
            if (*reinterpret_cast<int*>(0x925E90u) != 3) return false;
            const Word db = *reinterpret_cast<Word*>(0x91CF90u);
            if (!db) return false;
            const Word flags = *reinterpret_cast<Word*>(db + 0x12Cu);
            return NFSMWAP::NativeStoreMode(flags,dealership);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    bool InEquipmentRoom()
    {
        if (!CareerScope(false)) return false;
        __try { return reinterpret_cast<bool(__cdecl*)()>(0x575B00u)(); }
        __except(EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    int NativeEquipmentPackages(int type)
    {
        __try { return reinterpret_cast<int(__cdecl*)(void*,int)>(0x672E80u)(reinterpret_cast<void*>(0x9B9EC8u),type); }
        __except(EXCEPTION_EXECUTE_HANDLER) { return 0; }
    }

    bool CanOpenEquipmentRoom()
    {
        __try {
            if (!*reinterpret_cast<Word*>(0x9B9EC4u))return false;


            if(g_visualBackroomReady)return true;
            if (reinterpret_cast<bool(__thiscall*)(void*)>(0x7A5790u)(reinterpret_cast<void*>(0x9B9EC0u))) return false;
        }
        __except(EXCEPTION_EXECUTE_HANDLER) { return false; }
        for (int type=0;type<7;++type) if (NativeEquipmentPackages(type)>0) return true;
        return false;
    }

    int InstalledEquipment(int type)
    {
        __try { return reinterpret_cast<int(__thiscall*)(void*,int)>(0x7A4D10u)(reinterpret_cast<void*>(0x9B9EC0u),type); }
        __except(EXCEPTION_EXECUTE_HANDLER) { return -1; }
    }

    bool ApplyEquipment(int type,int level)
    {
        __try {
            if (!*reinterpret_cast<Word*>(0x9B9EC4u)) return false;
            reinterpret_cast<void(__thiscall*)(void*,int,int)>(0x7A4C20u)(reinterpret_cast<void*>(0x9B9EC0u),type,level);
            return InstalledEquipment(type)==level;
        }
        __except(EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    bool UniqueInstalled(int type)
    {
        __try {return reinterpret_cast<bool(__thiscall*)(void*,int)>(0x7A4CD0u)(reinterpret_cast<void*>(0x9B9EC0u),type);}
        __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }
    bool UniqueAvailable(unsigned int menu)
    {
        const int type=NFSMWAP::EquipmentPhysicsType(menu);if (type<0) return false;
        __try {
            return UniqueInstalled(type) || (reinterpret_cast<int(__cdecl*)(unsigned int)>(0x7A58D0u)(menu)>0 &&
                reinterpret_cast<bool(__thiscall*)(void*,int)>(0x7A56A0u)(reinterpret_cast<void*>(0x9B9EC0u),type));
        } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }
    bool ApplyUnique(unsigned int menu,int type)
    {
        if (UniqueInstalled(type)) return true;
        if (!UniqueAvailable(menu)) return false;
        __try {
            reinterpret_cast<void(__thiscall*)(void*,int,int)>(0x7A4C20u)(reinterpret_cast<void*>(0x9B9EC0u),type,7);
            if (!UniqueInstalled(type)) return false;
            reinterpret_cast<void(__thiscall*)(void*,int)>(0x576E30u)(reinterpret_cast<void*>(0x91D928u),type);
            return true;
        } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }

    bool ObjectIsString(Word* object)
    {
        __try { return NFSMWAP::NativeFEObjectIsString(object); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    int CollectNativeStrings(Word* root,Word** result,int capacity)
    {
        __try
        {
            Word* pending[256]={};int queued=0,visited=0,count=0;
            if (root) pending[queued++]=root;
            while (queued && visited++<256 && count<capacity)
            {
                Word* object=pending[--queued];
                const Word type=object[offsetof(NFSMWAP::NativeFEObjectPrefix,type)/4u];
                if (type==2u) result[count++]=object;
                else if (type==5u)
                {
                    const Word children=object[0x60u/4u];
                    Word* child=reinterpret_cast<Word*>(object[0x64u/4u]);
                    if (children>128u) continue;
                    for (Word n=0;n<children && child && queued<256;++n)
                    {pending[queued++]=child;child=reinterpret_cast<Word*>(child[1]);}
                }
            }
            return count;
        }
        __except(EXCEPTION_EXECUTE_HANDLER) { return 0; }
    }

    struct RewardGeometry {Word data=0,font=0,width=0;float x=1,y=1;};
    struct RewardLayout {RewardGeometry original,last;Word guid=0,name=0;std::u16string label;float factor=1,lineLimit=0;Word width=0,fitWidth=0;};
    std::unordered_map<Word*,RewardLayout> g_rewardLayouts;
    bool ReadRewardGeometry(Word* text,RewardGeometry& geometry)
    {
        __try {
            geometry.data=text[0x2Cu/4u];geometry.font=text[0x24u/4u];
            if (geometry.data<0x10000u || text[0x30u/4u]<0x44u) return false;
            const auto data=reinterpret_cast<const float*>(geometry.data);
            geometry.x=data[0x38u/4u];geometry.y=data[0x3Cu/4u];
            geometry.width=text[NFSMWAP::FEStringMaxWidthOffset/4u];
            return std::isfinite(geometry.x) && std::isfinite(geometry.y) && geometry.x>0 && geometry.y>0;
        } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }
    bool MeasureRewardFit(Word fontHash,const char16_t* text,int leading,Word flags,Word width,float& scale,Word& wrapWidth,float lineLimit=1.35f)
    {
        __try {
            void* font=reinterpret_cast<void*(__cdecl*)(Word)>(0x585B50u)(fontHash);
            if (!font) return false;
            using Height=float(__thiscall*)(void*,const char16_t*,int,Word,Word,bool);
            const auto height=reinterpret_cast<Height>(0x591FD0u);
            const float line=height(font,u"Ag",leading,flags,0,false);
            if (!std::isfinite(line) || line<=0) return false;


            for (const float candidate:{1.0f,0.9f,0.8f,0.7f,0.6f,0.5f,0.45f,0.4f,0.35f,0.3f}) {
                const auto limit=static_cast<Word>(std::ceil(width/candidate));
                const float measured=height(font,text,leading,flags,limit,true);
                if (!std::isfinite(measured) || measured<=0) return false;
                scale=candidate;wrapWidth=limit;
                if (lineLimit<=1.0f ? measured<=line*1.01f : measured*candidate<=line*lineLimit) return true;
            }
            return true;
        } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }
    bool RewardLiteralMatches(Word* text,const char16_t* expected)
    {
        __try {
            const auto flags=text[offsetof(NFSMWAP::NativeFEObjectPrefix,flags)/4u];
            if ((flags&NFSMWAP::FERewardLiteral)!=NFSMWAP::FERewardLiteral || (flags&0x20u)) return false;
            const Word buffer=text[NFSMWAP::FEStringBufferOffset/4u],capacity=text[NFSMWAP::FEStringBufferOffset/4u+1u];
            if (buffer<0x10000u || !capacity) return false;
            const auto value=reinterpret_cast<const char16_t*>(buffer);
            for (Word n=0;n<capacity && n<4096u;++n) {
                if (value[n]!=expected[n]) return false;
                if (!expected[n]) return true;
            }
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
        return false;
    }
    void FormatRewardTitle(Word* text,const std::u16string& label,Word requestedWidth=0,float lineLimit=1.35f)
    {


        text[NFSMWAP::FEStringFormatOffset/4u]|=NFSMWAP::FEStringWordWrap;
        if (!text[NFSMWAP::FEStringMaxWidthOffset/4u]) text[NFSMWAP::FEStringMaxWidthOffset/4u]=500u;
        RewardGeometry current;
        if (!ReadRewardGeometry(text,current)) return;
        auto entry=g_rewardLayouts.find(text);
        const Word guid=text[0xCu/4u],name=text[0x10u/4u];
        if (entry==g_rewardLayouts.end() || entry->second.last.font!=current.font ||
            entry->second.guid!=guid || entry->second.name!=name) {
            RewardLayout fresh;fresh.original=current;fresh.last=current;fresh.guid=guid;fresh.name=name;
            entry=g_rewardLayouts.insert_or_assign(text,std::move(fresh)).first;
        }
        auto& layout=entry->second;
        const auto close=[](float a,float b){return std::abs(a-b)<0.0001f;};


        const Word desiredWidth=requestedWidth ? requestedWidth : (layout.original.width ? layout.original.width : 500u);
        if (layout.label!=label || layout.fitWidth!=desiredWidth || layout.lineLimit!=lineLimit) {
            layout.factor=1.0f;layout.width=desiredWidth;layout.fitWidth=desiredWidth;layout.lineLimit=lineLimit;
            const Word baseWidth=static_cast<Word>(std::clamp(std::floor(desiredWidth/layout.original.x),1.0f,65535.0f));
            layout.width=baseWidth;
            if (!MeasureRewardFit(current.font,label.c_str(),static_cast<int>(text[0x70u/4u]),
                                  text[offsetof(NFSMWAP::NativeFEObjectPrefix,flags)/4u],baseWidth,layout.factor,layout.width,lineLimit)) {
                layout.factor=1.0f;layout.width=baseWidth;
            }
            layout.label=label;
        }
        const float x=layout.original.x*layout.factor,y=layout.original.y*layout.factor;
        if (!close(current.x,x) || !close(current.y,y))
            reinterpret_cast<void(__cdecl*)(Word*,float,float)>(0x5155E0u)(text,x,y);
        text[NFSMWAP::FEStringMaxWidthOffset/4u]=layout.width;
        RewardGeometry applied=current;
        ReadRewardGeometry(text,applied);
        layout.last={applied.data,applied.font,layout.width,x,y};
    }

    void FormatNativeName(const char* package,Word hash,Word width,bool wrap)
    {
        Word* strings[64]={};
        const auto count=CollectNativeStrings(reinterpret_cast<FindFn>(0x524850u)(package,hash),strings,64);
        for (int n=0;n<count;++n)
        {
            Word* text=strings[n];
            auto& format=text[NFSMWAP::FEStringFormatOffset/4u];
            format=wrap ? format|NFSMWAP::FEStringWordWrap : format&~NFSMWAP::FEStringWordWrap;
            text[NFSMWAP::FEStringMaxWidthOffset/4u]=width;
            text[offsetof(NFSMWAP::NativeFEObjectPrefix,flags)/4u] |= (1u<<22u)|(1u<<25u);
        }
    }

    void FormatDealerName(const char* package,Word hash,Word width,const std::string& label,float lineLimit=1.8f)
    {
        const auto wide=NFSMWAP::NativeShopWideText(label);
        Word* strings[64]={};
        const auto count=CollectNativeStrings(reinterpret_cast<FindFn>(0x524850u)(package,hash),strings,64);
        for(int n=0;n<count;++n)
        {
            Word* text=strings[n];
            auto& format=text[NFSMWAP::FEStringFormatOffset/4u];


            format=(format&~NFSMWAP::FEStringHorizontalMask)|
                NFSMWAP::FEStringHorizontalCenter|NFSMWAP::FEStringWordWrap;
            text[NFSMWAP::FEStringMaxWidthOffset/4u]=width;
            auto& flags=text[offsetof(NFSMWAP::NativeFEObjectPrefix,flags)/4u];


            flags=(flags&~0x20u)|NFSMWAP::FERewardLiteral|(1u<<22u)|(1u<<25u);


            FormatRewardTitle(text,wide,width,lineLimit);
        }
    }

    bool SetString(const char* package,Word hash,const std::string& text,bool visible);
    void FitNativeString(Word* text,const std::u16string& label,Word width,float lineLimit)
    {
        if(!ObjectIsString(text))return;
        auto& flags=text[offsetof(NFSMWAP::NativeFEObjectPrefix,flags)/4u];
        flags=(flags&~0x20u)|NFSMWAP::FERewardLiteral|(1u<<22u)|(1u<<25u);
        FormatRewardTitle(text,label,width,lineLimit);
    }
    void FitPackageString(const char* package,Word hash,const std::string& label,Word width,float lineLimit)
    {
        const auto wide=NFSMWAP::NativeShopWideText(label);
        Word* strings[64]={};
        const auto count=CollectNativeStrings(reinterpret_cast<FindFn>(0x524850u)(package,hash),strings,64);
        for(int n=0;n<count;++n)FitNativeString(strings[n],wide,width,lineLimit);
    }
    void SetEquipmentFooter(const char* package,Word hash,const std::string& label,Word width)
    {
        SetString(package,hash,label,true);
        Word* strings[64]={};const auto count=CollectNativeStrings(reinterpret_cast<FindFn>(0x524850u)(package,hash),strings,64);
        const auto wide=NFSMWAP::NativeShopWideText(label);
        for(int n=0;n<count;++n)FitNativeString(strings[n],wide,width,1.0f);
    }
    bool SetPartDetail(const char* package,const char* name,const std::string& label)
    {
        const Word hash=Hash(name);
        if(!SetString(package,hash,label,true))return false;
        const auto wide=NFSMWAP::NativeShopWideText(label);
        Word* strings[64]={};
        const auto count=CollectNativeStrings(reinterpret_cast<FindFn>(0x524850u)(package,hash),strings,64);
        for(int n=0;n<count;++n) {
            auto* text=strings[n];
            FitNativeString(text,wide,300u,1.8f);
        }
        return count>0;
    }

    bool SetObjectString(Word* object, const std::string& text, bool visible = false)
    {


        if (!ObjectIsString(object)) return false;


        const auto wide=NFSMWAP::NativeShopWideText(text);
        reinterpret_cast<void(__cdecl*)(Word*,const char16_t*)>(0x515CC0u)(object,wide.c_str());
        object[offsetof(NFSMWAP::NativeFEObjectPrefix,flags)/sizeof(Word)] |=
            NFSMWAP::FEStringLiteral | (1u<<22u) | (1u<<25u);
        if (visible)
        {


            reinterpret_cast<void(__cdecl*)(Word*,Word)>(0x5157E0u)(object,0xFFFFFFFFu);
            reinterpret_cast<Word*(__cdecl*)(Word*)>(0x514CC0u)(object);
        }
        return true;
    }

    bool SetString(const char* package, Word hash, const std::string& text, bool visible = false)
    {
        Word* strings[64]={};
        const auto count=CollectNativeStrings(reinterpret_cast<FindFn>(0x524850u)(package,hash),strings,64);
        bool written=false;
        for (int n=0;n<count;++n) written=SetObjectString(strings[n],text,visible) || written;
        return written;
    }

    bool SetMoney(const char* package, Word hash, int amount)
    {
        Word* strings[64]={};
        const auto count=CollectNativeStrings(reinterpret_cast<FindFn>(0x524850u)(package,hash),strings,64);
        for (int n=0;n<count;++n)
        {
            Word* object=strings[n];
            if (!object[NFSMWAP::FEStringBufferOffset/4u] || object[NFSMWAP::FEStringBufferOffset/4u+1u]<64u)
                reinterpret_cast<void(__thiscall*)(void*,Word)>(0x5B91C0u)(object+NFSMWAP::FEStringBufferOffset/4u,64u);
            reinterpret_cast<PrintFn>(0x515D70u)(object,"%$d",amount);
            object[offsetof(NFSMWAP::NativeFEObjectPrefix,flags)/4u] |= NFSMWAP::FEStringLiteral|(1u<<22u)|(1u<<25u);
            reinterpret_cast<void(__cdecl*)(Word*,Word)>(0x5157E0u)(object,0xFFFFFFFFu);
            reinterpret_cast<Word*(__cdecl*)(Word*)>(0x514CC0u)(object);
        }
        return count>0;
    }


    void SetGroupVisible(const char* package, Word hash)
    {
        Word* object=reinterpret_cast<FindFn>(0x524850u)(package,hash);
        if (object)
        {
            reinterpret_cast<Word*(__cdecl*)(Word*)>(0x514CC0u)(object);
        }
    }

    void LogLabel(Word* screen, const NFSMWAP::ShopEntry& entry, bool written)
    {
        auto& previous=g_labelStates[screen];
        const std::string text=NFSMWAP::NativeShopItemLabel(entry);
        if (previous.location==entry.locationId && previous.item==text && previous.written==written) return;
        previous={entry.locationId,text,written};
        NFSMWAP::Log("AP NATIVE SHOP LABEL: location="+std::to_string(entry.locationId)+
            " item_id="+std::to_string(entry.itemId)+" item='"+text+"' scouted_item='"+entry.itemName+"' recipient='"+entry.recipientName+
            "' native_text="+(written ? "written" : "field_missing"));
    }


    ScreenHook* HookFor(Word* screen)
    {
        if (!screen) return nullptr;
        for (auto& hook : g_screens) if (*screen == hook.table) return &hook;
        return nullptr;
    }

    void TrackScreen(ActiveScreen& active, Word* screen)
    {
        active.object=screen;
        active.table=*screen;
        active.package=reinterpret_cast<const char*>(screen[4]);
    }

    bool SameLiveScreen(const ActiveScreen& active)
    {
        __try { return active.object && *active.object==active.table; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    bool PaintScreen(Word* screen) { return screen && *screen == 0x8B8068u; }

    void ReplaceBuildMapping()
    {
        if (!g_replaceMappingPending || !g_buildScreen) return;
        g_entries[g_buildScreen].locations.clear();
        g_entries[g_buildScreen].lastUnmappedSelection=nullptr;
        g_replaceMappingPending=false;
    }
    void StartShopBuild(Word* screen,const std::vector<NFSMWAP::ShopEntry>& catalog,bool lazyMapping=false)
    {
        g_buildScreen=screen;g_buildEntries=catalog;g_buildOrdinal=0;
        g_buildParts.clear();g_rejectedParts.clear();g_rejectedDatums.clear();
        g_replaceMappingPending=lazyMapping;
        g_entries[screen].catalog=catalog;
        if (!lazyMapping) g_entries[screen].locations.clear();
    }
    void FinishShopBuild(Word* screen)
    {


        for (Word* part:g_rejectedParts) (*reinterpret_cast<void(__thiscall**)(Word*,int)>(*part))(part,1);
        for (Word* datum:g_rejectedDatums) (*reinterpret_cast<void(__thiscall**)(Word*,int)>(*datum))(datum,1);
        g_rejectedParts.clear();g_rejectedDatums.clear();
        g_entries[screen].menu=screen[82];
        g_buildScreen=nullptr;g_replaceMappingPending=false;
        g_buildEntries.clear();g_buildParts.clear();
        NFSMWAP::Log("AP SHOP LIST READY: menu="+std::to_string(screen[82])+" car='"+g_entries[screen].car+
            "' mapped_rows="+std::to_string(g_entries[screen].locations.size()));
    }

    void RebuildPaintMap(Word* screen)
    {
        auto it = g_entries.find(screen);
        if (it == g_entries.end()) return;
        const auto& entries=it->second.catalog;
        if (entries.empty()) return;
        it->second.locations.clear();
        using DatumFn = Word*(__thiscall*)(Word*, int);
        for (int i = 0; i < 1024; ++i)
        {
            Word* datum = reinterpret_cast<DatumFn>(0x588250u)(screen + 136, i);
            if (!datum) break;
            if (static_cast<std::size_t>(i)>=entries.size()) break;
            if (datum[6]) it->second.locations[reinterpret_cast<Word*>(datum[6])] = entries[static_cast<std::size_t>(i)].locationId;
        }
    }

    bool GetEntry(Word* screen, NFSMWAP::ShopEntry& entry)
    {
        const auto it = g_entries.find(screen);
        if (it == g_entries.end()) return false;

        Word* selected = (*reinterpret_cast<GetSelectedFn*>(*screen + 20u))(screen);
        const auto location = it->second.locations.find(selected);
        bool mapped=false;
        if (location!=it->second.locations.end()) {
            if (it->second.equipment) {
                for (const auto& row:it->second.catalog) if (row.locationId==location->second) {entry=row;mapped=true;break;}
                if (mapped) entry.checked=entry.itemType=="native_unique" ? UniqueInstalled(NFSMWAP::EquipmentPhysicsType(screen[82])) :
                    InstalledEquipment(NFSMWAP::EquipmentPhysicsType(screen[82]))==
                    NFSMWAP::EquipmentLevel(entry.tier,NFSMWAP::EquipmentPhysicsType(screen[82]),it->second.packages);
            } else mapped=NFSMWAP::GetShopEntry(location->second,entry);
        }
        if (mapped) it->second.lastUnmappedSelection=nullptr;
        else if (selected && g_buildScreen!=screen && selected!=it->second.lastUnmappedSelection)
        {
            it->second.lastUnmappedSelection=selected;
            NFSMWAP::Log("AP NATIVE SHOP LABEL: selected native row has no catalog mapping; car='"+
                it->second.car+"' rows="+std::to_string(it->second.locations.size())+
                " selected="+std::to_string(reinterpret_cast<std::uintptr_t>(selected)));
        }
        return mapped;
    }

    void RefreshAP(Word* screen)
    {
        NFSMWAP::ShopEntry entry;
        if (!GetEntry(screen, entry))
        {
            const char* package=reinterpret_cast<const char*>(screen[4]);
            const auto state=g_entries.find(screen);
            const bool equipment=state!=g_entries.end() && state->second.equipment;
            const bool waiting=state==g_entries.end() || state->second.catalog.empty();
            const char* label=equipment ? "NO SUPPORTED PERFORMANCE PACKAGES" : waiting ?
                "WAITING FOR ARCHIPELAGO ITEMS" : "SELECT AN ARCHIPELAGO ITEM";
            SetString(package,0x5E7B09C9u,label,true);
            if (PaintScreen(screen)) SetString(package,0x78008599u,label,true);
            SetString(package,0xB94139F4u,"Unavailable",true);
            return;
        }
        const char* package = reinterpret_cast<const char*>(screen[4]);
        if (g_entries.at(screen).equipment) {
            const auto labels=NFSMWAP::EquipmentLabels(entry);
            SetString(package,0x5E7B09C9u,labels.title,true);
            SetString(package,Hash("PART_NAME"),labels.title,true);
            auto* directTitle=reinterpret_cast<Word*>(screen[75]);
            SetObjectString(directTitle,labels.title,true);
            FitPackageString(package,0x5E7B09C9u,labels.title,275u,1.0f);
            FitPackageString(package,Hash("PART_NAME"),labels.title,275u,1.0f);
            FitNativeString(directTitle,NFSMWAP::NativeShopWideText(labels.title),275u,1.0f);
            SetPartDetail(package,"DETAIL_TEXT_LINE1",labels.car);
            const bool unique=entry.itemType=="native_unique";
            SetPartDetail(package,"DETAIL_TEXT_LINE2",labels.description);
            SetPartDetail(package,"DETAIL_TEXT_LINE3",labels.status);
            SetString(package,0xB94139F4u,entry.checked ? "Equipped" : unique ? "Equip - 1 Unique marker" : "Equip FREE",true);
            SetEquipmentFooter(package,0x63CA8308u,"AP EQUIPMENT",230u);
            SetString(package,0x23D918FEu,"FREE",true);
            SetEquipmentFooter(package,0x83E3CD39u,unique ? "UNIQUE" : entry.itemId ? "RECEIVED" : "STOCK",110u);
            SetMoney(package,0xDBB80EDDu,0);SetMoney(package,0x7A6D2F71u,0);SetMoney(package,0xA91EDA8Au,0);
            return;
        }
        const std::string item = NFSMWAP::NativeShopItemLabel(entry);
        if(g_buildScreen!=screen)NFSMWAP::ReportViewedShopLocation(entry.locationId);
        const std::string wrapped=item;
        const bool partName=SetString(package,0x5E7B09C9u,wrapped,true);
        const bool alternateName=SetString(package,Hash("PART_NAME"),wrapped,true);
        const bool paintName=PaintScreen(screen) && SetString(package,0x78008599u,wrapped,true);
        const bool directName=SetObjectString(reinterpret_cast<Word*>(screen[75]),wrapped,true);


        FormatNativeName(package,0x5E7B09C9u,500u,false);
        FormatNativeName(package,Hash("PART_NAME"),500u,false);
        if (PaintScreen(screen)) FormatNativeName(package,0x78008599u,500u,false);
        bool named=partName || alternateName || paintName || directName;


        const bool details=SetPartDetail(package,"DETAIL_TEXT_LINE1",item);
        SetPartDetail(package,"DETAIL_TEXT_LINE2","Check: "+entry.locationName);
        const std::string price="Price: "+NFSMWAP::NativeShopPriceLabel(entry.price);
        SetPartDetail(package,"DETAIL_TEXT_LINE3",price+(entry.checked ? " | Purchased" : " | To: "+entry.recipientName));


        LogLabel(screen,entry,named || details);
        SetString(package, 0xB94139F4u, entry.checked ? "Purchased" : "Buy "+NFSMWAP::NativeShopPriceLabel(entry.price), true);
        for (const char* name : {"COST", "COST_DATA", "COST_VALUE", "PRICE", "PRICE_DATA", "PART_COST", "PART_PRICE"})
            SetMoney(package, Hash(name), entry.price);
        SetMoney(package,0xDBB80EDDu,entry.price);
        SetMoney(package,0x7A6D2F71u,entry.price);
        SetMoney(package,0xA91EDA8Au,0);


        using VisibleFn = Word*(__cdecl*)(Word*);
        for (const char* name : {"ACCELERATION", "HANDLING", "TOPSPEED", "HEAT_LEVEL_GROUP"})
        {
            Word* object = reinterpret_cast<FindFn>(0x524850u)(package, Hash(name));
            if (object) reinterpret_cast<VisibleFn>(0x514C70u)(object);
        }
        for (int n = 1; n <= 3; ++n)
        {
            const std::string name = "BRAND_ICON_" + std::to_string(n);
            Word* image = reinterpret_cast<FindFn>(0x5251A0u)(package, Hash(name.c_str()));
            if (image && g_textureReady) reinterpret_cast<TextureFn>(0x515B90u)(image, Hash("AP_SHOP_LOGO"));
        }
        if (PaintScreen(screen))
        {
            using SlotFn = Word*(__thiscall*)(Word*, int);
            using ColorFn = void(__cdecl*)(Word*, Word);
            for (int i = 0; i < 80; ++i)
            {
                Word* slot = reinterpret_cast<SlotFn>(0x588220u)(screen + 136, i);
                Word* image = slot ? reinterpret_cast<Word*>(slot[3]) : nullptr;
                if (!image) continue;
                reinterpret_cast<TextureFn>(0x515B90u)(image, Hash("AP_SHOP_LOGO"));
                reinterpret_cast<ColorFn>(0x5157E0u)(image, 0xFFFFFFFFu);
            }
        }
    }

    void __fastcall RefreshHook(Word* screen, void*)
    {
        ScreenHook* hook = HookFor(screen);
        if (!hook) return;
        if (!CareerScope(false) || g_entries.find(screen) == g_entries.end())
        {
            hook->refresh(screen);
            return;
        }
        TrackScreen(g_activeParts,screen);
        if (g_entries.at(screen).equipment) {
            hook->refresh(screen);
            RefreshAP(screen);return;
        }


        if (PaintScreen(screen)) RebuildPaintMap(screen);
        NFSMWAP::ShopEntry selected;
        if (GetEntry(screen, selected)) g_priceOverride = selected.price;
        if (PaintScreen(screen))
        {
            (*reinterpret_cast<SetupFn*>(screen[136] + 8u))(screen + 136);
            Word* part = (*reinterpret_cast<GetSelectedFn*>(*screen + 20u))(screen);
            using CareerFn = void(__thiscall*)(Word*, Word*, int, int);
            if (part) reinterpret_cast<CareerFn>(0x7B13C0u)(screen + 85, part, screen[82], 0);
        }
        else reinterpret_cast<SetupFn>(0x7B1620u)(screen);
        g_priceOverride = -1;
        RefreshAP(screen);
    }

    void __fastcall NotifyHook(Word* screen, void*, Word message, Word* object, Word p1, Word p2)
    {
        ScreenHook* hook = HookFor(screen);
        if (!hook) return;
        if (message==Back)
        {
            if (g_activeParts.object==screen) g_activeParts={};
            g_entries.erase(screen);
            g_labelStates.erase(screen);
            hook->notify(screen,message,object,p1,p2);
            return;
        }
        if (CareerScope(false) && message == Accept && g_entries.find(screen)!=g_entries.end())
        {
            NFSMWAP::ShopEntry entry;
            if (GetEntry(screen, entry) && g_entries.at(screen).equipment) {
                const auto& state=g_entries.at(screen);
                std::string car;
                const int type=NFSMWAP::EquipmentPhysicsType(screen[82]);
                const int level=NFSMWAP::EquipmentLevel(entry.tier,type,state.packages);
                const bool unique=entry.itemType=="native_unique";
                if (InEquipmentRoom() && NFSMWAP::GetNativeShopCar(car) && car==state.car && type>=0 && level>=0 &&
                    (entry.itemId==0 || NFSMWAP::HasReceivedItem(entry.itemId)) &&
                    (unique ? ApplyUnique(screen[82],type) : ApplyEquipment(type,level))) {
                    NFSMWAP::RequestCareerAutosave();
                    NFSMWAP::Log("AP EQUIPMENT INSTALLED: car='"+car+"' type="+std::to_string(type)+" level="+std::to_string(level));
                    NFSMWAP::QueueNotification("ARCHIPELAGO BACKROOM",entry.itemName,unique ? "UNIQUE PART INSTALLED" : "EQUIPPED - FREE",3500);
                    RefreshHook(screen,nullptr);
                } else NFSMWAP::QueueNotification("ARCHIPELAGO BACKROOM","UPGRADE COULD NOT BE EQUIPPED","REENTER THE BACKROOM",3500);
                return;
            }
            if (InEquipmentRoom()) {RefreshAP(screen);return;}
            if (GetEntry(screen, entry)) NFSMWAP::PurchaseNativeShopEntry(entry.locationId, g_entries.at(screen).car);
            else NFSMWAP::QueueNotification("ARCHIPELAGO SHOP", "NATIVE SHOP DATA NOT READY",
                "CHECK LOG / REENTER AFTER AP CONNECTS", 4000);
            RefreshAP(screen);
            return;
        }
        const auto state=g_entries.find(screen);
        const bool filter=(message==FilterLeft || message==FilterRight) &&
            (*screen==0x8B7FBCu || *screen==0x8B7FDCu || PaintScreen(screen));
        if (filter && CareerScope(false) && state!=g_entries.end() && !state->second.equipment &&
            !state->second.catalog.empty() && !g_buildScreen)
        {


            const auto catalog=NFSMWAP::NativeShopMenuEntries(
                NFSMWAP::GetShopEntriesForCar("performance_shop",state->second.car),screen[82]);
            if (!catalog.empty()) {
                StartShopBuild(screen,catalog,true);
                hook->notify(screen,message,object,p1,p2);
                FinishShopBuild(screen);
                if (PaintScreen(screen)) RebuildPaintMap(screen);
                RefreshAP(screen);return;
            }
        }
        hook->notify(screen, message, object, p1, p2);


    }

    void __fastcall AddPartHook(Word* screen, void*, Word* part, Word icon, Word name,
                                Word unknown, Word unlock, bool locked)
    {
        if (screen == g_buildScreen && part && !g_buildEntries.empty())
        {
            ReplaceBuildMapping();
            if (g_buildOrdinal>=g_buildEntries.size())
            {


                part[1]=part[2]=static_cast<Word>(reinterpret_cast<std::uintptr_t>(part+1));
                g_rejectedParts.push_back(part);
                return;
            }
            if (g_buildOrdinal<g_buildEntries.size())
            {
                g_entries[screen].locations[part] = g_buildEntries[g_buildOrdinal].locationId;
                g_buildParts.push_back(part);
                ++g_buildOrdinal;
                icon = Hash("AP_SHOP_LOGO");
                unlock = 0;
                locked = false;
                part[8] = g_buildEntries[g_buildOrdinal-1].checked ? 16u : 1u;
                if (g_entries[screen].equipment) {
                    const auto& state=g_entries[screen];const auto& row=g_buildEntries[g_buildOrdinal-1];
                    const int type=NFSMWAP::EquipmentPhysicsType(screen[82]);
                    part[3]=0;part[4]=0;part[5]=NFSMWAP::EquipmentLevel(row.tier,type,state.packages);
                    part[6]=type;part[7]=1;part[8]=1;part[9]=0;part[10]=row.itemType=="native_unique" ? 1u : 0u;
                }
            }
        }
        reinterpret_cast<AddFn>(0x7B1740u)(screen, part, icon, name, unknown, unlock, locked);
    }

    void __fastcall AddPaintDatumHook(Word* scroller,void*,Word* datum)
    {
        if (g_buildScreen && scroller==g_buildScreen+136 && datum && !g_buildEntries.empty())
        {
            ReplaceBuildMapping();
            if (g_buildOrdinal>=g_buildEntries.size())
            {
                Word* part=reinterpret_cast<Word*>(datum[6]);
                if (part) part[1]=part[2]=static_cast<Word>(reinterpret_cast<std::uintptr_t>(part+1));
                g_rejectedDatums.push_back(datum);return;
            }
            Word* part=reinterpret_cast<Word*>(datum[6]);
            if (part)
            {
                g_entries[g_buildScreen].locations[part]=g_buildEntries[g_buildOrdinal].locationId;
                part[8]=g_buildEntries[g_buildOrdinal].checked ? 16u : 1u;
            }
            ++g_buildOrdinal;datum[7]=0;
        }
        reinterpret_cast<void(__thiscall*)(Word*,Word*)>(0x59BD30u)(scroller,datum);
    }

    void __fastcall IconPositionHook(Word* scroller,void*,int position)
    {
        const auto original=g_iconPositions.find(*scroller);
        if (original==g_iconPositions.end()) return;
        if (g_buildScreen && scroller==g_buildScreen+11 && !g_buildEntries.empty())
        {
            ReplaceBuildMapping();


            while (g_buildOrdinal<g_buildEntries.size() && !g_buildParts.empty())
            {
                Word* copy=static_cast<Word*>(reinterpret_cast<void*(__cdecl*)(std::size_t)>(0x652AD0u)(0x2Cu));
                if (!copy) break;
                reinterpret_cast<void(__thiscall*)(Word*,Word*)>(0x7A9E60u)(copy,g_buildParts.front());
                AddPartHook(g_buildScreen,nullptr,copy,Hash("AP_SHOP_LOGO"),0,0,0,false);
            }
            position=1;
        }
        original->second(scroller,position);
    }

    void __fastcall ArrayPositionHook(Word* scroller,void*,int position)
    {
        if (g_buildScreen && scroller==g_buildScreen+136 && !g_buildEntries.empty()) {ReplaceBuildMapping();position=0;}
        reinterpret_cast<PositionFn>(0x593560u)(scroller,position);
    }

    void __fastcall SetupHook(Word* screen, void*)
    {
        ScreenHook* hook = HookFor(screen);
        if (!hook) return;
        g_entries.erase(screen);
        g_labelStates.erase(screen);
        std::string car;
        if (!g_partsReady || !CareerScope(false) || g_visualBackroom || !NFSMWAP::GetNativeShopCar(car))
        {
            hook->setup(screen);
            return;
        }
        const bool equipment=InEquipmentRoom();
        if (!equipment && !NFSMWAP::NativeShopHasHome(screen[82])) {
            hook->setup(screen);return;
        }
        const int type=NFSMWAP::EquipmentPhysicsType(screen[82]);
        const int packages=equipment && hook->performance && type>=0 ? NativeEquipmentPackages(type) : 0;
        g_buildEntries=equipment ? NFSMWAP::EquipmentCatalog(NFSMWAP::GetReceivedInventory(),car,screen[82],packages,UniqueAvailable(screen[82])) :
            NFSMWAP::NativeShopMenuEntries(NFSMWAP::GetShopEntriesForCar("performance_shop",car),screen[82]);
        if (!EnsurePositionHook(screen,PaintScreen(screen)))
        { hook->setup(screen);NFSMWAP::Log("AP NATIVE SHOP: native position hook unavailable; AP list setup skipped.");return; }
        const auto catalog=g_buildEntries;
        g_entries[screen].car = car;
        g_entries[screen].equipment=equipment;
        g_entries[screen].packages=packages;
        g_entries[screen].inventoryCount=NFSMWAP::GetReceivedItemCount();
        g_entries[screen].menu=screen[82];
        StartShopBuild(screen,catalog);
        hook->setup(screen);
        if (PaintScreen(screen)) RebuildPaintMap(screen);
        NFSMWAP::Log(std::string(equipment ? "AP BACKROOM EQUIPMENT 1.0.0: car='" : "AP NATIVE SHOP 1.0.0: car='") + car + "' native_carriers="+std::to_string(g_buildOrdinal)+
            " catalog_items=" + std::to_string(g_buildEntries.size()) + " icons=native_tpk selection=native unique_menu_checks=yes");
        FinishShopBuild(screen);
        RefreshHook(screen, nullptr);
    }


    template<std::size_t I> void __fastcall SetupCallHook(Word* screen, void*)
    { if (HookFor(screen)) SetupHook(screen, nullptr); else g_screens[I].setup(screen); }
    template<std::size_t I> void __fastcall RefreshCallHook(Word* screen, void*)
    { if (HookFor(screen)) RefreshHook(screen, nullptr); else g_screens[I].refresh(screen); }
    using DirectScreenFn = void(__fastcall*)(Word*, void*);
    const std::array<DirectScreenFn, 5> g_setupCalls{{
        &SetupCallHook<0>, &SetupCallHook<1>,
        &SetupCallHook<2>, &SetupCallHook<3>,
        &SetupCallHook<4>}};
    const std::array<DirectScreenFn, 5> g_refreshCalls{{
        &RefreshCallHook<0>, &RefreshCallHook<1>,
        &RefreshCallHook<2>, &RefreshCallHook<3>,
        &RefreshCallHook<4>}};

    bool ReadDealerContext(Word* screen, Word& mode, Word& player, Word& filter)
    {
        __try
        {
            const Word database=*reinterpret_cast<Word*>(0x91CF90u);
            if (!database || !screen) return false;
            mode=*reinterpret_cast<Word*>(database+0x12Cu);
            player=screen[106];filter=screen[107];
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    void RefreshDealership(Word* screen, bool nativeRefresh = false)
    {
        if (g_ready)
        {
            Word mode=0, player=0, filter=0;
            if (ReadDealerContext(screen,mode,player,filter))
            {
                static Word previousMode=0xFFFFFFFFu;
                if (mode!=previousMode)
                {
                    previousMode=mode;
                    NFSMWAP::Log("AP NATIVE SHOP DEALER CONTEXT: mode="+std::to_string(mode)+
                        " player="+std::to_string(player)+" filter="+std::to_string(filter));
                }
            }
        }
        if (!g_ready || !CareerScope(true) || !(screen[107]&1u)) return;
        std::string car;
        NFSMWAP::ShopEntry entry;
        if (!NFSMWAP::GetNativeDealerCar(screen,car) || !NFSMWAP::GetShopEntryForCar("dealership", car, entry))
        {
            static Word* lastFailed=nullptr;
            if (lastFailed!=screen)
            { lastFailed=screen;NFSMWAP::Log("AP NATIVE SHOP DEALER: live selection/catalog lookup not ready."); }
            return;
        }
        const char* package = reinterpret_cast<const char*>(screen[4]);
        if (screen[13] && *(reinterpret_cast<unsigned char*>(screen[13])+12))
        {
            *(reinterpret_cast<unsigned char*>(screen[13])+12)=0;
            g_carSelectRefresh(screen);
        }


        const std::string item=NFSMWAP::NativeShopItemLabel(entry);
        const auto previous=g_labelStates.find(screen);
        if (nativeRefresh || previous==g_labelStates.end() || previous->second.location!=entry.locationId)
            reinterpret_cast<void(__cdecl*)(const char*,Word,Word,bool)>(0x524920u)(package,0xD0F7C7CCu,Hash("SHOW"),true);
        SetGroupVisible(package,0xD0F7C7CCu);


        NFSMWAP::ReportViewedShopLocation(entry.locationId);
        const auto headingText=item+"\nPrice: "+NFSMWAP::NativeShopPriceLabel(entry.price);
        const bool heading=SetString(package,0xAA9834BCu,headingText,true);
        bool named=SetString(package,Hash("CAR_NAME"),item,true);
        FormatDealerName(package,Hash("CAR_NAME"),320u,item,1.0f);
        FormatDealerName(package,0xAA9834BCu,320u,headingText);
        SetMoney(package, 0x20C83C31u, entry.price);
        int balance=0;const bool cashReady=NFSMWAP::GetNativeCareerCash(balance);
        if(cashReady)SetMoney(package,0x1930B057u,balance);
        const std::string details=(cashReady ? "Cash: "+NFSMWAP::NativeShopCashLabel(balance)+" | " : "")+"Price: "+NFSMWAP::NativeShopPriceLabel(entry.price)+
            (entry.checked ? " | Purchased" : " | To: "+entry.recipientName);
        const auto subtitleText=item+"\n"+details;
        const bool subtitle=SetString(package,0x2D25B2C4u,subtitleText,true);
        FormatDealerName(package,0x2D25B2C4u,490u,subtitleText);
        named=named || subtitle || heading;
        SetString(package, 0xB94139F4u, entry.checked ? "Purchased" : "Buy "+NFSMWAP::NativeShopPriceLabel(entry.price), true);
        using VisibleFn = Word*(__cdecl*)(Word*);
        for (int n : {15, 16})
            if (screen[n]) reinterpret_cast<VisibleFn>(0x514C70u)(reinterpret_cast<Word*>(screen[n]));
        Word* group = reinterpret_cast<FindFn>(0x524850u)(package, Hash("ACCEPT_GROUP"));
        if (group) reinterpret_cast<VisibleFn>(0x514CC0u)(group);


        if (screen[13]) *(reinterpret_cast<unsigned char*>(screen[13]) + 12) = 0;
        LogLabel(screen,entry,named);
    }

    bool EnsureDealerNotifyHook(Word* screen);

    bool OwnedCareerCar(Word handle,int player) {
        if (player!=0 || !CareerScope(false)) return false;
        __try {
            const Word db=*reinterpret_cast<Word*>(0x91CF90u),profile=*reinterpret_cast<Word*>(db+0x10u);
            if (!profile) return false;
            const auto car=reinterpret_cast<Word*(__thiscall*)(void*,Word)>(0x56ECC0u)(reinterpret_cast<void*>(profile+0x414u),handle);
            return car && car[0]==handle && (car[3]&2u)!=0;
        } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }
    bool __cdecl CareerCarUnlocked(Word filter,Word handle,int player) {
        if (OwnedCareerCar(handle,player)) return true;
        return reinterpret_cast<bool(__cdecl*)(Word,Word,int)>(0x58A9F0u)(filter,handle,player);
    }
    void UnlockOwnedSelection(Word* screen) {
        __try {
            if (screen && (screen[107]&2u) && screen[13]) {
                auto datum=reinterpret_cast<Word*>(screen[13]);
                if (OwnedCareerCar(datum[2],static_cast<int>(screen[106])))
                    *reinterpret_cast<unsigned char*>(datum+3)=0;
            }
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
    }

    void __fastcall CarSelectRefreshHook(Word* screen, void*)
    {


        if (!EnsureDealerNotifyHook(screen))
        { g_carSelectRefresh(screen); return; }
        TrackScreen(g_activeDealer,screen);
        if (!CareerScope(true))
        {
            using VisibleFn = Word*(__cdecl*)(Word*);
            for (int n : {15, 16})
                if (screen[n]) reinterpret_cast<VisibleFn>(0x514CC0u)(reinterpret_cast<Word*>(screen[n]));
            const char* package = reinterpret_cast<const char*>(screen[4]);
            Word* name = reinterpret_cast<FindFn>(0x5251E0u)(package, Hash("CAR_NAME"));
            if (name) reinterpret_cast<VisibleFn>(0x514C70u)(name);
        }
        UnlockOwnedSelection(screen);
        g_carSelectRefresh(screen);
        RefreshDealership(screen,true);
    }

    bool PrepareReceivedChoice(Word* screen,Word handle)
    {
        __try
        {
            const Word database=*reinterpret_cast<Word*>(0x91CF90u);
            if (!database) return false;
            const Word mode=*reinterpret_cast<Word*>(database+0x12Cu);
            if (!NFSMWAP::NativeCareerDeliveryMode(mode) || !(mode&0x8000u)) return false;
            const bool prepared=NFSMWAP::PrepareNativeOwnedCareerSelection(reinterpret_cast<std::uintptr_t>(screen),handle,
                [](std::uintptr_t address,Word& value) {value=*reinterpret_cast<Word*>(address);return true;},
                [](std::uintptr_t address,Word value) {*reinterpret_cast<Word*>(address)=value;return true;});
            if (!prepared) return false;


            *reinterpret_cast<Word*>(database+0x12Cu)=mode&~0x8000u;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    bool CompleteReceivedCareerStart(Word* screen)
    {
        unsigned int handle=0;
        if (!g_ready || !screen || !CareerScope(true) || !NFSMWAP::GetReceivedCareerStartChoice(handle)) return false;
        NotifyFn original=nullptr;
        for (const auto& dealer:g_dealers) if (*screen==dealer.table) {original=dealer.notify;break;}
        if (!original || !PrepareReceivedChoice(screen,handle)) return false;
        NFSMWAP::NotifyReceivedCareerStartChoice();
        NFSMWAP::NotifyInitialCareerCarSelected();
        g_activeDealer={};g_labelStates.erase(screen);
        UpdateShowroom(false);
        NFSMWAP::Log("AP FIRST CAR: native owned-car Accept dispatched for received handle="+std::to_string(handle)+"; no stock purchase or extra cash debit.");
        original(screen,Accept,nullptr,0,0);
        return true;
    }

    void __fastcall CarSelectNotifyHook(Word* screen, void*, Word message, Word* object, Word p1, Word p2)
    {
        if ((message==Back || message==Accept) && CompleteReceivedCareerStart(screen)) return;
        if (message==Back)
        {
            if(NFSMWAP::InitialDealershipNeedsCar())return;
            if (g_activeDealer.object==screen) g_activeDealer={};
            g_labelStates.erase(screen);
            for (const auto& dealer:g_dealers)
                if (*screen==dealer.table)
                { dealer.notify(screen,message,object,p1,p2);break; }
            return;
        }
        if (g_ready && CareerScope(true) && (screen[107]&1u) && message == Accept)
        {
            std::string car;
            NFSMWAP::ShopEntry entry;
            if (NFSMWAP::GetNativeDealerCar(screen,car) && NFSMWAP::GetShopEntryForCar("dealership", car, entry))
                NFSMWAP::PurchaseNativeShopEntry(entry.locationId, car);
            else NFSMWAP::QueueNotification("ARCHIPELAGO", "SHOP DATA NOT READY", "CONNECT THE AP CLIENT", 3500);
            return;
        }
        if (message==Accept) UnlockOwnedSelection(screen);
        for (const auto& dealer : g_dealers)
            if (*screen == dealer.table)
            { dealer.notify(screen, message, object, p1, p2); break; }


    }

    void RefreshActiveCash()
    {
        static int previous=-1;static std::string previousPackage;static Word* previousScreen=nullptr;
        std::string package;int cash=0;
        const bool career=CareerScope(false)||CareerScope(true);
        if(!career || !NFSMWAP::GetNativeStorePackage(package) || !NFSMWAP::GetNativeCareerCash(cash)) {
            previous=-1;previousPackage.clear();previousScreen=nullptr;return;
        }
        const bool dealer=g_activeDealer.object&&package==g_activeDealer.package&&SameLiveScreen(g_activeDealer);
        const bool parts=g_activeParts.object&&package==g_activeParts.package&&SameLiveScreen(g_activeParts);
        const bool visual=package.rfind("Customize",0)==0 || package=="Rims.fng" || package=="Paint.fng" || package=="Vinyls.fng" || package=="Spoiler.fng" || package=="Decals.fng" || package=="Numbers.fng";
        Word* screen=dealer?g_activeDealer.object:parts?g_activeParts.object:nullptr;
        if(!dealer&&!parts&&!visual){previous=-1;return;}
        if(cash==previous&&package==previousPackage&&screen==previousScreen)return;
        previous=cash;previousPackage=package;previousScreen=screen;
        SetMoney(package.c_str(),0x1930B057u,cash);
        for(const char* field:{"CASH","CASH_VALUE","CAREER_CASH","CASH_AMOUNT"})SetMoney(package.c_str(),Hash(field),cash);
        if(dealer)RefreshDealership(g_activeDealer.object);
    }

    void RefreshActiveLabels()
    {
        std::string package;
        if (!NFSMWAP::GetNativeStorePackage(package)) return;
        if (g_activeDealer.object && package==g_activeDealer.package && CareerScope(true) && SameLiveScreen(g_activeDealer))
            RefreshDealership(g_activeDealer.object);
        if (g_activeParts.object && package==g_activeParts.package && CareerScope(false) && SameLiveScreen(g_activeParts))
        {
            const auto state=g_entries.find(g_activeParts.object);
            if (state!=g_entries.end() && state->second.equipment &&
                state->second.inventoryCount!=NFSMWAP::GetReceivedItemCount()) {
                SetupHook(g_activeParts.object,nullptr);return;
            }
            if (state!=g_entries.end() && !state->second.equipment && !g_buildScreen) {
                const auto current=NFSMWAP::NativeShopMenuEntries(
                    NFSMWAP::GetShopEntriesForCar("performance_shop",state->second.car),g_activeParts.object[82]);
                if (state->second.menu!=g_activeParts.object[82] ||
                    NFSMWAP::NativeShopCatalogChanged(state->second.catalog,current)) {
                    SetupHook(g_activeParts.object,nullptr);return;
                }
            }
            if (PaintScreen(g_activeParts.object)) RebuildPaintMap(g_activeParts.object);
            RefreshAP(g_activeParts.object);
        }
    }

    bool PatchPointer(Word address, void* expected, void* replacement)
    {
        if (*reinterpret_cast<void**>(address) != expected) return false;
        DWORD old = 0, ignored = 0;
        if (!VirtualProtect(reinterpret_cast<void*>(address), 4, PAGE_READWRITE, &old)) return false;
        *reinterpret_cast<void**>(address) = replacement;
        VirtualProtect(reinterpret_cast<void*>(address), 4, old, &ignored);
        return true;
    }

    bool EnsurePositionHook(Word* screen,bool paint)
    {
        if (paint) return true;
        const Word table=screen[11];
        if (!table) return false;
        if (g_iconPositions.find(table)!=g_iconPositions.end()) return true;
        const auto original=*reinterpret_cast<PositionFn*>(table+64u);
        if (reinterpret_cast<std::uintptr_t>(original)!=0x592C90u) return false;
        if (!PatchPointer(table+64u,reinterpret_cast<void*>(original),reinterpret_cast<void*>(&IconPositionHook))) return false;
        g_iconPositions[table]=original;
        return true;
    }

    bool GameFunction(void* pointer)
    {
        const auto address = reinterpret_cast<std::uintptr_t>(pointer);
        return address >= 0x401000u && address < 0x890000u;
    }

    bool EnsureDealerNotifyHook(Word* screen)
    {
        if (!screen) return false;
        for (const auto& dealer : g_dealers) if (dealer.table==*screen) return true;
        const Word table=*screen;
        const NotifyFn original=*reinterpret_cast<NotifyFn*>(table+4u);
        if (g_dealers.size()>=8 || reinterpret_cast<std::uintptr_t>(original)==0x7ADA50u || !GameFunction(reinterpret_cast<void*>(original)) ||
            !PatchPointer(table+4u,reinterpret_cast<void*>(original),reinterpret_cast<void*>(&CarSelectNotifyHook)))
        {
            static bool logged=false;
            if (!logged)
            {
                logged=true;
                NFSMWAP::Log("AP NATIVE SHOP: live Car_Select Notify validation failed; dealer purchases not remapped.");
                NFSMWAP::QueueNotification("ARCHIPELAGO", "DEALERSHIP HOOK FAILED", "SEND NFSMWArchipelago.log", 6000);
            }
            return false;
        }
        g_dealers.push_back({table,original});
        NFSMWAP::Log("AP NATIVE SHOP: live Car_Select controller Notify hooked, table=" + std::to_string(table));
        return true;
    }


    std::uintptr_t FindPattern(const unsigned char* bytes, const char* mask, bool branch)
    {
        const auto base = reinterpret_cast<std::uintptr_t>(GetModuleHandleA(nullptr));
        auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(base);
        auto* nt = reinterpret_cast<IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
        auto* sections = IMAGE_FIRST_SECTION(nt);
        std::uintptr_t result = 0;
        const std::size_t length = std::strlen(mask);
        for (unsigned int s = 0; s < nt->FileHeader.NumberOfSections; ++s)
        {
            if (!(sections[s].Characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;
            const auto start = base + sections[s].VirtualAddress;
            const auto size = sections[s].Misc.VirtualSize;
            for (std::size_t i = 0; i + length <= size; ++i)
            {
                bool match = true;
                for (std::size_t j = 0; j < length; ++j)
                    if (mask[j] == 'x' && *reinterpret_cast<const unsigned char*>(start+i+j) != bytes[j]) { match=false; break; }
                if (!match) continue;
                const auto hit = start+i;
                const auto target = branch ? hit+5+*reinterpret_cast<std::int32_t*>(hit+1) : hit;
                if (!NFSMWAP::AccumulateNativeDestination(target,result)) return 0;
            }
        }
        return result;
    }

    void __fastcall EquipmentMainSetup(Word* screen,void*);

    void __fastcall EquipmentMainRefresh(Word* screen,void*)
    {
        if(g_backroomCarSwapPending&&CareerScope(false)){EquipmentMainSetup(screen,nullptr);return;}
        TrackScreen(g_equipmentMain,screen);
        reinterpret_cast<SetupFn>(0x7B1210u)(screen);
        if (!CareerScope(false) || (!InEquipmentRoom() && !CanOpenEquipmentRoom())) return;
        const char* package=reinterpret_cast<const char*>(screen[4]);
        SetGroupVisible(package,0xDC6EE739u);
        if (!InEquipmentRoom()) SetString(package,0xDC6EE739u,"AP BACKROOM",true);
    }

    bool VerifyBackroomCarSwap()
    {
        __try {
            const unsigned char relinquish[]={0xA1,0x90,0xCF,0x91,0x00,0x53,0x56,0x57,0x8B,0xF9};
            const unsigned char construct[]={0x8B,0x44,0x24,0x0C,0x8B,0x54,0x24,0x04,0x56,0x8B,0xF1};
            const unsigned char open[]={0x81,0x7C,0x24,0x08,0x10,0x72,0x40,0x0C};
            return std::memcmp(reinterpret_cast<void*>(0x7AEB10u),relinquish,sizeof(relinquish))==0&&
                std::memcmp(reinterpret_cast<void*>(0x51FF80u),construct,sizeof(construct))==0&&
                std::memcmp(reinterpret_cast<void*>(0x532080u),open,sizeof(open))==0&&
                *reinterpret_cast<Word*>(0x89C434u)==0x532080u;
        } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }
    void __fastcall BackroomChangeCar(Word*,void*,const char*,Word message,Word*,Word,Word)
    {
        if(message!=0x0C407210u||!g_backroomCarSwapReady||!InEquipmentRoom()||g_visualBackroom)return;
        const Word db=*reinterpret_cast<Word*>(0x91CF90u),feng=*reinterpret_cast<Word*>(0x91CADCu);
        if(!db||!feng||g_backroomCarSwapPending)return;
        g_backroomCarSwapMode=*reinterpret_cast<Word*>(db+0x12Cu);
        g_backroomCarSwapPending=true;
        g_activeParts={};g_activeDealer={};g_entries.clear();
        *reinterpret_cast<Word*>(db+0x12Cu)=1u;
        NFSMWAP::Log("AP BACKROOM: opening native owned-car selector; backroom return retained.");
        reinterpret_cast<void(__thiscall*)(Word*,const char*,int,Word,bool)>(0x525940u)
            (reinterpret_cast<Word*>(feng),"Car_Select.fng",0,0,false);
    }
    void AddBackroomCarSwap(Word* screen)
    {
        if(!g_backroomCarSwapReady||!InEquipmentRoom()||g_visualBackroom)return;
        auto* option=reinterpret_cast<Word*(__cdecl*)(unsigned)>(0x652AD0u)(0x58u);
        if(!option)return;
        reinterpret_cast<Word*(__thiscall*)(Word*,Word,Word,Word)>(0x51FF80u)(option,0xC6A1A6E0u,0x00D5F627u,0);
        if(!g_backroomCarSwapOptionTable[0]) {
            std::memcpy(g_backroomCarSwapOptionTable.data(),reinterpret_cast<void*>(0x89C430u),sizeof(Word)*2u);
            g_backroomCarSwapOptionTable[1]=static_cast<Word>(reinterpret_cast<std::uintptr_t>(&BackroomChangeCar));
        }

        option[19]=0;option[20]=0;option[21]=1;
        *option=static_cast<Word>(reinterpret_cast<std::uintptr_t>(g_backroomCarSwapOptionTable.data()));
        reinterpret_cast<Word*(__thiscall*)(Word*,Word*)>(0x573960u)(screen,option);
    }
    void __fastcall EquipmentMainBuildOptions(Word* screen,void*)
    {
        reinterpret_cast<SetupFn>(0x7BCDB0u)(screen);
        AddBackroomCarSwap(screen);
    }
    void __fastcall EquipmentMainSetup(Word* screen,void*)
    {
        TrackScreen(g_equipmentMain,screen);
        if(g_backroomCarSwapPending) {
            const Word db=*reinterpret_cast<Word*>(0x91CF90u);
            if(db&&CareerScope(false)) {
                *reinterpret_cast<Word*>(db+0x12Cu)=g_backroomCarSwapMode;
                reinterpret_cast<void(__cdecl*)(bool)>(0x575B10u)(true);
                g_visualBackroom=false;g_activeParts={};g_activeDealer={};g_entries.clear();
                g_backroomCarSwapPending=false;
                NFSMWAP::Log("AP BACKROOM: owned-car selector returned; rebuilding equipment for the current car.");
            }
        }
        if(g_visualBackroom) {


            const bool career=CareerScope(false);
            g_visualBackroom=false;g_activeParts={};
            if(career)reinterpret_cast<void(__cdecl*)(bool)>(0x575B10u)(true);
        }
        reinterpret_cast<SetupFn>(0x7BFFF0u)(screen);
    }

    bool RebindBackroomCareerCarNative()
    {
        __try {
            const Word db=*reinterpret_cast<Word*>(0x91CF90u);
            const Word profile=db?*reinterpret_cast<Word*>(db+0x10u):0;
            if(!profile)return false;
            const Word handle=*reinterpret_cast<Word*>(profile+0xA8u);
            auto* record=reinterpret_cast<Word*(__thiscall*)(void*,Word)>(0x56ECC0u)
                (reinterpret_cast<void*>(profile+0x414u),handle);
            if(!record||record[0]!=handle||!(record[3]&2u))return false;


            reinterpret_cast<void(__thiscall*)(Word*)>(0x7AEB10u)(reinterpret_cast<Word*>(0x9B9EC0u));
            *reinterpret_cast<Word*>(0x91D3D4u)=static_cast<Word>(reinterpret_cast<std::uintptr_t>(record));
            return true;
        } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }

    bool RebindBackroomCareerCar()
    {
        if(!RebindBackroomCareerCarNative())return false;
        g_activeParts={};g_activeDealer={};g_entries.clear();
        return true;
    }

    void __fastcall BackroomCarSelectExit(Word* feng,void*,const char* package,int argument,Word control,bool suppressPause)
    {
        if(g_backroomCarSwapPending && CareerScope(false) && package &&
           std::strcmp(package,"MainMenu_Sub.fng")==0) {
            if(!RebindBackroomCareerCar()) {
                NFSMWAP::Log("AP BACKROOM: selected Career car could not be validated; return held to protect customization.");
                return;
            }
            package="CustomizeMain.fng";argument=0;control=0;
            NFSMWAP::Log("AP BACKROOM: native car selection exit redirected to customization, not the safe house.");
        }
        reinterpret_cast<void(__thiscall*)(Word*,const char*,int,Word,bool)>(0x525940u)(feng,package,argument,control,suppressPause);
    }

    void __fastcall EquipmentVisualSwitch(Word* feng,void*,const char* package,int argument,Word control,bool suppressPause)
    {


        if(g_visualBackroomReady && CareerScope(false) && InEquipmentRoom() &&
           NFSMWAP::BackroomVisualRoot(static_cast<Word>(argument)) && SameLiveScreen(g_equipmentMain)) {
            reinterpret_cast<void(__cdecl*)(bool)>(0x575B10u)(false);
            g_visualBackroom=true;g_activeParts={};


            reinterpret_cast<SetupFn>(0x7A65C0u)(g_equipmentMain.object);
            package="CustomizeCategory.fng";
            NFSMWAP::Log("AP BACKROOM VISUALS: native cosmetic customization opened; cash checkout, no AP check.");
        }
        reinterpret_cast<void(__thiscall*)(Word*,const char*,int,Word,bool)>(0x525940u)(feng,package,argument,control,suppressPause);
    }

    void __fastcall EquipmentMainNotify(Word* screen,void*,Word message,Word* object,Word p1,Word p2)
    {
        TrackScreen(g_equipmentMain,screen);
        if (CareerScope(false) && message==0xC519BFC4u) {
            if (InEquipmentRoom() || CanOpenEquipmentRoom())
                reinterpret_cast<SetupFn>(0x7BFC50u)(screen);
            else NFSMWAP::QueueNotification("ARCHIPELAGO BACKROOM","CUSTOMIZATION IS NOT AVAILABLE FOR THIS CAR","SELECT ANOTHER RECEIVED CAR",3500);
            return;
        }
        reinterpret_cast<NotifyFn>(0x7BFD30u)(screen,message,object,p1,p2);
    }

    bool __fastcall EquipmentCategoryLocked(Word* manager,void*,Word category,bool backroom)
    {
        if (InEquipmentRoom())
            return !(NFSMWAP::EquipmentCategoryAllowed(category) ||
                (g_visualBackroomReady&&NFSMWAP::BackroomVisualRoot(category)));
        if (CareerScope(false)) return false;
        return reinterpret_cast<bool(__thiscall*)(Word*,Word,bool)>(0x7BAD10u)(manager,category,backroom);
    }

    bool __fastcall CareerPartLocked(Word* manager,void*,Word* part,int level) {

        if (CareerScope(false)) return false;
        return reinterpret_cast<bool(__thiscall*)(Word*,Word*,int)>(0x7A4E50u)(manager,part,level);
    }
    bool __fastcall CareerRimCategoryLocked(Word* manager,void*,Word category,bool backroom) {
        if (CareerScope(false) && !InEquipmentRoom()) return false;
        return reinterpret_cast<bool(__thiscall*)(Word*,Word,bool)>(0x7B60E0u)(manager,category,backroom);
    }

    bool InstallHooks()
    {

        static const unsigned char create[] = {0xE8,0,0,0,0,0x83,0xC4,0,0x8B,0xF0,0xA1,0,0,0,0,0x57};
        static const unsigned char load[] = {0xE8,0,0,0,0,0x6A,0,0xE8,0,0,0,0,0x83,0xC4,0,0x85,0xC0,0x74,0,0x8B,0x0D};
        static const unsigned char service[] = {0xE8,0,0,0,0,0xA1,0,0,0,0,0x85,0xC0,0x75,0,0xA1,0,0,0,0,0x85,0xC0,0x8B,0xD0};
        g_createResource = reinterpret_cast<CreateResourceFn>(FindPattern(create,"x????xx?xxx????x",true));
        g_loadResource = reinterpret_cast<LoadResourceFn>(FindPattern(load,"x????x?x????xx?xxx?xx",true));
        g_serviceResource = reinterpret_cast<ServiceResourceFn>(FindPattern(service,"x????x????xxx?x????xxxx",true));
        g_resourceReady = GameFunction(reinterpret_cast<void*>(g_createResource)) && GameFunction(reinterpret_cast<void*>(g_loadResource)) &&
            GameFunction(reinterpret_cast<void*>(g_serviceResource));
        if (!g_resourceReady)
            NFSMWAP::Log("AP NATIVE SHOP: TPK loader unavailable; dealership hooks remain independent. Parts icons cannot activate.");

        for (auto& hook : g_screens)
        {
            hook.notify = *reinterpret_cast<NotifyFn*>(hook.table+4);
            hook.refresh = *reinterpret_cast<SetupFn*>(hook.table+12);
            hook.setup = *reinterpret_cast<SetupFn*>(hook.table+16);
            if (!GameFunction(reinterpret_cast<void*>(hook.notify)) || !GameFunction(reinterpret_cast<void*>(hook.refresh)) ||
                !GameFunction(reinterpret_cast<void*>(hook.setup)))
            { NFSMWAP::Log("AP NATIVE SHOP: invalid customization vtable " + std::to_string(hook.table)); return false; }
        }
        Word mainTable=0;
        for (Word p=0x8B6000u;p<0x8B9000u;p+=4u)
            if (*reinterpret_cast<Word*>(p+4u)==0x7BFD30u && *reinterpret_cast<Word*>(p+12u)==0x7B1210u &&
                *reinterpret_cast<Word*>(p+16u)==0x7BFFF0u) {
                if (mainTable) {NFSMWAP::Log("AP BACKROOM: ambiguous CustomizeMain table; no patches applied.");return false;}
                mainTable=p;
            }
        if (!mainTable) {NFSMWAP::Log("AP BACKROOM: CustomizeMain table not validated; no patches applied.");return false;}

        struct CallPatch { std::uintptr_t site, original, replacement; };
        std::vector<CallPatch> calls;
        std::size_t addCalls=0, dealerCalls=0,paintAddCalls=0,paintPositionCalls=0,visualSwitchCalls=0,mainSetupCalls=0,backroomBuildCalls=0,carSelectExitCalls=0;
        std::array<std::size_t,5> setupCounts{};
        for (auto p=0x7A0000u; p+5<0x7C4000u; ++p)
        {
            if (*reinterpret_cast<unsigned char*>(p)!=0xE8u) continue;
            const auto target=p+5+*reinterpret_cast<std::int32_t*>(p+1);
            std::uintptr_t replacement=0;
            if (target==0x7B1210u) replacement=reinterpret_cast<std::uintptr_t>(&EquipmentMainRefresh);
            else if (target==0x7BCDB0u && (p==0x7BFCECu || p==0x7C0055u))
                {replacement=reinterpret_cast<std::uintptr_t>(&EquipmentMainBuildOptions);++backroomBuildCalls;}
            else if (target==0x7BFFF0u) {replacement=reinterpret_cast<std::uintptr_t>(&EquipmentMainSetup);++mainSetupCalls;}
            else if (target==0x525940u && p>=0x7C1770u && p<0x7C2777u)
                {replacement=reinterpret_cast<std::uintptr_t>(&BackroomCarSelectExit);++carSelectExitCalls;}
            else if (target==0x525940u && p>=0x7AA020u && p+5u<=0x7AA044u)
                {replacement=reinterpret_cast<std::uintptr_t>(&EquipmentVisualSwitch);++visualSwitchCalls;}
            else if (target==0x7BFD30u) replacement=reinterpret_cast<std::uintptr_t>(&EquipmentMainNotify);
            else if (target==0x7BAD10u) replacement=reinterpret_cast<std::uintptr_t>(&EquipmentCategoryLocked);
            else if (target==0x7A4E50u) replacement=reinterpret_cast<std::uintptr_t>(&CareerPartLocked);
            else if (target==0x7B60E0u) replacement=reinterpret_cast<std::uintptr_t>(&CareerRimCategoryLocked);
            else if (target==0x58A9F0u) replacement=reinterpret_cast<std::uintptr_t>(&CareerCarUnlocked);
            else if (target==0x7B1740u)
            { replacement=reinterpret_cast<std::uintptr_t>(&AddPartHook); ++addCalls; }
            else if (target==0x59BD30u)
            { replacement=reinterpret_cast<std::uintptr_t>(&AddPaintDatumHook); ++paintAddCalls; }
            else if (target==0x593560u)
            { replacement=reinterpret_cast<std::uintptr_t>(&ArrayPositionHook); ++paintPositionCalls; }
            else if (target==0x7ADA50u)
            { replacement=reinterpret_cast<std::uintptr_t>(&CarSelectRefreshHook); ++dealerCalls; }
            else for (std::size_t i=0;i<g_screens.size();++i)
            {
                if (target==reinterpret_cast<std::uintptr_t>(g_screens[i].setup))
                { replacement=reinterpret_cast<std::uintptr_t>(g_setupCalls[i]); ++setupCounts[i]; break; }
                if (target==reinterpret_cast<std::uintptr_t>(g_screens[i].refresh))
                { replacement=reinterpret_cast<std::uintptr_t>(g_refreshCalls[i]); break; }
            }
            if (replacement) calls.push_back({p,target,replacement});
        }
        if (!addCalls || !dealerCalls || std::find(setupCounts.begin(),setupCounts.end(),std::size_t{0})!=setupCounts.end())
        {

            for (std::size_t i=0;i<g_screens.size();++i)
                setupCounts[i]=static_cast<std::size_t>(std::count_if(calls.begin(),calls.end(),[i](const CallPatch& c)
                    { return c.original==reinterpret_cast<std::uintptr_t>(g_screens[i].setup); }));
            if (!addCalls || !dealerCalls || std::find(setupCounts.begin(),setupCounts.end(),std::size_t{0})!=setupCounts.end())
            { NFSMWAP::Log("AP NATIVE SHOP: required direct setup/refresh calls missing; no patches applied."); return false; }
        }
        if (!paintAddCalls || !paintPositionCalls)
        { NFSMWAP::Log("AP NATIVE SHOP: required paint list calls missing; no patches applied.");return false; }
        const bool visualValidated=visualSwitchCalls==1 && mainSetupCalls>0 &&
            GameFunction(reinterpret_cast<void*>(0x7A65C0u)) && GameFunction(reinterpret_cast<void*>(0x575B10u));
        if(!visualValidated) {

            calls.erase(std::remove_if(calls.begin(),calls.end(),[](const CallPatch& p){
                return p.replacement==reinterpret_cast<std::uintptr_t>(&EquipmentVisualSwitch);
            }),calls.end());
            NFSMWAP::Log("AP BACKROOM VISUALS: native entry validation failed; performance equipment and shops retained.");
        }
#if defined(_M_IX86)
        std::size_t priceCalls = 0;
        for (auto p=0x7B13C0u;p+5<0x7B1740u;++p)
        {
            if (*reinterpret_cast<unsigned char*>(p)!=0xE8u) continue;
            const auto target=p+5+*reinterpret_cast<std::int32_t*>(p+1);
            if (target==g_nativeObjectPrintf)
            { calls.push_back({p,target,reinterpret_cast<std::uintptr_t>(&NativeObjectPriceHook)}); ++priceCalls; }
            if (target==g_nativePackagePrintf)
            { calls.push_back({p,target,reinterpret_cast<std::uintptr_t>(&NativePackagePriceHook)}); ++priceCalls; }
        }
        g_priceReady=priceCalls!=0;
        if (!g_priceReady)
            NFSMWAP::Log("AP NATIVE SHOP: currency callsite missing; parts remain unavailable, dealership is independent.");
#endif

        struct Patch { Word address; void* before; void* after; };
        std::vector<Patch> patches;
        for (auto& hook : g_screens)
        {
            patches.push_back({hook.table+4,reinterpret_cast<void*>(hook.notify),reinterpret_cast<void*>(&NotifyHook)});
            patches.push_back({hook.table+12,reinterpret_cast<void*>(hook.refresh),reinterpret_cast<void*>(&RefreshHook)});
            patches.push_back({hook.table+16,reinterpret_cast<void*>(hook.setup),reinterpret_cast<void*>(&SetupHook)});
        }
        patches.push_back({mainTable+4u,reinterpret_cast<void*>(0x7BFD30u),reinterpret_cast<void*>(&EquipmentMainNotify)});
        patches.push_back({mainTable+12u,reinterpret_cast<void*>(0x7B1210u),reinterpret_cast<void*>(&EquipmentMainRefresh)});
        patches.push_back({mainTable+16u,reinterpret_cast<void*>(0x7BFFF0u),reinterpret_cast<void*>(&EquipmentMainSetup)});
        std::size_t written=0;
        for (const auto& patch : patches)
        {
            if (!PatchPointer(patch.address,patch.before,patch.after)) break;
            ++written;
        }
        std::size_t callWrites=0;
        if (written==patches.size())
            for (const auto& patch : calls)
            {
                const auto call = patch.site;
                DWORD old=0, ignored=0;
                if (!VirtualProtect(reinterpret_cast<void*>(call),5,PAGE_EXECUTE_READWRITE,&old)) break;
                *reinterpret_cast<std::int32_t*>(call+1)=static_cast<std::int32_t>(patch.replacement-call-5);
                VirtualProtect(reinterpret_cast<void*>(call),5,old,&ignored);
                FlushInstructionCache(GetCurrentProcess(),reinterpret_cast<void*>(call),5);
                ++callWrites;
            }
        if (written!=patches.size() || callWrites!=calls.size())
        {
            for (std::size_t i=0;i<callWrites;++i)
            {
                DWORD old=0,ignored=0; const auto call=calls[i].site;
                if (VirtualProtect(reinterpret_cast<void*>(call),5,PAGE_EXECUTE_READWRITE,&old))
                {
                    *reinterpret_cast<std::int32_t*>(call+1)=static_cast<std::int32_t>(calls[i].original-call-5);
                    VirtualProtect(reinterpret_cast<void*>(call),5,old,&ignored);
                    FlushInstructionCache(GetCurrentProcess(),reinterpret_cast<void*>(call),5);
                }
            }
            for (std::size_t i=written;i>0;--i) PatchPointer(patches[i-1].address,patches[i-1].after,patches[i-1].before);
            return false;
        }
        g_backroomCarSwapReady=backroomBuildCalls==2 && carSelectExitCalls>0 && VerifyBackroomCarSwap();
        if(g_backroomCarSwapReady)NFSMWAP::Log("NFSMW_AP_BACKROOM_CAR_SWAP_V4: native owned-car option and backroom return enabled.");
        g_visualBackroomReady=visualValidated;
        if(g_visualBackroomReady)NFSMWAP::Log("NFSMW_AP_BACKROOM_VISUALS_V1: native Parts/Visual customization and cash checkout; received performance equipment retained.");
        NFSMWAP::Log("AP NATIVE SHOP: installed direct calls=" + std::to_string(calls.size()) +
            " dealer_tables=" + std::to_string(g_dealers.size()) + " dealer_refresh_calls=" + std::to_string(dealerCalls));
        return true;
    }

    std::size_t ReadShowroomCars(Word* result, std::size_t capacity)
    {
        __try
        {
            const Word head=0x9B27ECu;
            Word node=*reinterpret_cast<Word*>(head);
            std::size_t count=0;
            while (node && node!=head && count<capacity)
            {
                const Word next=*reinterpret_cast<Word*>(node);
                const Word prev=*reinterpret_cast<Word*>(node+4);
                if (!next || !prev || *reinterpret_cast<Word*>(next+4)!=node || *reinterpret_cast<Word*>(prev)!=node) return 0;
                const int visible=*reinterpret_cast<int*>(node+0x574u);
                const int view=*reinterpret_cast<int*>(node+0x31Cu);
                if (visible<0 || visible>1 || view<0 || view>32) return 0;
                result[count++]=node;
                node=next;
            }
            return node==head ? count : 0;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return 0; }
    }

    bool SetCarVisible(Word node, int value, Word* rideKey)
    {
        __try
        {
            if (rideKey) *rideKey=*reinterpret_cast<Word*>(node+8u);
            *reinterpret_cast<int*>(node+0x574u)=value;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    void UpdateShowroom(bool active)
    {
        static DWORD activeSince=0;
        static bool failureLogged=false;
        if(!active && g_hidden.empty()){g_showModel=false;activeSince=0;failureLogged=false;return;}
        Word cars[16]={};
        const auto count=ReadShowroomCars(cars,16);

        for (auto& hidden : g_hidden)
            for (std::size_t i=0;i<count;++i)
                if (cars[i]==hidden.address && *reinterpret_cast<Word*>(cars[i]+8u)==hidden.rideKey)
                    SetCarVisible(cars[i],hidden.visible,nullptr);
        g_hidden.clear();
        g_showModel=false;
        if (!active) { activeSince=0;failureLogged=false;return; }
        if (!activeSince) activeSince=GetTickCount();
        for (std::size_t i=0;i<count;++i)
        {
            HiddenCar car{cars[i],0,*reinterpret_cast<int*>(cars[i]+0x574u)};
            if (SetCarVisible(cars[i],0,&car.rideKey)) g_hidden.push_back(car);
        }
        g_showModel=!g_hidden.empty();
        if (!g_showModel && !failureLogged && GetTickCount()-activeSince>2000u)
        { failureLogged=true; NFSMWAP::Log("AP NATIVE SHOP: dealership active but no validated showroom cars; carrier visibility unresolved."); }
    }
}

namespace NFSMWAP
{
    bool WriteNativeRewardText(const char* package,std::uint32_t hash,const std::string& text)
    {
        Word* strings[64]={};bool written=false;
        const auto count=CollectNativeStrings(reinterpret_cast<FindFn>(0x524850u)(package,hash),strings,64);
        const auto wide=NativeShopWideText(text);
        for (int n=0;n<count;++n) {
            auto* value=strings[n];
            if (RewardLiteralMatches(value,wide.c_str()) &&
                (value[FEStringFormatOffset/4u]&FEStringWordWrap)) {written=true;continue;}


            if (SetObjectString(value,text,false)) {
                auto& flags=value[offsetof(NativeFEObjectPrefix,flags)/4u];
                flags=(flags&~0x20u)|FERewardLiteral;
                FormatRewardTitle(value,wide);written=true;
            }
        }
        return written;
    }
    bool NativeShopsEnabled() { return g_ready; }

    bool RequestNativeModelResource(const std::string& path)
    {
        if(!g_resourceReady || GetFileAttributesA(path.c_str())==INVALID_FILE_ATTRIBUTES)return false;
        void* resource=g_createResource(path.c_str(),0,0,0,0);
        if(!resource)return false;
        g_loadResource(resource,nullptr,nullptr,nullptr);
        return true;
    }
    void ServiceNativeModelResources()
    {
        if(g_resourceReady)g_serviceResource();
    }


    void NativeShopMainThreadTick()
    {
        StorePurchaseMainThreadTick();
        if (!NativeShopRequested()) return;
        ClearStoreOverlay();
        if (!g_initialized && *reinterpret_cast<int*>(0x925E90u)==3)
        {
            g_initialized=true;
            if (!InstallNativeRewardHooks()) Log("AP REWARD UI: native hook validation failed; original race/milestone fields retained.");
            g_ready=InstallHooks();
            Log(g_ready ? "AP NATIVE SHOP 1.0.0: frontend hooks installed." : "AP NATIVE SHOP 1.0.0: frontend validation failed; merchandise overlay disabled.");
            if (g_ready) Log("NFSMW_AP_DEALERSHIP_START_V17: native banner height fit, proportional fonts, controller rows and unique menu checks enabled.");
            if (!g_ready) QueueNotification("ARCHIPELAGO SHOP", "NATIVE HOOK VALIDATION FAILED", "SEND NFSMWArchipelago.log", 7000);
        }
        if (!g_ready) return;
        const int flow=*reinterpret_cast<int*>(0x925E90u);
        if(!CareerScope(false)) {g_visualBackroom=false;g_equipmentMain={};}
        if (flow==0 || flow>=4)
        { g_activeParts={};g_activeDealer={}; }
        if(flow>=4) {
            if(!g_hidden.empty() || g_showModel)UpdateShowroom(false);
            return;
        }
        if (g_activeDealer.object && SameLiveScreen(g_activeDealer) && CompleteReceivedCareerStart(g_activeDealer.object)) return;
        RefreshActiveCash();


        static DWORD nextUiPass=0;
        static Word* lastDealer=nullptr;
        static Word* lastParts=nullptr;
        const DWORD now=GetTickCount();
        const bool screenChanged=g_activeDealer.object!=lastDealer || g_activeParts.object!=lastParts;
        if (screenChanged || !nextUiPass || static_cast<std::int32_t>(now-nextUiPass)>=0) {
            lastDealer=g_activeDealer.object;
            lastParts=g_activeParts.object;
            nextUiPass=now+50u;
            RefreshActiveLabels();
            UpdateShowroom(g_activeDealer.object && SameLiveScreen(g_activeDealer) &&
                           (g_activeDealer.object[107]&1u) && CareerScope(true));
        }
        if (!g_resourceReady) return;
        if (!g_textureRequested)
        {
            const std::string path=GetGameDirectory()+"\\scripts\\NFSMWArchipelago.tpk";
            if (GetFileAttributesA(path.c_str())==INVALID_FILE_ATTRIBUTES)
            {
                static bool logged=false;
                if (!logged)
                {
                    logged=true;
                    Log("AP NATIVE SHOP: MISSING TPK: " + path);
                    QueueNotification("ARCHIPELAGO SHOP", "NATIVE TEXTURE PACK MISSING", "COPY NFSMWArchipelago.tpk TO scripts", 7000);
                }
                return;
            }
            void* resource=g_createResource(path.c_str(),0,0,0,0);
            if (!resource) return;
            g_loadResource(resource,nullptr,nullptr,nullptr);
            g_textureRequested=true;
            Log("AP NATIVE SHOP: TPK requested: " + path);
        }


        static DWORD nextTextureCheck=0;
        const DWORD textureNow=GetTickCount();
        if(!g_textureReady || !nextTextureCheck ||
           static_cast<std::int32_t>(textureNow-nextTextureCheck)>=0) {
            nextTextureCheck=textureNow+250u;
            if (!g_textureReady) g_serviceResource();
            g_textureReady=reinterpret_cast<GetTextureFn>(0x503400u)(Hash("AP_SHOP_LOGO"),0,0)!=nullptr;
        }
        const bool parts=g_textureReady && g_priceReady;
        const bool previouslyReady=g_partsReady.exchange(parts);
        if (parts && !previouslyReady) Log("AP NATIVE SHOP: AP_SHOP_LOGO ready; native controller parts menus active.");
        if (!g_textureReady)
        {
            static DWORD firstRequest=GetTickCount();
            static bool logged=false;
            if (!logged && GetTickCount()-firstRequest>5000u)
            { logged=true; Log("AP NATIVE SHOP: TPK loaded request but AP_SHOP_LOGO not found. Parts remain blocked."); }
        }
    }

    void DrawNativeShopModel(IDirect3DDevice9* device)
    {
        if (!g_showModel || !g_ready || !CareerScope(true)) return;
        D3DVIEWPORT9 viewport{};
        if (FAILED(device->GetViewport(&viewport))) return;
        IDirect3DStateBlock9* state=nullptr;
        if (FAILED(device->CreateStateBlock(D3DSBT_ALL,&state)) || !state) return;
        if (FAILED(state->Capture())) { state->Release();return; }
        IDirect3DSurface9* depth=nullptr;
        device->GetDepthStencilSurface(&depth);

        IDirect3DSurface9* logoDepth=nullptr;
        IDirect3DSurface9* target=nullptr;
        D3DSURFACE_DESC targetInfo{};
        if (SUCCEEDED(device->GetRenderTarget(0,&target)) && target)
        { target->GetDesc(&targetInfo); target->Release(); }
        HRESULT hr=device->CreateDepthStencilSurface(targetInfo.Width ? targetInfo.Width : viewport.Width,
            targetInfo.Height ? targetInfo.Height : viewport.Height,D3DFMT_D16,
            targetInfo.MultiSampleType,targetInfo.MultiSampleQuality,TRUE,&logoDepth,nullptr);
        if (FAILED(hr) || !logoDepth) { if(depth)depth->Release();state->Release();return; }
        if (FAILED(device->SetDepthStencilSurface(logoDepth)))
        { if(depth)depth->Release();logoDepth->Release();state->Release();return; }
        device->Clear(0,nullptr,D3DCLEAR_ZBUFFER,0,1.0f,0);
        const float angle=static_cast<float>(GetTickCount()%30000u)*0.00020943951f;
        const float c=std::cos(angle), s=std::sin(angle);
        D3DMATRIX world{}; world._11=c;world._13=s;world._22=1;world._31=-s;world._33=c;world._44=1;
        D3DMATRIX view{};view._11=view._22=view._33=view._44=1;view._43=3.8f;
        const float aspect=static_cast<float>(viewport.Width)/static_cast<float>(viewport.Height);
        D3DMATRIX projection{};projection._11=2.4f/aspect;projection._22=2.4f;projection._33=100.0f/99.9f;projection._34=1;projection._43=-.1f*100.0f/99.9f;
        device->SetTransform(D3DTS_WORLD,&world);device->SetTransform(D3DTS_VIEW,&view);device->SetTransform(D3DTS_PROJECTION,&projection);
        device->SetVertexShader(nullptr);device->SetPixelShader(nullptr);device->SetTexture(0,nullptr);
        device->SetFVF(D3DFVF_XYZ|D3DFVF_NORMAL);
        device->SetRenderState(D3DRS_ZENABLE,TRUE);device->SetRenderState(D3DRS_ZWRITEENABLE,TRUE);
        device->SetRenderState(D3DRS_ZFUNC,D3DCMP_LESSEQUAL);device->SetRenderState(D3DRS_STENCILENABLE,FALSE);
        device->SetRenderState(D3DRS_FILLMODE,D3DFILL_SOLID);device->SetRenderState(D3DRS_CLIPPLANEENABLE,0);
        device->SetRenderState(D3DRS_VERTEXBLEND,D3DVBF_DISABLE);device->SetRenderState(D3DRS_INDEXEDVERTEXBLENDENABLE,FALSE);
        device->SetRenderState(D3DRS_CULLMODE,D3DCULL_NONE);device->SetRenderState(D3DRS_ALPHABLENDENABLE,FALSE);
        device->SetRenderState(D3DRS_ALPHATESTENABLE,FALSE);device->SetRenderState(D3DRS_FOGENABLE,FALSE);
        device->SetRenderState(D3DRS_SCISSORTESTENABLE,FALSE);device->SetRenderState(D3DRS_LIGHTING,TRUE);
        device->SetRenderState(D3DRS_AMBIENT,D3DCOLOR_XRGB(70,70,70));device->SetRenderState(D3DRS_NORMALIZENORMALS,TRUE);
        device->SetRenderState(D3DRS_COLORVERTEX,FALSE);device->SetRenderState(D3DRS_SPECULARENABLE,TRUE);
        device->SetRenderState(D3DRS_COLORWRITEENABLE,15);
        D3DMATERIAL9 material{};material.Diffuse={.19f,.42f,.52f,1};material.Ambient=material.Diffuse;material.Specular={.8f,.85f,.9f,1};material.Power=32;
        device->SetMaterial(&material);
        D3DLIGHT9 light{};light.Type=D3DLIGHT_DIRECTIONAL;light.Diffuse={1,1,.95f,1};light.Specular={1,1,1,1};light.Direction={.3f,-.5f,1};
        device->SetLight(0,&light);device->LightEnable(0,TRUE);
        for (DWORD i=1;i<8;++i) device->LightEnable(i,FALSE);
        device->SetTextureStageState(0,D3DTSS_COLOROP,D3DTOP_SELECTARG1);device->SetTextureStageState(0,D3DTSS_COLORARG1,D3DTA_DIFFUSE);
        device->SetTextureStageState(1,D3DTSS_COLOROP,D3DTOP_DISABLE);
        device->DrawPrimitiveUP(D3DPT_TRIANGLELIST,static_cast<UINT>(std::size(APLogoMesh)/3),APLogoMesh,sizeof(APLogoVertex));
        device->SetDepthStencilSurface(depth);
        if (depth) depth->Release();
        logoDepth->Release();
        state->Apply();
        state->Release();
    }
}
