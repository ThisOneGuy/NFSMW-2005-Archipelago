#include "SeedConfig.h"
#include "BountyRequirements.h"

#include <array>
#include <mutex>

namespace
{
    std::mutex g_mutex;
    std::string g_startingCar;
    bool g_configReceived=false, g_dealershipFirst=false;
    int g_startingCarPrice = 5000;
    std::array<std::string, 16> g_blacklistCars{};
    bool g_randomizeOpponentCars = false;
    int g_opponentSeed = 0;
    bool g_blacklistAppearance=false;
    int g_blacklistAppearanceSeed=0;
}

namespace NFSMWAP
{
    void ResetSeedConfig()
    {
        ConfigureBountyRequirements("original",100);
        std::lock_guard<std::mutex> lock(g_mutex);
        g_startingCar.clear();g_configReceived=false;g_dealershipFirst=false;
        g_startingCarPrice = 5000;

        for (auto& car : g_blacklistCars)
            car.clear();

        g_randomizeOpponentCars = false;
        g_opponentSeed = 0;
        g_blacklistAppearance=false;g_blacklistAppearanceSeed=0;
    }

    void SetDealershipFirstStart(bool enabled)
    {
        std::lock_guard<std::mutex> lock(g_mutex);g_dealershipFirst=enabled;
    }
    bool IsDealershipFirstStart()
    {
        std::lock_guard<std::mutex> lock(g_mutex);return g_dealershipFirst;
    }

    void SetSeedStartingCar(const std::string& car)
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        g_startingCar = car;g_configReceived=true;
    }

    void SetSeedStartingCarPrice(int price)
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        g_startingCarPrice = price < 0 ? 0 : price;
    }

    void SetSeedOpponentCarConfig(bool randomize, int seed)
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        g_randomizeOpponentCars = randomize;
        g_opponentSeed = seed;
    }

    void SetSeedBlacklistCar(int rank, const std::string& car)
    {
        if (rank < 1 || rank > 15)
            return;

        std::lock_guard<std::mutex> lock(g_mutex);
        g_blacklistCars[static_cast<std::size_t>(rank)] = car;
    }
    void SetSeedBlacklistAppearanceConfig(bool enabled,int seed)
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        g_blacklistAppearance=enabled;g_blacklistAppearanceSeed=seed;
    }
    bool GetSeedRandomizeBlacklistAppearance()
    {
        std::lock_guard<std::mutex> lock(g_mutex);return g_blacklistAppearance;
    }
    int GetSeedBlacklistAppearanceSeed()
    {
        std::lock_guard<std::mutex> lock(g_mutex);return g_blacklistAppearanceSeed;
    }

    std::string GetSeedStartingCar()
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        return g_startingCar;
    }

    int GetSeedStartingCarPrice()
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        return g_startingCarPrice;
    }

    std::string GetSeedBlacklistCar(int rank)
    {
        if (rank < 1 || rank > 15)
            return {};

        std::lock_guard<std::mutex> lock(g_mutex);
        return g_blacklistCars[static_cast<std::size_t>(rank)];
    }

    bool GetSeedRandomizeOpponentCars()
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        return g_randomizeOpponentCars;
    }

    int GetSeedOpponentCarSeed()
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        return g_opponentSeed;
    }

    bool IsSeedConfigReady()
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        return g_configReceived;
    }
}
