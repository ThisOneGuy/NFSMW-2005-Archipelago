#pragma once
#include <cmath>
namespace NFSMWAP {


class RaceFinishGate {
    bool running=false;
public:
    void Reset(){running=false;}
    bool Observe(bool career,bool finished,int ranking,float progress,bool mayArm=true) {
        if(!career){Reset();return false;}
        if(!finished) {
            if(mayArm&&ranking>0&&ranking<=128&&std::isfinite(progress)&&progress>=0&&progress<100)running=true;
            return false;
        }
        const bool earned=running&&ranking>0&&ranking<=128;
        running=false;return earned;
    }
};
}
