#pragma once
#include <cstdint>
#include <limits>
#include <string>

namespace NFSMWAP
{
    enum class BountyMode { Original, Multiplied, Removed };
    inline std::int32_t BountyRequirement(std::int32_t original,BountyMode mode,unsigned percent)
    {
        if(original<=0 || mode==BountyMode::Original)return original;
        if(mode==BountyMode::Removed)return 0;
        if(percent<1u || percent>10000u)percent=100u;
        const auto value=(static_cast<std::uint64_t>(original)*percent+99u)/100u;
        return value>static_cast<std::uint64_t>(std::numeric_limits<std::int32_t>::max()) ?
            std::numeric_limits<std::int32_t>::max() : static_cast<std::int32_t>(value);
    }
    void ConfigureBountyRequirements(const std::string& mode,int percent);
    void BountyRequirementsMainThreadTick();
}
