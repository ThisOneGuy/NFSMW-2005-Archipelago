#include "BountyRequirements.h"
#include "CareerBootstrap.h"
#include "SeedConfig.h"
#include "Logger.h"
#include <Windows.h>
#include <algorithm>
#include <mutex>
#include <vector>

namespace
{
    using Word=std::uint32_t;
    constexpr Word RequiredBountyKey=0xD3657D92u,BinIndexKey=0x6CE23062u;
    struct Settings { NFSMWAP::BountyMode mode=NFSMWAP::BountyMode::Original;unsigned percent=100; };
    struct Field { Word key=0;int bin=-1;std::int32_t* address=nullptr;std::int32_t value=0; };
    struct Record { Field field;std::int32_t original=0,applied=0;bool seen=false; };
    Settings settings;
    std::mutex settingsMutex;
    std::vector<Record> records;
    void* trackedClass=nullptr;
    DWORD lastTick=0;

    bool ReadClass(void*& klass,unsigned& count,Word& first)
    {
        __try {
            void* database=*reinterpret_cast<void**>(0x90DCBCu);
            if(!database)return false;
            const auto key=reinterpret_cast<Word(__cdecl*)(const char*)>(0x454640u)("gameplay");
            klass=reinterpret_cast<void*(__thiscall*)(void*,Word)>(0x455BC0u)(database,key);
            if(!klass || *static_cast<Word*>(klass)!=key)return false;
            count=reinterpret_cast<unsigned(__thiscall*)(void*)>(0x453FC0u)(klass);
            if(count==0u || count>65536u)return false;
            first=reinterpret_cast<Word(__thiscall*)(void*)>(0x456B00u)(klass);
            return first!=0u;
        } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }

    bool ReadField(void* klass,Word key,Field& result,Word* next=nullptr)
    {
        __try {
            if(next)*next=reinterpret_cast<Word(__thiscall*)(void*,Word)>(0x456B20u)(klass,key);
            void* collection=reinterpret_cast<void*(__thiscall*)(void*,Word)>(0x455960u)(klass,key);
            if(!collection)return false;
            using GetData=std::int32_t*(__thiscall*)(void*,Word,int);
            auto* bin=reinterpret_cast<GetData>(0x454190u)(collection,BinIndexKey,0);
            auto* bounty=reinterpret_cast<GetData>(0x454190u)(collection,RequiredBountyKey,0);
            if(!bin || !bounty || *bin<0 || *bin>15 || *bounty<0)return false;
            result={key,*bin,bounty,*bounty};return true;
        } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }

    bool WriteField(const Field& field,std::int32_t value)
    {
        __try {
            if(*field.address!=field.value)return false;
            DWORD protection=0;
            if(!VirtualProtect(field.address,sizeof(value),PAGE_READWRITE,&protection))return false;
            *field.address=value;
            DWORD ignored=0;VirtualProtect(field.address,sizeof(value),protection,&ignored);
            return true;
        } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
    }

    void Restore(void* klass)
    {
        for(const auto& record:records) {
            Field field;
            if(ReadField(klass,record.field.key,field) && field.address==record.field.address &&
                field.bin==record.field.bin && field.value==record.applied)WriteField(field,record.original);
        }
        records.clear();
    }
}

namespace NFSMWAP
{
    void ConfigureBountyRequirements(const std::string& mode,int percent)
    {
        Settings next;
        if(mode=="multiplied")next.mode=BountyMode::Multiplied;
        else if(mode=="removed" || mode=="no_bounty_requirement")next.mode=BountyMode::Removed;
        if(percent>=1 && percent<=10000)next.percent=static_cast<unsigned>(percent);
        std::lock_guard<std::mutex> lock(settingsMutex);settings=next;
    }

    void BountyRequirementsMainThreadTick()
    {
        const auto now=GetTickCount();if(static_cast<DWORD>(now-lastTick)<250u)return;lastTick=now;
        Settings selected;
        {std::lock_guard<std::mutex> lock(settingsMutex);selected=settings;}
        if(!IsSeedConfigReady() || !IsCareerProfileReady())selected.mode=BountyMode::Original;
        if(selected.mode==BountyMode::Original && records.empty())return;
        void* klass=nullptr;unsigned count=0;Word key=0;
        if(!ReadClass(klass,count,key))return;
        if(klass!=trackedClass){records.clear();trackedClass=klass;}
        if(selected.mode==BountyMode::Original){Restore(klass);return;}
        for(auto& record:records)record.seen=false;
        const auto previous=records.size();
        for(unsigned n=0;n<count && key;++n) {
            Field field;Word next=0;
            if(ReadField(klass,key,field,&next)) {
                auto record=std::find_if(records.begin(),records.end(),[&](const Record& r){return r.field.key==key && r.field.address==field.address && r.field.bin==field.bin;});
                if(record!=records.end()) {
                    record->seen=true;
                    if(field.value!=record->applied)record->original=field.value;
                    const auto value=BountyRequirement(record->original,selected.mode,selected.percent);
                    if(value==field.value || WriteField(field,value))record->applied=value;
                } else if(field.value>0 && std::none_of(records.begin(),records.end(),[&](const Record& r){return r.field.address==field.address;})) {
                    const auto value=BountyRequirement(field.value,selected.mode,selected.percent);
                    if(value==field.value || WriteField(field,value))records.push_back({field,field.value,value,true});
                }
            }
            if(next==key)break;key=next;
        }
        records.erase(std::remove_if(records.begin(),records.end(),[](const Record& r){return !r.seen;}),records.end());
        if(records.size()!=previous)Log("NFSMW_AP_BOUNTY_REQUIREMENTS_V1: seed requirement settings applied to "+std::to_string(records.size())+" Blacklist data fields.");
    }
}
