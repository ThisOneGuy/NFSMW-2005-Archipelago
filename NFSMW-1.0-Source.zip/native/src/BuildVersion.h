#pragma once
#define NFSMW_AP_BUILD "1.0.0"
