#include "CareerBootstrap.h"
#include "BridgeClient.h"
#include "SaveIsolation.h"
#include "SeedConfig.h"
#include "StoreRuntime.h"
#include "NativeShop.h"
#include "Logger.h"
#include <Windows.h>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <system_error>
#include <algorithm>
#include <string>
#include <vector>

namespace {
using Word=std::uint32_t;
constexpr Word NativeOptionPressed=0x0C407210u;
bool routed=false,needsCar=false,savePending=false,prepared=false,saveRequested=false,saveAgain=false;
bool firstCarResumeRequested=false;
enum class LoadStage { Idle, Reading, Accepted, Ready, Failed };
std::atomic<LoadStage> loadStage{LoadStage::Idle};
std::atomic_bool profileReady{false};
char loadSlot[32]={};
DWORD loadStartedAt=0;
bool loadWaitLogged=false;
bool loadSlowLogged=false;
struct LoadMessagePolicy {
    Word card=0,backend=0,hidden=0,disabled=0;
    unsigned char manual=0;
    bool captured=false;
};
LoadMessagePolicy loadMessagePolicy;
bool progressRefreshSeen=false;
int progressFlow=-1;bool progressWorldPending=true;
Word progressProfile=0;unsigned progressRank=0;DWORD lastProgressRefresh=0;
bool freshAutoLoadSeen=false,startRequested=false,resumePending=false,startupFinished=false,waitLogged=false,saveWaitLogged=false;
bool pathDiagnosticLogged=false,nativeDirectoryBound=false,nativeDirectoryBindingLogged=false;
char callbackFile[260]={};
DWORD lastSaveTry=0;
Word* resumeScreen=nullptr;Word resumeTable=0;
std::atomic_bool hooksReady{false};


enum class SlotSaveRoute { HookedCardHandoff, VerifiedRetailAutoSave };
SlotSaveRoute slotSaveRoute=SlotSaveRoute::VerifiedRetailAutoSave;
enum class SaveStage { Idle, Preparing, Writing, Complete, Failed };
std::atomic<SaveStage> saveStage{SaveStage::Idle};
thread_local bool startingSave=false;
const char* SaveStageName() {
    switch(saveStage.load()) {
        case SaveStage::Preparing:return "native autosave setup";
        case SaveStage::Writing:return "serialization";
        case SaveStage::Complete:return "native callback complete";
        case SaveStage::Failed:return "failed";
        default:return "not requested";
    }
}
void __fastcall ResumeOptionReact(Word*,void*,const char*,Word,Word*,Word,Word);
struct State {Word db=0,profile=0;bool loaded=false,started=false,owned=false;unsigned rank=0;int flow=0;};
bool Scope() {
    char mode[8]={};
    return NFSMWAP::IsSaveIsolationActive()&&GetEnvironmentVariableA("NFSMW_AP_BOOTSTRAP",mode,sizeof(mode))&&std::strcmp(mode,"2")==0;
}
bool Launch(char (&slot)[32],bool& fresh) {
    char key[512]={},flag[8]={};
    const auto size=GetEnvironmentVariableA("NFSMW_AP_SLOT_NAME",slot,sizeof(slot));
    if(!size||size>=sizeof(slot)||!GetEnvironmentVariableA("NFSMW_AP_SESSION_KEY",key,sizeof(key)))return false;
    for(unsigned n=0;n<size;++n)if(static_cast<unsigned char>(slot[n])<32u||static_cast<unsigned char>(slot[n])>126u||std::strchr("<>:\"/\\|?*",slot[n]))return false;
    GetEnvironmentVariableA("NFSMW_AP_FRESH_START",flag,sizeof(flag));fresh=flag[0]=='1';return true;
}
bool Read(State& s) {
    __try {
        s.flow=*reinterpret_cast<int*>(0x925E90u);if(s.flow!=3&&s.flow!=6)return false;
        s.db=*reinterpret_cast<Word*>(0x91CF90u);if(!s.db)return false;
        s.profile=*reinterpret_cast<Word*>(s.db+0x10u);if(s.profile<0x10000u||(s.profile&3u))return false;
        s.loaded=*reinterpret_cast<unsigned char*>(s.db+3u)!=0;
        s.started=reinterpret_cast<bool(__thiscall*)(void*)>(0x50E310u)(reinterpret_cast<void*>(s.profile+0xA8u));
        s.rank=*reinterpret_cast<unsigned char*>(s.profile+0xB0u);
        const auto stable=reinterpret_cast<void*(__thiscall*)(void*,int)>(0x4061B0u)(reinterpret_cast<void*>(s.db),0);if(!stable)return false;
        s.owned=reinterpret_cast<int(__thiscall*)(void*)>(0x5810E0u)(stable)>0||reinterpret_cast<int(__thiscall*)(void*)>(0x5811A0u)(stable)>0;
        return !s.loaded||s.rank<=16;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool NameProfile(const State& s,const char* slot) {
    __try {
        if(std::strncmp(reinterpret_cast<const char*>(s.profile),slot,32)!=0||!*reinterpret_cast<unsigned char*>(s.profile+0x20u))
            reinterpret_cast<void(__thiscall*)(void*,const char*,bool)>(0x56DA30u)(reinterpret_cast<void*>(s.profile),slot,true);
        *reinterpret_cast<unsigned char*>(s.db+3u)=1;return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool InitializeWithoutGameplay(Word career) {
    unsigned char intro=0,dday=0;bool captured=false,ok=false;
    __try {
        intro=*reinterpret_cast<unsigned char*>(0x926125u);dday=*reinterpret_cast<unsigned char*>(0x926126u);captured=true;
        *reinterpret_cast<unsigned char*>(0x926125u)=0;*reinterpret_cast<unsigned char*>(0x926126u)=0;
        reinterpret_cast<void(__thiscall*)(void*,bool)>(0x5A3950u)(reinterpret_cast<void*>(career),false);ok=true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
    __try {if(captured){*reinterpret_cast<unsigned char*>(0x926125u)=intro;*reinterpret_cast<unsigned char*>(0x926126u)=dday;}}
    __except(EXCEPTION_EXECUTE_HANDLER) {ok=false;}
    return ok;
}
bool IntroComplete(const State& s) {
    __try {
        return reinterpret_cast<bool(__thiscall*)(void*)>(0x5660B0u)(reinterpret_cast<void*>(s.profile+0xA8u));
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool EnableNativePrologueSkip() {
    if(!Scope())return false;
    __try {


        *reinterpret_cast<unsigned char*>(0x926125u)=1;
        *reinterpret_cast<unsigned char*>(0x926126u)=1;
        return *reinterpret_cast<unsigned char*>(0x926125u)==1&&*reinterpret_cast<unsigned char*>(0x926126u)==1;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool ClearQueuedPrologue(bool& cleared) {
    cleared=false;
    __try {
        const auto database=*reinterpret_cast<Word*>(0x91E004u);if(!database)return false;
        const auto race=reinterpret_cast<void*(__thiscall*)(void*)>(0x5DCA00u)(reinterpret_cast<void*>(database));
        if(race&&reinterpret_cast<bool(__thiscall*)(void*)>(0x5FBD20u)(race)) {


            reinterpret_cast<void(__thiscall*)(void*)>(0x5DC9D0u)(reinterpret_cast<void*>(database));
            if(reinterpret_cast<void*(__thiscall*)(void*)>(0x5DCA00u)(reinterpret_cast<void*>(database)))return false;
            cleared=true;
        }
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool CompleteCareerIntro(State& s,bool& changed) {
    changed=false;
    __try {
        if(!IntroComplete(s)) {
            reinterpret_cast<void(__thiscall*)(void*)>(0x50E350u)(reinterpret_cast<void*>(s.profile+0xA8u));
            changed=true;
        }


        if(s.rank==16u) {
            *reinterpret_cast<unsigned char*>(s.profile+0xB0u)=15;s.rank=15;changed=true;
        }
        return IntroComplete(s);
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool ReadLockedObjectives(Word manager,unsigned rank,unsigned& milestones,unsigned& cameras) {
    milestones=cameras=0;
    __try {
        if(manager<0x10000u||(manager&3u)||rank<1u||rank>15u)return false;

        const Word count=*reinterpret_cast<Word*>(manager+0xA4u),rows=*reinterpret_cast<Word*>(manager+0xA8u);
        const Word trapCount=*reinterpret_cast<Word*>(manager+0xACu),traps=*reinterpret_cast<Word*>(manager+0xB0u);
        if(count>4096u||trapCount>4096u ||
            (count&&(rows<0x10000u||(rows&3u)||rows>0xFFFFFFFFu-count*20u)) ||
            (trapCount&&(traps<0x10000u||(traps&3u)||traps>0xFFFFFFFFu-trapCount*20u)))return false;
        for(Word n=0;n<count;++n) {
            const Word row=rows+n*20u;
            if(*reinterpret_cast<unsigned short*>(row+0xAu)==rank&&*reinterpret_cast<unsigned char*>(row+8u)==1u)++milestones;
        }
        for(Word n=0;n<trapCount;++n) {
            const Word row=traps+n*20u;
            if(*reinterpret_cast<unsigned short*>(row+2u)==rank&&!(*reinterpret_cast<unsigned short*>(row)&1u))++cameras;
        }
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool EnableCurrentObjectives(const State& s,unsigned& milestones,unsigned& cameras) {
    milestones=cameras=0;
    __try {
        const auto manager=*reinterpret_cast<Word*>(0x91E00Cu);
        if(!ReadLockedObjectives(manager,s.rank,milestones,cameras)||(!milestones&&!cameras))return false;


        if(milestones)reinterpret_cast<void(__thiscall*)(void*,unsigned)>(0x5E46F0u)(reinterpret_cast<void*>(manager),s.rank);
        if(cameras)reinterpret_cast<void(__thiscall*)(void*,unsigned)>(0x5E9D60u)(reinterpret_cast<void*>(manager),s.rank);
        unsigned remaining=0,remainingCameras=0;
        return ReadLockedObjectives(manager,s.rank,remaining,remainingCameras)&&!remaining&&!remainingCameras;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
struct BinProgress {unsigned oldWins=0,oldMilestones=0,wins=0,milestones=0;};
bool RebuildCurrentBinProgress(const State& s,BinProgress& result) {
    __try {
        if(s.rank<1u||s.rank>15u)return false;
        const Word database=*reinterpret_cast<Word*>(0x91E004u),manager=*reinterpret_cast<Word*>(0x91E00Cu);
        unsigned locked=0,cameras=0;
        if(database<0x10000u||(database&3u)||!ReadLockedObjectives(manager,s.rank,locked,cameras))return false;
        const Word raceCount=*reinterpret_cast<Word*>(database),scores=*reinterpret_cast<Word*>(database+0x3Cu);
        const Word bins=*reinterpret_cast<Word*>(database+0x20u),binRows=*reinterpret_cast<Word*>(database+0x24u);
        if(!raceCount||raceCount>4096u||scores<0x10000u||(scores&3u)||scores>0xFFFFFFFFu-raceCount*16u||
           !bins||bins>32u||binRows<0x10000u||(binRows&3u)||binRows>0xFFFFFFFFu-bins*28u)return false;
        const auto bin=static_cast<Word>(reinterpret_cast<std::uintptr_t>(reinterpret_cast<void*(__thiscall*)(void*,int)>(0x5E3980u)(reinterpret_cast<void*>(database),s.rank)));
        if(bin<binRows||bin>=binRows+bins*28u||(bin-binRows)%28u)return false;
        result.oldMilestones=*reinterpret_cast<unsigned short*>(bin+0x18u);
        result.oldWins=*reinterpret_cast<unsigned short*>(bin+0x1Au);


        reinterpret_cast<void(__thiscall*)(void*)>(0x6010E0u)(reinterpret_cast<void*>(bin));
        result.milestones=*reinterpret_cast<unsigned short*>(bin+0x18u);
        result.wins=*reinterpret_cast<unsigned short*>(bin+0x1Au);
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool Prepare(State& s,const char* slot,bool initialize) {
    __try {
        if(initialize) {


            reinterpret_cast<void(__thiscall*)(void*)>(0x5AB9C0u)(reinterpret_cast<void*>(s.db));
            if(!InitializeWithoutGameplay(s.profile+0xA8u))return false;
        }
        if(!NameProfile(s,slot))return false;
        *reinterpret_cast<unsigned char*>(s.profile+0xB0u)=15;s.rank=15;
        bool changed=false;if(!CompleteCareerIntro(s,changed))return false;
        reinterpret_cast<void(__thiscall*)(void*,int,char)>(0x56DBA0u)(reinterpret_cast<void*>(s.db),0,0);
        if(initialize) {
            auto* cash=reinterpret_cast<int*>(s.profile+0xA8u+0x0Cu);
            *cash=30000;
            if(*cash!=30000)return false;
        }
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}


#if defined(_MSC_VER)
__declspec(noinline)
#elif defined(__GNUC__)
__attribute__((noinline))
#endif
void LogOutsideSeh(const char* message) {
    NFSMWAP::Log(message);
}


#if defined(NFSMWAP_BOOTSTRAP_HOST_FIXTURE)
bool VerifyRetailAutosave() {return ::g_hostAutosaveSignatureValid;}
#else
bool VerifyRetailAutosave() {
    __try {
        const unsigned char entry[]={0x8B,0x44,0x24,0x04,0x56,0x50,0x8B,0xF1};
        const auto* const start=reinterpret_cast<const unsigned char*>(0x562AB0u);
        if(std::memcmp(start,entry,sizeof(entry))!=0)return false;
        if(*reinterpret_cast<const unsigned char*>(0x562B14u)!=0xE8u)return false;
        const auto displacement=*reinterpret_cast<const std::int32_t*>(0x562B15u);
        if(0x562B19u+displacement!=0x526800u)return false;
        return *reinterpret_cast<const unsigned char*>(0x562B19u)==0x5Eu&&
               *reinterpret_cast<const unsigned char*>(0x562B1Au)==0xC2u&&
               *reinterpret_cast<const unsigned char*>(0x562B1Bu)==0x04u&&
               *reinterpret_cast<const unsigned char*>(0x562B1Cu)==0x00u;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
#endif


#if defined(_MSC_VER)
__declspec(noinline)
#endif
bool EnsureSlotDirectory() {
    char root[4096]={};
    const auto n=GetEnvironmentVariableA("NFSMW_AP_DOCUMENTS_ROOT",root,sizeof(root));
    if(!n||n>=sizeof(root))return false;
    const auto documents=std::filesystem::path(root);
    const auto folder=documents/"NFS Most Wanted";
    std::error_code error;
    if(!std::filesystem::is_directory(documents,error)||error)return false;
    error.clear();
    if(!std::filesystem::exists(folder,error)) {
        if(error)return false;
        error.clear();
        if(!std::filesystem::create_directory(folder,error)||error)return false;
        NFSMWAP::Log("AP SLOT SAVE PATH: created isolated native profile directory '"+folder.string()+"'.");
    }
    error.clear();
    if(!std::filesystem::is_directory(folder,error)||error)return false;
    if(!pathDiagnosticLogged) {
        pathDiagnosticLogged=true;
        NFSMWAP::Log("AP SLOT SAVE PATH: verified isolated directory '"+folder.string()+"'.");
    }
    return true;
}


const char* nativeDirectoryFailure="not attempted";
#if defined(NFSMWAP_BOOTSTRAP_HOST_FIXTURE)
bool VerifyRetailDirectorySetter() {return ::g_hostDirectorySetterSignatureValid;}
#else
bool VerifyRetailDirectorySetter() {
    __try {
        const unsigned char thunk[]={0x55,0x8B,0xEC,0x8B,0x09,0x5D,0xE9,0x6F,0x0F,0x00,0x00};
        const unsigned char setter[]={0x55,0x8B,0xEC,0x68,0x04,0x01,0x00,0x00,0xFF,0x75,0x08,
            0x81,0xC1,0x8C,0x01,0x00,0x00,0x51,0xE8,0xFF,0x97,0x06,0x00,
            0x83,0xC4,0x0C,0x5D,0xC2,0x04,0x00};
        const unsigned char caller[]={0xA1,0x20,0xCB,0x91,0x00,0x8B,0x88,0xC8,0x00,0x00,0x00,
            0x8D,0x54,0x24,0x04,0x52,0xE8,0x8D,0x7D,0x12,0x00};
        const unsigned char reader[]={0x8D,0x83,0x8C,0x01,0x00,0x00};
        return std::memcmp(reinterpret_cast<const void*>(0x7F3D00u),thunk,sizeof(thunk))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x7F4C7Au),setter,sizeof(setter))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x6CBF5Eu),caller,sizeof(caller))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x7F500Cu),reader,sizeof(reader))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x7F503Fu),reader,sizeof(reader))==0;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
#endif
bool BindNativeProfileDirectory(const char* directory) {
    if(!VerifyRetailDirectorySetter()) {nativeDirectoryFailure="native directory setter signature changed";return false;}
    if(!directory||!directory[0]||std::strlen(directory)>=260u) {
        nativeDirectoryFailure="isolated directory is empty or exceeds the native buffer";return false;
    }
    __try {
        const Word card=*reinterpret_cast<Word*>(0x91CB20u);
        if(card<0x10000u||(card&3u)) {nativeDirectoryFailure="native card is unavailable";return false;}
        const Word implementation=*reinterpret_cast<Word*>(card+0xC8u);
        if(implementation<0x10000u||(implementation&3u)) {nativeDirectoryFailure="native PC implementation is unavailable";return false;}
        const Word backend=*reinterpret_cast<Word*>(implementation);
        if(backend<0x10000u||(backend&3u)) {nativeDirectoryFailure="native PC file backend is unavailable";return false;}
        const auto current=reinterpret_cast<const char*>(backend+0x18Cu);
        if(!nativeDirectoryBound||std::strncmp(current,directory,260u)!=0) {


            reinterpret_cast<void(__thiscall*)(void*,const char*)>(0x7F3D00u)(
                reinterpret_cast<void*>(implementation),directory);
        }
        if(std::strncmp(current,directory,260u)!=0) {
            nativeDirectoryFailure="native directory readback does not match this AP session";return false;
        }
        nativeDirectoryBound=true;nativeDirectoryFailure=nullptr;return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        nativeDirectoryFailure="exception while binding or reading the native PC directory";return false;
    }
}
#if defined(_MSC_VER)
__declspec(noinline)
#endif
bool ConfigureSlotDirectory() {
    char root[4096]={};const auto n=GetEnvironmentVariableA("NFSMW_AP_DOCUMENTS_ROOT",root,sizeof(root));
    if(!n||n>=sizeof(root)) {nativeDirectoryFailure="session Documents root is unavailable";return false;}


    const auto folder=std::filesystem::path(root)/"NFS Most Wanted";
    const auto directory=folder.string();
    if(!BindNativeProfileDirectory(directory.c_str())) {
        NFSMWAP::Log("AP SLOT NATIVE DIRECTORY BLOCKED: "+std::string(nativeDirectoryFailure?nativeDirectoryFailure:"unknown binding failure")+
            "; no profile write submitted.");return false;
    }
    if(!nativeDirectoryBindingLogged) {
        nativeDirectoryBindingLogged=true;
        NFSMWAP::Log("AP SLOT NATIVE DIRECTORY READY: native PC backend path readback matches '"+directory+"'.");
    }
    return true;
}


struct NativeSaveSnapshot {
    bool readable=false;
    Word card=0,storage=0,storageState=0,cardState=0,ioMode=0,ioStatus=0;
    unsigned cardFlags=0;
    unsigned char profileLoaded=0;
};
bool ReadNativeSaveSnapshot(NativeSaveSnapshot& state) {
    __try {
        state.card=*reinterpret_cast<Word*>(0x91CB20u);
        state.ioMode=*reinterpret_cast<Word*>(0x9258D4u);
        state.ioStatus=*reinterpret_cast<Word*>(0x9258D8u);
        state.cardState=*reinterpret_cast<Word*>(0x91CBACu);
        const Word db=*reinterpret_cast<Word*>(0x91CF90u);
        if(!state.card||!db)return false;
        state.profileLoaded=*reinterpret_cast<unsigned char*>(db+3u);
        state.storage=*reinterpret_cast<Word*>(state.card+0xD0u);
        state.cardFlags=static_cast<unsigned>(*reinterpret_cast<unsigned char*>(state.card+0x1Eu)) |
                        (static_cast<unsigned>(*reinterpret_cast<unsigned char*>(state.card+0x20u))<<8u) |
                        (static_cast<unsigned>(*reinterpret_cast<unsigned char*>(state.card+0x24u))<<16u);
        state.storageState=state.storage?*reinterpret_cast<Word*>(state.storage+8u):0;
        state.readable=true;
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
#if defined(_MSC_VER)
__declspec(noinline)
#endif
void LogNativeSaveSnapshot(const char* phase) {
    NativeSaveSnapshot s{};
    if(!ReadNativeSaveSnapshot(s)) {
        NFSMWAP::Log(std::string("AP SLOT NATIVE STATE ")+phase+": unreadable; no runtime state was modified.");
        return;
    }
    NFSMWAP::Log(std::string("AP SLOT NATIVE STATE ")+phase+
        ": card="+std::to_string(s.card)+
        " card_state="+std::to_string(s.cardState)+
        " storage="+std::to_string(s.storage)+
        " storage_state="+std::to_string(s.storageState)+
        " flags="+std::to_string(s.cardFlags)+
        " io_mode="+std::to_string(s.ioMode)+
        " io_status="+std::to_string(s.ioStatus)+
        " loaded="+std::to_string(s.profileLoaded)+" (read only).");
}
void LogUnredirectedSaveLocation(const char* slot) {


    const HMODULE shell=GetModuleHandleA("shfolder.dll");
    using OriginalFolderPath=HRESULT (WINAPI*)(HWND,int,HANDLE,DWORD,LPSTR);
    const auto original=shell?reinterpret_cast<OriginalFolderPath>(GetProcAddress(shell,"SHGetFolderPathA")):nullptr;
    char root[MAX_PATH]={};
    if(!original||FAILED(original(nullptr,5,nullptr,0,root))) {
        NFSMWAP::Log("AP SLOT VANILLA PATH DIAGNOSTIC: native Documents lookup unavailable (no files read).");
        return;
    }
    const auto vanilla=std::filesystem::path(root)/"NFS Most Wanted";
    for (const auto& candidate: {vanilla/slot,vanilla/slot/slot}) {
        std::error_code error;
        const bool exists=std::filesystem::is_regular_file(candidate,error)&&!error;
        std::uintmax_t size=0;
        if(exists)size=std::filesystem::file_size(candidate,error);
        NFSMWAP::Log("AP SLOT VANILLA PATH DIAGNOSTIC: path='"+candidate.string()+
            "' file="+(exists?"yes":"no")+
            " bytes="+std::to_string(!error?size:0)+
            " (read-only metadata; no vanilla save imported).");
    }
}
void LogSaveDirectoryContents(const char* slot) {
    char root[4096]={};
    const auto n=GetEnvironmentVariableA("NFSMW_AP_DOCUMENTS_ROOT",root,sizeof(root));
    if(!n||n>=sizeof(root))return;
    const auto folder=std::filesystem::path(root)/"NFS Most Wanted";
    std::error_code error;
    const bool exists=std::filesystem::is_directory(folder,error);
    NFSMWAP::Log("AP SLOT SAVE DIAGNOSTIC: expected='"+(folder/slot).string()+
        "' folder_exists="+(exists&&!error?"yes":"no")+
        " callback_name='"+std::string(callbackFile)+"'"+
        " isolated_documents_lookups="+std::to_string(NFSMWAP::GetSaveIsolationRedirectCount())+
        " profile_createfile_opens="+std::to_string(NFSMWAP::GetSaveIsolationProfileOpenCount())+
        " profile_redirects="+std::to_string(NFSMWAP::GetSaveIsolationProfileRedirectCount())+
        " last_file_open='"+NFSMWAP::GetSaveIsolationLastProfileOpenPath()+"'.");
    if(!exists||error)return;
    unsigned count=0;
    for(std::filesystem::directory_iterator it(folder,error),end;!error&&it!=end&&count<8u;it.increment(error)) {
        auto entry=it->path();
        std::error_code fileError;
        const bool regular=it->is_regular_file(fileError);
        const auto bytes=regular&&!fileError?it->file_size(fileError):0;
        NFSMWAP::Log("AP SLOT SAVE DIAGNOSTIC ENTRY: '"+entry.filename().string()+
            "' regular="+(regular&&!fileError?"yes":"no")+
            " bytes="+std::to_string(bytes));
        ++count;
    }
    if(error)NFSMWAP::Log("AP SLOT SAVE DIAGNOSTIC: directory enumeration error="+std::to_string(error.value()));
    LogUnredirectedSaveLocation(slot);
    LogNativeSaveSnapshot("after_wait");
}
#if defined(_MSC_VER)
__declspec(noinline)
#endif
void LogSaveCallback(const char* filename) {
    NFSMWAP::Log("AP SLOT SAVE CALLBACK DETAIL: native filename='"+
        std::string(filename?filename:"<null>")+"' isolated_documents_lookups="+
        std::to_string(NFSMWAP::GetSaveIsolationRedirectCount())+
        " profile_file_opens="+std::to_string(NFSMWAP::GetSaveIsolationProfileOpenCount())+".");
}


bool CopyCallbackName(const char* source) {
    if(!source){callbackFile[0]=0;return true;}
    __try {
        for(std::size_t i=0;i<sizeof(callbackFile);++i) {
            const char c=source[i];callbackFile[i]=c;
            if(!c)return true;
        }
    } __except(EXCEPTION_EXECUTE_HANDLER) {callbackFile[0]=0;return false;}
    callbackFile[0]=0;return false;
}
void* IdleCard() {
    __try {
        const auto card=reinterpret_cast<void*(__cdecl*)()>(0x50EBF0u)();
        if(!card||reinterpret_cast<bool(__thiscall*)(void*)>(0x50EC40u)(card)||
           reinterpret_cast<bool(__cdecl*)()>(0x5436B0u)()||reinterpret_cast<bool(__thiscall*)(void*)>(0x50EC90u)(card)||
           reinterpret_cast<bool(__thiscall*)(void*)>(0x50ECF0u)(card))return nullptr;
        return card;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return nullptr;}
}
bool BeginSlotLoadMessages(void* card) {
    __try {
        if(loadMessagePolicy.captured)return false;
        const auto address=static_cast<Word>(reinterpret_cast<std::uintptr_t>(card));
        const Word implementation=*reinterpret_cast<Word*>(address+0xC8u);
        if(implementation<0x10000u||(implementation&3u))return false;
        const Word backend=*reinterpret_cast<Word*>(implementation);
        if(backend<0x10000u||(backend&3u))return false;
        loadMessagePolicy.card=address;loadMessagePolicy.backend=backend;
        loadMessagePolicy.hidden=*reinterpret_cast<Word*>(backend+0x7Cu);
        loadMessagePolicy.disabled=*reinterpret_cast<Word*>(backend+0x80u);
        loadMessagePolicy.manual=*reinterpret_cast<unsigned char*>(address+0x1Au);
        loadMessagePolicy.captured=true;


        reinterpret_cast<void(__thiscall*)(void*,bool)>(0x518820u)(card,false);
        *reinterpret_cast<Word*>(address+0x50u)=0;
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool RestoreSlotLoadMessages() {
    if(!loadMessagePolicy.captured)return true;
    const auto card=IdleCard();if(!card)return false;
    __try {
        const auto address=static_cast<Word>(reinterpret_cast<std::uintptr_t>(card));
        const Word implementation=*reinterpret_cast<Word*>(address+0xC8u);
        if(address!=loadMessagePolicy.card||implementation<0x10000u||
           *reinterpret_cast<Word*>(implementation)!=loadMessagePolicy.backend)return false;


        const auto set=reinterpret_cast<void(__thiscall*)(void*,int,Word)>(0x7F3CA0u);
        auto* iface=reinterpret_cast<void*>(implementation);
        set(iface,0,0xFFFFFFFFu);set(iface,1,loadMessagePolicy.hidden);set(iface,2,loadMessagePolicy.disabled);
        *reinterpret_cast<unsigned char*>(address+0x1Au)=loadMessagePolicy.manual;
        loadMessagePolicy.captured=false;return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool BlockPrematureCareerInput(Word message) {
    return Scope()&&!profileReady&&(message==0x406415E3u||message==0xB5AF2461u||
        message==NativeOptionPressed||message==0x911AB364u);
}
bool SaveNamedProfile(const State& s,const char* slot) {
    if(!EnsureSlotDirectory()) {


        LogOutsideSeh("AP SLOT SAVE PATH ERROR: isolated profile directory is not accessible; native save not requested.");
        saveStage=SaveStage::Failed;
        return false;
    }


    const auto card=IdleCard();if(!card)return false;
    if(!ConfigureSlotDirectory()) {saveStage=SaveStage::Failed;return false;}
    callbackFile[0]=0;
    if(!IdleCard())return false;
    __try {
        if(!s.loaded||std::strncmp(reinterpret_cast<const char*>(s.profile),slot,32)!=0)return false;
        saveStage=SaveStage::Preparing;
        startingSave=true;
        if(slotSaveRoute==SlotSaveRoute::HookedCardHandoff) {


            reinterpret_cast<void(__thiscall*)(void*,bool)>(0x562AB0u)(card,true);
            startingSave=false;
            if(saveStage==SaveStage::Preparing) {

                if(reinterpret_cast<bool(__thiscall*)(void*)>(0x50EC90u)(card))
                    reinterpret_cast<void(__thiscall*)(void*)>(0x526860u)(card);
                saveStage=SaveStage::Failed;
            }
            if(!reinterpret_cast<bool(__thiscall*)(void*)>(0x50EC90u)(card)&&saveStage!=SaveStage::Complete)
                saveStage=SaveStage::Failed;
        } else {


            saveStage=SaveStage::Writing;
            LogNativeSaveSnapshot("before_retail_start");
            LogOutsideSeh("AP SLOT SAVE RETAIL START: invoking verified native StartAutoSave (not a direct serializer call).");
            reinterpret_cast<void(__thiscall*)(void*,bool)>(0x562AB0u)(card,true);
            startingSave=false;
            LogNativeSaveSnapshot("after_retail_return");
            if(saveStage==SaveStage::Writing &&
               !reinterpret_cast<bool(__thiscall*)(void*)>(0x50EC90u)(card)) {
                saveStage=SaveStage::Failed;
                LogOutsideSeh("AP SLOT SAVE RETAIL BLOCKED: StartAutoSave returned without a live save operation.");
            } else {
                LogOutsideSeh("AP SLOT SAVE RETAIL SUBMITTED: awaiting native SaveDone and disk-confirmed slot file.");
            }
        }
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {startingSave=false;saveStage=SaveStage::Failed;return false;}
}
void __fastcall SubmitSlotSave(void* card,void*,int slotNumber) {
    if(Scope()&&startingSave&&saveStage==SaveStage::Preparing) {
        if(card&&reinterpret_cast<bool(__thiscall*)(void*)>(0x50EC90u)(card)&&
           reinterpret_cast<bool(__thiscall*)(void*)>(0x50ECA0u)(card)) {
            char slot[32]={};bool fresh=false;State current;
            if(!Launch(slot,fresh)||!Read(current)||!current.loaded||
               std::strncmp(reinterpret_cast<const char*>(current.profile),slot,32)!=0) {
                saveStage=SaveStage::Failed;
                reinterpret_cast<void(__thiscall*)(void*)>(0x526860u)(card);
                NFSMWAP::Log("AP SLOT SAVE BLOCKED: the active profile changed before the bound slot could be serialized.");return;
            }


            saveStage=SaveStage::Writing;
            NFSMWAP::Log("AP SLOT SAVE WRITE: autosave initialized; committing the bound slot without submitting a card-check request.");
            reinterpret_cast<void(__thiscall*)(void*)>(0x526800u)(card);
            NFSMWAP::Log("AP SLOT SAVE SUBMITTED: native serializer returned.");return;
        }
        saveStage=SaveStage::Failed;
        if(card&&reinterpret_cast<bool(__thiscall*)(void*)>(0x50EC90u)(card))
            reinterpret_cast<void(__thiscall*)(void*)>(0x526860u)(card);
        NFSMWAP::Log("AP SLOT SAVE REFUSED: native autosave setup was not ready for the bound slot.");return;
    }
    reinterpret_cast<void(__thiscall*)(void*,int)>(0x518840u)(card,slotNumber);
}
void __fastcall SaveDone(void* callbacks,void*,const char* filename) {
    const bool ours=Scope()&&saveStage==SaveStage::Writing;


    const bool nameReadable=ours&&CopyCallbackName(filename);
    reinterpret_cast<void(__thiscall*)(void*,const char*)>(0x526AC0u)(callbacks,filename);
    if(ours){
        saveStage=SaveStage::Complete;
        NFSMWAP::Log("AP SLOT SAVE CALLBACK: native SaveDone completed; checking the slot file.");
        LogSaveCallback(nameReadable?callbackFile:"<unreadable>");
        LogNativeSaveSnapshot("save_done_callback");
    }
}
bool CleanupFailedSlotLoad(int result,int status) {


    __try {
        const Word card=*reinterpret_cast<Word*>(0x91CB20u),db=*reinterpret_cast<Word*>(0x91CF90u);
        if(card<0x10000u||db<0x10000u)return false;
        const Word buffer=*reinterpret_cast<Word*>(card+0x44u);
        if(buffer) {reinterpret_cast<void(__cdecl*)(void*)>(0x4655F0u)(reinterpret_cast<void*>(buffer));*reinterpret_cast<Word*>(card+0x44u)=0;}
        const Word imp=*reinterpret_cast<Word*>(card+0xD0u);
        if(imp&&*reinterpret_cast<Word*>(imp+8u))reinterpret_cast<void(__thiscall*)(void*)>(0x6CBEE0u)(reinterpret_cast<void*>(imp));
        *reinterpret_cast<Word*>(card+0x40u)=0;
        *reinterpret_cast<unsigned short*>(card+0x48u)=static_cast<unsigned short>(result);
        *reinterpret_cast<unsigned short*>(card+0x4Au)=static_cast<unsigned short>(status);
        reinterpret_cast<void(__thiscall*)(void*)>(0x5ACE40u)(reinterpret_cast<void*>(db));
        reinterpret_cast<void(__thiscall*)(void*)>(0x56DBB0u)(reinterpret_cast<void*>(db));
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
void __fastcall SaveFailed(void* callbacks,void*,int result,int status) {
    if(Scope()&&!profileReady&&(loadStage==LoadStage::Reading||loadStage==LoadStage::Accepted)) {
        loadStage=LoadStage::Failed;profileReady=false;
        CleanupFailedSlotLoad(result,status);
        NFSMWAP::Log("AP SLOT LOAD FAILED: native result="+std::to_string(result)+" status="+std::to_string(status)+
            "; existing save retained; no memory-card screen callback or replacement Career.");
        return;
    }
    const bool ours=Scope()&&(saveStage==SaveStage::Preparing||saveStage==SaveStage::Writing);
    if(ours)saveStage=SaveStage::Failed;
    reinterpret_cast<void(__thiscall*)(void*,int,int)>(0x526F60u)(callbacks,result,status);
    if(ours)NFSMWAP::Log("AP SLOT SAVE FAILED: native result="+std::to_string(result)+" status="+std::to_string(status)+
        "; dealership remains blocked; automatic save retries stopped.");
}
bool SlotSaveExists(const char* slot) {
    char root[4096]={};const auto n=GetEnvironmentVariableA("NFSMW_AP_DOCUMENTS_ROOT",root,sizeof(root));if(!n||n>=sizeof(root))return false;
    const auto folder=std::filesystem::path(root)/"NFS Most Wanted";
    for(const auto& path:{folder/slot,folder/slot/slot}) {
        std::error_code error;if(!std::filesystem::is_regular_file(path,error)||error)continue;
        const auto size=std::filesystem::file_size(path,error);if(!error&&size>=0x4039u&&size<=1024u*1024u)return true;
    }
    return false;
}
bool __fastcall AcceptLoadedSlot(void* database,void*,void* data,int size,int player) {
    const bool ours=Scope()&&loadStage==LoadStage::Reading&&player==0;
    const bool accepted=reinterpret_cast<bool(__thiscall*)(void*,void*,int,int)>(0x5ACDD0u)(database,data,size,player);
    if(ours)loadStage=accepted?LoadStage::Accepted:LoadStage::Failed;
    return accepted;
}
bool StartSlotLoad(const char* slot) {
    if(loadStage!=LoadStage::Idle)return false;
    const auto slotBytes=slot ? std::strlen(slot)+1u : 0u;
    if(slotBytes<2u||slotBytes>sizeof(loadSlot)) {loadStage=LoadStage::Failed;return false;}
    if(!SlotSaveExists(slot)) {
        loadStage=LoadStage::Failed;
        LogOutsideSeh("AP SLOT LOAD BLOCKED: existing session has no valid slot file; existing progress will not be replaced.");return false;
    }
    const auto card=IdleCard();if(!card)return false;
    if(!ConfigureSlotDirectory()) {loadStage=LoadStage::Failed;return false;}


    std::memcpy(loadSlot,slot,slotBytes);
    if(!BeginSlotLoadMessages(card)) {loadStage=LoadStage::Failed;return false;}
    loadSlowLogged=false;loadStartedAt=GetTickCount();loadStage=LoadStage::Reading;
    __try {
        reinterpret_cast<void(__thiscall*)(void*,const char*)>(0x5189F0u)(card,loadSlot);
    } __except(EXCEPTION_EXECUTE_HANDLER) {loadStage=LoadStage::Failed;return false;}
    LogOutsideSeh("AP SLOT LOAD REQUESTED: exact isolated slot; native screenless load messages configured; initialization and item delivery blocked until acceptance.");
    return true;
}
void PollSlotLoad() {
    const auto stage=loadStage.load();
    if(stage==LoadStage::Reading||stage==LoadStage::Accepted) {
        const auto elapsed=GetTickCount()-loadStartedAt;
        if(elapsed>=5000u&&!loadSlowLogged) {
            loadSlowLogged=true;LogNativeSaveSnapshot("load_wait");
        }


        if(elapsed>=30000u) {loadStage=LoadStage::Failed;profileReady=false;}
    }
    if(loadStage==LoadStage::Failed) {
        RestoreSlotLoadMessages();
        if(!loadWaitLogged) {
            loadWaitLogged=true;LogNativeSaveSnapshot("load_failed");
            NFSMWAP::Log("AP SLOT LOAD FAILED: native load did not accept/finish the saved slot; save preserved; no replacement Career or save created.");
        }
    }
}
bool FinishSlotLoad(const State& s,const char* slot) {
    if(loadStage==LoadStage::Ready)return true;
    if(loadStage==LoadStage::Accepted&&IdleCard()&&RestoreSlotLoadMessages()) {
        if(!s.loaded||!s.started||std::strncmp(reinterpret_cast<const char*>(s.profile),slot,32)!=0) {
            loadStage=LoadStage::Failed;
        } else {
            loadStage=LoadStage::Ready;profileReady=true;
            NFSMWAP::Log("AP SLOT LOAD READY: native deserializer accepted profile '"+std::string(slot)+
                "' at Blacklist #"+std::to_string(s.rank)+"; Career, cars, cash and gameplay records retained.");return true;
        }
    }
    return false;
}
bool RefreshObjectiveMapIcons(const State& s) {
    __try {
        const Word manager=*reinterpret_cast<Word*>(0x91E00Cu);
        unsigned locked=0,cameras=0;
        if(s.rank<1u||s.rank>15u||!ReadLockedObjectives(manager,s.rank,locked,cameras))return false;
        const Word mask=*reinterpret_cast<Word*>(manager+0x70u),probe=*reinterpret_cast<Word*>(manager+0x74u);
        const Word table=*reinterpret_cast<Word*>(manager+0x78u),count=*reinterpret_cast<Word*>(manager+0x2BCu),icons=*reinterpret_cast<Word*>(manager+0x2C4u);
        if(mask>65535u||(mask&(mask+1u))||probe>mask+1u||table<0x10000u||(table&3u)||table>0xFFFFFFFFu-(mask+1u)*8u||
           *reinterpret_cast<Word*>(manager+0x60u)>=32u||count>4096u||
           (count&&(icons<0x10000u||(icons&3u)||icons>0xFFFFFFFFu-count*4u)))return false;


        reinterpret_cast<void(__thiscall*)(void*)>(0x5E9DE0u)(reinterpret_cast<void*>(manager));
        reinterpret_cast<void(__thiscall*)(void*)>(0x5FDAE0u)(reinterpret_cast<void*>(manager));
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
void __fastcall ObjectiveWorldMapSetup(Word* screen,void*) {
    char slot[32]={};bool fresh=false;State s;
    const bool ours=Scope()&&profileReady&&Launch(slot,fresh)&&Read(s)&&s.loaded&&s.started&&
        std::strncmp(reinterpret_cast<const char*>(s.profile),slot,32)==0&&s.rank>=1u&&s.rank<=15u&&IdleCard()&&!saveRequested;
    const bool refreshed=ours&&RefreshObjectiveMapIcons(s);
    reinterpret_cast<void(__thiscall*)(Word*)>(0x55B8C0u)(screen);


    if(refreshed&&screen&&(screen[0x164u/4u]==0u||screen[0x164u/4u]==1u)) {
        reinterpret_cast<void(__thiscall*)(Word*,int)>(0x5486A0u)(screen,12);
        reinterpret_cast<void(__thiscall*)(Word*,int)>(0x5486A0u)(screen,11);

        reinterpret_cast<void(__thiscall*)(Word*,int)>(0x5A5EA0u)(screen,0);
        reinterpret_cast<void(__thiscall*)(Word*)>(0x5488B0u)(screen);
    }
    if(ours)NFSMWAP::Log(std::string("AP OBJECTIVE MAP: native icon refresh ")+(refreshed?"ready":"waiting for world data")+
        "; Blacklist #"+std::to_string(s.rank)+"; native photo-ticket and pursuit-start markers retained.");
}
enum class CareerFrontend { Dealership, Manager, Safehouse };
bool safehouseSpawnPending=false;
Word safehouseExitMarker=0;
bool PrepareSafehouseSpawn(Word& selected) {
    selected=0;
    __try {
        const Word gm=*reinterpret_cast<Word*>(0x91E00Cu);
        if(gm<0x10000u||(gm&3u))return false;
        const Word mask=*reinterpret_cast<Word*>(gm+0x70u),entries=*reinterpret_cast<Word*>(gm+0x78u);
        if(mask>0xFFFFu||(mask&(mask+1u))||entries<0x10000u||(entries&3u)||entries>0xFFFFFFFFu-(mask+1u)*8u)return false;
        const Word previous=*reinterpret_cast<Word*>(gm+0x10Cu);
        Word retained=0;


        for(Word index=0;index<=mask;++index) {
            const Word trigger=*reinterpret_cast<Word*>(entries+index*8u+4u);
            if(trigger<0x10000u||(trigger&3u)||*reinterpret_cast<Word*>(trigger)!=0x8A3A84u)continue;
            if(!reinterpret_cast<bool(__thiscall*)(void*,Word)>(0x5E28B0u)(reinterpret_cast<void*>(trigger),0x326427BBu))continue;


            const auto marker=reinterpret_cast<const Word*(__thiscall*)(void*,Word,unsigned)>(0x454810u)
                (reinterpret_cast<void*>(trigger+4u),0x2241F4CDu,0);
            if(!marker||!*marker||!reinterpret_cast<void*(__cdecl*)(Word,Word)>(0x455FD0u)(0x5CEA9D46u,*marker))continue;
            if(*marker==previous){selected=previous;break;}
            if(*marker==safehouseExitMarker)retained=*marker;
            if(!selected||*marker<selected)selected=*marker;
        }
        if(selected!=previous&&retained)selected=retained;
        if(!selected&&safehouseExitMarker&&reinterpret_cast<void*(__cdecl*)(Word,Word)>(0x455FD0u)(0x5CEA9D46u,safehouseExitMarker))selected=safehouseExitMarker;
        if(!selected)return false;
        safehouseExitMarker=selected;
        reinterpret_cast<void(__thiscall*)(void*,Word)>(0x5DAA30u)(reinterpret_cast<void*>(gm),selected);


        reinterpret_cast<void(__thiscall*)(void*,Word)>(0x5DAA10u)(reinterpret_cast<void*>(gm),selected);


        reinterpret_cast<void(__thiscall*)(void*)>(0x604180u)(reinterpret_cast<void*>(gm));
        reinterpret_cast<void(__thiscall*)(void*,Word)>(0x50E990u)(reinterpret_cast<void*>(gm),0);
        return *reinterpret_cast<Word*>(gm+0x10Cu)==selected&&*reinterpret_cast<unsigned char*>(gm+0x110u)==1u;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
void __cdecl StartFreeRoamFromSafehouse() {
    State s;
    if(Scope()&&profileReady&&Read(s)&&(s.flow==3||s.flow==6)&&s.loaded&&s.started&&s.owned&&s.rank>=1u&&s.rank<=15u&&IntroComplete(s)) {


        const Word db=*reinterpret_cast<Word*>(0x91E004u);
        if(db&&!reinterpret_cast<void*(__thiscall*)(void*)>(0x5DCA00u)(reinterpret_cast<void*>(db))) {
            safehouseSpawnPending=true;
            Word marker=0;
            const bool preparedSpawn=PrepareSafehouseSpawn(marker);
            NFSMWAP::Log(preparedSpawn?"AP SAFEHOUSE EXIT: native home and fallback marker="+std::to_string(marker)+"; late respawn verification armed.":
                "AP SAFEHOUSE EXIT: waiting for loaded native safehouse gates; late respawn repair armed.");
        }
    }
    reinterpret_cast<void(__cdecl*)()>(0x56C5B0u)();
}
Word __fastcall ResolveSafehouseRespawn(void* manager,void*) {


    if(safehouseSpawnPending&&Scope()&&profileReady&&
       reinterpret_cast<std::uintptr_t>(manager)==*reinterpret_cast<Word*>(0x91E00Cu)) {
        const Word db=*reinterpret_cast<Word*>(0x91E004u);
        if(db&&!reinterpret_cast<void*(__thiscall*)(void*)>(0x5DCA00u)(reinterpret_cast<void*>(db))) {
            Word marker=0;
            const bool resolved=PrepareSafehouseSpawn(marker);
            safehouseSpawnPending=false;
            if(resolved)return marker;
            if(safehouseExitMarker&&reinterpret_cast<void*(__cdecl*)(Word,Word)>(0x455FD0u)(0x5CEA9D46u,safehouseExitMarker)) {
                NFSMWAP::Log("AP SAFEHOUSE RESPAWN: retained validated home marker through unloaded/hidden frontend gates.");
                return safehouseExitMarker;
            }
            NFSMWAP::Log("AP SAFEHOUSE RESPAWN: home gate unavailable; native fallback retained for this transition.");
        } else safehouseSpawnPending=false;
    }
    return reinterpret_cast<Word(__thiscall*)(void*)>(0x5E4CF0u)(manager);
}
bool Route(const State& s,const char* package,CareerFrontend destination=CareerFrontend::Dealership) {
    __try {
        const auto manager=reinterpret_cast<void*(__cdecl*)()>(0x516E10u)();const auto feng=*reinterpret_cast<Word*>(0x91CADCu);
        if(!manager||!feng)return false;
        reinterpret_cast<void(__thiscall*)(void*)>(0x50E500u)(reinterpret_cast<void*>(s.db));
        const Word mode=destination==CareerFrontend::Manager?0x100u:destination==CareerFrontend::Safehouse?1u:0x8001u;
        reinterpret_cast<void(__thiscall*)(void*,Word)>(0x50E4C0u)(reinterpret_cast<void*>(s.db),mode);
        if(destination!=CareerFrontend::Manager)
            reinterpret_cast<void(__thiscall*)(void*,int)>(0x516E30u)(manager,destination==CareerFrontend::Safehouse?2:5);
        reinterpret_cast<void(__thiscall*)(void*,const char*,int,Word,bool)>(0x525940u)(reinterpret_cast<void*>(feng),package,0,0,false);return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
bool OpenOwnedSafehouse(const State& s) {
    char slot[32]={};bool fresh=false;
    if(!Scope()||!profileReady||!Launch(slot,fresh)||s.flow!=3||!s.loaded||!s.started||!s.owned||
       s.rank<1u||s.rank>15u||!IntroComplete(s)||!IdleCard()||savePending||
       std::strncmp(reinterpret_cast<const char*>(s.profile),slot,32)!=0)return false;
    bool cleared=false;if(!EnableNativePrologueSkip()||!ClearQueuedPrologue(cleared))return false;


    safehouseSpawnPending=false;
    Word marker=0;PrepareSafehouseSpawn(marker);
    if(!Route(s,"MainMenu_Sub.fng",CareerFrontend::Safehouse)){safehouseSpawnPending=false;return false;}
    needsCar=false;routed=false;resumePending=false;firstCarResumeRequested=false;
    startupFinished=true;resumeScreen=nullptr;
    return true;
}
bool ResumeNative() {
    __try {
        State current;if(!Read(current)||!current.owned||current.rank>15u||!IntroComplete(current))return false;
        if(!resumeScreen||*resumeScreen!=resumeTable)return false;
        bool cleared=false;if(!EnableNativePrologueSkip()||!ClearQueuedPrologue(cleared))return false;

        Word* option=nullptr;


        for(int index=1;index<=16;++index) {
            auto* candidate=reinterpret_cast<Word*(__thiscall*)(Word*,int)>(0x5870F0u)(resumeScreen+11,index);
            if(!candidate)break;
            const auto table=reinterpret_cast<const Word*>(*candidate);
            if(table&&(table[1]==0x532650u||table[1]==static_cast<Word>(reinterpret_cast<std::uintptr_t>(&ResumeOptionReact)))){option=candidate;break;}
        }
        if(!option)return false;


        return OpenOwnedSafehouse(current);
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
void FinishEmptyAutoLoadBoot() {
    __try {
        const auto card=reinterpret_cast<void*(__cdecl*)()>(0x50EBF0u)();
        if(card&&reinterpret_cast<bool(__thiscall*)(void*)>(0x50EC40u)(card))
            reinterpret_cast<void(__thiscall*)(void*)>(0x518230u)(card);
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
}
void __fastcall MainMenuNotify(Word* screen,void*,Word message,Word* object,Word a,Word b) {
    if(BlockPrematureCareerInput(message))return;
    char slot[32]={};bool fresh=false;
    if(Scope()&&message==0x35F8620Bu&&Launch(slot,fresh)) {


        reinterpret_cast<void(__thiscall*)(Word*,Word,Word*,Word,Word)>(0x587D30u)(screen,message,object,a,b);
        FinishEmptyAutoLoadBoot();
        if(!freshAutoLoadSeen)NFSMWAP::Log(fresh?"AP STARTUP: empty-session profile prompt suppressed; creating native slot profile automatically.":"AP STARTUP: native boot complete; selecting this session slot explicitly before Resume.");
        freshAutoLoadSeen=true;return;
    }
    reinterpret_cast<void(__thiscall*)(Word*,Word,Word*,Word,Word)>(0x559FC0u)(screen,message,object,a,b);
}
void __fastcall NewCareerOptionReact(Word* option,void*,const char* package,Word message,Word* object,Word a,Word b) {


    if(Scope()&&message==NativeOptionPressed){
        startRequested=true;State s;
        if(Read(s)&&s.owned)firstCarResumeRequested=true;
        NFSMWAP::Log("AP STARTUP: native New Career button redirected to the existing slot Career.");return;
    }
    reinterpret_cast<void(__thiscall*)(Word*,const char*,Word,Word*,Word,Word)>(0x532750u)(option,package,message,object,a,b);
}
void __fastcall NewCareerEntry(void* career,void*,bool enter) {
    if(!Scope()){reinterpret_cast<void(__thiscall*)(void*,bool)>(0x5A3950u)(career,enter);return;}


    startRequested=true;NFSMWAP::Log("AP STARTUP: native New Career gameplay transition suppressed.");
}
void __fastcall ResumeCareerEntry(void* career,void*) {
    State s;if(Scope()&&(!profileReady||(Read(s)&&(!s.owned||s.rank==16u||!IntroComplete(s)||(savePending&&!routed))))){startRequested=true;return;}
    if(Scope()&&Read(s)&&s.flow==3){OpenOwnedSafehouse(s);return;}
    reinterpret_cast<void(__thiscall*)(void*)>(0x57F570u)(career);
}
void __fastcall ResumeOptionReact(Word* option,void*,const char* package,Word message,Word* object,Word a,Word b) {
    State s;if(Scope()&&(!profileReady||(Read(s)&&(!s.owned||s.rank==16u||!IntroComplete(s)||(savePending&&!routed))))){startRequested=true;return;}
    if(Scope()&&message==NativeOptionPressed){if(Read(s))OpenOwnedSafehouse(s);return;}
    reinterpret_cast<void(__thiscall*)(Word*,const char*,Word,Word*,Word,Word)>(0x532650u)(option,package,message,object,a,b);
}
void __fastcall CareerMenuNotify(Word* screen,void*,Word message,Word* object,Word a,Word b) {
    if(BlockPrematureCareerInput(message))return;
    if(Scope()&&resumePending&&message==0x35F8620Bu){resumeScreen=screen;resumeTable=*screen;}
    reinterpret_cast<void(__thiscall*)(Word*,Word,Word*,Word,Word)>(0x532570u)(screen,message,object,a,b);
}
struct Patch {Word address,old,value;};
#if defined(NFSMWAP_BOOTSTRAP_HOST_FIXTURE)
bool VerifyNativeCareerIntro() {return ::g_hostIntroSignatureValid;}
#else
bool VerifyNativeCareerIntro() {
    __try {
        const unsigned char setter[]={0x83,0x49,0x04,0x20,0xC3};
        const unsigned char getter[]={0x8B,0x41,0x04,0xC1,0xE8,0x05,0x24,0x01,0xC3};
        const unsigned char transition[]={0x8B,0x82,0xAC,0x00,0x00,0x00,0xC1,0xE8,0x05,0x24,0x01,0xC3};
        const unsigned char optionMessage[]={0x81,0x7C,0x24,0x08,0x10,0x72,0x40,0x0C};
        return std::memcmp(reinterpret_cast<const void*>(0x50E350u),setter,sizeof(setter))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x5660B0u),getter,sizeof(getter))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x6124C5u),transition,sizeof(transition))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x532650u),optionMessage,sizeof(optionMessage))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x532750u),optionMessage,sizeof(optionMessage))==0;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
#endif
bool VerifyNativeSafehouseSpawn() {
#if defined(NFSMWAP_BOOTSTRAP_HOST_FIXTURE)
    return ::g_hostBypassSignatureValid;
#else
    __try {
        const unsigned char attribute[]={0x8B,0x49,0x04,0x85,0xC9,0x74,0x05,0xE9,0x74,0xF9,0xFF,0xFF};
        const unsigned char collection[]={0xA1,0xBC,0xDC,0x90,0,0x56,0x8B,0x70,0x04,0x8B,0x44,0x24};
        const unsigned char setMarker[]={0x8B,0x44,0x24,0x04,0x89,0x81,0x0C,0x01,0,0,0xC2,0x04,0};
        const unsigned char generalMarker[]={0x8B,0x44,0x24,0x04,0x89,0x81,0x08,0x01,0,0,0xC2,0x04,0};
        const unsigned char select[]={0xC6,0x81,0x10,0x01,0,0,0x01,0xC3};
        const unsigned char overrideMarker[]={0x8B,0x44,0x24,0x04,0x89,0x81,0x1C,0x01,0,0,0xC2,0x04,0};
        const unsigned char resolve[]={0x8A,0x86,0x10,0x01,0,0,0x84,0xC0,0x57,0x74,0x08,0x8B,0xBE,0x0C,0x01,0,0,0xEB,0x06,0x8B,0xBE,0x08,0x01,0,0};
        const unsigned char hideIcon[]={0x8B,0x81,0xC0,0,0,0,0x85,0xC0,0x74,0x0E,0x80,0x60,0x02,0xFE};
        const unsigned char parent[]={0x68,0xBB,0x27,0x64,0x32,0x8B,0xCD,0xE8,0x98,0x0A,0xFE,0xFF};
        const unsigned char icon[]={0x6A,0,0x6A,0,0x52,0x6A,0x08};
        const unsigned char zoneMarker[]={0x8B,0x4C,0x24,0x08,0x6A,0,0x68,0xCD,0xF4,0x41,0x22,0x83,0xC1,0x04,0xE8,0xB4,0x27,0xE4,0xFF};
        const unsigned char isA[]={0x64,0xA1,0,0,0,0,0x6A,0xFF,0x68,0xC0,0x4F,0x87,0,0x50,0x64,0x89};
        return std::memcmp(reinterpret_cast<void*>(0x454810u),attribute,sizeof(attribute))==0&&
            std::memcmp(reinterpret_cast<void*>(0x455FD0u),collection,sizeof(collection))==0&&
            std::memcmp(reinterpret_cast<void*>(0x5DAA30u),setMarker,sizeof(setMarker))==0&&
            std::memcmp(reinterpret_cast<void*>(0x5DAA10u),generalMarker,sizeof(generalMarker))==0&&
            std::memcmp(reinterpret_cast<void*>(0x604180u),select,sizeof(select))==0&&
            std::memcmp(reinterpret_cast<void*>(0x50E990u),overrideMarker,sizeof(overrideMarker))==0&&
            std::memcmp(reinterpret_cast<void*>(0x5E4D58u),resolve,sizeof(resolve))==0&&
            std::memcmp(reinterpret_cast<void*>(0x601E0Cu),parent,sizeof(parent))==0&&
            std::memcmp(reinterpret_cast<void*>(0x5E2D30u),hideIcon,sizeof(hideIcon))==0&&
            std::memcmp(reinterpret_cast<void*>(0x601E24u),icon,sizeof(icon))==0&&
            std::memcmp(reinterpret_cast<void*>(0x612049u),zoneMarker,sizeof(zoneMarker))==0&&
            std::memcmp(reinterpret_cast<void*>(0x5E28B0u),isA,sizeof(isA))==0&&
            *reinterpret_cast<const Word*>(0x8F3B58u)==8u&&*reinterpret_cast<const Word*>(0x8F3B60u)==0x8A01ECu&&
            *reinterpret_cast<const unsigned char*>(0x532015u)==0xE8u&&
            0x53201Au+*reinterpret_cast<const Word*>(0x532016u)==0x56C5B0u&&
            *reinterpret_cast<const unsigned char*>(0x5E4E08u)==0xE8u&&
            0x5E4E0Du+*reinterpret_cast<const Word*>(0x5E4E09u)==0x5E4CF0u;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
#endif
}
bool VerifyNativeSafehouseRoute() {
#if defined(NFSMWAP_BOOTSTRAP_HOST_FIXTURE)
    return ::g_hostBypassSignatureValid;
#else
    __try {
        const unsigned char reset[]={0xC7,0x81,0x2C,0x01,0,0,0,0,0,0,0xC3};
        const unsigned char set[]={0x8B,0x91,0x2C,0x01,0,0,0x8B,0x44,0x24,0x04,0x0B,0xD0};
        const unsigned char garage[]={0x8B,0x41,0x18,0x8B,0x54,0x24,0x04,0x89,0x41,0x1C,0x89,0x51,0x18,0xC2,0x04,0};
        const unsigned char resumeGarage[]={0x6A,0x02,0xE8,0xD1,0x76,0xF9,0xFF,0x8B,0xC8,0xE8,0xEA,0x76,0xF9,0xFF};
        return std::memcmp(reinterpret_cast<const void*>(0x50E500u),reset,sizeof(reset))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x50E4C0u),set,sizeof(set))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x516E30u),garage,sizeof(garage))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x57F738u),resumeGarage,sizeof(resumeGarage))==0;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
#endif
}


#if defined(NFSMWAP_BOOTSTRAP_HOST_FIXTURE)
bool VerifyNativePrologueBypass() {return ::g_hostBypassSignatureValid;}
#else
bool VerifyNativePrologueBypass() {
    __try {
        const unsigned char exitBranch[]={0xA0,0x26,0x61,0x92,0x00,0x84,0xC0,0x0F,0x85,0x8D,0x00,0x00,0x00};
        const unsigned char introBranch[]={0x80,0x3D,0x25,0x61,0x92,0x00,0x01,0x74,0x2F};
        const unsigned char getter[]={0x8B,0x41,0x2C,0xC3};
        const unsigned char classifier[]={0x56,0x8B,0xF1,0x8B,0x46,0x04,0x85,0xC0,0x74,0x0A,
            0x8B,0x40,0x18,0xC1,0xE8,0x04,0x24,0x01,0x5E,0xC3};
        const unsigned char clear[]={0x53,0x56,0x8B,0xF1,0x8B,0x46,0x2C,0x33,0xDB,0x3B,0xC3,0x74,0x0D,
            0x38,0x58,0x1D,0x74,0x08,0x50,0x8B,0xCE,0xE8,0x86,0xFF,0xFF,0xFF,
            0x89,0x5E,0x2C,0x89,0x5E,0x30,0x5E,0x5B,0xC3};
        return std::memcmp(reinterpret_cast<const void*>(0x531F7Bu),exitBranch,sizeof(exitBranch))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x612499u),introBranch,sizeof(introBranch))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x5DCA00u),getter,sizeof(getter))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x5FBD20u),classifier,sizeof(classifier))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x5DC9D0u),clear,sizeof(clear))==0;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
#endif
#if defined(NFSMWAP_BOOTSTRAP_HOST_FIXTURE)
bool VerifyNativeSlotLoad() {return ::g_hostSlotLoadSignatureValid;}
#else
bool VerifyNativeSlotLoad() {
    __try {
        const unsigned char entry[]={0x53,0x56,0x57,0x8B,0xF1};
        const unsigned char decode[]={0x8B,0x44,0x24,0x0C,0x85,0xC0,0x56,0x8B,0xF1};
        const unsigned char failedScreen[]={0x8B,0x82,0xCC,0,0,0,0x8B,0x48,0x10};
        const unsigned char messages[]={0x8A,0x44,0x24,0x04,0x33,0xD2,0x84,0xC0,0x0F,0x94,0xC2,0x6A,0xFF,0x88,0x41,0x1A,0x8B,0x89,0xC8,0,0,0,0x52};
        const unsigned char messageThunk[]={0x55,0x8B,0xEC,0x8B,0x09,0x5D,0xE9,0x27,0x1F,0,0};
        const unsigned char hideMask[]={0x09,0x41,0x7C,0xF7,0xD0};
        const unsigned char disableMask[]={0x09,0x81,0x80,0,0,0};
        return std::memcmp(reinterpret_cast<const void*>(0x5189F0u),entry,sizeof(entry))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x518820u),messages,sizeof(messages))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x7F3CA0u),messageThunk,sizeof(messageThunk))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x7F5BDEu),hideMask,sizeof(hideMask))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x7F5BEBu),disableMask,sizeof(disableMask))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x5ACDD0u),decode,sizeof(decode))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x527114u),failedScreen,sizeof(failedScreen))==0&&
            *reinterpret_cast<const unsigned char*>(0x526D71u)==0xE8u&&
            0x526D76u+*reinterpret_cast<const std::int32_t*>(0x526D72u)==0x5ACDD0u&&
            *reinterpret_cast<const unsigned short*>(0x526D76u)==0xC084u;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
#endif
#if defined(NFSMWAP_BOOTSTRAP_HOST_FIXTURE)
bool VerifyNativeObjectiveUnlock() {return ::g_hostObjectiveUnlockSignatureValid;}
#else
bool VerifyNativeObjectiveUnlock() {
    __try {
        const unsigned char milestoneEntry[]={0x8B,0x91,0xA8,0,0,0,0x56,0x8B,0xB1,0xA4,0,0,0};
        const unsigned char trapEntry[]={0x8B,0x91,0xB0,0,0,0,0x56,0x8B,0xB1,0xAC,0,0,0};
        const unsigned char unlock[]={0x80,0x78,0x08,0x01,0x75,0x04,0xC6,0x40,0x08,0x02};
        const unsigned char activate[]={0x80,0x08,0x03};
        return std::memcmp(reinterpret_cast<const void*>(0x5E46F0u),milestoneEntry,sizeof(milestoneEntry))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x5E9D60u),trapEntry,sizeof(trapEntry))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x5E4730u),unlock,sizeof(unlock))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x5E9DA0u),activate,sizeof(activate))==0&&
            *reinterpret_cast<const unsigned char*>(0x62C347u)==0xE8u&&
            0x62C34Cu+*reinterpret_cast<const std::int32_t*>(0x62C348u)==0x5E46F0u&&
            *reinterpret_cast<const unsigned char*>(0x62C353u)==0xE8u&&
            0x62C358u+*reinterpret_cast<const std::int32_t*>(0x62C354u)==0x5E9D60u;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
#endif
#if defined(NFSMWAP_BOOTSTRAP_HOST_FIXTURE)
bool VerifyNativeBinProgress() {return ::g_hostBinProgressSignatureValid;}
#else
bool VerifyNativeBinProgress() {
    __try {
        const unsigned char getBin[]={0x53,0x55,0x56,0x8B,0xF1,0x8B,0x46,0x20};
        const unsigned char refresh[]={0x83,0xEC,0x08,0x53,0x55,0x56,0x33,0xED,0x57,0x8B,0xD9};
        const unsigned char careerWin[]={0x8B,0x41,0x04,0xD1,0xE8,0x24,0x01};
        const unsigned char awarded[]={0x80,0x7F,0x08,0x04,0x75,0x01,0x45};
        const unsigned char photo[]={0x8A,0x07,0xC0,0xE8,0x02,0xA8,0x01};
        const unsigned char milestones[]={0x0F,0xB7,0x41,0x18,0xC3},wins[]={0x0F,0xB7,0x41,0x1A,0xC3};
        return std::memcmp(reinterpret_cast<const void*>(0x5E3980u),getBin,sizeof(getBin))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x6010E0u),refresh,sizeof(refresh))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x601155u),careerWin,sizeof(careerWin))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x6011D0u),awarded,sizeof(awarded))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x601283u),photo,sizeof(photo))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x5DD1C0u),milestones,sizeof(milestones))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x5DD1D0u),wins,sizeof(wins))==0&&
            *reinterpret_cast<const unsigned char*>(0x52EE6Eu)==0xE8u&&
            0x52EE73u+*reinterpret_cast<const std::int32_t*>(0x52EE6Fu)==0x5DD1D0u&&
            *reinterpret_cast<const unsigned char*>(0x52EE80u)==0xE8u&&
            0x52EE85u+*reinterpret_cast<const std::int32_t*>(0x52EE81u)==0x5DD1C0u;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
#endif


#if defined(NFSMWAP_BOOTSTRAP_HOST_FIXTURE)
bool VerifyNativeObjectiveMap() {return ::g_hostObjectiveMapSignatureValid;}
#else
bool VerifyNativeObjectiveMap() {
    __try {
        const unsigned char refresh[]={0x51,0x8B,0x81,0xB0,0,0,0,0x89,0x0C,0x24};
        const unsigned char active[]={0x66,0x8B,0x0B,0x8A,0xD1,0xD0,0xEA,0xF6,0xC2,0x01};
        const unsigned char visible[]={0x83,0xEC,0x18,0x53,0x55,0x57,0x8B,0xF9};
        const unsigned char gather[]={0x8B,0x87,0xC0,0x02,0,0};
        const unsigned char add[]={0x81,0xEC,0x28,0x03,0,0,0xA1,0x84,0xD8,0x92,0};
        const unsigned char setup[]={0x6A,0xFF,0x64,0xA1,0,0,0,0};
        const unsigned char ordinary[]={0x6A,0x0A,0x8B,0xCF};
        const unsigned char pursuit[]={0x6A,0x0C,0x8B,0xCE};
        return std::memcmp(reinterpret_cast<const void*>(0x5E9DE0u),refresh,sizeof(refresh))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x5E9E3Du),active,sizeof(active))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x5FDAE0u),visible,sizeof(visible))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x5E4996u),gather,sizeof(gather))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x5486A0u),add,sizeof(add))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x55B8C0u),setup,sizeof(setup))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x55BC59u),ordinary,sizeof(ordinary))==0&&
            std::memcmp(reinterpret_cast<const void*>(0x548880u),pursuit,sizeof(pursuit))==0&&
            *reinterpret_cast<const unsigned char*>(0x55BCF1u)==0xE8u&&
            0x55BCF6u+*reinterpret_cast<const std::int32_t*>(0x55BCF2u)==0x5A5EA0u&&
            *reinterpret_cast<const unsigned char*>(0x55BCF8u)==0xE8u&&
            0x55BCFDu+*reinterpret_cast<const std::int32_t*>(0x55BCF9u)==0x5488B0u;
    } __except(EXCEPTION_EXECUTE_HANDLER) {return false;}
}
#endif
bool FindSaveHandoff(std::vector<Patch>& patches) {
    Patch found{};unsigned count=0;


    for(Word p=0x562AB0u;p+5u<=0x562B1Du;++p) {
        const auto opcode=*reinterpret_cast<unsigned char*>(p);
        if(opcode!=0xE8u&&opcode!=0xE9u)continue;
        const auto old=*reinterpret_cast<std::int32_t*>(p+1u);
        if(p+5u+old!=0x518840u)continue;
        found={p+1u,static_cast<Word>(old),static_cast<Word>(reinterpret_cast<std::uintptr_t>(&SubmitSlotSave)-p-5u)};
        ++count;p+=4u;
    }
    if(count==1u) {
        slotSaveRoute=SlotSaveRoute::HookedCardHandoff;
        patches.push_back(found);
        NFSMWAP::Log("AP STARTUP SAVE HANDOFF: unique direct CheckCard branch verified; native autosave setup will be used.");
    } else {


        if(!VerifyRetailAutosave()) {
            NFSMWAP::Log("AP STARTUP SAVE GUARD FAILED: retail StartAutoSave entry or DoAutoSave call did not match the uploaded speed.exe.");
            return false;
        }
        slotSaveRoute=SlotSaveRoute::VerifiedRetailAutoSave;
        NFSMWAP::Log("AP STARTUP SAVE HANDOFF: native CheckCard branches="+std::to_string(count)+
            "; verified retail StartAutoSave -> DoAutoSave; native flags and profile validation retained.");
    }
    return true;
}
bool Write(const Patch& p) {
    DWORD old=0,unused=0;if(*reinterpret_cast<Word*>(p.address)!=p.old||!VirtualProtect(reinterpret_cast<void*>(p.address),4,PAGE_EXECUTE_READWRITE,&old))return false;
    *reinterpret_cast<Word*>(p.address)=p.value;VirtualProtect(reinterpret_cast<void*>(p.address),4,old,&unused);
    FlushInstructionCache(GetCurrentProcess(),reinterpret_cast<void*>(p.address),4);return true;
}
bool Install() {
    if(hooksReady)return true;
    if(!VerifyNativeCareerIntro()||!VerifyNativeSafehouseRoute()||!VerifyNativeSafehouseSpawn()||!VerifyNativePrologueBypass()||!VerifyNativeSlotLoad()||!VerifyNativeObjectiveUnlock()||!VerifyNativeBinProgress()||!VerifyNativeObjectiveMap()) {
        NFSMWAP::Log("AP STARTUP GUARD FAILED: native intro, safehouse spawn, saved-slot load or objective-unlock instructions differ from the supported executable.");return false;
    }
    std::vector<Patch> patches;unsigned starts=0,resumes=0;
    patches.push_back({0x526D72u,static_cast<Word>(0x5ACDD0u-0x526D76u),
        static_cast<Word>(reinterpret_cast<std::uintptr_t>(&AcceptLoadedSlot)-0x526D76u)});
    patches.push_back({0x532016u,static_cast<Word>(0x56C5B0u-0x53201Au),
        static_cast<Word>(reinterpret_cast<std::uintptr_t>(&StartFreeRoamFromSafehouse)-0x53201Au)});
    patches.push_back({0x5E4E09u,static_cast<Word>(0x5E4CF0u-0x5E4E0Du),
        static_cast<Word>(reinterpret_cast<std::uintptr_t>(&ResolveSafehouseRespawn)-0x5E4E0Du)});
    for(Word p=0x500000u;p+5u<0x5C0000u;++p)if(*reinterpret_cast<unsigned char*>(p)==0xE8u) {
        const auto old=*reinterpret_cast<std::int32_t*>(p+1u);const Word target=p+5u+old;const void* hook=nullptr;
        if(target==0x5A3950u){hook=reinterpret_cast<const void*>(&NewCareerEntry);++starts;}
        else if(target==0x57F570u){hook=reinterpret_cast<const void*>(&ResumeCareerEntry);++resumes;}
        else if(target==0x526AC0u)hook=reinterpret_cast<const void*>(&SaveDone);
        else if(target==0x526F60u)hook=reinterpret_cast<const void*>(&SaveFailed);
        if(hook){patches.push_back({p+1u,static_cast<Word>(old),static_cast<Word>(reinterpret_cast<std::uintptr_t>(hook)-p-5u)});p+=4u;}
    }
    if(!FindSaveHandoff(patches))return false;


    const Patch virtuals[]={
        {0x89EAD8u,0x559FC0u,static_cast<Word>(reinterpret_cast<std::uintptr_t>(&MainMenuNotify))},
        {0x89E768u,0x532570u,static_cast<Word>(reinterpret_cast<std::uintptr_t>(&CareerMenuNotify))},
        {0x89C454u,0x532650u,static_cast<Word>(reinterpret_cast<std::uintptr_t>(&ResumeOptionReact))},
        {0x89C45Cu,0x532750u,static_cast<Word>(reinterpret_cast<std::uintptr_t>(&NewCareerOptionReact))},
        {0x89CD88u,0x526AC0u,static_cast<Word>(reinterpret_cast<std::uintptr_t>(&SaveDone))},
        {0x89CDACu,0x526F60u,static_cast<Word>(reinterpret_cast<std::uintptr_t>(&SaveFailed))},
        {0x89E73Cu,0x55B8C0u,static_cast<Word>(reinterpret_cast<std::uintptr_t>(&ObjectiveWorldMapSetup))}
    };
    for(const auto& p:virtuals) {
        if(*reinterpret_cast<Word*>(p.address)!=p.old) {
            NFSMWAP::Log("AP STARTUP GUARD VALIDATION FAILED: native virtual slot="+std::to_string(p.address)+
                " expected="+std::to_string(p.old)+" actual="+std::to_string(*reinterpret_cast<Word*>(p.address)));return false;
        }
        patches.push_back(p);
    }
    if(!starts||!resumes||patches.size()>128u) {
        NFSMWAP::Log("AP STARTUP GUARD VALIDATION FAILED: new="+std::to_string(starts)+" resume="+std::to_string(resumes)+
            " patches="+std::to_string(patches.size()));return false;
    }
    std::size_t n=0;for(;n<patches.size();++n)if(!Write(patches[n]))break;
    if(n!=patches.size()){
        NFSMWAP::Log("AP STARTUP GUARD PATCH FAILED: address="+std::to_string(patches[n].address));
        while(n){const auto p=patches[--n];Write({p.address,p.value,p.old});}return false;
    }
    if(!EnableNativePrologueSkip()) {
        while(n){const auto p=patches[--n];Write({p.address,p.value,p.old});}
        NFSMWAP::Log("AP STARTUP PROLOGUE BYPASS FAILED: native skip controls could not be enabled.");return false;
    }
    hooksReady=true;
    NFSMWAP::Log("NFSMW_AP_DEALERSHIP_BOOT_V23: home markers independent of map visibility; retained exit marker returned at world spawn; isolated reload retained.");return true;
}
}
namespace NFSMWAP {
bool InstallCareerBootstrapHooks(){return !Scope()||Install();}
bool InitialDealershipNeedsCar(){return needsCar;}
bool InitialDealershipSelectionPending(){return Scope()&&routed&&!startupFinished&&!resumePending&&!firstCarResumeRequested;}
bool IsCareerProfileReady(){return !Scope()||profileReady.load();}
const char* CareerLoadStatusText() {
    if(!Scope())return nullptr;
    switch(loadStage.load()) {
        case LoadStage::Reading:return "AP: LOADING YOUR SAVE";
        case LoadStage::Accepted:return "AP: RESTORING YOUR CAREER";
        case LoadStage::Failed:return "AP: SAVE LOAD FAILED - SAVE KEPT - SEE LOG";
        default:return nullptr;
    }
}
void NotifyInitialCareerCarSelected(){if(Scope()&&routed)firstCarResumeRequested=true;}
void CareerBootstrapMainThreadTick() {
    if(!Scope()||!hooksReady)return;
    PollSlotLoad();
    if(!IsBridgeConnected()||!IsDealershipFirstStart()||!NativeShopsEnabled())return;
    char slot[32]={};bool fresh=false;if(!Launch(slot,fresh))return;
    State s;
    if(!Read(s)){progressFlow=s.flow;return;}
    if(s.flow==6 && progressFlow!=6)progressWorldPending=true;
    progressFlow=s.flow;
    if(!fresh&&!FinishSlotLoad(s,slot)) {
        if(s.flow==3&&freshAutoLoadSeen&&loadStage==LoadStage::Idle)StartSlotLoad(slot);
        return;
    }
    if(s.flow==3&&s.loaded&&s.started&&std::strncmp(reinterpret_cast<const char*>(s.profile),slot,32)==0) {
        if(!EnableNativePrologueSkip())return;
        bool cleared=false;if(!ClearQueuedPrologue(cleared))return;
        if(cleared)Log("AP PROLOGUE BYPASS: removed a queued DDay startup race through native cleanup; normal race requests retained.");
    }
    if(profileReady&&s.loaded&&s.started&&s.rank>=1u&&s.rank<=15u&&
       std::strncmp(reinterpret_cast<const char*>(s.profile),slot,32)==0&&IdleCard()&&!saveRequested) {
        const auto now=GetTickCount();
        const bool identityChanged=!progressRefreshSeen||progressProfile!=s.profile||progressRank!=s.rank;
        const bool repairDue=identityChanged || (s.flow==6 && progressWorldPending) ||
            (s.flow==3 && now-lastProgressRefresh>=1000u);
        if(repairDue) {
            unsigned milestones=0,cameras=0;
            if(EnableCurrentObjectives(s,milestones,cameras)) {
                if(!savePending){savePending=true;saveRequested=false;saveWaitLogged=false;saveStage=SaveStage::Idle;}
                Log("AP CURRENT OBJECTIVES ENABLED: Blacklist #"+std::to_string(s.rank)+
                    " milestones="+std::to_string(milestones)+" photo_traps="+std::to_string(cameras)+
                    "; existing completion preserved; native save queued.");
            }
            BinProgress progress;
            if(RebuildCurrentBinProgress(s,progress)) {
                progressRefreshSeen=true;progressProfile=s.profile;progressRank=s.rank;lastProgressRefresh=now;
                if(s.flow==6){RefreshObjectiveMapIcons(s);progressWorldPending=false;}
                if(progress.wins!=progress.oldWins||progress.milestones!=progress.oldMilestones) {
                    if(!savePending){savePending=true;saveRequested=false;saveWaitLogged=false;saveStage=SaveStage::Idle;}
                    Log("AP BIN PROGRESS REBUILT: Blacklist #"+std::to_string(s.rank)+
                        " race_wins="+std::to_string(progress.oldWins)+"->"+std::to_string(progress.wins)+
                        " milestones="+std::to_string(progress.oldMilestones)+"->"+std::to_string(progress.milestones)+
                        "; native completion records retained; saving corrected counters.");
                }
            }
        }
    }
    if(needsCar&&s.owned){
        needsCar=false;


        if(savePending){if(saveRequested)saveAgain=true;}
        else {savePending=true;saveRequested=false;saveWaitLogged=false;saveStage=SaveStage::Idle;}
    }
    if(savePending) {
        if(saveRequested&&saveStage==SaveStage::Complete&&IdleCard()&&SlotSaveExists(slot)) {
            saveRequested=false;saveWaitLogged=false;saveStage=SaveStage::Idle;
            if(saveAgain){
                saveAgain=false;
                Log("AP SLOT SAVE FOLLOW-UP: initial write completed; queuing the car received during saving.");
            } else {
                savePending=false;
                Log("AP SLOT SAVE READY: native callback completed and engine-written slot profile '"+std::string(slot)+"' exists in this session.");
            }
        } else if(!saveRequested&&saveStage==SaveStage::Idle) {
            if(SaveNamedProfile(s,slot)) {
                Log("AP SLOT SAVE REQUESTED: native async save for '"+std::string(slot)+"'.");
                if(saveStage==SaveStage::Failed)Log("AP SLOT SAVE REFUSED: native slot-save request failed; see the preceding native diagnostic.");
                saveRequested=true;lastSaveTry=GetTickCount();
            }
        } else if(!saveWaitLogged&&(saveStage==SaveStage::Failed||GetTickCount()-lastSaveTry>=5000u)) {
            saveWaitLogged=true;
            Log("AP SLOT SAVE WAIT: stage="+std::string(SaveStageName())+
                " slot_file="+(SlotSaveExists(slot)?"present":"missing")+
                "; retaining frontend startup; no overlapping save request will be issued.");
            if(saveStage==SaveStage::Complete)LogSaveDirectoryContents(slot);
        }
    }
    if(s.flow!=3)return;
    std::string package;if(!GetNativeStorePackage(package))return;
    const bool main=package=="MainMenu.fng"||package=="MainMenu_Sub.fng"||package=="CareerMain.fng";if(!main)return;
    if(firstCarResumeRequested) {
        if(savePending||needsCar||!s.owned||!SlotSaveExists(slot))return;
        if(std::strncmp(reinterpret_cast<const char*>(s.profile),slot,32)!=0) {
            if(!waitLogged){waitLogged=true;Log("AP FIRST CAR BLOCKED: active profile does not match the session slot.");}return;
        }
        if(!IdleCard())return;
        bool changed=false;if(!CompleteCareerIntro(s,changed))return;
        if(changed) {
            savePending=true;saveRequested=false;saveWaitLogged=false;saveStage=SaveStage::Idle;
            Log("AP FIRST CAR: saving repaired intro state before native Resume.");return;
        }


        if(Route(s,"MainMenu_Sub.fng",CareerFrontend::Manager)) {
            firstCarResumeRequested=false;resumePending=true;startupFinished=false;resumeScreen=nullptr;
            Log("AP FIRST CAR: saved owned car routed to native Resume; waiting for Career menu initialization.");
        }
        return;
    }
    if(resumePending){if(ResumeNative())Log("AP STARTUP: existing owned slot Career opened at native safehouse; no dealership or gameplay detour.");return;}
    if(startupFinished||routed)return;
    if(!prepared) {


        if(fresh&&!freshAutoLoadSeen)return;
        if(!fresh&&!s.loaded)return;
        if(s.loaded&&s.started&&s.owned&&s.rank<=16u) {
            if(std::strncmp(reinterpret_cast<const char*>(s.profile),slot,32)!=0) {
                if(!waitLogged){waitLogged=true;Log("AP STARTUP BLOCKED: loaded profile name does not match the session slot.");}return;
            }
            if(savePending)return;
            if((!IntroComplete(s)||s.rank==16u)&&!IdleCard())return;
            bool changed=false;
            if(!CompleteCareerIntro(s,changed)) {
                if(!waitLogged){waitLogged=true;Log("AP STARTUP BLOCKED: native Career intro completion could not be verified.");}return;
            }
            if(changed) {
                savePending=true;saveRequested=false;saveWaitLogged=false;saveStage=SaveStage::Idle;
                Log("AP STARTUP INTRO REPAIR: preserving the owned car and Career; saving native intro-completed state before Resume.");return;
            }
            if(Route(s,"MainMenu_Sub.fng",CareerFrontend::Manager)){resumePending=true;resumeScreen=nullptr;}return;
        }
        if(s.owned)return;
        if(!fresh) {


            if(!s.loaded||!s.started||std::strncmp(reinterpret_cast<const char*>(s.profile),slot,32)!=0)return;
            prepared=true;needsCar=true;return;
        }
        if(SlotSaveExists(slot)) {
            if(!waitLogged){waitLogged=true;Log("AP STARTUP BLOCKED: a slot file appeared during fresh startup; refusing to replace it.");}return;
        }
        if(!IdleCard()||!Prepare(s,slot,true))return;
        profileReady=true;
        prepared=true;needsCar=true;savePending=true;saveRequested=false;
        Log("AP STARTUP: slot Career initialized at Blacklist #15 with $30,000 starting cash; waiting for native save before dealership.");return;
    }
    if(savePending||!SlotSaveExists(slot))return;
    if(Route(s,"Car_Select.fng")){routed=true;Log("AP CAREER START: saved slot profile ready; dealership opened without prologue, starter car or AP check.");}
}
}
