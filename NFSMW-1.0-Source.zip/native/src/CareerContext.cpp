#include "CareerContext.h"

#include <atomic>
#include <cstdlib>
#include <Windows.h>
#include <cstdint>
#include <sstream>
#include "BridgeClient.h"
#include "ConnectionSetup.h"
#include "JsonLite.h"

namespace
{
    std::atomic<int> g_lastCareerRank{0};
    std::atomic<int> g_activeRivalRank{0};

    int ReadLiveCareerRank()
    {
        __try
        {
            const auto database=*reinterpret_cast<std::uint32_t*>(0x91CF90u);
            if (!database) return 0;
            const auto flags=*reinterpret_cast<std::uint32_t*>(database+0x12Cu);
            if (!(flags&0x8001u) || (flags&0xEu)) return 0;
            const auto profile=*reinterpret_cast<std::uint32_t*>(database+0x10u);
            if (profile<0x10000u || (profile&3u)) return 0;

            const auto rank=*reinterpret_cast<unsigned char*>(profile+0xA8u+8u);
            return rank>=1 && rank<=15 ? rank : 0;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return 0; }
    }

    bool ReadNamedProfile(char (&name)[32])
    {
        __try
        {
            const auto database=*reinterpret_cast<std::uint32_t*>(0x91CF90u);
            if (!database) return false;
            const auto profile=*reinterpret_cast<std::uint32_t*>(database+0x10u);
            if (profile<0x10000u || (profile&3u) ||
                !*reinterpret_cast<unsigned char*>(profile+0x20u)) return false;
            const auto source=reinterpret_cast<const char*>(profile);
            for (unsigned i=0;i<32;++i)
            {
                name[i]=source[i];
                if (!name[i]) return i!=0;
            }
            return false;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    bool ParseCareerEventID(const std::string& eventId, int& rank, int& variant)
    {
        rank = 0;
        variant = 0;

        const std::size_t firstDot = eventId.find('.');
        if (firstDot == std::string::npos || firstDot == 0)
            return false;

        const std::size_t secondDot = eventId.find('.', firstDot + 1);
        if (secondDot == std::string::npos || secondDot + 1 >= eventId.size())
            return false;

        const std::string rankText = eventId.substr(0, firstDot);
        const std::string variantText = eventId.substr(secondDot + 1);

        char* end = nullptr;
        const long parsedRank = std::strtol(rankText.c_str(), &end, 10);
        if (!end || *end != '\0' || parsedRank < 1 || parsedRank > 15)
            return false;

        end = nullptr;
        const long parsedVariant = std::strtol(variantText.c_str(), &end, 10);
        if (!end || *end != '\0' || parsedVariant < 0 || parsedVariant > 99)
            return false;

        rank = static_cast<int>(parsedRank);
        variant = static_cast<int>(parsedVariant);
        return true;
    }
}

namespace NFSMWAP
{
    void ObserveCareerEventID(const std::string& eventId)
    {
        int rank = 0;
        int variant = 0;
        if (!ParseCareerEventID(eventId, rank, variant))
            return;

        g_lastCareerRank.store(rank);


        g_activeRivalRank.store(variant != 1 ? rank : 0);
    }

    int GetLastCareerRank()
    {
        const int live=ReadLiveCareerRank();
        return live ? live : g_lastCareerRank.load();
    }

    bool IsLiveCareerMode() { return ReadLiveCareerRank()!=0; }

    void CareerContextMainThreadTick()
    {
        if (IsConnectionSetupOnly() || !IsBridgeConnected()) return;
        static DWORD lastTick=0;
        const DWORD now=GetTickCount();
        if (lastTick && now-lastTick<1000u) return;
        lastTick=now;
        const int rank=ReadLiveCareerRank();
        if (!rank) return;
        char name[32]={};
        const bool named=ReadNamedProfile(name);
        std::string profileName;
        if (named)
        {
            wchar_t wide[64]={};
            char utf8[256]={};
            const int characters=MultiByteToWideChar(CP_ACP,0,name,-1,wide,64);
            if (characters>0 && WideCharToMultiByte(CP_UTF8,0,wide,characters,utf8,256,nullptr,nullptr)>0)
                profileName=utf8;
        }
        std::ostringstream message;
        message << "{\"type\":\"career_context\",\"career_mode\":true,\"blacklist_rank\":"
                << rank << ",\"profile_name\":\""
                << JsonLite::Escape(profileName) << "\"}";
        SendBridgeLine(message.str());
    }

    int GetActiveRivalRank()
    {
        return g_activeRivalRank.load();
    }

    void ClearActiveRivalRank()
    {
        g_activeRivalRank.store(0);
    }
}
