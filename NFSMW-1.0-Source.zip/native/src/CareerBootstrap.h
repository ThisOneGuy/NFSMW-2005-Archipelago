#pragma once
namespace NFSMWAP {
    bool InstallCareerBootstrapHooks();
    void CareerBootstrapMainThreadTick();
    bool InitialDealershipNeedsCar();
    bool InitialDealershipSelectionPending();
    bool IsCareerProfileReady();
    const char* CareerLoadStatusText();
    void NotifyInitialCareerCarSelected();
}
