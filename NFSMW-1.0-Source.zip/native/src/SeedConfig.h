#pragma once

#include <string>

namespace NFSMWAP
{
    void ResetSeedConfig();
    void SetDealershipFirstStart(bool enabled);
    bool IsDealershipFirstStart();

    void SetSeedStartingCar(const std::string& car);
    void SetSeedStartingCarPrice(int price);
    void SetSeedOpponentCarConfig(bool randomize, int seed);
    void SetSeedBlacklistAppearanceConfig(bool enabled,int seed);
    void SetSeedBlacklistCar(int rank, const std::string& car);

    std::string GetSeedStartingCar();
    int GetSeedStartingCarPrice();
    std::string GetSeedBlacklistCar(int rank);
    bool GetSeedRandomizeOpponentCars();
    int GetSeedOpponentCarSeed();
    bool GetSeedRandomizeBlacklistAppearance();
    int GetSeedBlacklistAppearanceSeed();
    bool IsSeedConfigReady();
}
