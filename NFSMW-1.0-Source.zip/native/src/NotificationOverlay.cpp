#include "BlacklistNames.h"
#include "BountyRequirements.h"
#include "NativeVisualTreatment.h"
#include "NotificationOverlay.h"

#include <d3d9.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <cctype>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <deque>
#include <mutex>
#include <string>
#include <vector>

#include "CareerEventMonitor.h"
#include "DeathLinkRuntime.h"
#include "CashDelivery.h"
#include "NativeRewardUI.h"
#include "Logger.h"
#include "NativeShop.h"
#include "ConnectionSetup.h"
#include "PoliceBadge.h"
#include "NativeSMS.h"
#include "CareerContext.h"
#include "CareerBootstrap.h"
#include "TurboTrap.h"
#include "StoreRuntime.h"

namespace
{
    constexpr std::uintptr_t D3DDevicePointerAddress = 0x00982BDCu;
    constexpr int PresentVtableIndex = 17;
    constexpr int EndSceneVtableIndex = 42;

    struct Notification
    {
        std::string title;
        std::string line1;
        std::string line2;
        unsigned int durationMs = 5000;
    };

    struct Vertex
    {
        float x;
        float y;
        float z;
        float rhw;
        D3DCOLOR color;
    };

    using PresentFn = HRESULT (STDMETHODCALLTYPE*)(
        IDirect3DDevice9*,
        const RECT*,
        const RECT*,
        HWND,
        const RGNDATA*);
    using EndSceneFn = HRESULT (STDMETHODCALLTYPE*)(IDirect3DDevice9*);

    std::atomic_bool g_enabled{ true };
    std::atomic_bool g_apConnected{false};
    std::atomic<int> g_queuedChecks{0};
    std::atomic<DWORD> g_apStatusTick{0};

    bool HasConnectionBadge() { return g_enabled.load()||NFSMWAP::CareerLoadStatusText()!=nullptr; }
    bool MultiworldOnline()
    {
        return g_apConnected.load() && static_cast<DWORD>(GetTickCount()-g_apStatusTick.load())<6500u;
    }
    std::mutex g_notificationMutex;
    std::deque<Notification> g_queue;
    std::mutex g_storeOverlayMutex;
    NFSMWAP::StoreOverlayInfo g_storeOverlay;
    Notification g_current;
    bool g_hasCurrent = false;
    ULONGLONG g_currentStarted = 0;

    PresentFn g_originalPresent = nullptr;
    EndSceneFn g_originalEndScene = nullptr;
    void** g_hookedVtable = nullptr;

    std::atomic_bool g_presentHookFiredLogged{ false };
    std::atomic_bool g_endSceneHookFiredLogged{ false };
    std::atomic<DWORD> g_lastEndSceneTick{ 0 };
    std::atomic_bool g_firstSuccessfulDrawLogged{ false };
    std::atomic_bool g_firstDrawFailureLogged{ false };

    std::string SanitizeLine(const std::string& text, std::size_t maxChars)
    {
        std::string result;
        result.reserve(std::min(text.size(), maxChars));
        for (unsigned char raw : text)
        {
            if (result.size() >= maxChars)
                break;
            char c = static_cast<char>(raw);
            if (c == '\n' || c == '\r' || c == '\t')
                c = ' ';
            if (raw < 0x20 || raw >= 0x7F)
                c = '?';
            result.push_back(static_cast<char>(std::toupper(static_cast<unsigned char>(c))));
        }
        return result;
    }

    const std::array<unsigned char, 7>& Glyph(char c)
    {
        using G = std::array<unsigned char, 7>;
        static const G blank{ 0,0,0,0,0,0,0 };
        static const G unknown{ 14,17,1,2,4,0,4 };

        static const G A{14,17,17,31,17,17,17};
        static const G B{30,17,17,30,17,17,30};
        static const G C{14,17,16,16,16,17,14};
        static const G D{28,18,17,17,17,18,28};
        static const G E{31,16,16,30,16,16,31};
        static const G F{31,16,16,30,16,16,16};
        static const G glyphG{14,17,16,23,17,17,15};
        static const G H{17,17,17,31,17,17,17};
        static const G I{14,4,4,4,4,4,14};
        static const G J{7,2,2,2,18,18,12};
        static const G K{17,18,20,24,20,18,17};
        static const G L{16,16,16,16,16,16,31};
        static const G M{17,27,21,21,17,17,17};
        static const G N{17,25,21,19,17,17,17};
        static const G O{14,17,17,17,17,17,14};
        static const G P{30,17,17,30,16,16,16};
        static const G Q{14,17,17,17,21,18,13};
        static const G R{30,17,17,30,20,18,17};
        static const G S{15,16,16,14,1,1,30};
        static const G T{31,4,4,4,4,4,4};
        static const G U{17,17,17,17,17,17,14};
        static const G V{17,17,17,17,17,10,4};
        static const G W{17,17,17,21,21,21,10};
        static const G X{17,17,10,4,10,17,17};
        static const G Y{17,17,10,4,4,4,4};
        static const G Z{31,1,2,4,8,16,31};

        static const G N0{14,17,19,21,25,17,14};
        static const G N1{4,12,4,4,4,4,14};
        static const G N2{14,17,1,2,4,8,31};
        static const G N3{30,1,1,14,1,1,30};
        static const G N4{2,6,10,18,31,2,2};
        static const G N5{31,16,16,30,1,1,30};
        static const G N6{14,16,16,30,17,17,14};
        static const G N7{31,1,2,4,8,8,8};
        static const G N8{14,17,17,14,17,17,14};
        static const G N9{14,17,17,15,1,1,14};

        static const G dash{0,0,0,31,0,0,0};
        static const G underscore{0,0,0,0,0,0,31};
        static const G colon{0,4,4,0,4,4,0};
        static const G dot{0,0,0,0,0,6,6};
        static const G comma{0,0,0,0,6,6,4};
        static const G slash{1,1,2,4,8,16,16};
        static const G lparen{2,4,8,8,8,4,2};
        static const G rparen{8,4,2,2,2,4,8};
        static const G plus{0,4,4,31,4,4,0};
        static const G hash{10,31,10,10,31,10,0};
        static const G apostrophe{4,4,2,0,0,0,0};
        static const G amp{12,18,20,8,21,18,13};
        static const G exclaim{4,4,4,4,4,0,4};

        static const std::array<G,26> lower{{
            G{0,0,14,1,15,17,15},G{16,16,30,17,17,17,30},G{0,0,14,16,16,17,14},G{1,1,15,17,17,17,15},
            G{0,0,14,17,31,16,14},G{6,9,8,28,8,8,8},G{0,0,15,17,15,1,14},G{16,16,30,17,17,17,17},
            G{4,0,12,4,4,4,14},G{2,0,6,2,2,18,12},G{16,16,18,20,24,20,18},G{12,4,4,4,4,4,14},
            G{0,0,26,21,21,21,21},G{0,0,30,17,17,17,17},G{0,0,14,17,17,17,14},G{0,0,30,17,30,16,16},
            G{0,0,15,17,15,1,1},G{0,0,22,25,16,16,16},G{0,0,15,16,14,1,30},G{8,8,28,8,8,9,6},
            G{0,0,17,17,17,19,13},G{0,0,17,17,17,10,4},G{0,0,17,17,21,21,10},G{0,0,17,10,4,10,17},
            G{0,0,17,17,15,1,14},G{0,0,31,2,4,8,31}
        }};
        if(c>='a'&&c<='z')return lower[static_cast<unsigned>(c-'a')];

        switch (c)
        {
        case ' ': return blank;
        case 'A': return A; case 'B': return B; case 'C': return C;
        case 'D': return D; case 'E': return E; case 'F': return F;
        case 'G': return glyphG; case 'H': return H; case 'I': return I;
        case 'J': return J; case 'K': return K; case 'L': return L;
        case 'M': return M; case 'N': return N; case 'O': return O;
        case 'P': return P; case 'Q': return Q; case 'R': return R;
        case 'S': return S; case 'T': return T; case 'U': return U;
        case 'V': return V; case 'W': return W; case 'X': return X;
        case 'Y': return Y; case 'Z': return Z;
        case '0': return N0; case '1': return N1; case '2': return N2;
        case '3': return N3; case '4': return N4; case '5': return N5;
        case '6': return N6; case '7': return N7; case '8': return N8;
        case '9': return N9;
        case '-': return dash; case '_': return underscore; case ':': return colon;
        case '.': return dot; case ',': return comma; case '/': return slash;
        case '(': return lparen; case ')': return rparen; case '+': return plus;
        case '#': return hash; case '\'': return apostrophe; case '&': return amp;
        case '!': return exclaim; case '?': return unknown;
        default: return unknown;
        }
    }

    void AddRect(
        std::vector<Vertex>& vertices,
        float x,
        float y,
        float width,
        float height,
        D3DCOLOR color)
    {
        const float x2 = x + width;
        const float y2 = y + height;
        const Vertex a{x,  y,  0.0f, 1.0f, color};
        const Vertex b{x2, y,  0.0f, 1.0f, color};
        const Vertex c{x2, y2, 0.0f, 1.0f, color};
        const Vertex d{x,  y2, 0.0f, 1.0f, color};
        vertices.push_back(a); vertices.push_back(b); vertices.push_back(c);
        vertices.push_back(a); vertices.push_back(c); vertices.push_back(d);
    }

    void AddText(
        std::vector<Vertex>& vertices,
        const std::string& text,
        float x,
        float y,
        float scale,
        D3DCOLOR color)
    {
        float cursor = x;
        for (char c : text)
        {
            const auto& rows = Glyph(c);
            for (int row = 0; row < 7; ++row)
            {
                for (int col = 0; col < 5; ++col)
                {
                    const unsigned char mask = static_cast<unsigned char>(1u << (4 - col));
                    if ((rows[row] & mask) != 0)
                    {
                        AddRect(
                            vertices,
                            cursor + col * scale,
                            y + row * scale,
                            scale,
                            scale,
                            color);
                    }
                }
            }
            cursor += 6.0f * scale;
        }
    }


    void AddPoliceConnection(std::vector<Vertex>& vertices,const D3DVIEWPORT9& viewport,
                             const NFSMWAP::ConnectionView& view,bool canClose)
    {
        const float unit=std::min(viewport.Width/960.0f,viewport.Height/540.0f);
        const float ox=(viewport.Width-960.0f*unit)*0.5f,oy=(viewport.Height-540.0f*unit)*0.5f;
        const auto ink=D3DCOLOR_ARGB(255,171,225,59),dim=D3DCOLOR_ARGB(255,113,147,42);
        const auto black=D3DCOLOR_ARGB(255,0,0,0),focus=D3DCOLOR_ARGB(255,28,39,8);
        const auto rect=[&](float x,float y,float w,float h,D3DCOLOR color){AddRect(vertices,ox+x*unit,oy+y*unit,w*unit,h*unit,color);};
        const auto outline=[&](float x,float y,float w,float h,float line,D3DCOLOR color){
            rect(x,y,w,line,color);rect(x,y+h-line,w,line,color);rect(x,y,line,h,color);rect(x+w-line,y,line,h,color);
        };
        const auto clean=[](const std::string& value,std::size_t count,bool tail=false){
            std::string result;
            for(unsigned char c:value) result+=c>=32u && c<127u ? static_cast<char>(c) : '?';
            if(result.size()>count) result=tail ? "..."+result.substr(result.size()-(count-3)) : result.substr(0,count-3)+"...";
            return result;
        };
        const auto text=[&](const std::string& value,float x,float y,float size,D3DCOLOR color){
            AddText(vertices,value,ox+x*unit,oy+y*unit,size*unit,color);
        };
        const auto centered=[&](const std::string& value,float y,float size,D3DCOLOR color){
            text(value,(960.0f-value.size()*6.0f*size)*0.5f,y,size,color);
        };

        AddRect(vertices,0,0,static_cast<float>(viewport.Width),static_cast<float>(viewport.Height),black);


        for(const auto& triangle:NFSMWAP::PoliceBadge::Triangles) {
            for(const auto& point:{triangle.a,triangle.b,triangle.c})
                vertices.push_back({ox+(NFSMWAP::PoliceBadge::OriginX+point.x)*unit,
                    oy+(NFSMWAP::PoliceBadge::OriginY+point.y)*unit,0.0f,1.0f,ink});
        }
        centered("R O C K P O R T   P O L I C E   D E P A R T M E N T",176,1.85f,ink);
        centered("ARCHIPELAGO  /  MULTIWORLD ACCESS",202,1.25f,dim);
        outline(205,228,550,136,4,ink);
        const bool editable=view.phase=="input" || view.phase=="error";
        const std::array<std::string,4> labels{{"SERVER","SLOT NAME","PASSWORD","SEED (OPTIONAL)"}};
        const std::array<std::string,4> values{{view.server,view.slot,std::string(view.passwordMask.size(),'X'),
            !editable && !view.seed.empty() ? view.seed : view.expectedSeed}};
        for(int row=0;row<4;++row) {
            const float y=240.0f+row*29.0f;
            const bool selected=editable && view.field==row;
            if(selected) {rect(214,y-5,532,25,focus);rect(214,y-5,3,25,ink);}
            text(labels[row]+":",227,y,1.55f,selected ? ink : dim);
            std::string value=values[row];const bool empty=value.empty();
            if(empty) value=row==0 ? "SERVER:PORT" : row==1 ? "YOUR SLOT NAME" : row==2 ? "NOT REQUIRED" : "AUTO FROM SERVER";
            value=clean(value,36,selected);
            if(selected && !empty && value.size()<36) value+='_';
            text(value,409,y,1.55f,empty ? dim : ink);
        }
        std::string phase=editable ? (view.phase=="error" ? "CONNECTION FAILED" : "SIGN IN TO MULTIWORLD") :
            view.phase=="connecting" ? "SIGNING IN --/" : view.phase=="connected" ? "CONNECTED" : "OPENING YOUR CAREER";
        centered(phase,388,1.8f,ink);
        std::string message=view.status;
        if(message.empty() && (view.phase=="first_car" || view.phase=="relaunch"))
            message="BUY YOUR GUARANTEED CAR IN THE DEALERSHIP TO BEGIN.";

        std::vector<std::string> lines;message=clean(message,180);
        while(message.size()>83 && lines.size()<2) {
            auto end=message.rfind(' ',83);if(end==std::string::npos || !end)end=83;
            lines.push_back(message.substr(0,end));message.erase(0,end);if(!message.empty()&&message[0]==' ')message.erase(0,1);
        }
        if(!message.empty())lines.push_back(message);
        for(std::size_t n=0;n<lines.size();++n)centered(SanitizeLine(lines[n],83),414.0f+n*12.0f,1.25f,dim);
        for(float x=171;x<789;x+=10)rect(x,458,5,5,ink);
        const auto button=[&](const std::string& key,const std::string& action,float x,float w){
            rect(x,486,w,27,focus);outline(x,486,w,27,1.5f,ink);
            const float kw=key.size()*6.0f*1.1f+10.0f;
            outline(x+6,491,kw,16,1,ink);text(key,x+11,495,1.1f,ink);
            text(action,x+kw+14,494,1.4f,ink);
        };
        if(editable) {
            button("ENTER","SIGN IN",205,170);button("TAB","NEXT FIELD",393,173);button("CTRL V","PASTE",584,171);
        } else if(view.phase=="connecting")button("ESC","EDIT CONNECTION",337,286);
        else if(canClose)button("F8","BACK",393,174);
        else centered("LOADING CAREER...",494,1.4f,dim);
    }

    void AddCircle2D(
        std::vector<Vertex>& vertices,
        float centerX,
        float centerY,
        float radius,
        D3DCOLOR color,
        int segments = 18)
    {
        const Vertex center{centerX, centerY, 0.0f, 1.0f, color};
        for (int i = 0; i < segments; ++i)
        {
            const float a0 = static_cast<float>(i) * 6.28318530718f / static_cast<float>(segments);
            const float a1 = static_cast<float>(i + 1) * 6.28318530718f / static_cast<float>(segments);
            const Vertex p0{centerX + std::cos(a0) * radius,
                            centerY + std::sin(a0) * radius, 0.0f, 1.0f, color};
            const Vertex p1{centerX + std::cos(a1) * radius,
                            centerY + std::sin(a1) * radius, 0.0f, 1.0f, color};
            vertices.push_back(center);
            vertices.push_back(p0);
            vertices.push_back(p1);
        }
    }

    void AddArchipelagoMark(
        std::vector<Vertex>& vertices,
        float x,
        float y,
        float scale,
        D3DCOLOR background = D3DCOLOR_ARGB(255, 12, 10, 18))
    {


        const D3DCOLOR colors[6] = {
            D3DCOLOR_ARGB(255, 203, 122, 140),
            D3DCOLOR_ARGB(255, 121, 194, 120),
            D3DCOLOR_ARGB(255, 195, 137, 190),
            D3DCOLOR_ARGB(255, 219, 160, 119),
            D3DCOLOR_ARGB(255, 118, 130, 194),
            D3DCOLOR_ARGB(255, 242, 226, 139)
        };

        const float cx = x + 11.5f * scale;
        const float cy = y + 11.5f * scale;
        const float orbit = 6.25f * scale;
        const float petalRadius = 5.15f * scale;

        for (int i = 0; i < 6; ++i)
        {
            const float angle = -1.57079632679f + static_cast<float>(i) * 1.04719755120f;
            AddCircle2D(vertices,
                        cx + std::cos(angle) * orbit,
                        cy + std::sin(angle) * orbit,
                        petalRadius,
                        colors[i],
                        18);
        }


        AddCircle2D(vertices, cx, cy, 4.65f * scale, background, 20);
    }

    struct Vec3
    {
        float x;
        float y;
        float z;
    };

    struct ScreenPoint
    {
        float x;
        float y;
    };

    ScreenPoint ProjectLogoPoint(
        const Vec3& point,
        float yaw,
        float pitch,
        float centerX,
        float centerY,
        float scale)
    {
        const float cy = std::cos(yaw);
        const float sy = std::sin(yaw);
        const float cp = std::cos(pitch);
        const float sp = std::sin(pitch);

        const float x1 = point.x * cy + point.z * sy;
        const float z1 = -point.x * sy + point.z * cy;
        const float y2 = point.y * cp - z1 * sp;
        const float z2 = point.y * sp + z1 * cp;

        const float cameraZ = 4.8f + z2;
        const float perspective = cameraZ > 0.25f ? (4.3f / cameraZ) : 1.0f;
        return ScreenPoint{
            centerX + x1 * scale * perspective,
            centerY - y2 * scale * perspective
        };
    }

    void AddProjectedFace(
        std::vector<Vertex>& vertices,
        const ScreenPoint& a,
        const ScreenPoint& b,
        const ScreenPoint& c,
        const ScreenPoint& d,
        D3DCOLOR color)
    {
        const Vertex va{a.x, a.y, 0.0f, 1.0f, color};
        const Vertex vb{b.x, b.y, 0.0f, 1.0f, color};
        const Vertex vc{c.x, c.y, 0.0f, 1.0f, color};
        const Vertex vd{d.x, d.y, 0.0f, 1.0f, color};
        vertices.push_back(va); vertices.push_back(vb); vertices.push_back(vc);
        vertices.push_back(va); vertices.push_back(vc); vertices.push_back(vd);
    }

    void AddProjectedTriangle(
        std::vector<Vertex>& vertices,
        const ScreenPoint& a,
        const ScreenPoint& b,
        const ScreenPoint& c,
        D3DCOLOR color)
    {
        vertices.push_back(Vertex{a.x, a.y, 0.0f, 1.0f, color});
        vertices.push_back(Vertex{b.x, b.y, 0.0f, 1.0f, color});
        vertices.push_back(Vertex{c.x, c.y, 0.0f, 1.0f, color});
    }

    D3DCOLOR ShadeColor(D3DCOLOR color, float factor)
    {
        const unsigned int a = (color >> 24) & 0xFFu;
        const unsigned int r = (color >> 16) & 0xFFu;
        const unsigned int g = (color >> 8) & 0xFFu;
        const unsigned int b = color & 0xFFu;
        const auto shade = [factor](unsigned int c) -> unsigned int
        {
            const float value = static_cast<float>(c) * factor;
            return static_cast<unsigned int>(std::max(0.0f, std::min(255.0f, value)));
        };
        return D3DCOLOR_ARGB(a, shade(r), shade(g), shade(b));
    }

    void AddLogoDisc3D(
        std::vector<Vertex>& vertices,
        float cx,
        float cy,
        float radius,
        float halfDepth,
        float yaw,
        float pitch,
        float centerX,
        float centerY,
        float scale,
        D3DCOLOR color,
        int segments = 18)
    {
        const D3DCOLOR side = ShadeColor(color, 0.58f);
        const D3DCOLOR back = ShadeColor(color, 0.36f);
        const Vec3 frontCenter3{cx, cy, halfDepth};
        const Vec3 backCenter3{cx, cy, -halfDepth};
        const ScreenPoint frontCenter = ProjectLogoPoint(frontCenter3, yaw, pitch, centerX, centerY, scale);
        const ScreenPoint backCenter = ProjectLogoPoint(backCenter3, yaw, pitch, centerX, centerY, scale);

        for (int i = 0; i < segments; ++i)
        {
            const float a0 = static_cast<float>(i) * 6.28318530718f / static_cast<float>(segments);
            const float a1 = static_cast<float>(i + 1) * 6.28318530718f / static_cast<float>(segments);
            const Vec3 f0{cx + std::cos(a0) * radius, cy + std::sin(a0) * radius, halfDepth};
            const Vec3 f1{cx + std::cos(a1) * radius, cy + std::sin(a1) * radius, halfDepth};
            const Vec3 b0{f0.x, f0.y, -halfDepth};
            const Vec3 b1{f1.x, f1.y, -halfDepth};
            const ScreenPoint pf0 = ProjectLogoPoint(f0, yaw, pitch, centerX, centerY, scale);
            const ScreenPoint pf1 = ProjectLogoPoint(f1, yaw, pitch, centerX, centerY, scale);
            const ScreenPoint pb0 = ProjectLogoPoint(b0, yaw, pitch, centerX, centerY, scale);
            const ScreenPoint pb1 = ProjectLogoPoint(b1, yaw, pitch, centerX, centerY, scale);

            AddProjectedTriangle(vertices, backCenter, pb1, pb0, back);
            AddProjectedFace(vertices, pb0, pb1, pf1, pf0, side);
            AddProjectedTriangle(vertices, frontCenter, pf0, pf1, color);
        }
    }

    void AddArchipelagoLogo3D(
        std::vector<Vertex>& vertices,
        float centerX,
        float centerY,
        float scale)
    {
        const float time = static_cast<float>(GetTickCount64() % 12000ull) / 12000.0f;
        const float yaw = time * 6.28318530718f;
        const float pitch = -0.25f + 0.08f * std::sin(time * 12.56637061436f);
        const D3DCOLOR colors[6] = {
            D3DCOLOR_ARGB(255, 203, 122, 140),
            D3DCOLOR_ARGB(255, 121, 194, 120),
            D3DCOLOR_ARGB(255, 195, 137, 190),
            D3DCOLOR_ARGB(255, 219, 160, 119),
            D3DCOLOR_ARGB(255, 118, 130, 194),
            D3DCOLOR_ARGB(255, 242, 226, 139)
        };


        const float orbit = 0.83f;
        const float radius = 0.68f;
        for (int i = 0; i < 6; ++i)
        {
            const float angle = 1.57079632679f - static_cast<float>(i) * 1.04719755120f;
            AddLogoDisc3D(vertices,
                          std::cos(angle) * orbit,
                          std::sin(angle) * orbit,
                          radius,
                          0.18f,
                          yaw, pitch, centerX, centerY, scale,
                          colors[i],
                          18);
        }

        AddLogoDisc3D(vertices, 0.0f, 0.0f, 0.58f, 0.205f,
                      yaw, pitch, centerX, centerY, scale,
                      D3DCOLOR_ARGB(255, 6, 6, 10), 20);
    }

    void AddArchipelagoItemPreview(
        std::vector<Vertex>& vertices,
        const D3DVIEWPORT9& viewport,
        const NFSMWAP::StoreOverlayInfo& store)
    {
        const float vw = static_cast<float>(viewport.Width);
        const float vh = static_cast<float>(viewport.Height);
        const D3DCOLOR accent = D3DCOLOR_ARGB(255, 150, 86, 235);
        const D3DCOLOR accentSoft = D3DCOLOR_ARGB(255, 112, 62, 180);
        const D3DCOLOR dark = D3DCOLOR_ARGB(255, 6, 6, 10);
        const D3DCOLOR dark2 = D3DCOLOR_ARGB(255, 12, 10, 18);
        const D3DCOLOR bright = D3DCOLOR_ARGB(255, 250, 247, 255);
        const D3DCOLOR dim = D3DCOLOR_ARGB(255, 190, 184, 204);
        const float textScale = viewport.Width >= 1280 ? 1.35f : 0.95f;

        if (store.presentationMode == NFSMWAP::StorePresentationMode::CarLot3DLogo)
        {


            const float x = 0.0f;
            const float y = 0.0f;
            const float w = vw;
            const float h = vh;

            AddRect(vertices, x, y, w, h, dark);
            AddRect(vertices, x, y, w, 5.0f, accent);
            AddRect(vertices, x, y, 5.0f, h, accent);
            AddRect(vertices, x + w - 5.0f, y, 5.0f, h, accent);
            AddRect(vertices, x, y + h - 5.0f, w, 5.0f, accent);

            const float logoScale = std::min(w, h) * 0.235f;
            AddArchipelagoLogo3D(vertices, x + w * 0.52f, y + h * 0.42f, logoScale);

            AddText(vertices, "ARCHIPELAGO CAR LOT", x + 22.0f, y + 18.0f,
                    textScale * 1.15f, accent);
            AddText(vertices,
                    SanitizeLine(store.itemName.empty() ? std::string("UNKNOWN ITEM") : store.itemName,
                                 viewport.Width >= 1280 ? 70 : 48),
                    x + 22.0f, y + h * 0.69f, textScale * 1.05f, bright);

            std::string route = "TO: " +
                (store.recipientName.empty() ? std::string("UNKNOWN") : store.recipientName);
            if (!store.recipientGame.empty())
                route += " [" + store.recipientGame + "]";
            AddText(vertices, SanitizeLine(route, viewport.Width >= 1280 ? 70 : 48),
                    x + 22.0f, y + h * 0.69f + 21.0f, textScale * 0.9f, dim);

            std::string cost = "PRICE: " + store.priceText;
            if (!store.careerCashText.empty())
                cost += "   CASH: " + store.careerCashText;
            AddText(vertices, SanitizeLine(cost, viewport.Width >= 1280 ? 70 : 48),
                    x + 22.0f, y + h * 0.69f + 40.0f, textScale * 0.9f, bright);
            return;
        }

        if (store.presentationMode == NFSMWAP::StorePresentationMode::Parts2DIcons)
        {


            const float x = 0.0f;
            const float y = std::max(54.0f, vh * 0.11f);
            const float w = vw;
            const float h = std::min(vh * 0.59f, vh - y - 108.0f);
            AddRect(vertices, x, y, w, h, dark);
            AddRect(vertices, x, y, w, 4.0f, accent);
            AddRect(vertices, x, y + h - 4.0f, w, 4.0f, accent);

            AddText(vertices, "ARCHIPELAGO PARTS STORE", x + 18.0f, y + 14.0f,
                    textScale * 1.1f, accent);
            AddText(vertices,
                    SanitizeLine(store.itemName.empty() ? std::string("UNKNOWN ITEM") : store.itemName,
                                 viewport.Width >= 1280 ? 70 : 48),
                    x + 18.0f, y + 36.0f, textScale, bright);

            std::string route = "TO: " +
                (store.recipientName.empty() ? std::string("UNKNOWN") : store.recipientName);
            if (!store.recipientGame.empty())
                route += " [" + store.recipientGame + "]";
            AddText(vertices, SanitizeLine(route, viewport.Width >= 1280 ? 70 : 48),
                    x + 18.0f, y + 57.0f, textScale * 0.86f, dim);

            const int iconCount = viewport.Width >= 1280 ? 8 : 6;
            const float gap = std::max(8.0f, w * 0.012f);
            const float usable = w - 28.0f - gap * static_cast<float>(iconCount - 1);
            const float tile = std::min(usable / static_cast<float>(iconCount), h * 0.43f);
            const float total = tile * iconCount + gap * (iconCount - 1);
            const float tilesX = x + (w - total) * 0.5f;
            const float tilesY = y + h * 0.36f;
            const int selected = iconCount / 2;

            for (int i = 0; i < iconCount; ++i)
            {
                const float tx = tilesX + static_cast<float>(i) * (tile + gap);
                const bool isSelected = i == selected;
                AddRect(vertices, tx, tilesY, tile, tile, isSelected ? accentSoft : dark2);
                AddRect(vertices, tx, tilesY, tile, isSelected ? 4.0f : 2.0f,
                        isSelected ? bright : accent);
                AddRect(vertices, tx, tilesY, isSelected ? 4.0f : 2.0f, tile,
                        isSelected ? bright : accent);

                const float markScale = std::max(0.72f, tile / 31.0f);
                const float markW = 21.0f * markScale;
                const float markH = 21.0f * markScale;
                AddArchipelagoMark(vertices,
                    tx + (tile - markW) * 0.5f,
                    tilesY + (tile - markH) * 0.5f,
                    markScale,
                    isSelected ? accentSoft : dark2);
            }

            std::string slot = "AP ITEM " + std::to_string(store.slotIndex) + "/" +
                               std::to_string(std::max(1, store.slotCount));
            std::string cost = "PRICE: " + store.priceText;
            if (!store.careerCashText.empty())
                cost += "   CASH: " + store.careerCashText;
            AddText(vertices, slot, x + 18.0f, y + h - 43.0f, textScale * 0.9f, accent);
            AddText(vertices, SanitizeLine(cost, viewport.Width >= 1280 ? 70 : 48),
                    x + 18.0f, y + h - 23.0f, textScale * 0.9f, bright);
            return;
        }


        const float previewW = std::min(vw * 0.43f, 540.0f);
        const float previewH = std::min(vh * 0.56f, 430.0f);
        const float x = std::max(12.0f, vw - previewW - 22.0f);
        const float y = std::max(54.0f, vh * 0.13f);
        AddRect(vertices, x, y, previewW, previewH, dark);
        AddRect(vertices, x, y, previewW, 4.0f, accent);
        const float logoScale = std::min(previewW, previewH) * 0.115f;
        AddArchipelagoLogo3D(vertices, x + previewW * 0.5f, y + previewH * 0.48f, logoScale);
        AddText(vertices, "ARCHIPELAGO ITEM", x + 18.0f, y + 15.0f, textScale, accent);
        AddText(vertices,
                SanitizeLine(store.itemName.empty() ? std::string("UNKNOWN ITEM") : store.itemName,
                             viewport.Width >= 1280 ? 46 : 34),
                x + 18.0f, y + previewH - 43.0f, textScale, bright);
    }

    bool GetStoreOverlay(NFSMWAP::StoreOverlayInfo& out)
    {
        std::lock_guard<std::mutex> lock(g_storeOverlayMutex);
        if (!g_storeOverlay.visible)
            return false;
        out = g_storeOverlay;
        return true;
    }

    bool HasStoreOverlay()
    {
        std::lock_guard<std::mutex> lock(g_storeOverlayMutex);
        return g_storeOverlay.visible;
    }

    bool GetCurrentNotification(Notification& out)
    {
        std::lock_guard<std::mutex> lock(g_notificationMutex);
        const ULONGLONG now = GetTickCount64();

        if (g_hasCurrent && now - g_currentStarted >= g_current.durationMs)
        {
            NFSMWAP::Log(
                "Notification finished: title='" +
                SanitizeLine(g_current.title, 64) + "'.");
            g_hasCurrent = false;
        }

        if (!g_hasCurrent && !g_queue.empty())
        {
            g_current = g_queue.front();
            g_queue.pop_front();
            g_currentStarted = now;
            g_hasCurrent = true;

            NFSMWAP::Log(
                "Notification display started: title='" +
                SanitizeLine(g_current.title, 64) + "'.");
        }

        if (!g_hasCurrent)
            return false;

        out = g_current;
        return true;
    }

    bool HasNotificationPending()
    {
        std::lock_guard<std::mutex> lock(g_notificationMutex);
        return g_hasCurrent || !g_queue.empty();
    }

    bool HasAnyOverlayPending()
    {
        return HasNotificationPending() || HasStoreOverlay() || NFSMWAP::ConnectionSetupVisible() || HasConnectionBadge();
    }

    void DrawNotification(IDirect3DDevice9* device,bool finalFrame=false)
    {
        const auto flash=finalFrame?NFSMWAP::FlashBangOpacity():0;
        if (!device || (!g_enabled.load()&&NFSMWAP::CareerLoadStatusText()==nullptr&&!flash))
            return;

        NFSMWAP::ConnectionInputTick(device);
        const auto connection=NFSMWAP::GetConnectionView();
        Notification note;
        const bool haveNotification = GetCurrentNotification(note);
        NFSMWAP::StoreOverlayInfo store;
        const bool haveStore = GetStoreOverlay(store);
        if (!haveNotification && !haveStore && !connection.visible && !HasConnectionBadge() && !flash)
            return;

        D3DVIEWPORT9 viewport{};
        if (FAILED(device->GetViewport(&viewport)) || viewport.Width == 0 || viewport.Height == 0)
            return;

        std::vector<Vertex> vertices;
        vertices.reserve(42000);

        if (finalFrame && !connection.visible && HasConnectionBadge())
        {
            const bool online=MultiworldOnline();
            const float scale=viewport.Width>=1280 ? 1.5f : 1.0f;
            const std::string text=online ? "AP: CONNECTED" : "AP: DISCONNECTED";
            const int queued=g_queuedChecks.load();
            const char* loadStatus=NFSMWAP::CareerLoadStatusText();
            const float height=(21.0f+(queued>0?13.0f:0.0f)+(loadStatus?13.0f:0.0f))*scale;
            const float width=std::max(queued>0 ? 184.0f : 120.0f,
                loadStatus ? static_cast<float>(std::strlen(loadStatus)*6u+16u) : 0.0f)*scale;
            AddRect(vertices,12.0f,12.0f,width,height,D3DCOLOR_ARGB(200,10,10,12));
            AddText(vertices,text,20.0f,18.0f,scale,online ? D3DCOLOR_ARGB(255,115,235,150) : D3DCOLOR_ARGB(255,255,185,85));
            if (queued>0) AddText(vertices,std::to_string(queued)+" CHECKS WAITING",
                20.0f,18.0f+13.0f*scale,scale,D3DCOLOR_ARGB(255,235,235,235));
            if(loadStatus)AddText(vertices,loadStatus,20.0f,18.0f+(queued>0?26.0f:13.0f)*scale,
                scale,D3DCOLOR_ARGB(255,255,210,125));
        }

        if (haveNotification)
        {
            const float scale = viewport.Width >= 1280 ? 2.0f : 1.5f;
            const std::size_t maxChars = viewport.Width >= 1280 ? 58 : 45;
            const std::string title = SanitizeLine(note.title, maxChars);
            const std::string line1 = SanitizeLine(note.line1, maxChars);
            const std::string line2 = SanitizeLine(note.line2, maxChars);
            const float charWidth = 6.0f * scale;
            const std::size_t longest = std::max({title.size(), line1.size(), line2.size()});
            const float panelWidth = std::min(
                static_cast<float>(viewport.Width) - 20.0f,
                std::max(300.0f, static_cast<float>(longest) * charWidth + 32.0f));
            const float panelHeight = 45.0f * scale;
            const float x = std::max(10.0f, (static_cast<float>(viewport.Width) - panelWidth) * 0.5f);
            const float y = 35.0f;

            AddRect(vertices, x, y, panelWidth, panelHeight, D3DCOLOR_ARGB(220, 10, 10, 12));
            AddRect(vertices, x, y, panelWidth, std::max(3.0f, scale), D3DCOLOR_ARGB(255, 140, 80, 210));

            const float textX = x + 16.0f;
            const float lineHeight = 10.0f * scale;
            AddText(vertices, title, textX, y + 7.0f, scale, D3DCOLOR_ARGB(255, 240, 225, 255));
            AddText(vertices, line1, textX, y + 7.0f + lineHeight, scale, D3DCOLOR_ARGB(255, 255, 255, 255));
            AddText(vertices, line2, textX, y + 7.0f + lineHeight * 2.0f, scale, D3DCOLOR_ARGB(255, 205, 205, 215));
        }

        if (haveStore)
        {
            AddArchipelagoItemPreview(vertices, viewport, store);

            const float scale = viewport.Width >= 1280 ? 1.35f : 1.0f;
            const std::size_t maxChars = viewport.Width >= 1280 ? 72 : 56;
            const float panelWidth = std::min(static_cast<float>(viewport.Width) - 28.0f, viewport.Width >= 1280 ? 760.0f : 590.0f);
            const float panelHeight = 86.0f * scale;
            const float x = 14.0f;
            const float y = std::max(12.0f, static_cast<float>(viewport.Height) - panelHeight - 18.0f);
            const D3DCOLOR accent = D3DCOLOR_ARGB(255, 150, 86, 235);
            const D3DCOLOR bright = D3DCOLOR_ARGB(255, 255, 255, 255);
            const D3DCOLOR dim = D3DCOLOR_ARGB(255, 205, 205, 215);
            const D3DCOLOR green = D3DCOLOR_ARGB(255, 150, 240, 180);

            AddRect(vertices, x, y, panelWidth, panelHeight, D3DCOLOR_ARGB(228, 9, 9, 14));
            AddRect(vertices, x, y, 5.0f * scale, panelHeight, accent);
            AddRect(vertices, x, y, panelWidth, 3.0f * scale, accent);
            AddArchipelagoMark(vertices, x + 13.0f * scale, y + 12.0f * scale, scale, D3DCOLOR_ARGB(255, 9, 9, 14));

            const float tx = x + 48.0f * scale;
            const float line = 10.0f * scale;
            std::string title = "ARCHIPELAGO / " + store.storeName;
            std::string item = store.itemName.empty() ? std::string("UNKNOWN ITEM") : store.itemName;
            std::string typeLine = "ITEM: " + (store.itemType.empty() ? std::string("UNKNOWN") : store.itemType);
            if (!store.itemDetail.empty())
                typeLine += " / " + store.itemDetail;
            std::string recipient = "TO: " + (store.recipientName.empty() ? std::string("UNKNOWN") : store.recipientName);
            if (!store.recipientGame.empty())
                recipient += " [" + store.recipientGame + "]";
            std::string price = "PRICE: " + store.priceText;
            if (!store.careerCashText.empty())
                price += "  CASH: " + store.careerCashText;
            if (store.slotCount > 0)
                price += "  SLOT: " + std::to_string(store.slotIndex) + "/" + std::to_string(store.slotCount);
            price += store.checked ? "  CHECKED" : "  AVAILABLE";
            if (store.carItem)
                price += store.recipientIsLocal ? "  LOCAL CAR DELIVERY" : "  CAR ITEM";

            AddText(vertices, SanitizeLine(title, maxChars), tx, y + 8.0f * scale, scale, accent);
            AddText(vertices, SanitizeLine(item, maxChars), tx, y + 8.0f * scale + line, scale, bright);
            AddText(vertices, SanitizeLine(typeLine, maxChars), tx, y + 8.0f * scale + line * 2.0f, scale, dim);
            AddText(vertices, SanitizeLine(recipient, maxChars), tx, y + 8.0f * scale + line * 3.0f, scale, store.recipientIsLocal ? green : dim);
            AddText(vertices, SanitizeLine(price, maxChars), tx, y + 8.0f * scale + line * 4.0f, scale, store.checked ? dim : bright);
            AddText(vertices, SanitizeLine(store.controls, maxChars), tx, y + 8.0f * scale + line * 5.0f, scale, dim);
        }

        if (connection.visible)
            AddPoliceConnection(vertices,viewport,connection,!NFSMWAP::IsConnectionSetupOnly());


        if (flash)
            AddRect(vertices,0.0f,0.0f,static_cast<float>(viewport.Width),static_cast<float>(viewport.Height),
                D3DCOLOR_ARGB(flash,255,255,255));

        if (vertices.empty())
            return;


        IDirect3DStateBlock9* state = nullptr;
        HRESULT hr = device->CreateStateBlock(D3DSBT_ALL, &state);

        if (FAILED(hr) || !state)
        {
            if (!g_firstDrawFailureLogged.exchange(true))
                NFSMWAP::Log("Notification overlay draw failed: CreateStateBlock returned HRESULT "
                    + std::to_string(static_cast<unsigned long>(hr)) + ".");
            return;
        }

        if (FAILED(state->Capture())) { state->Release();return; }

        device->SetVertexShader(nullptr);
        device->SetPixelShader(nullptr);
        device->SetTexture(0, nullptr);
        device->SetFVF(D3DFVF_XYZRHW | D3DFVF_DIFFUSE);

        device->SetRenderState(D3DRS_ZENABLE, FALSE);
        device->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
        device->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
        device->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
        device->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
        device->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
        device->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
        device->SetRenderState(D3DRS_LIGHTING, FALSE);
        device->SetRenderState(D3DRS_FOGENABLE, FALSE);
        device->SetRenderState(D3DRS_SCISSORTESTENABLE, FALSE);
        device->SetRenderState(
            D3DRS_COLORWRITEENABLE,
            D3DCOLORWRITEENABLE_RED |
            D3DCOLORWRITEENABLE_GREEN |
            D3DCOLORWRITEENABLE_BLUE |
            D3DCOLORWRITEENABLE_ALPHA);

        device->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
        device->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_DIFFUSE);
        device->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
        device->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE);

        hr = device->DrawPrimitiveUP(
            D3DPT_TRIANGLELIST,
            static_cast<UINT>(vertices.size() / 3),
            vertices.data(),
            sizeof(Vertex));

        state->Apply();
        state->Release();

        if (SUCCEEDED(hr))
        {
            if (connection.visible && finalFrame) NFSMWAP::ConnectionPromptRendered();
            if (!g_firstSuccessfulDrawLogged.exchange(true))
            {
                NFSMWAP::Log(
                    "In-game notification overlay successfully drew its first notification "
                    "using Direct3D9.");
            }
        }
        else if (!g_firstDrawFailureLogged.exchange(true))
        {
            NFSMWAP::Log(
                "Notification overlay DrawPrimitiveUP failed with HRESULT "
                + std::to_string(static_cast<unsigned long>(hr)) + ".");
        }
    }

    HRESULT STDMETHODCALLTYPE EndSceneHook(IDirect3DDevice9* device)
    {
        g_lastEndSceneTick.store(GetTickCount());

        if (!g_endSceneHookFiredLogged.exchange(true))
            NFSMWAP::Log("D3D9 EndScene hook fired for the first time.");


        NFSMWAP::CareerEventMainThreadTick();
        NFSMWAP::CareerContextMainThreadTick();
        NFSMWAP::CareerBootstrapMainThreadTick();
        NFSMWAP::TurboTrapMainThreadTick();
        NFSMWAP::DeathLinkMainThreadTick();
        NFSMWAP::CashDeliveryMainThreadTick();
        NFSMWAP::NativeSMSMainThreadTick();

        NFSMWAP::BlacklistNamesMainThreadTick();
        NFSMWAP::BountyRequirementsMainThreadTick();
        NFSMWAP::NativeVisualTreatmentMainThreadTick();

        NFSMWAP::NativeShopMainThreadTick();


        NFSMWAP::NativeRewardMainThreadTick();
        NFSMWAP::DrawNativeShopModel(device);

        DrawNotification(device);

        return g_originalEndScene
            ? g_originalEndScene(device)
            : D3DERR_INVALIDCALL;
    }

    HRESULT STDMETHODCALLTYPE PresentHook(
        IDirect3DDevice9* device,
        const RECT* source,
        const RECT* destination,
        HWND window,
        const RGNDATA* dirty)
    {
        if (!g_presentHookFiredLogged.exchange(true))
            NFSMWAP::Log("D3D9 Present hook fired for the first time.");


        const DWORD now = GetTickCount();
        const DWORD lastEndScene = g_lastEndSceneTick.load();
        const bool endSceneRecent =
            lastEndScene != 0 &&
            static_cast<DWORD>(now - lastEndScene) < 250u;

        const bool flashVisible=NFSMWAP::FlashBangOpacity()!=0;
        if (device && ((!endSceneRecent && (HasAnyOverlayPending() || NFSMWAP::NativeShopRequested() || NFSMWAP::DrivingTrapsPending())) || NFSMWAP::ConnectionSetupVisible() || HasConnectionBadge() || flashVisible))
        {
            const bool formVisible=NFSMWAP::ConnectionSetupVisible();
            const bool finalOverlay=formVisible || HasConnectionBadge() || flashVisible;
            IDirect3DSurface9 *oldTarget=nullptr,*backbuffer=nullptr,*oldDepth=nullptr;
            D3DVIEWPORT9 oldViewport{};
            bool targetReady=!finalOverlay;
            bool changedTarget=false;
            if (finalOverlay && SUCCEEDED(device->GetRenderTarget(0,&oldTarget)) && oldTarget &&
                SUCCEEDED(device->GetViewport(&oldViewport)) &&
                SUCCEEDED(device->GetBackBuffer(0,0,D3DBACKBUFFER_TYPE_MONO,&backbuffer)) && backbuffer)
            {
                device->GetDepthStencilSurface(&oldDepth);
                if (SUCCEEDED(device->SetDepthStencilSurface(nullptr)))
                {
                    targetReady=SUCCEEDED(device->SetRenderTarget(0,backbuffer));
                    changedTarget=targetReady;
                    if (!targetReady) device->SetDepthStencilSurface(oldDepth);
                }
            }
            HRESULT hr = targetReady ? device->BeginScene() : D3DERR_INVALIDCALL;

            if (SUCCEEDED(hr))
            {
                if (!endSceneRecent)
                {
                    NFSMWAP::CareerContextMainThreadTick();
                    NFSMWAP::CareerBootstrapMainThreadTick();
                    NFSMWAP::TurboTrapMainThreadTick();
                    NFSMWAP::DeathLinkMainThreadTick();
                    NFSMWAP::CashDeliveryMainThreadTick();
        NFSMWAP::NativeSMSMainThreadTick();
                    NFSMWAP::BlacklistNamesMainThreadTick();
                    NFSMWAP::BountyRequirementsMainThreadTick();
        NFSMWAP::NativeVisualTreatmentMainThreadTick();

        NFSMWAP::NativeShopMainThreadTick();


                    NFSMWAP::NativeRewardMainThreadTick();
                    NFSMWAP::DrawNativeShopModel(device);
                }
                DrawNotification(device,changedTarget);
                device->EndScene();

                if (!g_firstSuccessfulDrawLogged.load())
                {
                    NFSMWAP::Log(
                        "Present fallback opened a D3D9 scene for notification rendering.");
                }
            }
            else if (!g_firstDrawFailureLogged.exchange(true))
            {
                NFSMWAP::Log(
                    "Present fallback BeginScene failed with HRESULT "
                    + std::to_string(static_cast<unsigned long>(hr)) + ".");
            }
            if (changedTarget)
            {
                device->SetRenderTarget(0,oldTarget);
                device->SetDepthStencilSurface(oldDepth);
                device->SetViewport(&oldViewport);
            }
            if (oldDepth) oldDepth->Release();
            if (backbuffer) backbuffer->Release();
            if (oldTarget) oldTarget->Release();
        }

        return g_originalPresent
            ? g_originalPresent(device, source, destination, window, dirty)
            : D3DERR_INVALIDCALL;
    }

    IDirect3DDevice9* ReadDevicePointer()
    {
        __try
        {
            return *reinterpret_cast<IDirect3DDevice9**>(D3DDevicePointerAddress);
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return nullptr;
        }
    }

    bool InstallRenderHooks(IDirect3DDevice9* device)
    {
        if (!device)
            return false;

        void*** object = reinterpret_cast<void***>(device);
        if (!object || !*object)
            return false;

        void** vtable = *object;


        void* currentEndScene = vtable[EndSceneVtableIndex];
        if (currentEndScene != reinterpret_cast<void*>(&EndSceneHook))
        {
            DWORD oldProtect = 0;
            if (!VirtualProtect(
                    &vtable[EndSceneVtableIndex],
                    sizeof(void*),
                    PAGE_EXECUTE_READWRITE,
                    &oldProtect))
            {
                return false;
            }

            g_originalEndScene =
                reinterpret_cast<EndSceneFn>(currentEndScene);

            vtable[EndSceneVtableIndex] =
                reinterpret_cast<void*>(&EndSceneHook);

            DWORD unused = 0;
            VirtualProtect(
                &vtable[EndSceneVtableIndex],
                sizeof(void*),
                oldProtect,
                &unused);

            FlushInstructionCache(
                GetCurrentProcess(),
                &vtable[EndSceneVtableIndex],
                sizeof(void*));
        }


        void* currentPresent = vtable[PresentVtableIndex];
        if (currentPresent != reinterpret_cast<void*>(&PresentHook))
        {
            DWORD oldProtect = 0;
            if (!VirtualProtect(
                    &vtable[PresentVtableIndex],
                    sizeof(void*),
                    PAGE_EXECUTE_READWRITE,
                    &oldProtect))
            {
                return false;
            }

            g_originalPresent =
                reinterpret_cast<PresentFn>(currentPresent);

            vtable[PresentVtableIndex] =
                reinterpret_cast<void*>(&PresentHook);

            DWORD unused = 0;
            VirtualProtect(
                &vtable[PresentVtableIndex],
                sizeof(void*),
                oldProtect,
                &unused);

            FlushInstructionCache(
                GetCurrentProcess(),
                &vtable[PresentVtableIndex],
                sizeof(void*));
        }

        g_hookedVtable = vtable;

        return
            vtable[EndSceneVtableIndex] ==
                reinterpret_cast<void*>(&EndSceneHook)
            &&
            vtable[PresentVtableIndex] ==
                reinterpret_cast<void*>(&PresentHook);
    }

    bool RenderHooksAreOurs(IDirect3DDevice9* device)
    {
        if (!device)
            return false;

        void*** object = reinterpret_cast<void***>(device);
        if (!object || !*object)
            return false;

        void** vtable = *object;

        return
            vtable[EndSceneVtableIndex] ==
                reinterpret_cast<void*>(&EndSceneHook)
            &&
            vtable[PresentVtableIndex] ==
                reinterpret_cast<void*>(&PresentHook);
    }

    void LogHookVerification(IDirect3DDevice9* device)
    {
        if (!device)
        {
            NFSMWAP::Log(
                "D3D9 hook verification: device pointer is null.");
            return;
        }

        void*** object = reinterpret_cast<void***>(device);
        if (!object || !*object)
        {
            NFSMWAP::Log(
                "D3D9 hook verification: device vtable is unavailable.");
            return;
        }

        void** vtable = *object;

        const bool endSceneOurs =
            vtable[EndSceneVtableIndex] ==
            reinterpret_cast<void*>(&EndSceneHook);

        const bool presentOurs =
            vtable[PresentVtableIndex] ==
            reinterpret_cast<void*>(&PresentHook);

        NFSMWAP::Log(
            std::string("D3D9 hook verification: EndScene=")
            + (endSceneOurs ? "ours" : "replaced")
            + ", Present="
            + (presentOurs ? "ours" : "replaced")
            + ".");

        if (!endSceneOurs || !presentOurs)
        {
            NFSMWAP::Log(
                "Another graphics/mod hook replaced at least one AP render hook "
                "after installation.");
        }
    }
}

namespace NFSMWAP
{
    void SetMultiworldStatus(bool connected,int queuedChecks)
    {
        g_apConnected=connected;g_queuedChecks=std::max(0,queuedChecks);g_apStatusTick=GetTickCount();
    }

    void ConfigureNotifications(bool enabled)
    {
        g_enabled = enabled;
    }

    void SetStoreOverlay(const StoreOverlayInfo& info)
    {
        std::lock_guard<std::mutex> lock(g_storeOverlayMutex);
        g_storeOverlay = info;
        g_storeOverlay.visible = true;
    }

    void ClearStoreOverlay()
    {
        std::lock_guard<std::mutex> lock(g_storeOverlayMutex);
        g_storeOverlay = StoreOverlayInfo{};
    }

    void QueueNotification(
        const std::string& title,
        const std::string& line1,
        const std::string& line2,
        unsigned int durationMs)
    {
        if (!g_enabled.load())
            return;

        (void)durationMs;


        Log("AP status: " + title + " | " + line1 + (line2.empty()?"":" | " + line2));
    }

    DWORD WINAPI NotificationOverlayThread(LPVOID)
    {
        Log("In-game Archipelago notification overlay watchdog launched.");
        Log("Waiting for NFSMW Direct3D9 device at 0x00982BDC.");

        IDirect3DDevice9* lastDevice = nullptr;
        void** lastVtable = nullptr;
        bool startupQueued = false;
        bool delayedInitialInstall = false;

        while (true)
        {
            IDirect3DDevice9* device = ReadDevicePointer();

            if (!device)
            {
                if (lastDevice)
                    Log("D3D9 device disappeared; waiting for replacement device.");

                lastDevice = nullptr;
                lastVtable = nullptr;
                g_lastEndSceneTick.store(0);
                Sleep(250);
                continue;
            }

            void*** object = reinterpret_cast<void***>(device);
            void** currentVtable =
                (object && *object) ? *object : nullptr;

            const bool deviceChanged =
                device != lastDevice ||
                currentVtable != lastVtable;

            const bool hooksLost =
                !RenderHooksAreOurs(device);

            if (deviceChanged && !delayedInitialInstall)
            {
                Log(
                    "D3D9 device found. Delaying initial AP render-hook "
                    "install by 5 seconds.");
                delayedInitialInstall = true;
                Sleep(5000);

                device = ReadDevicePointer();
                if (!device)
                    continue;

                object = reinterpret_cast<void***>(device);
                currentVtable =
                    (object && *object) ? *object : nullptr;
            }

            if (deviceChanged || hooksLost)
            {
                if (hooksLost && lastDevice)
                {
                    Log(
                        "AP D3D9 hooks were replaced or the render device "
                        "changed; reinstalling notification hooks.");
                }

                if (InstallRenderHooks(device))
                {
                    lastDevice = device;

                    void*** refreshed =
                        reinterpret_cast<void***>(device);
                    lastVtable =
                        (refreshed && *refreshed) ? *refreshed : nullptr;

                    g_lastEndSceneTick.store(0);

                    Log(
                        "In-game Archipelago notification overlay active on "
                        "D3D9 EndScene + Present.");

                    if (!startupQueued)
                    {
                        startupQueued = true;
                        Log("AP render service ready; startup test SMS suppressed.");
                    }
                }
                else
                {
                    Log(
                        "ERROR: Failed to install AP D3D9 notification hooks; "
                        "watchdog will retry.");
                }
            }

            Sleep(500);
        }
    }
}
