#include "CareerEventMonitor.h"

#include <Windows.h>

#include <atomic>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <iomanip>
#include <sstream>
#include <string>
#include <mutex>
#include <unordered_map>

#include "BridgeClient.h"
#include "MilestoneJournal.h"
#include "PhotoTrapLogic.h"
#include "DeathLinkRuntime.h"
#include "CareerContext.h"
#include "Logger.h"
#include "NotificationOverlay.h"

namespace
{
    constexpr std::uintptr_t BusBroadcastAddress = 0x0061FC10u;
    constexpr std::uintptr_t StringToKeyAddress = 0x00454640u;


    constexpr std::size_t BroadcastPatchLength = 7;

    const unsigned char ExpectedBroadcastPrologue[BroadcastPatchLength] =
    {
        0x6A, 0xFF,
        0x68, 0x28, 0x6B, 0x87, 0x00
    };

    using BroadcastFn =
        void (__thiscall*)(void* bus, void* eventHandle);

    using StringToKeyFn =
        std::uint32_t (__cdecl*)(const char*);

    std::atomic_bool g_hashesReady{ false };
    bool g_hookAttempted = false;
    bool g_hookInstalled = false;

    BroadcastFn g_originalBroadcast = nullptr;
    void* g_trampolineMemory = nullptr;

    std::uint32_t g_hashMilestoneReached = 0;
    std::uint32_t g_hashMilestoneProgress = 0;
    std::uint32_t g_hashPursuitEnter = 0;
    std::uint32_t g_hashPursuitOver = 0;
    std::uint32_t g_hashPerpBusted = 0;

    std::atomic<unsigned int> g_enterCount{ 0 };
    std::atomic<unsigned int> g_overCount{ 0 };
    std::atomic<unsigned int> g_progressProbeCount{ 0 };
    struct MetricSample { DWORD tick=0;std::uint32_t bits=0;int rank=0; };
    std::mutex g_metricMutex;
    std::unordered_map<std::string,MetricSample> g_metricSamples;


    std::string JsonEscape(const std::string& text);
    std::string TryReadAscii(std::uintptr_t address);

    std::uint32_t g_seenDescriptors[32]{};
    std::size_t g_seenDescriptorCount = 0;

    bool g_staticMetricScanDone = false;

    bool SafeReadByte(
        std::uintptr_t address,
        unsigned char& value)
    {
        if (!address)
            return false;

        __try
        {
            value =
                *reinterpret_cast<const unsigned char*>(address);

            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            value = 0;
            return false;
        }
    }

    bool SafeReadDword(
        std::uintptr_t address,
        std::uint32_t& value)
    {
        if (!address)
            return false;

        __try
        {
            value =
                *reinterpret_cast<const std::uint32_t*>(address);

            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            value = 0;
            return false;
        }
    }

    bool IsReadablePointer(std::uintptr_t address)
    {
        if (address < 0x00010000u || address >= 0x80000000u)
            return false;

        MEMORY_BASIC_INFORMATION mbi{};

        if (!VirtualQuery(
                reinterpret_cast<const void*>(address),
                &mbi,
                sizeof(mbi)))
        {
            return false;
        }

        if (mbi.State != MEM_COMMIT)
            return false;

        if (mbi.Protect & PAGE_GUARD)
            return false;

        const DWORD protection =
            mbi.Protect & 0xFFu;

        return
            protection == PAGE_READONLY ||
            protection == PAGE_READWRITE ||
            protection == PAGE_WRITECOPY ||
            protection == PAGE_EXECUTE_READ ||
            protection == PAGE_EXECUTE_READWRITE ||
            protection == PAGE_EXECUTE_WRITECOPY;
    }

    std::string Hex32(std::uint32_t value)
    {
        std::ostringstream out;

        out << "0x"
            << std::uppercase
            << std::hex
            << std::setw(8)
            << std::setfill('0')
            << value;

        return out.str();
    }

    float FloatFromBits(std::uint32_t bits)
    {
        float value = 0.0f;
        static_assert(
            sizeof(value) == sizeof(bits),
            "float/u32 size mismatch");

        std::memcpy(
            &value,
            &bits,
            sizeof(value));

        return value;
    }

    std::string FloatText(float value)
    {
        std::ostringstream out;

        if (!std::isfinite(value))
        {
            out << "nonfinite";
            return out.str();
        }

        out << std::fixed
            << std::setprecision(6)
            << value;

        return out.str();
    }

    bool DescriptorAlreadySeen(
        std::uint32_t descriptor)
    {
        for (std::size_t i = 0;
             i < g_seenDescriptorCount;
             ++i)
        {
            if (g_seenDescriptors[i] == descriptor)
                return true;
        }

        if (g_seenDescriptorCount <
            (sizeof(g_seenDescriptors) /
             sizeof(g_seenDescriptors[0])))
        {
            g_seenDescriptors[
                g_seenDescriptorCount++] =
                descriptor;
        }

        return false;
    }

    std::string DumpMemoryDwords(
        std::uintptr_t address,
        std::size_t count)
    {
        std::ostringstream out;

        for (std::size_t i = 0;
             i < count;
             ++i)
        {
            if (i)
                out << ";";

            std::uint32_t value = 0;

            if (!SafeReadDword(
                    address + i * 4u,
                    value))
            {
                out << "d" << i
                    << "=UNREADABLE";
                continue;
            }

            out << "d" << i
                << "=" << Hex32(value);
        }

        return out.str();
    }

    std::string DumpMemoryBytes(
        std::uintptr_t address,
        std::size_t count)
    {
        std::ostringstream out;

        out << std::uppercase
            << std::hex
            << std::setfill('0');

        for (std::size_t i = 0;
             i < count;
             ++i)
        {
            if (i)
                out << " ";

            unsigned char value = 0;

            if (!SafeReadByte(
                    address + i,
                    value))
            {
                out << "??";
                continue;
            }

            out << std::setw(2)
                << static_cast<unsigned int>(
                    value);
        }

        return out.str();
    }

    std::string ExtractAsciiRuns(
        std::uintptr_t address,
        std::size_t count)
    {
        std::ostringstream out;
        bool first = true;

        std::string current;
        std::uintptr_t currentStart = 0;

        auto flush = [&]()
        {
            if (current.size() >= 4)
            {
                if (!first)
                    out << ";";

                first = false;

                out
                    << Hex32(
                        static_cast<std::uint32_t>(
                            currentStart))
                    << "="
                    << current;
            }

            current.clear();
            currentStart = 0;
        };

        for (std::size_t i = 0;
             i < count;
             ++i)
        {
            unsigned char c = 0;

            if (!SafeReadByte(
                    address + i,
                    c))
            {
                flush();
                continue;
            }

            if (c >= 0x20 &&
                c < 0x7F)
            {
                if (current.empty())
                {
                    currentStart =
                        address + i;
                }

                if (current.size() < 96)
                {
                    current.push_back(
                        static_cast<char>(c));
                }
            }
            else
            {
                flush();
            }
        }

        flush();

        return out.str();
    }

    int ReadPhotoCameraRank(int rank,NFSMWAP::PhotoCamera* cameras,int capacity)
    {

        __try {
            const auto manager=*reinterpret_cast<std::uint32_t*>(0x91E00Cu);
            if (!IsReadablePointer(manager)) return 0;
            using First=void*(__thiscall*)(void*,bool,unsigned int);
            using Next=void*(__thiscall*)(void*,void*,bool,unsigned int);
            void* trap=reinterpret_cast<First>(0x5E9D40u)(reinterpret_cast<void*>(manager),false,rank);
            void* seen[64]={};int count=0;
            while (trap && count<capacity && count<64) {
                if (!IsReadablePointer(reinterpret_cast<std::uintptr_t>(trap))) return 0;
                for (int n=0;n<count;++n) if (seen[n]==trap) return 0;
                seen[count]=trap;
                const float metresPerSecond=reinterpret_cast<float(__thiscall*)(void*)>(0x5118B0u)(trap);
                const auto key=reinterpret_cast<std::uint32_t(__thiscall*)(void*)>(0x5E5810u)(trap);
                const bool complete=reinterpret_cast<bool(__thiscall*)(void*,unsigned int)>(0x5118C0u)(trap,4u);
                cameras[count++]={key,static_cast<double>(metresPerSecond)*2.2369362920544,complete};
                trap=reinterpret_cast<Next>(0x5E4770u)(reinterpret_cast<void*>(manager),trap,false,rank);
            }
            return trap ? 0 : count;
        }
        __except(EXCEPTION_EXECUTE_HANDLER) { return 0; }
    }

    void ReconcilePhotoTraps(int onlyRank=0)
    {
        static DWORD previous=0;
        const DWORD now=GetTickCount();
        if (!onlyRank) {
            if (previous && now-previous<1000u) return;
            previous=now;
        }
        if (!NFSMWAP::IsLiveCareerMode()) return;
        for (int rank=15;rank>=1;--rank) {
            if (onlyRank && rank!=onlyRank) continue;
            NFSMWAP::PhotoCamera native[64]={};
            const int count=ReadPhotoCameraRank(rank,native,64);
            const std::vector<NFSMWAP::PhotoCamera> cameras(native,native+count);
            static std::unordered_map<int,std::string> rosters;
            std::ostringstream roster;
            for (const auto& camera:cameras) roster<<Hex32(camera.key)<<"@"<<camera.requiredMph<<"MPH ";
            if (count && rosters[rank]!=roster.str()) {
                rosters[rank]=roster.str();NFSMWAP::Log("AP PHOTO CAMERA ROSTER: rank=#"+std::to_string(rank)+" "+roster.str());
            }
            for (const auto& check:NFSMWAP::MatchPhotoCameras(rank,cameras)) {
                if (NFSMWAP::HasRecordedMilestone(check.location)) continue;
                std::ostringstream packet;
                packet<<"{\"type\":\"milestone_progress_decoded\",\"event_name\":\"PhotoTrapCompleted\",\"career_mode\":true"
                    <<",\"blacklist_rank\":"<<rank<<",\"ap_category\":\"Photo Ticket\",\"metric_name\":\"photo_camera_completed\""
                    <<",\"target_location_id\":"<<check.location<<",\"camera_key\":\""<<Hex32(check.camera.key)<<"\",\"camera_completed\":true"
                    <<",\"required_speed_mph\":\""<<check.camera.requiredMph<<"\",\"value_float\":\""<<check.targetMph<<"\"}";
                NFSMWAP::SendRecordedMilestoneEvent(packet.str());
            }
        }
    }

    void ReconcilePhotoTrapsIncremental()
    {


        static DWORD nextRankTick=0;
        static int rank=15;
        const DWORD now=GetTickCount();
        if (nextRankTick && static_cast<std::int32_t>(now-nextRankTick)<0)return;
        nextRankTick=now+65u;
        if (!NFSMWAP::IsLiveCareerMode()) {rank=15;return;}
        ReconcilePhotoTraps(rank);
        if (--rank<1)rank=15;
    }

    const char* KnownInnerSourceName(
        std::uint32_t hash)
    {

        if (hash == 0x20D60DBFu)
            return "PursuitBountyAwarded";

        return "";
    }

    const char* KnownApMilestoneCategory(
        const std::string& metricName)
    {
        if (metricName == "cops_damaged_in_pursuit" ||
            metricName == "cops_damaged")
            return "Trade Paint";

        if (metricName == "bounty_in_pursuit" ||
            metricName == "bounty")
            return "Bounty";

        if (metricName == "pursuit_evasion_time")
            return "Pursuit Evasion";

        if (metricName == "pursuit_length" ||
            metricName == "pursuit_length_in_pursuit")
        {
            return "Pursuit Time";
        }

        if (metricName == "cost_to_state_in_pursuit" ||
            metricName == "cost_to_state")
            return "Cost to State";

        if (metricName == "roadblocks_dodged_in_pursuit" ||
            metricName == "roadblocks_dodged")
            return "Roadblock";

        if (metricName == "total_infractions_in_pursuit" ||
            metricName == "total_infractions")
            return "Infractions";

        if (metricName == "tire_spikes_dodged_in_pursuit" ||
            metricName == "tire_spikes_dodged")
            return "Spike Strip";


        if (metricName == "speedtrap_speed")
            return "Photo Ticket";

        return "";
    }

    bool ContainsMetricToken(
        const std::string& text)
    {
        return
            text.find("_in_pursuit") != std::string::npos ||
            text.find("pursuit_") != std::string::npos ||
            text.find("roadblock") != std::string::npos ||
            text.find("spike") != std::string::npos ||
            text.find("infraction") != std::string::npos ||
            text.find("bounty") != std::string::npos ||
            text.find("speedtrap") != std::string::npos ||
            text.find("speed_trap") != std::string::npos ||
            text.find("photo_ticket") != std::string::npos;
    }

    void SendStaticMetricString(
        std::uintptr_t address,
        const std::string& value)
    {
        NFSMWAP::Log(
            "MILESTONE STATIC STRING CANDIDATE: address="
            + Hex32(static_cast<std::uint32_t>(address))
            + ", text="
            + value
            + ".");

        std::ostringstream json;

        json
            << "{\"type\":\"milestone_metric_string\""
            << ",\"address\":\""
            << Hex32(static_cast<std::uint32_t>(address))
            << "\""
            << ",\"text\":\""
            << JsonEscape(value)
            << "\""
            << "}";

        NFSMWAP::SendBridgeLine(json.str());
    }

    void ScanStaticMilestoneMetricStrings()
    {
        if (g_staticMetricScanDone)
            return;

        g_staticMetricScanDone = true;


        constexpr std::uintptr_t Start = 0x00880000u;
        constexpr std::uintptr_t End   = 0x008A5000u;

        std::string current;
        std::uintptr_t currentStart = 0;
        unsigned int emitted = 0;

        auto flush = [&]()
        {
            if (current.size() >= 4 &&
                current.size() <= 96 &&
                ContainsMetricToken(current))
            {
                SendStaticMetricString(
                    currentStart,
                    current);

                ++emitted;
            }

            current.clear();
            currentStart = 0;
        };

        for (std::uintptr_t address = Start;
             address < End;
             ++address)
        {
            unsigned char c = 0;

            if (!SafeReadByte(address, c))
            {
                flush();
                continue;
            }

            if (c >= 0x20 && c < 0x7F)
            {
                if (current.empty())
                    currentStart = address;

                if (current.size() < 96)
                    current.push_back(static_cast<char>(c));
            }
            else
            {
                flush();
            }

            if (emitted >= 250)
                break;
        }

        flush();

        NFSMWAP::Log(
            "MILESTONE STATIC STRING SCAN COMPLETE: emitted "
            + std::to_string(emitted)
            + " pursuit/milestone-related candidate strings.");
    }

    void SendDecodedMilestonePayload(
        const char* eventName,
        void* eventHandle,
        std::uint32_t outerHash)
    {
        const std::uintptr_t base =
            reinterpret_cast<std::uintptr_t>(
                eventHandle);

        std::uint32_t payloadPointer = 0;


        if (!SafeReadDword(
                base + 0x1Cu,
                payloadPointer)
            ||
            !IsReadablePointer(
                payloadPointer))
        {
            NFSMWAP::Log(
                std::string("MILESTONE PAYLOAD DECODE: ")
                + eventName
                + " has no readable +0x1C payload pointer.");

            return;
        }

        std::uint32_t words[6]{};

        for (std::size_t i = 0;
             i < 6;
             ++i)
        {
            if (!SafeReadDword(
                    static_cast<std::uintptr_t>(
                        payloadPointer)
                    + i * 4u,
                    words[i]))
            {
                NFSMWAP::Log(
                    std::string("MILESTONE PAYLOAD DECODE: ")
                    + eventName
                    + " payload became unreadable.");

                return;
            }
        }

        const std::uint32_t payloadEventHash =
            words[0];

        const std::uint32_t sourceHash =
            words[1];

        const std::uint32_t payloadSizeOrType =
            words[2];

        const std::uint32_t payloadFlags =
            words[3];

        const std::uint32_t descriptor =
            words[4];

        const std::uint32_t valueBits =
            words[5];

        const float progressValue =
            FloatFromBits(
                valueBits);

        const char* sourceName =
            KnownInnerSourceName(
                sourceHash);

        const std::string metricName =
            (descriptor != 0 &&
             IsReadablePointer(descriptor))
                ? TryReadAscii(descriptor)
                : std::string();

        const char* apCategory =
            KnownApMilestoneCategory(
                metricName);

        if (!std::isfinite(progressValue) || progressValue<0.0f) return;
        if (outerHash==g_hashMilestoneProgress)
        {
            if (!apCategory[0] || !NFSMWAP::IsLiveCareerMode()) return;
            const DWORD now=GetTickCount();
            const int rank=NFSMWAP::GetLastCareerRank();
            std::lock_guard<std::mutex> lock(g_metricMutex);
            auto& previous=g_metricSamples[metricName];
            if (previous.tick && previous.bits==valueBits && previous.rank==rank && now-previous.tick<1000u) return;


            if (metricName=="pursuit_length" || metricName=="pursuit_length_in_pursuit")
                if (previous.tick && previous.rank==rank && now-previous.tick<200u) return;
            previous={now,valueBits,rank};
        }

        std::ostringstream json;

        json
            << "{\"type\":\"milestone_progress_decoded\""
            << ",\"event_name\":\""
            << JsonEscape(std::string(eventName ? eventName : "")) << "\""
            << ",\"blacklist_rank\":"
            << NFSMWAP::GetLastCareerRank()
            << ",\"career_mode\":" << (NFSMWAP::IsLiveCareerMode() ? "true" : "false")
            << ",\"outer_hash\":\""
            << Hex32(outerHash) << "\""
            << ",\"payload_pointer\":\""
            << Hex32(payloadPointer) << "\""
            << ",\"payload_hash\":\""
            << Hex32(payloadEventHash) << "\""
            << ",\"source_hash\":\""
            << Hex32(sourceHash) << "\""
            << ",\"source_name\":\""
            << JsonEscape(
                std::string(
                    sourceName[0]
                        ? sourceName
                        : ""))
            << "\""
            << ",\"size_or_type\":\""
            << Hex32(payloadSizeOrType) << "\""
            << ",\"flags\":\""
            << Hex32(payloadFlags) << "\""
            << ",\"descriptor\":\""
            << Hex32(descriptor) << "\""
            << ",\"metric_name\":\""
            << JsonEscape(metricName) << "\""
            << ",\"ap_category\":\""
            << JsonEscape(
                apCategory[0]
                    ? std::string(apCategory)
                    : std::string())
            << "\""
            << ",\"value_bits\":\""
            << Hex32(valueBits) << "\""
            << ",\"value_float\":\""
            << FloatText(progressValue) << "\""
            << "}";

        NFSMWAP::SendRecordedMilestoneEvent(json.str());
    }

    std::string JsonEscape(
        const std::string& text)
    {
        std::string out;
        out.reserve(text.size() + 16);

        for (unsigned char c : text)
        {
            switch (c)
            {
            case '\\': out += "\\\\"; break;
            case '"':  out += "\\\""; break;
            case '\n': out += "\\n";  break;
            case '\r': out += "\\r";  break;
            case '\t': out += "\\t";  break;

            default:
                if (c >= 0x20 && c < 0x7F)
                    out.push_back(static_cast<char>(c));
                else
                    out.push_back('?');
                break;
            }
        }

        return out;
    }

    std::string TryReadAscii(
        std::uintptr_t address)
    {
        if (!IsReadablePointer(address))
            return {};

        std::string result;
        result.reserve(64);

        for (int i = 0; i < 64; ++i)
        {
            unsigned char c = 0;

            if (!SafeReadByte(
                    address
                    + static_cast<std::uintptr_t>(i),
                    c))
            {
                return {};
            }

            if (c == 0)
                break;

            if (c < 0x20 || c >= 0x7F)
                return {};

            result.push_back(
                static_cast<char>(c));
        }

        if (result.size() < 4)
            return {};

        return result;
    }

    struct EventSnapshot
    {
        void* handle{};
        std::uint32_t hash{};
        std::uint32_t words[16]{};
        bool wordReadable[16]{};
        std::string rawDwords;
        std::string pointerAscii;
        std::string pointerDwords;
    };

    EventSnapshot CaptureEventSnapshot(
        void* eventHandle,
        std::uint32_t hash)
    {
        EventSnapshot snapshot{};
        snapshot.handle = eventHandle;
        snapshot.hash = hash;

        std::ostringstream raw;
        std::ostringstream ascii;
        std::ostringstream pointed;

        bool firstAscii = true;
        bool firstPointed = true;

        const std::uintptr_t base =
            reinterpret_cast<std::uintptr_t>(
                eventHandle);

        for (std::size_t i = 0; i < 16; ++i)
        {
            if (i)
                raw << ";";

            std::uint32_t value = 0;

            if (!SafeReadDword(
                    base + i * 4u,
                    value))
            {
                raw << "d" << i
                    << "=UNREADABLE";
                continue;
            }

            snapshot.words[i] = value;
            snapshot.wordReadable[i] = true;

            raw << "d" << i
                << "=" << Hex32(value);

            if (!IsReadablePointer(value))
                continue;

            const std::string text =
                TryReadAscii(
                    static_cast<std::uintptr_t>(
                        value));

            if (!text.empty())
            {
                if (!firstAscii)
                    ascii << ";";

                firstAscii = false;

                ascii
                    << "d" << i
                    << "@" << Hex32(value)
                    << "=" << text;
            }

            std::uint32_t pointedWords[6]{};
            bool allReadable = true;

            for (std::size_t j = 0; j < 6; ++j)
            {
                if (!SafeReadDword(
                        static_cast<std::uintptr_t>(value)
                        + j * 4u,
                        pointedWords[j]))
                {
                    allReadable = false;
                    break;
                }
            }

            if (!allReadable)
                continue;

            if (!firstPointed)
                pointed << ";";

            firstPointed = false;

            pointed
                << "d" << i
                << "@" << Hex32(value)
                << "=[";

            for (int j = 0; j < 6; ++j)
            {
                if (j)
                    pointed << ",";

                pointed << Hex32(
                    pointedWords[j]);
            }

            pointed << "]";
        }

        snapshot.rawDwords = raw.str();
        snapshot.pointerAscii = ascii.str();
        snapshot.pointerDwords = pointed.str();

        return snapshot;
    }

    void SendBusHealth(
        const char* eventName,
        std::uint32_t hash,
        unsigned int count)
    {
        NFSMWAP::Log(
            std::string("CAREER EVENT BUS HEALTH: ")
            + eventName
            + " received from BusBroadcastEventByHash, hash="
            + Hex32(hash)
            + ", count="
            + std::to_string(count)
            + ".");

        std::ostringstream json;

        json
            << "{\"type\":\"career_bus_health\""
            << ",\"event_name\":\""
            << eventName << "\""
            << ",\"event_hash\":\""
            << Hex32(hash) << "\""
            << ",\"count\":"
            << count
            << "}";

        NFSMWAP::SendBridgeLine(
            json.str());
    }

    void EmitCareerProbe(
        const char* eventName,
        const EventSnapshot& snapshot,
        bool notifyPlayer)
    {
        NFSMWAP::Log(
            std::string("CAREER EVENT PROBE: ")
            + eventName
            + ", hash="
            + Hex32(snapshot.hash)
            + ", handle="
            + Hex32(
                static_cast<std::uint32_t>(
                    reinterpret_cast<std::uintptr_t>(
                        snapshot.handle)))
            + ", raw="
            + snapshot.rawDwords
            + (snapshot.pointerAscii.empty()
                ? ""
                : ", ascii="
                    + snapshot.pointerAscii));

        std::ostringstream json;

        json
            << "{\"type\":\"career_event_probe\""
            << ",\"event_name\":\""
            << JsonEscape(eventName) << "\""
            << ",\"event_hash\":\""
            << Hex32(snapshot.hash) << "\""
            << ",\"event_handle\":\""
            << Hex32(
                static_cast<std::uint32_t>(
                    reinterpret_cast<std::uintptr_t>(
                        snapshot.handle)))
            << "\""
            << ",\"raw_dwords\":\""
            << JsonEscape(
                snapshot.rawDwords)
            << "\""
            << ",\"pointer_ascii\":\""
            << JsonEscape(
                snapshot.pointerAscii)
            << "\""
            << ",\"pointer_dwords\":\""
            << JsonEscape(
                snapshot.pointerDwords)
            << "\""
            << "}";

        NFSMWAP::SendBridgeLine(
            json.str());

        if (notifyPlayer)
        {
            NFSMWAP::QueueNotification(
                "MILESTONE REACHED",
                "MATCHING LIVE BLACKLIST RANK",
                "CHECKING ARCHIPELAGO...",
                5000);
        }
    }

    bool TryComputeEventHash(
        const char* name,
        std::uint32_t& value)
    {
        value = 0;

        if (!name || !*name)
            return false;

        __try
        {
            const auto hashFn =
                reinterpret_cast<StringToKeyFn>(
                    StringToKeyAddress);

            value = hashFn(name);

            return value != 0;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            value = 0;
            return false;
        }
    }

    void ProcessObservedEvent(
        void* eventHandle)
    {
        if (!eventHandle)
            return;


        std::uint32_t hash = 0;

        if (!SafeReadDword(
                reinterpret_cast<std::uintptr_t>(
                    eventHandle)
                + 0x18u,
                hash))
        {
            return;
        }

        if (hash == g_hashPerpBusted && hash) {
            std::uint32_t payload=0,handle=0;
            if (SafeReadDword(reinterpret_cast<std::uintptr_t>(eventHandle)+0x1Cu,payload) &&
                SafeReadDword(payload+0x10u,handle)) NFSMWAP::ObserveDeathLinkArrest(handle);
            return;
        }
        if (hash == g_hashPursuitEnter && hash)
        {
            NFSMWAP::ObserveDeathLinkPursuitEntered();

            const unsigned int count =
                g_enterCount.fetch_add(1) + 1;

            SendBusHealth(
                "MPlayerEnterPursuit",
                hash,
                count);

            return;
        }

        if (hash == g_hashPursuitOver && hash)
        {

            std::uint32_t payload=0,handle=0;
            if (SafeReadDword(reinterpret_cast<std::uintptr_t>(eventHandle)+0x1Cu,payload) &&
                SafeReadDword(payload+0x10u,handle)) NFSMWAP::ObserveDeathLinkPursuitEnded(handle);
            const unsigned int count =
                g_overCount.fetch_add(1) + 1;

            SendBusHealth(
                "MPursuitOver",
                hash,
                count);

            return;
        }

        if (hash == g_hashMilestoneReached)
        {
            SendDecodedMilestonePayload(
                "MNotifyMilestoneReached",
                eventHandle,
                hash);

            return;
        }

        if (hash == g_hashMilestoneProgress)
        {
            SendDecodedMilestonePayload(
                "MNotifyMilestoneProgress",
                eventHandle,
                hash);


        }
    }

    void __fastcall BusBroadcastHook(
        void* bus,
        void*              ,
        void* eventHandle)
    {


        ProcessObservedEvent(
            eventHandle);

        if (g_originalBroadcast)
        {
            g_originalBroadcast(
                bus,
                eventHandle);
        }
    }

    bool WriteRelativeJump(
        unsigned char* site,
        const void* target)
    {
        if (!site || !target)
            return false;

        site[0] = 0xE9;

        const std::intptr_t displacement =
            reinterpret_cast<const unsigned char*>(
                target)
            - (site + 5);

        *reinterpret_cast<std::int32_t*>(
            site + 1) =
            static_cast<std::int32_t>(
                displacement);

        return true;
    }

    bool InstallBroadcastHook()
    {
        if (g_hookInstalled)
            return true;

        unsigned char current[
            BroadcastPatchLength]{};

        for (std::size_t i = 0;
             i < BroadcastPatchLength;
             ++i)
        {
            if (!SafeReadByte(
                    BusBroadcastAddress + i,
                    current[i]))
            {
                NFSMWAP::Log(
                    "ERROR: Could not read "
                    "BusBroadcastEventByHash prologue.");

                return false;
            }
        }

        if (std::memcmp(
                current,
                ExpectedBroadcastPrologue,
                BroadcastPatchLength) != 0)
        {
            std::ostringstream found;
            found << std::uppercase
                  << std::hex
                  << std::setfill('0');

            for (std::size_t i = 0;
                 i < BroadcastPatchLength;
                 ++i)
            {
                if (i)
                    found << " ";

                found << std::setw(2)
                      << static_cast<unsigned int>(
                            current[i]);
            }

            NFSMWAP::Log(
                "ERROR: Refusing BusBroadcastEventByHash hook "
                "because the 7-byte retail prologue did not match. "
                "Found: "
                + found.str());

            return false;
        }

        constexpr std::size_t TrampolineSize =
            BroadcastPatchLength + 5;

        auto* trampoline =
            reinterpret_cast<unsigned char*>(
                VirtualAlloc(
                    nullptr,
                    TrampolineSize,
                    MEM_COMMIT | MEM_RESERVE,
                    PAGE_EXECUTE_READWRITE));

        if (!trampoline)
        {
            NFSMWAP::Log(
                "ERROR: VirtualAlloc failed for "
                "BusBroadcastEventByHash trampoline.");

            return false;
        }

        std::memcpy(
            trampoline,
            ExpectedBroadcastPrologue,
            BroadcastPatchLength);

        if (!WriteRelativeJump(
                trampoline
                    + BroadcastPatchLength,
                reinterpret_cast<const void*>(
                    BusBroadcastAddress
                    + BroadcastPatchLength)))
        {
            VirtualFree(
                trampoline,
                0,
                MEM_RELEASE);

            return false;
        }

        g_trampolineMemory =
            trampoline;

        g_originalBroadcast =
            reinterpret_cast<BroadcastFn>(
                trampoline);

        auto* target =
            reinterpret_cast<unsigned char*>(
                BusBroadcastAddress);

        DWORD oldProtect = 0;

        if (!VirtualProtect(
                target,
                BroadcastPatchLength,
                PAGE_EXECUTE_READWRITE,
                &oldProtect))
        {
            VirtualFree(
                trampoline,
                0,
                MEM_RELEASE);

            g_trampolineMemory = nullptr;
            g_originalBroadcast = nullptr;

            NFSMWAP::Log(
                "ERROR: VirtualProtect failed for "
                "BusBroadcastEventByHash.");

            return false;
        }

        WriteRelativeJump(
            target,
            reinterpret_cast<const void*>(
                &BusBroadcastHook));

        for (std::size_t i = 5;
             i < BroadcastPatchLength;
             ++i)
        {
            target[i] = 0x90;
        }

        DWORD ignored = 0;

        VirtualProtect(
            target,
            BroadcastPatchLength,
            oldProtect,
            &ignored);

        FlushInstructionCache(
            GetCurrentProcess(),
            target,
            BroadcastPatchLength);

        g_hookInstalled = true;

        NFSMWAP::Log(
            "GLOBAL EVENT BROADCAST HOOK INSTALLED at "
            "0x0061FC10. Verified retail prologue "
            "6A FF 68 28 6B 87 00; single 7-byte "
            "function-entry detour + trampoline.");

        NFSMWAP::Log(
            "No BusSubscribeListenerByHash calls are used. "
            "No callsite scanning is used. "
            "Only AP-relevant event hashes are inspected.");

        return true;
    }
}

namespace NFSMWAP
{
    DWORD WINAPI CareerEventMonitorThread(
        LPVOID)
    {
        Log(
            "Career broadcast monitor 1.0.0 started. "
            "Preparing five AP-relevant event hashes.");

        if (!TryComputeEventHash(
                "MNotifyMilestoneReached",
                g_hashMilestoneReached)
            ||
            !TryComputeEventHash(
                "MNotifyMilestoneProgress",
                g_hashMilestoneProgress)
            ||
            !TryComputeEventHash(
                "MPlayerEnterPursuit",
                g_hashPursuitEnter)
            ||
            !TryComputeEventHash(
                "MPursuitOver",
                g_hashPursuitOver) ||
            !TryComputeEventHash("MPerpBusted",g_hashPerpBusted))
        {
            Log(
                "ERROR: Could not compute one or more "
                "career event hashes.");

            return 0;
        }

        Log(
            "Career broadcast hashes ready: "
            "MNotifyMilestoneReached="
            + Hex32(g_hashMilestoneReached)
            + ", MNotifyMilestoneProgress="
            + Hex32(g_hashMilestoneProgress)
            + ", MPlayerEnterPursuit="
            + Hex32(g_hashPursuitEnter)
            + ", MPursuitOver="
            + Hex32(g_hashPursuitOver)
            + ".");


        g_hashesReady.store(
            true,
            std::memory_order_release);

        Log(
            "Broadcast hook is armed and will be installed "
            "from NFSMW's EndScene/render thread.");

        return 0;
    }

    void CareerEventMainThreadTick()
    {
        ReconcilePhotoTrapsIncremental();
        if (!g_hashesReady.load(
                std::memory_order_acquire))
        {
            return;
        }

        if (g_hookInstalled ||
            g_hookAttempted)
        {
            return;
        }

        g_hookAttempted = true;

        if (!InstallBroadcastHook())
        {
            Log(
                "ERROR: Global event broadcast hook was not installed. "
                "Career milestone probing remains disabled.");
        }
    }
}
