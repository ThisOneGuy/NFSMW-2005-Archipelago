#include "BuildVersion.h"
#include <Windows.h>

#include <sstream>
#include <string>

#include "Config.h"
#include "ConnectionSetup.h"
#include "BridgeClient.h"
#include "CareerEventMonitor.h"
#include "EventDiscovery.h"
#include "GameVersion.h"
#include "Logger.h"
#include "NotificationOverlay.h"
#include "RaceMonitor.h"
#include "SaveIsolation.h"
#include "CareerBootstrap.h"
#include "TurboTrap.h"
#include "StoreRuntime.h"

namespace
{
    DWORD WINAPI NFSMWArchipelagoThread(LPVOID)
    {
        const std::string gameDirectory = NFSMWAP::GetGameDirectory();
        NFSMWAP::InitializeLogger(gameDirectory);

        NFSMWAP::Log("NFSMWArchipelago.asi loaded.");
        NFSMWAP::Log("Build: " NFSMW_AP_BUILD " native AP stores (runtime validation required)");
        NFSMWAP::Log("Process architecture target: x86 / Win32");
        NFSMWAP::Log("NFSMW_AP_RUNTIME_ABI_V1: Microsoft x86 variadic argument headers verified.");

        const NFSMWAP::GameVersionInfo version = NFSMWAP::DetectGameVersion();

        {
            std::ostringstream line;
            line << "Executable: " << version.exePath;
            NFSMWAP::Log(line.str());
        }

        {
            std::ostringstream line;
            line << "speed.exe size: " << version.fileSize << " bytes";
            NFSMWAP::Log(line.str());
        }

        if (!version.supported)
        {
            NFSMWAP::Log(
                "UNSUPPORTED GAME VERSION. Expected speed.exe size "
                "6,029,312 bytes. Game hooks will NOT be installed.");

            MessageBoxA(
                nullptr,
                "NFSMW Archipelago loaded, but this speed.exe is not the "
                "supported 1.3 executable.\n\nNo game hooks were installed.",
                "NFSMW Archipelago",
                MB_OK | MB_ICONWARNING);

            return 0;
        }

        NFSMWAP::Log("NFSMW 1.3 executable check: PASS.");


        if (!NFSMWAP::InitializeSaveIsolation()) {
            char required[8]={};
            if (GetEnvironmentVariableA("NFSMW_AP_ISOLATION_VERSION",required,sizeof(required))) {
                NFSMWAP::Log("AP STARTUP ABORTED: save isolation could not be verified; no Career may be opened.");
                ExitProcess(ERROR_ACCESS_DENIED);
            }
        }
        if (!NFSMWAP::InstallCareerBootstrapHooks()) {
            NFSMWAP::Log("AP STARTUP ABORTED: native startup guards failed validation; refusing the vanilla prologue/profile flow.");
            ExitProcess(ERROR_INVALID_DATA);
        }

        NFSMWAP::InitializeTurboTraps();
        const NFSMWAP::Config config = NFSMWAP::LoadConfig(gameDirectory);

        NFSMWAP::Log("Configuration loaded.");
        NFSMWAP::Log("AP server: " + config.serverAddress);
        NFSMWAP::Log("AP slot: " + config.slotName);
        NFSMWAP::Log(
            "DeathLink is controlled by the AP client and its authenticated seed/slot bridge.");

        NFSMWAP::ConfigureBridge(
            config.bridgeHost,
            config.bridgePort);
        NFSMWAP::ConfigureConnectionSetup(config.serverAddress,config.slotName,config.password);
        NFSMWAP::ConfigureNotifications(true);
        NFSMWAP::ConfigureStoreRuntime(
            config.storeRuntime && !NFSMWAP::IsConnectionSetupOnly(),
            config.storePurchaseHotkey);

        HANDLE bridgeThread = CreateThread(
            nullptr,
            0,
            NFSMWAP::BridgeClientThread,
            nullptr,
            0,
            nullptr);

        if (bridgeThread)
        {
            CloseHandle(bridgeThread);
            NFSMWAP::Log("Local AP bridge thread launched.");
        }
        else
        {
            NFSMWAP::Log("ERROR: Failed to launch local AP bridge thread.");
        }

        if (config.inGameNotifications || config.storeRuntime || NFSMWAP::ConnectionSetupVisible() || NFSMWAP::IsSaveIsolationActive())
        {
            HANDLE notificationThread = CreateThread(
                nullptr,
                0,
                NFSMWAP::NotificationOverlayThread,
                nullptr,
                0,
                nullptr);

            if (notificationThread)
            {
                CloseHandle(notificationThread);
                NFSMWAP::Log("In-game notification overlay initialization started.");
            }
            else
            {
                NFSMWAP::Log("ERROR: Failed to launch notification overlay thread.");
            }
        }

        if (NFSMWAP::InstallEventDiscoveryHook())
        {
            HANDLE discoveryThread = CreateThread(
                nullptr,
                0,
                NFSMWAP::EventDiscoveryThread,
                nullptr,
                0,
                nullptr);

            if (discoveryThread)
            {
                CloseHandle(discoveryThread);
                NFSMWAP::Log("Career EventID discovery thread launched.");
            }
            else
            {
                NFSMWAP::Log(
                    "ERROR: Failed to launch Career EventID discovery thread.");
            }
        }


        HANDLE careerEventThread = CreateThread(
            nullptr,
            0,
            NFSMWAP::CareerEventMonitorThread,
            nullptr,
            0,
            nullptr);

        if (careerEventThread)
        {
            CloseHandle(careerEventThread);
            NFSMWAP::Log(
                "Career rank-aware milestone location monitor preparation started.");
        }
        else
        {
            NFSMWAP::Log(
                "ERROR: Failed to launch Career event listener preparation.");
        }

        NFSMWAP::Log(
            "AP runtime hooks initialized. Race detection, Career EventID discovery, persistent D3D9 notifications, and global career-event broadcast monitoring are enabled.");

        HANDLE storeThread = CreateThread(nullptr, 0, NFSMWAP::StoreRuntimeThread, nullptr, 0, nullptr);
        if (storeThread) CloseHandle(storeThread);
        else NFSMWAP::Log("ERROR: Failed to launch AP Store runtime thread.");

        HANDLE monitorThread = CreateThread(
            nullptr,
            0,
            NFSMWAP::RaceMonitorThread,
            nullptr,
            0,
            nullptr);

        if (monitorThread)
        {
            CloseHandle(monitorThread);
            NFSMWAP::Log("Race monitor thread launched.");
        }
        else
        {
            NFSMWAP::Log("ERROR: Failed to launch race monitor thread.");
        }

        return 0;
    }
}

BOOL APIENTRY DllMain(
    HMODULE module,
    DWORD reason,
    LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH)
    {
        DisableThreadLibraryCalls(module);


        const bool isolated=NFSMWAP::PrimeSaveIsolationEarly();
        char required[8]={};
        if(!isolated&&GetEnvironmentVariableA("NFSMW_AP_ISOLATION_VERSION",required,sizeof(required))) {

            TerminateProcess(GetCurrentProcess(),ERROR_ACCESS_DENIED);
            return FALSE;
        }

        HANDLE thread = CreateThread(
            nullptr,
            0,
            NFSMWArchipelagoThread,
            nullptr,
            0,
            nullptr);

        if (thread)
            CloseHandle(thread);
    }

    return TRUE;
}
