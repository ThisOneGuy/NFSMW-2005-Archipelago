
from pathlib import Path
import argparse
import hashlib
import json
import shutil

ROOT=Path(__file__).resolve().parents[1]

def stage(destination,core_scripts=None):
    destination=Path(destination);destination.mkdir(parents=True,exist_ok=True)
    data=destination/'NFSMWClient_Data';data.mkdir(exist_ok=True)
    source=ROOT/'NFSMWClient_Data'
    shutil.copy2(ROOT/'NFSMWClient.pyw',destination/'NFSMWClient.pyw')
    shutil.copy2(ROOT/'NFSMW_Install.pyw',destination/'NFSMW_Install.pyw')
    shutil.copy2(source/'app.zip',data/'app.zip')
    shutil.copytree(source/'assets',data/'assets',dirs_exist_ok=True)
    licenses=data/'licenses';licenses.mkdir(exist_ok=True)
    shutil.copy2(ROOT/'LICENSE-Archipelago.txt',licenses/'LICENSE-Archipelago.txt')
    notice=source/'licenses/PYTHON-NOTICES.txt'
    if notice.is_file():shutil.copy2(notice,licenses/notice.name)
    files={}
    selected=[data/'app.zip',licenses/'LICENSE-Archipelago.txt']
    if notice.is_file():selected.append(licenses/notice.name)
    selected+=[data/p.relative_to(source) for p in sorted((source/'assets').rglob('*')) if p.is_file()]
    for p in selected:
        content=p.read_bytes();files[p.relative_to(data).as_posix()]={'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()}
    manifest={'format':1,'client_build':'1.0.0','native_build':'1.0.0','mode':'pythonw','files':files,
              'entrypoint':'NFSMWClient.pyw','entrypoint_sha256':hashlib.sha256((destination/'NFSMWClient.pyw').read_bytes()).hexdigest()}
    if core_scripts:
        scripts=destination/'scripts';scripts.mkdir(exist_ok=True)
        for name in ('NFSMWArchipelago.asi','NFSMWArchipelago.tpk','NFSMW_TurboTrap.wav','NFSMW_FlashBangTrap.wav','NFSMW_TruckTrap.wav'):
            shutil.copy2(Path(core_scripts)/name,scripts/name)
        manifest['core_files']={name:{'bytes':(scripts/name).stat().st_size,
            'sha256':hashlib.sha256((scripts/name).read_bytes()).hexdigest()} for name in
            ('NFSMWArchipelago.asi','NFSMWArchipelago.tpk','NFSMW_TurboTrap.wav','NFSMW_FlashBangTrap.wav','NFSMW_TruckTrap.wav')}
    (data/'bundle.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return destination

if __name__=='__main__':
    parser=argparse.ArgumentParser(description='Stage the ordinary Python variant without a custom EXE or private runtime.');parser.add_argument('destination',type=Path)
    parser.add_argument('--core-scripts',type=Path)
    args=parser.parse_args();print(stage(args.destination,args.core_scripts))
