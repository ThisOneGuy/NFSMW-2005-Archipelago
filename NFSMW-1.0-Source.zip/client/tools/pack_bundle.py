
from pathlib import Path
import hashlib
import json
import zipfile

root=Path(__file__).resolve().parents[1];data=root/'NFSMWClient_Data'
with zipfile.ZipFile(data/'app.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for base in (root/'source',root/'framework'):
        for p in sorted(base.rglob('*.py')):
            if '__pycache__' not in p.parts:archive.write(p,p.relative_to(base).as_posix())
files={}
for p in sorted(data.rglob('*')):
    if not p.is_file() or p.name=='bundle.json' or 'user' in p.relative_to(data).parts:continue
    content=p.read_bytes()
    files[p.relative_to(data).as_posix()]={'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()}
manifest={'format':1,'client_build':'1.0.0','native_build':'1.0.0','files':files}
if (root/'NFSMWClient.exe').is_file():
    manifest.update(runtime='CPython 3.13.17 x64',executable_sha256=hashlib.sha256((root/'NFSMWClient.exe').read_bytes()).hexdigest())
else:manifest.update(mode='pythonw',runtime='Installed Windows x64 Python 3.11-3.13')
(data/'bundle.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(f'Bundled {len(files)} private files, {sum(v["bytes"] for v in files.values()):,} bytes')
