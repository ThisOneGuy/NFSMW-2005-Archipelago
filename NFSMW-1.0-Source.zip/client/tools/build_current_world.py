
from pathlib import Path
import argparse
import runpy
import shutil

root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description='Build the combined nfsmw.apworld and place it in the private installer payload.')
parser.add_argument('world_source',type=Path,help='Folder containing build.py and nfsmw/')
args=parser.parse_args()
shutil.copy2(root/'source/NFSMW_HintSearch.py',args.world_source/'nfsmw/client_view/hint_search.py')
shutil.copy2(root/'source/NFSMW_ViewResults.py',args.world_source/'nfsmw/client_view/results.py')
runpy.run_path(str(args.world_source/'build.py'),run_name='__main__')
target=root/'NFSMWClient_Data/launcher';target.mkdir(parents=True,exist_ok=True)
shutil.copy2(args.world_source/'nfsmw.apworld',target/'nfsmw.apworld')
