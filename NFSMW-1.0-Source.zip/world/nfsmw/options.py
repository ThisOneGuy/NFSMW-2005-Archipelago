from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

from Options import Choice, DefaultOnToggle, FreeText, PerGameCommonOptions, Range


class StartingCar(Choice):
    __doc__ = 'Choose the pool for the guaranteed first dealership car. It is purchased, not granted at start.\n\n    `random` in the YAML is intentionally treated as the NFSMW-specific\n    "randomize from all customizable cars" mode. Archipelago itself reserves\n    the literal option name `random`, so we register this mode internally as\n    `randomized` and translate YAML `random` to it here.\n    '
    display_name = "Guaranteed Dealership Car"

    option_randomized = 0
    option_vanilla_starter_pool = 1
    default = 0

    @classmethod
    def from_text(cls, text: str):
        if text.lower() == "random":
            return cls(cls.option_randomized)
        return super().from_text(text)


class RandomizeBlacklistCars(DefaultOnToggle):
    __doc__ = 'Randomize the vehicle driven by each of the 15 Blacklist racers.'
    display_name = "Randomize Blacklist Cars"


class RandomizeOpponentCars(DefaultOnToggle):
    __doc__ = 'Randomize normal AI opponent vehicles.'
    display_name = "Randomize Opponent Cars"


class ShopPriceMultiplier(Range):
    __doc__ = 'Multiplier for AP shop/location prices, expressed as a percentage.'
    display_name = "Shop Price Multiplier"
    range_start = 25
    range_end = 500
    default = 100


class IncomingItemPriceMultiplier(Range):
    __doc__ = 'Multiplier for received NFSMW items that must be purchased before use.'
    display_name = "Incoming Item Price Multiplier"
    range_start = 0
    range_end = 500
    default = 100


class BountyMode(Choice):
    __doc__ = 'Choose the bounty required to challenge Blacklist rivals: original, multiplied, or removed. Race and milestone requirements still apply.'
    display_name = "Bounty Requirements"
    option_original = 0
    option_multiplied = 1
    option_removed = 2
    alias_no_bounty_requirement = 2
    default = 0


class BountyMultiplier(FreeText):
    __doc__ = 'Multiply Blacklist bounty requirements by this amount when bounty_mode is multiplied. Enter 0.01 to 100, with up to two decimal places; 2 doubles the requirement and 0.5 halves it.'
    display_name = "Bounty Requirement Multiplier"
    default = "1"

    def __init__(self,value):
        try:amount=Decimal(str(value))
        except (InvalidOperation,ValueError):raise ValueError('Bounty multiplier must be a number from 0.01 to 100.') from None
        if not amount.is_finite() or not Decimal('0.01')<=amount<=Decimal('100'):
            raise ValueError('Bounty multiplier must be a number from 0.01 to 100.')
        if amount*100!=(amount*100).to_integral_value():
            raise ValueError('Bounty multiplier supports up to two decimal places.')
        super().__init__(format(amount.normalize(),'f'))


class DeathLink(DefaultOnToggle):
    __doc__ = 'Enable DeathLink. A natural police bust can send a DeathLink.'
    display_name = "DeathLink"


class DeathLinkPenalty(Choice):
    __doc__ = 'Incoming DeathLink starts a pursuit at the current Career heat cap. Older names remain YAML-compatible.'
    display_name = "DeathLink Penalty"

    option_money = 0
    option_impound = 1
    option_money_and_impound = 2
    option_pursuit = 3
    default = 3


class DeathLinkMoneyPenalty(Range):
    __doc__ = 'Legacy YAML compatibility value; the current client applies the requested pursuit effect.'
    display_name = "DeathLink Money Penalty"
    range_start = 0
    range_end = 1_000_000
    default = 10_000


class TrapPercentage(Range):
    __doc__ = 'Percentage of cash filler replaced with Turbo, Brake, Flash Bang, Truck and Speedbreaker Traps. Does not replace cars or parts.\n\n    Traps wait for live driving and pause in menus. Turbo boosts to 350 mph\n    from seconds 2 to 17 of its clip; Brake forces a three-second stop.\n    Speedbreaker empties the meter once; normal recharge remains available.\n    Truck plays its clip, then launches a semi at the spoken truck cue.\n    Flash Bang whites out the screen at one second into its 6.316-second clip,\n    fading back during the last half-second.\n    '
    display_name = "Trap Percentage"
    range_start = 0
    range_end = 100
    default = 20


@dataclass
class NFSMWOptions(PerGameCommonOptions):
    starting_car: StartingCar
    randomize_blacklist_cars: RandomizeBlacklistCars
    randomize_opponent_cars: RandomizeOpponentCars
    shop_price_multiplier: ShopPriceMultiplier
    incoming_item_price_multiplier: IncomingItemPriceMultiplier
    bounty_mode: BountyMode
    bounty_multiplier: BountyMultiplier
    death_link: DeathLink
    death_link_penalty: DeathLinkPenalty
    death_link_money_penalty: DeathLinkMoneyPenalty
    trap_percentage: TrapPercentage
