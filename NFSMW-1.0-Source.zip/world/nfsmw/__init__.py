from typing import Any, Dict

from BaseClasses import Item, ItemClassification, Location, Region
from worlds.AutoWorld import World

from .cars import CUSTOMIZABLE_CARS
from .items import ITEM_TABLE, FILLER_ITEMS, TRAP_ITEMS
from .locations import LOCATION_TABLE
from .options import NFSMWOptions
from .webworld import NFSMWWebWorld

from .client_view.registration import register as _register_client
_register_client()



class NFSMWItem(Item):
    game = "Need for Speed: Most Wanted"


class NFSMWLocation(Location):
    game = "Need for Speed: Most Wanted"


CLASSIFICATION_MAP = {
    "progression": ItemClassification.progression,
    "useful": ItemClassification.useful,
    "filler": ItemClassification.filler,
    "trap": ItemClassification.trap,
}


class NFSMWWorld(World):
    game = "Need for Speed: Most Wanted"
    web = NFSMWWebWorld()

    options_dataclass = NFSMWOptions
    options: NFSMWOptions

    item_name_to_id = {name: data["id"] for name, data in ITEM_TABLE.items()}
    location_name_to_id = {name: data["id"] for name, data in LOCATION_TABLE.items()}

    item_name_groups = {
        "Cars": {
            name for name, data in ITEM_TABLE.items()
            if data["type"] == "car"
        },
        "Performance Parts": {
            name for name, data in ITEM_TABLE.items()
            if data["type"] == "performance_part"
        },
        "Cash": set(FILLER_ITEMS),
        "Traps": set(TRAP_ITEMS),
    }

    
    generated_starting_car: str
    generated_blacklist_cars: Dict[int, str]
    generated_opponent_seed: int

    def generate_early(self) -> None:
        if self.options.starting_car.value == 1:
            starter_pool = [
                "Fiat Punto",
                "Chevrolet Cobalt SS",
                "Lexus IS 300",
                "Volkswagen Golf GTI",
            ]
            self.generated_first_car = self.random.choice(starter_pool)
        else:
            self.generated_first_car = self.random.choice(CUSTOMIZABLE_CARS)

        self.generated_starting_car = ""  
        self.first_car_location = "Dealership - Aston Martin DB9"

        if self.options.randomize_blacklist_cars:
            chosen = self.random.sample(CUSTOMIZABLE_CARS, 15)
        else:
            
            
            
            chosen = CUSTOMIZABLE_CARS[:15]

        self.generated_blacklist_cars = {
            rank: car for rank, car in zip(range(15, 0, -1), chosen)
        }
        self.generated_opponent_seed = self.random.randrange(0, 2**31)

    def create_regions(self) -> None:
        menu = Region("Menu", self.player, self.multiworld)
        rockport = Region("Rockport Career", self.player, self.multiworld)
        dealership = Region("AP Dealership", self.player, self.multiworld)
        performance = Region("AP Performance Shop", self.player, self.multiworld)

        self.multiworld.regions += [menu, rockport, dealership, performance]

        menu.connect(rockport)
        menu.connect(dealership)
        menu.connect(performance)

        for name, data in LOCATION_TABLE.items():
            if data["type"] == "dealership":
                region = dealership
            elif data["type"] == "performance_shop":
                region = performance
            else:
                region = rockport

            region.locations.append(
                NFSMWLocation(self.player, name, data["id"], region)
            )

    def create_item(self, name: str) -> NFSMWItem:
        data = ITEM_TABLE[name]
        return NFSMWItem(
            name,
            CLASSIFICATION_MAP[data["classification"]],
            data["id"],
            self.player,
        )

    def create_items(self) -> None:
        core_names = [
            name for name, data in ITEM_TABLE.items()
            if data["type"] not in {"cash", "trap"}
        ]

        
        
        first = self.multiworld.get_location(self.first_car_location, self.player)
        first.place_locked_item(self.create_item(self.generated_first_car))
        core_names.remove(self.generated_first_car)
        total_locations = len(LOCATION_TABLE) - 1
        if len(core_names) > total_locations:
            raise Exception(
                f"NFSMW has {len(core_names)} core items but only "
                f"{total_locations} locations."
            )

        pool = [self.create_item(name) for name in core_names]
        filler_names = tuple(FILLER_ITEMS)

        trap_count = (total_locations - len(pool)) * self.options.trap_percentage.value // 100
        pool.extend(self.create_item(self.random.choice(self.enabled_trap_items())) for _ in range(trap_count))

        while len(pool) < total_locations:
            pool.append(self.create_item(self.random.choice(filler_names)))

        self.multiworld.itempool += pool

    def enabled_trap_items(self):
        return TRAP_ITEMS

    def get_filler_item_name(self) -> str:
        if self.random.randrange(100) < self.options.trap_percentage.value:
            return self.random.choice(self.enabled_trap_items())
        return self.random.choice(tuple(FILLER_ITEMS))

    def set_rules(self) -> None:
        
        
        
        player = self.player
        cars = tuple(CUSTOMIZABLE_CARS)
        for name, data in LOCATION_TABLE.items():
            if data["type"] != "dealership":
                self.multiworld.get_location(name, player).access_rule = (
                    lambda state, p=player, names=cars: state.has_any(names, p)
                )
        self.multiworld.get_location(self.first_car_location, player).access_rule = lambda state: True
        self.set_completion_rules()

    def set_completion_rules(self) -> None:
        
        
        
        names = tuple(name for name, data in LOCATION_TABLE.items() if data["type"] == "blacklist_defeat")
        assert len(names) == 15
        self.multiworld.completion_condition[self.player] = lambda state: all(
            state.can_reach(name, "Location", self.player) for name in names
        )

    def fill_slot_data(self) -> Dict[str, Any]:
        return {
            "schema_version": 3,
            "bounty_mode": self.options.bounty_mode.current_key,
            "bounty_multiplier": float(self.options.bounty_multiplier.value),
            "trap_percentage": self.options.trap_percentage.value,
            "turbo_trap_boost_start_ms": 2000,
            "turbo_trap_end_ms": 17000,
            "brake_trap_duration_ms": 3000,
            "flash_bang_start_ms": 1000,
            "flash_bang_end_ms": 6316,
            "flash_bang_fade_ms": 500,
            "truck_trap_cue_ms": 5000,
            "truck_trap_end_ms": 6316,
            "goal": "defeat_all_blacklist",
            "required_blacklist_ranks": list(range(1, 16)),
            "release_checks_on_goal": True,
            "dealership_first_start": True,
            "first_car_purchase_in_store": True,
            "first_car_location_id": LOCATION_TABLE[self.first_car_location]["id"],
            "first_car_item_id": ITEM_TABLE[self.generated_first_car]["id"],
            "first_car": self.generated_first_car,
            "first_car_price": 0,
            "starting_car": self.generated_starting_car,
            "blacklist_cars": self.generated_blacklist_cars,
            "randomize_opponent_cars": bool(self.options.randomize_opponent_cars.value),
            "opponent_car_seed": self.generated_opponent_seed,
            "randomize_blacklist_appearance": True,
            "blacklist_appearance_seed": self.generated_opponent_seed,
            "shop_price_multiplier": self.options.shop_price_multiplier.value / 100.0,
            "incoming_item_price_multiplier":
                self.options.incoming_item_price_multiplier.value / 100.0,
            "death_link": bool(self.options.death_link.value),
            "death_link_penalty": self.options.death_link_penalty.current_key,
            "death_link_money_penalty": self.options.death_link_money_penalty.value,
            "location_count": len(LOCATION_TABLE),
        }
